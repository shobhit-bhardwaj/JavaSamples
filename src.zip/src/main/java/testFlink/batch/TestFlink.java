package testFlink.batch;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.aggregation.Aggregations;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;
import org.apache.flink.api.java.utils.ParameterTool;

public class TestFlink {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment environment = ExecutionEnvironment.getExecutionEnvironment();
        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        environment.getConfig().setGlobalJobParameters(parameterTool);

        DataSet<String> source = environment.readTextFile("C:\\Users\\bharsob\\abc.txt");

        DataSet<Tuple2<String, Integer>> dataSet = source
                .flatMap((input, output) -> {
                    String[] tokens = input.split(" ");
                    for (String token : tokens)
                        output.collect(new Tuple2<>(token, 1));
                })
                .returns(new TupleTypeInfo(TypeInformation.of(String.class), TypeInformation.of(Integer.class)))
                .filter(new FilterFunction<Tuple2<String, Integer>>() {
                    @Override
                    public boolean filter(Tuple2<String, Integer> input) throws Exception {
                        return !"CCC".equals(input.f0);
                    }
                })
                .groupBy(0)
                .aggregate(Aggregations.SUM, 1);

        dataSet.print();
    }
}