package testFlink.batch;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.tuple.Tuple1;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.util.Collector;

public class StringToBean {
    static class Person {
        private String name;
        private int age;

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        @Override
        public String toString() {
            return "Person{" +
                    "name='" + name + '\'' +
                    ", age=" + age +
                    '}';
        }
    }
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment environment = ExecutionEnvironment.getExecutionEnvironment();
        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        environment.getConfig().setGlobalJobParameters(parameterTool);

        DataSet<String> dataSet = environment.readTextFile("C:\\Users\\bharsob\\person.txt");

        DataSet<Tuple1<Person>> personSet = dataSet.flatMap(new FlatMapFunction<String, Tuple1<Person>>() {
            @Override
            public void flatMap(String input, Collector<Tuple1<Person>> collector) throws Exception {
                String[] tokens = input.split(" ");
                collector.collect(new Tuple1<>(new Person(tokens[0], Integer.parseInt(tokens[1]))));
            }
        });

        DataSet<Tuple1<Person>> filterSet = personSet.filter(new FilterFunction<Tuple1<Person>>() {
            @Override
            public boolean filter(Tuple1<Person> person) throws Exception {
                return ((person.f0.getName().toLowerCase().startsWith("a")) || (person.f0.getName().toLowerCase().startsWith("s")));
            }
        });

        filterSet.print();
    }
}