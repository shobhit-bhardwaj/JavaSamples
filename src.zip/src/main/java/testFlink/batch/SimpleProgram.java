package testFlink.batch;

import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.utils.ParameterTool;

public class SimpleProgram {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment environment = ExecutionEnvironment.getExecutionEnvironment();
        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        environment.getConfig().setGlobalJobParameters(parameterTool);

        DataSet<String> dataSet = environment.readTextFile("C:\\Users\\bharsob\\abc.txt");
        dataSet.map(String :: toLowerCase).print();
    }
}