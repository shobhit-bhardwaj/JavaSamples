package testFlink.stream;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

public class WordCount {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment environment = StreamExecutionEnvironment.getExecutionEnvironment();
        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        environment.getConfig().setGlobalJobParameters(parameterTool);

        DataStream<String> dataStream = environment.readTextFile("C:\\Users\\bharsob\\abc.txt");

        DataStream<Tuple2<String, Integer>> mapStream = dataStream
                .flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public void flatMap(String input, Collector<Tuple2<String, Integer>> collector) throws Exception {
                        String[] tokens = input.split(" ");
                        for(String token : tokens)
                            collector.collect(new Tuple2<>(token, 1));
                    }
                });

        DataStream<Tuple2<String, Integer>> resultStream =  mapStream
                .keyBy(0)
                .sum(1);

        resultStream.print();

        environment.execute();
    }
}