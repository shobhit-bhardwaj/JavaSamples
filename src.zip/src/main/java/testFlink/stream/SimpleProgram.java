package testFlink.stream;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class SimpleProgram {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment environment = StreamExecutionEnvironment.getExecutionEnvironment();
        ParameterTool parameterTool = ParameterTool.fromArgs(args);
        environment.getConfig().setGlobalJobParameters(parameterTool);

        DataStream<String> dataStream = environment.readTextFile("C:\\Users\\bharsob\\abc.txt");
        dataStream.map(String :: toLowerCase).print();

        environment.execute("Executing Simple Program");
    }
}