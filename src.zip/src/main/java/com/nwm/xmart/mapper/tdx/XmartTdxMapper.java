package com.nwm.xmart.mapper.tdx;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.tdx.XmartTdxEventSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.tdx.event.TDXSourceEvent;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by aslammh on 07/08/17.
 */
public class XmartTdxMapper extends XmartMapper<TDXSourceEvent> {

    private static final long serialVersionUID = -3815025350133699262L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTdxMapper.class);

    protected MappingNode mappingHierarchy;

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public void open(Configuration config) throws XmartException {

        super.open(config);

        mappingHierarchy = MappingNodeFactory.ReadResourceFile(parameters.get("operator.mapper.config.file"));
    }

    public XmartGenericSet map(TDXSourceEvent tdxSourceEvent) throws Exception {
        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        XmartGenericSet xmartSet = new XmartTdxEventSet();

        if (logger.isDebugEnabled()) {
            logger.debug("Mapping TDX event {}, {}", tdxSourceEvent.getDataSetId(),
                    tdxSourceEvent.getEventSequenceId());
        }

        xmartSet.addStreamEvent(tdxSourceEvent, jobId, mappingHierarchy);

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }

        return xmartSet;
    }
}
