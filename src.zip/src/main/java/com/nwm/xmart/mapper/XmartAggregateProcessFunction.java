package com.nwm.xmart.mapper;

import com.nwm.xmart.core.XmartSet;
import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.checkpoint.ListCheckpointed;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;
import static java.util.Objects.isNull;

/**
 * {@link ProcessFunction} implementation for accumulation of {@link com.nwm.xmart.core.XmartSet} objects. <br> Objects are received
 * and are accumulated in the {@link Collector} during the call to
 * {@link XmartAggregateProcessFunction#processElement(Object, Context, Collector)} (XmartODCSet, Context, Collector)}
 * <br><p>Depends on the configuration for the windowing is enabled or not</p>
 *
 * @author heskets.
 */

public abstract class XmartAggregateProcessFunction<I extends XmartSet> extends ProcessFunction<I, List<I>>
        implements ListCheckpointed {

    private static final Logger logger = LoggerFactory.getLogger(XmartAggregateProcessFunction.class);
    private List<I> accumulatorSet;
    private ParameterTool parameters;
    private Boolean accumulatorsOn = false;
    private Long startTime;
    private IntCounter recordsProcessed = new IntCounter();
    private IntCounter windowsProcessed = new IntCounter();
    private AverageAccumulator avgRecordProcessTime = new AverageAccumulator();
    private int windowCount, maxWindowCount, maxWindowTime;

    @Override
    public void open(Configuration config) throws Exception {
        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        windowCount = 0;
        maxWindowCount = parameters.getInt("operator.aggregate.window.max.count");
        maxWindowTime = parameters.getInt("operator.aggregate.window.max.period.ms");
        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);

        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("aggregateRecordsProcessed", this.recordsProcessed);
            getRuntimeContext().addAccumulator("aggregateWindowsProcessed", this.windowsProcessed);
            getRuntimeContext().addAccumulator("aggregateAvgRecordProcessTime", this.avgRecordProcessTime);
        }

        if (isNull(accumulatorSet)) {
            accumulatorSet = new ArrayList<>();
        }
    }

    @Override
    public void onTimer(long timestamp, OnTimerContext ctx, Collector<List<I>> out) throws Exception {
        if (windowCount > 0) {
            if (accumulatorsOn) {
                this.recordsProcessed.add(accumulatorSet.size());
                this.windowsProcessed.add(1);
            }
            accumulateElements(out);
            windowCount = 0;
        }
    }

    protected void accumulateElements(Collector<List<I>> out) throws Exception {
        putJobNameInMDC(parameters);

        if (getLogger().isDebugEnabled()) {
            getLogger().debug("collecting records from windows list with {} elements", accumulatorSet.size());
        }

        out.collect(accumulatorSet);

        accumulatorSet.clear();
    }

    @Override
    public List snapshotState(long l, long l1) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("Taking snapshot of windows list with {} elements", accumulatorSet.size());
        }
        return accumulatorSet;
    }

    @Override
    public void restoreState(List list) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("Restoring from snapshot of windows list with {} elements", list.size());
        }
        accumulatorSet = list;
    }

    public Boolean getAccumulatorsOn() {
        return accumulatorsOn;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public int getWindowCount() {
        return windowCount;
    }

    public void setWindowCount(int windowCount) {
        this.windowCount = windowCount;
    }

    public List<I> getAccumulatorSet() {
        return accumulatorSet;
    }

    public int getMaxWindowCount() {
        return maxWindowCount;
    }

    public int getMaxWindowTime() {
        return maxWindowTime;
    }

    public ParameterTool getParameters() {
        return parameters;
    }

    public IntCounter getRecordsProcessed() {
        return recordsProcessed;
    }

    public void setRecordsProcessed(IntCounter recordsProcessed) {
        this.recordsProcessed = recordsProcessed;
    }

    public IntCounter getWindowsProcessed() {
        return windowsProcessed;
    }

    public AverageAccumulator getAvgRecordProcessTime() {
        return avgRecordProcessTime;
    }

    protected abstract Logger getLogger();
}

