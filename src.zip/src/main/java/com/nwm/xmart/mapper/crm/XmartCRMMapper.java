package com.nwm.xmart.mapper.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.crm.XmartCRMSourceEventSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class XmartCRMMapper extends XmartMapper<CRMSourceEvent> {
    private static final long serialVersionUID = -3815025350133699262L;
    private static final Logger logger = LoggerFactory.getLogger(XmartCRMMapper.class);

    protected MappingNode mappingHierarchy;

    private Map<String, Integer> topicMap = new HashMap<>();

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        super.open(config);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        topicMap.put("AccountCoverage", getParameters().getInt("flink.kafka.consumer.account.coverage.topic.ID", 0));
        topicMap.put("CallLog", getParameters().getInt("flink.kafka.consumer.call.log.topic.ID", 0));
        topicMap.put("CallReport", getParameters().getInt("flink.kafka.consumer.call.report.topic.ID", 0));
        topicMap.put("Contact", getParameters().getInt("flink.kafka.consumer.contact.topic.ID", 0));
        topicMap.put("ContactCoverage", getParameters().getInt("flink.kafka.consumer.contact.coverage.topic.ID", 0));
        topicMap.put("Organization", getParameters().getInt("flink.kafka.consumer.organization.topic.ID", 0));
        topicMap.put("User", getParameters().getInt("flink.kafka.consumer.user.topic.ID", 0));
        topicMap.put("UserRole", getParameters().getInt("flink.kafka.consumer.user.role.topic.ID", 0));
        topicMap.put("Interest", getParameters().getInt("flink.kafka.consumer.interest.topic.ID", 0));
        topicMap.put("AccountDesk", getParameters().getInt("flink.kafka.consumer.account.desk.topic.ID", 0));
    }

    public XmartGenericSet map(CRMSourceEvent event) throws Exception {
        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        XmartGenericSet eventSet = new XmartCRMSourceEventSet();

        eventSet.addStreamEvent(event, topicMap.get(event.getCrmSourceEventType().name()), mappingHierarchy);

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }
        return eventSet;
    }
}
