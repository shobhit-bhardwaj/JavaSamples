package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.entities.common.XmartMappedAttribute;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.SourceObjectUtil;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Method;
import java.util.List;

import static com.nwm.xmart.util.BusinessRulesUtil.isKdbNull;

/**
 * <p>
 * Provides an attribute mapping node to pull a single attribute from a source object and add it to an XmartEntity object.
 * </p>
 * <p>
 * This node may contain a set of MdifiedAttributeMappingNode objects each of which will apply a simpled business logic
 * step to produce a modified version of the raw attribute.
 * </p>
 *
 * @author heskets
 */
public class AttributeMappingNode extends MappingNode {

    private Boolean triggerAttribute;
    private Boolean outputAttribute;
    private Boolean keyAttribute;
    private String methodName;
    private String methodReturnType;
    private Method methodReflectionMethod;

    private int methodIndex;
    private String methodAttributeName;
    private String methodAttributeName2;
    private String fixedString;

    /**
     * Standard constructor for core attributes of a mapping node - and the AttributeMappingNode specific configuration
     *
     * @param stringNode an array of strings containing the configuration of the required mapping node
     */
    AttributeMappingNode(String[] stringNode) throws XmartException {

        super(stringNode);

        validateNode(stringNode);

        this.triggerAttribute = stringNode[9].equals("Y");
        this.outputAttribute = stringNode[10].equals("Y");
        this.keyAttribute = stringNode[11].equals("Y");
        this.methodName = stringNode[12];
        this.methodReturnType = stringNode[13];
        if (isIndexedMethod()) {
            this.methodIndex = Integer.parseInt(stringNode[14]);
        }
        if (isMapMethod() || isSingleParameterisedMethod()) {
            this.methodAttributeName = stringNode[14];
        }
        if (isJSONNodeDoubleParameterisedMethod()) {
            this.methodAttributeName = stringNode[14];
            this.methodAttributeName2 = (StringUtils.isNotEmpty(stringNode[15]) ? stringNode[15] : null);
        }
        if (isFixedValue()) {
            this.fixedString = stringNode[14];
        }
    }

    private void validateNode(String[] stringNode) throws XmartException {

        if (stringNode.length < 14) {
            throw new XmartException("Invalid attribute mapping - insufficient number of elements in row");
        }

        if (stringNode[9] == null || stringNode[9].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - triggerAttribute is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!(stringNode[9].equals("Y") || stringNode[9].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - triggerAttribute flag in mapping nodes not a valid value - element: "
                            + stringNode[4] + " " + stringNode[5] + " - " + stringNode[9]);
        }

        if (stringNode[10] == null || stringNode[10].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - outputAttribute is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!(stringNode[10].equals("Y") || stringNode[10].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - outputAttribute flag in mapping nodes not a valid value - element: "
                            + stringNode[4] + " " + stringNode[5] + " - " + stringNode[10]);
        }

        if (stringNode[11] == null || stringNode[11].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - keyAttribute is not populated in mapping nodes - element: " + stringNode[4] + " "
                            + stringNode[5]);
        }

        if (!(stringNode[11].equals("Y") || stringNode[11].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - keyAttribute flag in mapping nodes not a valid value - element: " + stringNode[4]
                            + " " + stringNode[5] + " - " + stringNode[11]);
        }

        if (stringNode[12] == null || stringNode[12].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - methodName is not populated in mapping nodes - element: " + stringNode[4] + " "
                            + stringNode[5]);
        }

        if (stringNode[13] == null || stringNode[13].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - methodReturnType is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (stringNode[12].equals("getIndexedValue")) {

            if (stringNode.length < 15) {
                throw new XmartException("Invalid attribute mapping - insufficient number of elements in row");
            }

            if (stringNode[14] == null || stringNode[14].isEmpty()) {
                throw new XmartException(
                        "Invalid mapping - methodIndex is not populated in mapping nodes - element: " + stringNode[4]
                                + " " + stringNode[5]);
            }
        }

        if (stringNode[12].equals("getMapValue")) {

            if (stringNode.length < 15) {
                throw new XmartException("Invalid attribute mapping - insufficient number of elements in row");
            }

            if (stringNode[14] == null || stringNode[14].isEmpty()) {
                throw new XmartException(
                        "Invalid mapping - attributeName is not populated in mapping nodes - element: " + stringNode[4]
                                + " " + stringNode[5]);
            }
        }

        if (stringNode[12].equals("setFixedValue")) {

            if (stringNode.length < 15) {
                throw new XmartException("Invalid attribute mapping - insufficient number of elements in row");
            }

            if (stringNode[14] == null || stringNode[14].isEmpty()) {
                throw new XmartException(
                        "Invalid mapping - attributeValue is not populated in mapping nodes - element: " + stringNode[4]
                                + " " + stringNode[5]);
            }
        }
    }

    private Boolean isTriggerAttribute() {
        return triggerAttribute;
    }

    private Boolean isIndexedMethod() {
        return getMethodName() != null && getMethodName().equals("getIndexedValue");
    }

    private Boolean isMapMethod() {
        return getMethodName() != null && getMethodName().equals("getMapValue");
    }

    private Boolean isSingleParameterisedMethod() {
        return getMethodName() != null && (getMethodName().equals("getNodeStringValueAt") || getMethodName()
                .equals("getNodeLongValueAt") || getMethodName().equals("getNodeBooleanValueAt") || getMethodName()
                .equals("getNodeIntegerValueAt") || getMethodName().equals("getNodeDoubleValueAt") || getMethodName()
                .equals("getNodeFloatValueAt") || getMethodName().equals("getNodeShortValueAt") || getMethodName()
                .equals("getDefaultStringValue") || getMethodName().equals("getAttributeValue") || getMethodName()
                .equals("getDoubleAttributeValue") || getMethodName().equals("getIntegerAttributeValue")
                || getMethodName().equals("getDateAttributeValue") || getMethodName().equals("getTextValueNode")
                || getMethodName().equals("getDoubleValueNode") || getMethodName().equals("getIntegerValueNode")
                || getMethodName().equals("getDateValueNode"));
    }

    private Boolean isJSONNodeDoubleParameterisedMethod() {
        return getMethodName() != null && (getMethodName().equals("getNodeStringValueAtWithDefault") || getMethodName()
                .equals("getDoubleAttributeFromArrayNode"));
    }

    private Boolean isFixedValue() {
        return getMethodName() != null && getMethodName().equals("setFixedValue");
    }

    private Boolean isOutputAttribute() {
        return outputAttribute;
    }

    private Boolean isKeyAttribute() {
        return keyAttribute;
    }

    private String getMethodName() {
        return methodName;
    }

    private String getMethodReturnType() {
        return methodReturnType;
    }

    /**
     * For the specified object pull the attribute held by that object and add a corresponding XmartAttribute
     * to the XMartEnties passed in to the method.
     * <p>
     * Then go through any child AttributeRuleMappingNode objects, applying the rules in these nodes to the
     * raw attribute returned by this node.
     *
     * @param rootObjectName the name of the root object to ensure the correct mapping hierarchy is being applied
     * @param objectToMap    the source object from the source to which the child root mappings are to be applied
     * @param mappedEntities NULL for a top level mapping
     *
     * @return List<XmartMappedEntity> an updated list of XmartMappedEntities produced by applying this mapping
     * hierarchy level to the source object
     */
    @Override
    public List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            List<XmartMappedEntity> mappedEntities) throws XmartException {

        if (objectToMap == null) {
            throw new XmartException("Failure mapping attribute - objectToMap is null - element: " + getElementId() + ""
                    + getElementName());
        }

        if (mappedEntities == null) {
            throw new XmartException(
                    "Failure mapping attribute - mappedEntities is null - element: " + getElementId() + ""
                            + getElementName());
        }

        if (methodReflectionMethod == null && !isFixedValue()) {
            methodReflectionMethod = SourceObjectUtil
                    .getMethod(objectToMap, getMethodName(), getMethodReturnType(), isIndexedMethod(), isMapMethod(),
                            isSingleParameterisedMethod(), isJSONNodeDoubleParameterisedMethod());
        }

        Object attributeObj = null;

        if (isIndexedMethod()) {
            attributeObj = SourceObjectUtil
                    .getIndexedObject(methodReflectionMethod, objectToMap, methodIndex, getMethodReturnType());
        } else if (isMapMethod() || isSingleParameterisedMethod()) {
            attributeObj = SourceObjectUtil
                    .getMappedObject(methodReflectionMethod, objectToMap, methodAttributeName, getMethodReturnType());
        } else if (isJSONNodeDoubleParameterisedMethod()) {
            attributeObj = SourceObjectUtil
                    .getMappedObject(methodReflectionMethod, objectToMap, methodAttributeName, methodAttributeName2,
                            getMethodReturnType());
        } else if (isFixedValue()) {
            attributeObj = fixedString;
        } else {
            attributeObj = SourceObjectUtil.getObject(methodReflectionMethod, objectToMap);
        }

        if (!isKdbNull(attributeObj)) {

            XmartMappedAttribute attribute = new XmartMappedAttribute(getElementName(), attributeObj,
                    isMandatoryElement(), isTriggerAttribute(), isOutputAttribute(), isKeyAttribute());
            mappedEntities.forEach((entity) -> entity.addAttribute(attribute));

            for (MappingNode node : getChildModifiedAttributeNodes()) {
                if (rootObjectName.equals(node.getRootObjectName())) {
                    mappedEntities = node.mapSourceObject(rootObjectName, attributeObj, mappedEntities);
                }
            }
        } else {
            if (isMandatoryElement()) {
                throw new XmartException(
                        "Failure mapping attribute - missing mandatory attribute: " + getElementId() + " "
                                + getElementName());
            }
        }

        return mappedEntities;
    }

    @Override
    public String toString() {
        return "AttributeMappingNode{" + "triggerAttribute=" + triggerAttribute + ", outputAttribute=" + outputAttribute
                + ", keyAttribute=" + keyAttribute + ", methodName='" + methodName + '\'' + ", methodReturnType='"
                + methodReturnType + '\'' + ", methodReflectionMethod=" + methodReflectionMethod + ", methodIndex="
                + methodIndex + ", methodAttributeName='" + methodAttributeName + '\'' + ", fixedString='" + fixedString
                + '\'' + ", elementType='" + elementType + '\'' + ", rootObjectName='" + rootObjectName + '\''
                + ", elementCollection='" + elementCollection + '\'' + ", elementGroup='" + elementGroup + '\''
                + ", elementId=" + elementId + ", elementName='" + elementName + '\'' + ", parentElementId="
                + parentElementId + ", parentElementName='" + parentElementName + '\'' + ", mandatoryElement="
                + mandatoryElement + ", children=" + children + '}';
    }
}
