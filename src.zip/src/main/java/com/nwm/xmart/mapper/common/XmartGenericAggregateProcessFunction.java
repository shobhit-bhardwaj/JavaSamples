package com.nwm.xmart.mapper.common;

import com.nwm.xmart.core.XmartSet;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.checkpoint.ListCheckpointed;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;
import static java.util.Objects.isNull;

/**
 * {@link ProcessFunction} implementation for accumulation of {@link XmartGenericSet} objects. <br> Objects are received
 * and are accumulated in the {@link Collector} during the call to
 * {@link XmartGenericAggregateProcessFunction#processElement(XmartGenericSet, Context, Collector)}
 * <br><p>Depends on the nodes for the windowing is enabled or not</p>
 *
 * @author heskets.
 */
public class XmartGenericAggregateProcessFunction extends ProcessFunction<XmartGenericSet, List<XmartGenericSet>>
        implements ListCheckpointed {

    private static final Logger logger = LoggerFactory.getLogger(XmartGenericAggregateProcessFunction.class);

    private transient List<XmartGenericSet> accumulatedList;

    private ParameterTool parameters;
    private Boolean accumulatorsOn = false;
    private Long startTime;
    private IntCounter recordsProcessed = new IntCounter();
    private IntCounter windowsProcessed = new IntCounter();
    private AverageAccumulator avgRecordProcessTime = new AverageAccumulator();
    private int windowCount, maxWindowCount, maxWindowTime;

    @Override
    public void open(Configuration config) throws Exception {

        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        windowCount = 0;
        maxWindowCount = parameters.getInt("operator.aggregate.window.max.count");
        maxWindowTime = parameters.getInt("operator.aggregate.window.max.period.ms");
        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);

        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("aggregateRecordsProcessed", this.recordsProcessed);
            getRuntimeContext().addAccumulator("aggregateWindowsProcessed", this.windowsProcessed);
            getRuntimeContext().addAccumulator("aggregateAvgRecordProcessTime", this.avgRecordProcessTime);
        }

        if (isNull(accumulatedList)) {
            accumulatedList = new ArrayList<>();
        }
    }

    @Override
    public void processElement(XmartGenericSet xmartSet, Context ctx, Collector<List<XmartGenericSet>> out)
            throws Exception {

        if (accumulatorsOn) {
            startTime = System.nanoTime();
        }

        if (windowCount == 0) {
            // schedule the next timer the specified number of milliseconds from the current process time
            ctx.timerService().registerProcessingTimeTimer(ctx.timerService().currentProcessingTime() + maxWindowTime);
        }

        try {
            if (xmartSet != null) {
                accumulatedList.add(xmartSet);
            } else {
                logger.error("Error - ignored NULL record in window function - failure in previous operator.");
            }
        } catch (Exception e) {
            logger.error("Error aggregating record:", e);
            logger.error("Error aggregating record: window key - ", xmartSet.getWindowKey());
        }

        windowCount++;

        if (windowCount >= maxWindowCount) {

            if (accumulatorsOn) {
                this.recordsProcessed.add(accumulatedList.size());
                this.windowsProcessed.add(1);
            }

            accumulateElements(out);

            windowCount = 0;
        }

        if (accumulatorsOn) {
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }
    }

    @Override
    public void onTimer(long timestamp, OnTimerContext ctx, Collector<List<XmartGenericSet>> out) throws Exception {

        if (windowCount > 0) {

            if (accumulatorsOn) {
                this.recordsProcessed.add(accumulatedList.size());
                this.windowsProcessed.add(1);
            }

            accumulateElements(out);

            windowCount = 0;
        }
    }

    private void accumulateElements(Collector<List<XmartGenericSet>> out) throws Exception {

        putJobNameInMDC(parameters);

        if (logger.isDebugEnabled()) {
            logger.debug("Collecting records from windows list with {} elements", accumulatedList.size());
        }

        logger.debug("Accumulating ");

        out.collect(accumulatedList);

        accumulatedList.clear();
    }

    @Override
    public List snapshotState(long l, long l1) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("Taking snapshot of windows list with {} elements", accumulatedList.size());
        }
        return accumulatedList;
    }

    @Override
    public void restoreState(List list) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("Restoring from snapshot of windows list with {} elements", list.size());
        }
        accumulatedList = list;
    }
}

