package com.nwm.xmart.mapper.kdb;

import com.nwm.xmart.core.XmartSet;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.kdb.XmartKdbEventSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by aslammh on 07/08/17.
 */
public class XmartKdbMapper extends XmartMapper<KDBSourceEvent> {

    private static final long serialVersionUID = -3815025350133699262L;
    private static final Logger logger = LoggerFactory.getLogger(XmartKdbMapper.class);

    protected MappingNode mappingHierarchy;

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        super.open(config);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile(parameters.get("operator.mapper.config.file"));
    }

    @Override
    public XmartGenericSet map(KDBSourceEvent sourceEvent) throws Exception {

        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        XmartGenericSet eventSet = new XmartKdbEventSet();

        eventSet.addStreamEvent(sourceEvent, jobId, mappingHierarchy);

        logger.info("map: Job ID {} KDB Function Name {} Date {} RecordIndex {}", jobId, sourceEvent.getDateTime(),
                sourceEvent.getFunctionName(), sourceEvent.getRecordIndex());

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }

        return eventSet;
    }
}
