package com.nwm.xmart.mapper;

import com.nwm.xmart.entities.XmartTransactionSet;
import com.nwm.xmart.entities.XmartXmlTransactionSet;
import com.nwm.xmart.exception.XmartException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by saprush on 26/10/17.
 */
public class XmartTransactionSetToXMLMapper extends XmartXmlMapper<XmartTransactionSet, XmartXmlTransactionSet> {

    private static final long serialVersionUID = 1678658664160819135L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionSetToXMLMapper.class);

    private Long startTime;

    @Override
    protected Logger logger() {
        return logger;
    }

    @Override
    public XmartXmlTransactionSet map(List<XmartTransactionSet> xmartTransactionSetList) throws XmartException {

        logger.debug("Entering map()");

        XmartXmlTransactionSet xmlTransactionSet = new XmartXmlTransactionSet(logEntityXml);

        if (accumulatorsOn) {
            startTime = System.nanoTime();
        }

        logger.debug("Mapping transactions - {}", xmartTransactionSetList.size());

        for (XmartTransactionSet transactionSet : xmartTransactionSetList) {

            if (transactionSet != null) {
                try {
                    xmlTransactionSet.add(transactionSet);
                } catch (Exception e) {
                    logger.error("Error converting record to XML", e);
                    throw new XmartException("Error converting record to XML", e);
                }
            } else {
                logger.warn("Error - ignored NULL record in XML mapping - failure in previous operator.");
            }
        }

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }

        return xmlTransactionSet;
    }
}
