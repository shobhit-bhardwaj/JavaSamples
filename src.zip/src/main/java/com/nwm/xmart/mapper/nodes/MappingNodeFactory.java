package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.enums.MappingElementTypeEnum;

import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * Provides a static method to generate mapping nodes based on the type of node specified in the configuration
 * string.
 * </p>
 *
 * @author heskets
 */
public class MappingNodeFactory {

    private MappingNodeFactory() throws XmartException {
        // no constructor
    }

    public static MappingNode getMappingNode(String[] stringNode) throws XmartException {

        MappingNode mappingNode;

        validateNode(stringNode);

        switch (MappingElementTypeEnum.valueOf(stringNode[0])) {
        case root:
            mappingNode = new RootMappingNode(stringNode);
            break;
        case attribute:
            mappingNode = new AttributeMappingNode(stringNode);
            break;
        case object:
            mappingNode = new ObjectMappingNode(stringNode);
            break;
        case collection:
            mappingNode = new CollectionMappingNode(stringNode);
            break;
        case attribute_rule:
            mappingNode = new AttributeRuleMappingNode(stringNode);
            break;
        case business_rule:
            mappingNode = new BusinessRuleMappingNode(stringNode);
            break;
        default:
            throw new XmartException("Mapping element type not recognised - " + stringNode[0]);
        }

        return mappingNode;
    }

    static MappingNode getTopMappingNode() throws XmartException {

        return new TopMappingNode();
    }

    private static void validateNode(String[] stringNode) throws XmartException {

        if (stringNode == null || stringNode.length < 1) {
            throw new XmartException("Invalid mapping - insufficient number of elements in row");
        }

        if (stringNode[0] == null || stringNode[0].isEmpty()) {
            throw new XmartException("Invalid mapping - elementType is not populated in mapping nodes.");
        }

        if (!MappingElementTypeEnum.contains(stringNode[0])) {
            throw new XmartException("Invalid mapping - elementType (" + stringNode[0] + ") is not a recognised type.");
        }
    }

    public static MappingNode ReadResourceFile(String resourceName) throws XmartException {

        MappingNode mappingHierarchy = getTopMappingNode();

        InputStream resourceInputStream = CsvUtil.class.getResourceAsStream(resourceName);

        if (resourceInputStream == null) {
            throw new XmartException("Resource not found - " + resourceName);
        }

        try (BufferedReader br = new BufferedReader(new InputStreamReader(resourceInputStream))) {

            List<String> lines = br.lines().skip(1).collect(Collectors.toList());

            for (String line : lines) {
                MappingNode childNode = getMappingNode(line.split(",", -1));
                if (!mappingHierarchy.addChildNode(childNode)) {
                    throw new XmartException("Mapping nodes line not added to mapping hierarchy - " + line);
                }
                ;
            }
        } catch (FileNotFoundException e) {

            throw new XmartException("Invalid mapping nodes file", e);
        } catch (IOException e) {

            throw new XmartException("Failure whilst loading mapping nodes file", e);
        }

        return mappingHierarchy;
    }
}
