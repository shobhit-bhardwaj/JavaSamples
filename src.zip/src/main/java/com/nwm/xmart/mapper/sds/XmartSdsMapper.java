package com.nwm.xmart.mapper.sds;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.sds.XmartSdsEventSet;
import com.nwm.xmart.mapper.XmartGenericMapper;
import com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Mapper that uses configurable mappings to map the input objects.
 * Configurable mappings are provided in the parameters.
 */
public class XmartSdsMapper extends XmartGenericMapper<DataFabricWatchEvent> {

    private static final Logger logger = LoggerFactory.getLogger(XmartSdsMapper.class);

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public XmartGenericSet map(DataFabricWatchEvent watchEvent) throws Exception {
        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        XmartGenericSet xmartSet = new XmartSdsEventSet();

        if (logger.isDebugEnabled()) {
            logger.debug("Mapping sds event - offset: {} key: {} version: {}", watchEvent.getOffset(), watchEvent.getDfKey(), watchEvent.getDfVersion());
        }

        xmartSet.addStreamEvent(watchEvent, jobId, mappingHierarchy);

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }

        return xmartSet;
    }
}
