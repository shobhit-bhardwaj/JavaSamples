package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.entities.common.XmartMappedAttribute;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.SourceObjectUtil;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static com.nwm.xmart.util.BusinessRulesUtil.isKdbNull;

/**
 * <p>
 * Provides an object mapping node to pull a single object from a source object and apply the relevant child mappings.
 * </p>
 * <p>
 * This node will contain a set of child mapping node (AttributeMappingNode, ObjectMappingNode and/or
 * CollectionMappingNode) objects that will  provide the next level of mapping for the single object
 * returned.
 * </p>
 *
 * @author heskets
 */
public class BusinessRuleMappingNode extends MappingNode {

    private Boolean triggerAttribute;
    private Boolean outputAttribute;
    private Boolean keyAttribute;
    private String methodName;
    private String methodReturnType;
    private Method methodReflectionMethod;

    /**
     * Standard constructor for core attributes of a mapping node - and the ObjectMappingNode specific
     * configuration.
     *
     * @param stringNode an array of strings containing the configuration of the required mapping node
     */
    BusinessRuleMappingNode(String[] stringNode) throws XmartException {

        super(stringNode);

        validateNode(stringNode);

        this.triggerAttribute = stringNode[9].equals("Y");
        this.outputAttribute = stringNode[10].equals("Y");
        this.keyAttribute = stringNode[11].equals("Y");
        this.methodName = stringNode[12];
        this.methodReturnType = stringNode[13];
    }

    private void validateNode(String[] stringNode) throws XmartException {

        if (stringNode.length < 14) {
            throw new XmartException("Invalid object mapping - insufficient number of elements in row");
        }

        if (stringNode[9] == null || stringNode[9].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - triggerAttribute is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!(stringNode[9].equals("Y") || stringNode[9].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - triggerAttribute flag in mapping nodes not a valid value - element: "
                            + stringNode[4] + " " + stringNode[5] + " - " + stringNode[9]);
        }

        if (stringNode[10] == null || stringNode[10].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - outputAttribute is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!(stringNode[10].equals("Y") || stringNode[10].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - outputAttribute flag in mapping nodes not a valid value - element: "
                            + stringNode[4] + " " + stringNode[5] + " - " + stringNode[10]);
        }

        if (stringNode[11] == null || stringNode[11].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - keyAttribute is not populated in mapping nodes - element: " + stringNode[4] + " "
                            + stringNode[5]);
        }

        if (!(stringNode[11].equals("Y") || stringNode[11].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - keyAttribute flag in mapping nodes not a valid value - element: " + stringNode[4]
                            + " " + stringNode[5] + " - " + stringNode[11]);
        }

        if (stringNode[12] == null || stringNode[12].isEmpty()) {
            throw new XmartException(
                    "Invalid object mapping - methodName is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (stringNode[13] == null || stringNode[13].isEmpty()) {
            throw new XmartException(
                    "Invalid object mapping - methodReturnType is not populated in mapping nodes - element: "
                            + stringNode[4] + " " + stringNode[5]);
        }
    }

    private Boolean isTriggerAttribute() {
        return triggerAttribute;
    }

    private Boolean isOutputAttribute() {
        return outputAttribute;
    }

    private Boolean isKeyAttribute() {
        return keyAttribute;
    }

    private String getMethodName() {
        return methodName;
    }

    private String getMethodReturnType() {
        return methodReturnType;
    }

    /**
     * For the supplied source object pull the sub-object using the method specified in the mapping.
     * Then loop through child mapping nodes as follows:
     * <p>
     * First go through any child attribute mapping nodes, adding the attributes pulled from the source object to
     * each of the input XmartMappedEntities.
     * Second go through any child object mapping nodes, pulling the lower level object and then iterating through
     * the next level of mapping nodes that apply.
     * Third go through any child collection mapping nodes, pulling the lower level object array, expanding the number
     * of XmartMappedEntities by the number of items in the collection and then, for each object in the array,
     * iterating through the next level of mapping nodes that apply.
     *
     * @param rootObjectName        the name of the root object to ensure the correct mapping hierarchy is being applied
     * @param objectToMap           the source object from the source to which the child root mappings are to be applied
     * @param initialMappedEntities NULL for a top level mapping
     *
     * @return List<XmartMappedEntity> an updated list of XmartMappedEntities produced by applying this mapping
     * hierarchy level to the source object
     */
    @Override
    public List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            final List<XmartMappedEntity> initialMappedEntities) throws XmartException {

        if (objectToMap == null) {
            throw new XmartException("Failure mapping object - objectToMap is null - element: " + getElementId() + ""
                    + getElementName());
        }

        List<XmartMappedEntity> returnEntities = new ArrayList<>();

        for (XmartMappedEntity entity : initialMappedEntities) {

            List<XmartMappedEntity> copyInitialMappedEntities = new ArrayList<>();

            copyInitialMappedEntities.add(new XmartMappedEntity(entity));

            Object thisObject = SourceObjectUtil.applyBusinessRule(entity, getMethodName(), getMethodReturnType());

            if (!isKdbNull(thisObject)) {

                XmartMappedAttribute attribute = new XmartMappedAttribute(getElementName(), thisObject,
                        isMandatoryElement(), isTriggerAttribute(), isOutputAttribute(), isKeyAttribute());
                copyInitialMappedEntities.forEach((newEntity) -> newEntity.addAttribute(attribute));

                for (MappingNode node : getChildModifiedAttributeNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }

                for (MappingNode node : getChildAttributeNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }

                for (MappingNode node : getChildObjectNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }

                for (MappingNode node : getChildCollectionNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }

                for (MappingNode node : getChildBusinessRuleNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }
            } else {
                if (isMandatoryElement()) {
                    throw new XmartException(
                            "Failure mapping object - missing mandatory object: " + getElementId() + " "
                                    + getElementName());
                }
            }

            returnEntities.addAll(copyInitialMappedEntities);
        }

        return returnEntities;
    }

    @Override
    public String toString() {
        return "BusinessRuleMappingNode{" + "triggerAttribute=" + triggerAttribute + ", outputAttribute="
                + outputAttribute + ", keyAttribute=" + keyAttribute + ", methodName='" + methodName + '\''
                + ", methodReturnType='" + methodReturnType + '\'' + ", methodReflectionMethod="
                + methodReflectionMethod + ", elementType='" + elementType + '\'' + ", rootObjectName='"
                + rootObjectName + '\'' + ", elementCollection='" + elementCollection + '\'' + ", elementGroup='"
                + elementGroup + '\'' + ", elementId=" + elementId + ", elementName='" + elementName + '\''
                + ", parentElementId=" + parentElementId + ", parentElementName='" + parentElementName + '\''
                + ", mandatoryElement=" + mandatoryElement + ", children=" + children + '}';
    }
}
