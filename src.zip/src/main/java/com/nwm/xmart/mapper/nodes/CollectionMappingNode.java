package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.nwm.xmart.util.SourceObjectUtil;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * <p>
 * Provides a collection mapping node to pull a list of objects from a source object,  expand the number of
 * XMart Entities to be processed by the number of objects in the collection and apply the relevant child mappings.
 * </p>
 * <p>
 * This node will contain a set of child mapping node (AttributeMappingNode, ObjectMappingNode and/or
 * CollectionMappinNode) objects that will  provide the next level of mapping for each object in the collection.
 * </p>
 *
 * @author heskets
 */
public class CollectionMappingNode extends MappingNode {

    private String methodName;
    private String methodReturnType;
    private Method methodReflectionMethod;
    private String methodAttributeName;

    /**
     * Standard constructor for core attributes of a mapping node - and the CollectionMappingNode specific
     * configuration.
     *
     * @param stringNode an array of strings containing the configuration of the required mapping node
     */
    CollectionMappingNode(String[] stringNode) throws XmartException {

        super(stringNode);

        validateNode(stringNode);

        this.methodName = stringNode[12];
        this.methodReturnType = stringNode[13];

        if (isSingleParameterisedMethod()) {
            this.methodAttributeName = stringNode[14];
        }
    }

    private void validateNode(String[] stringNode) throws XmartException {

        if (stringNode.length < 14) {
            throw new XmartException("Invalid collection mapping - insufficient number of elements in row");
        }

        if (stringNode[12] == null || stringNode[12].isEmpty()) {
            throw new XmartException(
                    "Invalid collection mapping - methodName is not populated in mapping nodes - element: "
                            + stringNode[4] + " " + stringNode[5]);
        }

        if (stringNode[13] == null || stringNode[13].isEmpty()) {
            throw new XmartException(
                    "Invalid collection mapping - methodReturnType is not populated in mapping nodes - element: "
                            + stringNode[4] + " " + stringNode[5]);
        }
    }

    private String getMethodName() {
        return methodName;
    }

    private String getMethodReturnType() {
        return methodReturnType;
    }

    /**
     * For the supplied source object pull the sub-collection using the method specified in the mapping.
     * For each object within this collection, take a copy of the incoming XMart Entities containing the progress of
     * the mappings to date and loop through child mapping nodes as follows:
     * <p>
     * First go through any child attribute mapping nodes, adding the attributes pulled from the source object to
     * each of the input XmartMappedEntities.
     * Second go through any child object mapping nodes, pulling the lower level object and then iterating through
     * the next level of mapping nodes that apply.
     * Third go through any child collection mapping nodes, pulling the lower level object array, expanding the number
     * of XmartMappedEntities by the number of items in the collection and then, for each object in the array,
     * iterating through the next level of mapping nodes that apply.
     * <p>
     * Finally merge all the XMart Entity sets generated against each of these collection objects.
     *
     * @param rootObjectName        the name of the root object to ensure the correct mapping hierarchy is being applied
     * @param objectToMap           the source object from the source to which the child root mappings are to be applied
     * @param initialMappedEntities NULL for a top level mapping
     *
     * @return List<XmartMappedEntity> an updated list of XmartMappedEntities produced by applying this mapping
     * hierarchy level to the source object
     */
    @Override
    public List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            final List<XmartMappedEntity> initialMappedEntities) throws XmartException {

        if (objectToMap == null) {
            throw new XmartException(
                    "Failure mapping collection - objectToMap is null - element: " + getElementId() + ""
                            + getElementName());
        }

        if (methodReflectionMethod == null) {
            methodReflectionMethod = SourceObjectUtil
                    .getMethod(objectToMap, getMethodName(), getMethodReturnType(), false, false,
                            isSingleParameterisedMethod(), false);
        }

        //        Collection collection = SourceObjectUtil.getCollection(methodReflectionMethod, objectToMap);

        Collection collection = null;
        if (!isSingleParameterisedMethod()) {
            collection = SourceObjectUtil.getCollection(methodReflectionMethod, objectToMap);
        } else {
            collection = SourceObjectUtil.getJSONCollection(methodReflectionMethod, objectToMap, methodAttributeName);
        }

        if (!CollectionsUtil.isEmptyOrNull(collection)) {

            List<XmartMappedEntity> returnEntities = new ArrayList<>();

            for (Object thisObject : collection) {

                List<XmartMappedEntity> copyInitialMappedEntities = new ArrayList<>();
                for (XmartMappedEntity entity : initialMappedEntities) {
                    copyInitialMappedEntities.add(new XmartMappedEntity(entity));
                }

                for (MappingNode node : getChildAttributeNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }

                for (MappingNode node : getChildObjectNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }

                for (MappingNode node : getChildCollectionNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, thisObject, copyInitialMappedEntities);
                    }
                }

                for (MappingNode node : getChildBusinessRuleNodes()) {
                    if (rootObjectName.equals(node.getRootObjectName())) {
                        copyInitialMappedEntities = node
                                .mapSourceObject(rootObjectName, objectToMap, copyInitialMappedEntities);
                    }
                }

                returnEntities.addAll(copyInitialMappedEntities);
            }
            return returnEntities;
        } else {
            if (isMandatoryElement()) {
                throw new XmartException(
                        "Failure mapping collection - missing mandatory collection: " + getElementId() + ""
                                + getElementName());
            }
            return initialMappedEntities;
        }
    }

    private Boolean isSingleParameterisedMethod() {
        return getMethodName() != null && (getMethodName().equals("getNodesAt") || getMethodName()
                .equals("getListOfNodes"));
    }

    @Override
    public String toString() {
        return "CollectionMappingNode{" + "methodName='" + methodName + '\'' + ", methodReturnType='" + methodReturnType
                + '\'' + ", methodReflectionMethod=" + methodReflectionMethod + ", elementType='" + elementType + '\''
                + ", rootObjectName='" + rootObjectName + '\'' + ", elementCollection='" + elementCollection + '\''
                + ", elementGroup='" + elementGroup + '\'' + ", elementId=" + elementId + ", elementName='"
                + elementName + '\'' + ", parentElementId=" + parentElementId + ", parentElementName='"
                + parentElementName + '\'' + ", mandatoryElement=" + mandatoryElement + ", children=" + children + '}';
    }
}
