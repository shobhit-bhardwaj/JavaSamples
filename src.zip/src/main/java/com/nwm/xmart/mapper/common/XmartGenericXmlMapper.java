package com.nwm.xmart.mapper.common;

import com.nwm.xmart.core.XmartSet;
import com.nwm.xmart.core.XmartXmlSet;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;

import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.nwm.xmart.util.ConfigParams.LOG_XML_PARAM;
import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public class XmartGenericXmlMapper extends RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> {

    private static final long serialVersionUID = 6343504338985101285L;
    private static final Logger logger = LoggerFactory.getLogger(XmartGenericXmlMapper.class);
    protected ParameterTool parameters;
    protected String operatorName;
    protected String jobName;
    protected IntCounter recordsProcessed;
    protected AverageAccumulator avgRecordProcessTime;
    protected Boolean accumulatorsOn;
    protected Boolean logEntityXml;
    private int topicId;
    private Long startTime;

    protected String getOperatorName() {
        return operatorName;
    }

    protected int getTopicId() {
        return topicId;
    }

    protected String getJobName() {
        return jobName;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        putJobNameInMDC(config);

        logger.debug("Entering open()");

        recordsProcessed = new IntCounter();
        avgRecordProcessTime = new AverageAccumulator();
        accumulatorsOn = false;

        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        topicId = parameters.getInt("flink.job.id");
        jobName = parameters.get("flink.job.name");
        operatorName = parameters.get("operator.mapper.name");
        logEntityXml = parameters.getBoolean(LOG_XML_PARAM, false);

        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);
        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("xmlRecordsProcessed", recordsProcessed);
            getRuntimeContext().addAccumulator("xmlAvgRecordProcessTime", avgRecordProcessTime);
        }
    }

    public XmartGenericXmlSet map(List<XmartGenericSet> xmartTransactionSetList) throws XmartException {

        if (accumulatorsOn) {
            startTime = System.nanoTime();
            logger.debug("Mapping transactions - {}", xmartTransactionSetList.size());
        }

        XmartGenericXmlSet xmartXmlSet = new XmartGenericXmlSet(logEntityXml);

        for (XmartGenericSet xmartSet : xmartTransactionSetList) {

            if (xmartSet != null) {
                try {
                    xmartXmlSet.add(xmartSet);
                } catch (Exception e) {
                    logger.error("Error converting record to XML", e);
                }
            } else {
                logger.error("Error - ignored NULL record in XML mapping - failure in previous operator.");
            }
        }

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }

        return xmartXmlSet;
    }
}
