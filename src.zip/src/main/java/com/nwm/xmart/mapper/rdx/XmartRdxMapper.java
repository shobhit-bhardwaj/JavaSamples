package com.nwm.xmart.mapper.rdx;

import com.nwm.xmart.core.XmartSet;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.rdx.XmartRdxEventSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by aslammh on 07/08/17.
 */
public class XmartRdxMapper extends XmartMapper<RDXSourceEvent> {

    private static final long serialVersionUID = -3815025350133699262L;
    private static final Logger logger = LoggerFactory.getLogger(XmartRdxMapper.class);

    protected MappingNode mappingHierarchy;

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public void open(Configuration config) throws XmartException {

        super.open(config);

        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/rdx-source-event.csv");
    }

    public XmartGenericSet map(RDXSourceEvent rdxSourceEvent) throws Exception {

        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        XmartGenericSet xmartSet = new XmartRdxEventSet();

        if (logger.isDebugEnabled()) {
            logger.debug("Mapping RDX event {}, {}", rdxSourceEvent.getChangeID(), rdxSourceEvent.getRdxId());
        }

        xmartSet.addStreamEvent(rdxSourceEvent, jobId, mappingHierarchy);

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }

        return xmartSet;
    }
}
