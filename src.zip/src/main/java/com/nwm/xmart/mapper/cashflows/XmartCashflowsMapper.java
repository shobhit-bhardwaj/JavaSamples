package com.nwm.xmart.mapper.cashflows;

import com.nwm.xmart.entities.cashflows.XmartCashflowSet;
import com.nwm.xmart.entities.cashflows.XmartCashflowsEvent;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.mapper.XmartGenericMapper;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.core.domain.ODCValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Mapper that uses configurable mappings to map the input objects.
 * Configurable mappings are provided in the parameters.
 */
public class XmartCashflowsMapper extends XmartGenericMapper<DataFabricStreamEvent<ODCValue>> {

    Logger logger = LoggerFactory.getLogger(XmartCashflowsMapper.class);

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public XmartGenericSet map(DataFabricStreamEvent<ODCValue> streamEvent) throws Exception {

        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        XmartCashflowsEvent xmartCashflowsEvent = new XmartCashflowsEvent(streamEvent,
                parameters.getInt("flink.kafka.consumer.topic.ID", 0));

        logger.info("map: documentKey {} topicId {} source[ TimeStamp={}, Partition={}, Position={}] ",
                xmartCashflowsEvent.getDocumentKey(), getTopicId(), streamEvent.getTimestamp(),
                streamEvent.getPartition(), streamEvent.getStreamPosition());

        XmartGenericSet eventSet = new XmartCashflowSet();

        eventSet.addStreamEvent(xmartCashflowsEvent, jobId, mappingHierarchy);

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }

        return eventSet;
    }/**/
}
