package com.nwm.xmart.database.statement.tdx;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;

import java.sql.SQLException;

public class TdxCashFlowXmlInsertStatement extends XmartStatement {
    public TdxCashFlowXmlInsertStatement() {
        super();
        PROC_COMMAND = "EXEC [api].[usp_CashFlowXmlInsert] ?, ?";
    }

    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {

        super.getPreparedStatement(obj);

        XmartGenericXmlSet xmartCashFlowsXml = (XmartGenericXmlSet) obj;

        int index = 1;
        preparedStatement.setObject(index++,  xmartCashFlowsXml.getEntityXml("XmartCashFlows"));
        preparedStatement.setObject(index++, xmartCashFlowsXml.getEntityXml("XmartTdxCashflowStatuses"));
        preparedStatement.addBatch();

        return preparedStatement;
    }
}
