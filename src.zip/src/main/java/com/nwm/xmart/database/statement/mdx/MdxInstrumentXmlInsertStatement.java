package com.nwm.xmart.database.statement.mdx;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;

import java.sql.SQLException;

public class MdxInstrumentXmlInsertStatement extends XmartStatement {
    public MdxInstrumentXmlInsertStatement() {
        super();
        PROC_COMMAND = "EXEC [api].[usp_MdxWrapperXmlInsert] " + "?, ?, ?, ?";
    }

    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {
        super.getPreparedStatement(obj);

        int index = 1;

        XmartGenericXmlSet genericXmlSetXml = (XmartGenericXmlSet) obj;

        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartMdxTimeSeriesEsmas"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartMdxInstruments"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartMdxInstrumentUnderlyings"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartMdxRefRegulatories"));
        preparedStatement.addBatch();
        return preparedStatement;
    }
}
