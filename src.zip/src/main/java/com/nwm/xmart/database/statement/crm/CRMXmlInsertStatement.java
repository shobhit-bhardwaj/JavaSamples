package com.nwm.xmart.database.statement.crm;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;

import java.sql.SQLException;

public class CRMXmlInsertStatement extends XmartStatement {
    public CRMXmlInsertStatement() {
        super();
        PROC_COMMAND = "EXEC [api].[usp_CRMXmlInsert] " + "?, ?, ?, ?, ?" + ", ?, ?, ?, ?, ?" + ", ?, ?, ?, ?" + ", ?";
    }

    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {
        super.getPreparedStatement(obj);

        int index = 1;

        XmartGenericXmlSet genericXmlSetXml = (XmartGenericXmlSet) obj;

        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmUsers"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmUserRoles"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmContacts"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmContactCoverages"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmAccountCoverages"));

        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmCallReports"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmCallReportExternalAttendees"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmCallReportInternalAttendees"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmCallReportAccounts"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmCallLogs"));

        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmCallLogParticipants"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmOrganizations"));
        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmOrganizationMembers"));

        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmInterests"));

        preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml("XmartCrmAccountDesks"));

        preparedStatement.addBatch();

        return preparedStatement;
    }
}
