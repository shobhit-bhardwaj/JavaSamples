package com.nwm.xmart.database.dao;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.XmartXmlTransactionSet;
import com.nwm.xmart.exception.XmartException;

import java.sql.SQLException;

public class ScheduleEntriesXmlInsertStatement extends XmartStatement {
    public ScheduleEntriesXmlInsertStatement() {
        super();
        PROC_COMMAND = "EXEC [api].[usp_TdxTradeAdditionalEntitiesXmlInsert] ? , ?";
    }

    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {

        super.getPreparedStatement(obj);

        XmartXmlTransactionSet transactionSetXml = (XmartXmlTransactionSet) obj;
        preparedStatement.setObject(1, transactionSetXml.getXmartScheduleEntriesXml());
        preparedStatement.setObject(2, transactionSetXml.getXmartFxFixingScheduleEntriesXml());

        preparedStatement.addBatch();
        return preparedStatement;
    }
}