package com.nwm.xmart.database.dao;

import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.api.java.utils.ParameterTool;

/**
 * <p>Defines the standard methods that all data access objects (DAO) must provide to be used in the Flink sinks.</p>
 * <p>To use the DAO the calling class must initialise by calling the open function,
 * objects can then be written using the write method. The close method must be called
 * to ensure the connection to any underlying persistance layer is closed correctly.</p>
 *
 * @author heskets
 */
public interface XmartDao<I> extends BindObject {

    /**
     * Performs any actions required to open the DAO such as opening connections to persistance layers.
     *
     * @param parameters the flink ParamaterTool object holding the job nodes
     *
     * @throws XmartException When the open fails. For instance, if the method cannot connect to
     *                        the persistence layer.
     */
    void open(ParameterTool parameters) throws XmartException;

    /**
     * Performs any actions required to close the DAO such as closing of connections to persistance layers.
     */
    void close();

    /**
     * Writes an object to the underlying persistence layer.
     *
     * @param i          the object to be written
     * @param parameters the flink ParamaterTool object holding the job nodes
     *
     * @throws XmartException When any persistence layer failures occur during the write.
     * @returns - nanoTime before final execution
     */
    Long write(I i, ParameterTool parameters) throws XmartException;
}
