package com.nwm.xmart.database.dao;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.SqlServerConnector;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * <p>Provides a data access layer to allow persisting data to SQL Server by calling a Stored Procedure.</p>
 * <p>The open method creates a JDBC connection and sets up the required statement class.</p>
 *
 * @author heskets
 */

public class SqlServerDao implements XmartDao {

    private static final long serialVersionUID = 7671680707369330182L;

    private static final Logger logger = LoggerFactory.getLogger(SqlServerDao.class);

    private final SqlServerConnector connector = new SqlServerConnector();

    private SQLServerConnection connection;

    @Inject
    @Named("XmartStatement")
    private XmartStatement xmartStatement;

    /**
     * <p>Opens a connection to SQL Server using SQL Server JDBC connection classes and created the relevant statement class.</p>
     * <p>Each different type of data has a separate statement class that handles the creation of the PrepareStatement and the
     * set up of the parameters.</p>
     *
     * @param parameters the flink ParamaterTool object holding the job nodes
     *
     * @throws XmartException When the open fails. For instance, if the method cannot connect to
     *                        the persistence layer.
     */
    @Override
    public void open(ParameterTool parameters) throws XmartException {

        connection = connector.getConnection(parameters);

        if (logger.isDebugEnabled()) {
            logger.debug("Initialised dao connection: {}", connection.toString());
        }

        try {
            xmartStatement.open(connection);
        } catch (SQLException e) {
            logger.error("Xmart prepared statement object failed to open", e);
            throw new XmartException("Xmart prepared statement object failed to open.");
        }
    }

    /**
     * Closes any open SQL Server connections.
     */
    @Override
    public void close() {

        try {

            if (xmartStatement != null) {
                xmartStatement.close();
            }
        } catch (SQLException e) {
            logger.warn("Close of prepared statement failed: {}", e.getMessage());
        }

        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            logger.warn("Close of connectionfailed: {}", e.getMessage());
        }
    }

    /**
     * Writes an object to the SQL Server database by setting up the prapared statement with the parameters and
     * executing against the database.
     *
     * @param i          the object to be written
     * @param parameters the flink ParamaterTool object holding the job nodes
     *
     * @throws XmartException When any persistence layer failures occur during the write.
     */
    @Override
    public Long write(Object i, ParameterTool parameters) throws XmartException {

        Long executeTime = 0L;

        if (!connector.checkConnection(connection)) {

            connection = connector.getConnection(parameters);
        }

        int retryCounter = 0;
        boolean isComplete = false;

        while (!isComplete && retryCounter < parameters.getInt("operator.sink.sqlserver.retry.limit")) {

            if (logger.isDebugEnabled()) {
                logger.debug("Sql Server attempt {} to write {}", retryCounter + 1, i.toString());
            }

            try {

                SQLServerPreparedStatement ps = xmartStatement.getPreparedStatement(i);

                ps.setEscapeProcessing(true);
                ps.setQueryTimeout(parameters.getInt("operator.sink.sqlserver.timeout.sec"));

                executeTime = System.nanoTime();

                //ps.executeBatch();
                ps.clearBatch();

                if (logger.isDebugEnabled()) {
                    logger.debug("Sql statement executed for XML : {}", i.toString());
                }

                isComplete = true;
            } catch (SQLException e) {
                logger.error("Error executing statement", e);
            }

            if (!isComplete) {

                retryCounter++;

                try {

                    Thread.sleep(parameters.getInt("operator.sink.sqlserver.retry.period"));
                } catch (InterruptedException ie) {

                    logger.error("Interrupt before retrying SQL Server connection:", ie);
                    Thread.currentThread().interrupt();

                    isComplete = true;
                }
            }
        }

        if (!isComplete) {
            logger.error("SQL Server {} attempts to execute statement exceeded retry limit.", retryCounter);
            throw new XmartException("SQL Server attempts to execute statement exceeded retry limit.");
        }

        return executeTime;
    }
}
