package com.nwm.xmart.bean;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.nwm.xmart.processor.JobType;
import com.nwm.xmart.processor.XmartProcessor;

/**
 * Created by aslammh on 22/09/17.
 */
public abstract class AbstractBeanProvider implements BeanProvider {
    private Injector injector;

    private Injector getInjector(JobType jobType) {
        if (injector == null) {
            synchronized (Injector.class) {
                if (injector == null) {
                    // This is the place where we can direct Guice to inject required beans.
                    Module[] modules = getModules(jobType);
                    injector = Guice.createInjector(modules);
                }
            }
        }
        return injector;
    }

    public abstract Module[] getModules(JobType jobType);

    @Override
    public <T extends XmartProcessor> T getBean(Class clazz, JobType jobType) {
        return (T) getInjector(jobType).getInstance(clazz);
    }
}
