package com.nwm.xmart.bean.schedule_entries.domain;

import com.rbs.odc.access.domain.ScheduleEntry;

import java.io.Serializable;
import java.util.Collection;

public class XmartODCScheduleEntries implements Serializable {

    private static final long serialVersionUID = -6923656813793741306L;
    private XmartODCScheduleEntryKey parentKey;
    private Collection<ScheduleEntry> childData;

    public XmartODCScheduleEntryKey getParentKey() {
        return parentKey;
    }

    public Collection<ScheduleEntry> getChildData() {
        return childData;
    }
}