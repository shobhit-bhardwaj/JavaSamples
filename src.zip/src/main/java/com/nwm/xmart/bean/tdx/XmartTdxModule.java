package com.nwm.xmart.bean.tdx;

import com.google.inject.AbstractModule;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.database.statement.tdx.TdxCashFlowXmlInsertStatement;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.mapper.common.XmartGenericAggregateProcessFunction;
import com.nwm.xmart.mapper.common.XmartGenericXmlMapper;
import com.nwm.xmart.mapper.tdx.XmartTdxMapper;
import com.nwm.xmart.streaming.source.tdx.event.TDXSourceEvent;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.streaming.api.functions.ProcessFunction;

import java.util.List;

public class XmartTdxModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(new TypeLiteral<RichMapFunction<TDXSourceEvent, XmartGenericSet>>() {
        }).annotatedWith(Names.named("XmartSourceEventMapper")).to(XmartTdxMapper.class);

        bind(new TypeLiteral<ProcessFunction<XmartGenericSet, List<XmartGenericSet>>>() {
        }).annotatedWith(Names.named("XmartWindowMapper")).to(XmartGenericAggregateProcessFunction.class);

        bind(new TypeLiteral<RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet>>() {
        }).annotatedWith(Names.named("XmartXmlMapper")).to(XmartGenericXmlMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement")).to(TdxCashFlowXmlInsertStatement.class);
    }
}
