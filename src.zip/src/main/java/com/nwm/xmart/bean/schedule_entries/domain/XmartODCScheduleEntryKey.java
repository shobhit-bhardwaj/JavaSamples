package com.nwm.xmart.bean.schedule_entries.domain;

import java.io.Serializable;

public class XmartODCScheduleEntryKey implements Serializable {
    private static final long serialVersionUID = -8402055620633269593L;

    private XmartODCId transactionId;
    private String legIdentifier;

    public XmartODCId getTransactionId() {
        return transactionId;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }
}