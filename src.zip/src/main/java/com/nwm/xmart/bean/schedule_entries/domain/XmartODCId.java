package com.nwm.xmart.bean.schedule_entries.domain;

import java.io.Serializable;

public class XmartODCId implements Serializable {

    private XmartODCTransactionId id;
    private long odcVersion;

    public long getOdcVersion() {
        return odcVersion;
    }

    public XmartODCTransactionId getId() {
        return id;
    }
}