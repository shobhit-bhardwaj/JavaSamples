package com.nwm.xmart.bean;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;
import com.nwm.xmart.database.dao.LoggerDao;
import com.nwm.xmart.database.dao.SqlServerDao;
import com.nwm.xmart.database.dao.XmartDao;
import com.nwm.xmart.sink.LoggerSink;
import com.nwm.xmart.sink.SqlServerSink;
import com.nwm.xmart.sink.XmartSink;

/**
 * Created by aslammh on 22/09/17.
 */
public class XmartModule extends AbstractModule {

    @Override
    protected void configure() {

        bind(XmartDao.class).annotatedWith(Names.named("LoggerDao")).to(LoggerDao.class);

        bind(XmartDao.class).annotatedWith(Names.named("SqlServerDao")).to(SqlServerDao.class);

        bind(XmartSink.class).annotatedWith(Names.named("LoggerSink")).to(LoggerSink.class);

        bind(XmartSink.class).annotatedWith(Names.named("BdxSink")).to(SqlServerSink.class);
    }
}
