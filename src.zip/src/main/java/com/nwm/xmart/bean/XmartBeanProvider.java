package com.nwm.xmart.bean;

import com.google.inject.Module;
import com.nwm.xmart.bean.cashflows.XmartCashFlowsModule;
import com.nwm.xmart.bean.crm.XmartCRMModule;
import com.nwm.xmart.bean.file.guice.XmartFileModule;
import com.nwm.xmart.bean.kdb.XmartKdbModule;
import com.nwm.xmart.bean.mdx.XmartMdxFxRatesModule;
import com.nwm.xmart.bean.mdx.XmartMdxInstrumentModule;
import com.nwm.xmart.bean.rdx.XmartRdxInstrumentModule;
import com.nwm.xmart.bean.schedule_entries.XmartScheduleEntriesModule;
import com.nwm.xmart.bean.sds.XmartSdsModule;
import com.nwm.xmart.bean.tdx.XmartTdxModule;
import com.nwm.xmart.processor.JobType;

/**
 * Created by aslammh on 22/09/17.
 * Provides the binding of beans specific to Xmart.
 */
public class XmartBeanProvider extends AbstractBeanProvider {
    @Override
    public Module[] getModules(JobType jobType) {

        Module jobModule = null;

        switch (jobType) {
        case BDX_RDX_INSTRUMENT_LOAD:
            jobModule = new XmartRdxInstrumentModule();
            break;
        case BDX_TRANSACTION_LOAD:
            jobModule = new XmartOdcTransactionModule();
            break;
        case BDX_CASHFLOWS_LOAD:
            jobModule = new XmartCashFlowsModule();
            break;
        case BDX_MDX_INSTRUMENT_LOAD:
            jobModule = new XmartMdxInstrumentModule();
            break;
        case BDX_MDX_FX_RATES_LOAD:
            jobModule = new XmartMdxFxRatesModule();
            break;
        case BDX_KDB_LOAD:
            jobModule = new XmartKdbModule();
            break;
        case BDX_SCHEDULE_ENTRIES_LOAD:
            jobModule = new XmartScheduleEntriesModule();
            break;
        case BDX_CASH_FLOWS_STATUS_LOAD:
            jobModule = new XmartTdxModule();
            break;
        case BDX_CRM_LOAD:
            jobModule = new XmartCRMModule();
            break;
        case BDX_FILE_LOAD:
            jobModule = new XmartFileModule();
            break;
        case BDX_ARGON:
            return new Module[] { new XmartArgonModule() };
        case BDX_SDS_LOAD:
            jobModule = new XmartSdsModule();
            break;
        default:
            throw new IllegalArgumentException("The job type is not recognised : " + jobType);
        }

        return new Module[] { new XmartModule(), jobModule };
    }
}
