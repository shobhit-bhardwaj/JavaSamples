package com.nwm.xmart.bean.crm;

import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.core.inject.XmartAbstractModule;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.database.statement.crm.CRMXmlInsertStatement;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.mapper.crm.XmartCRMMapper;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import org.apache.flink.api.common.functions.RichMapFunction;

public class XmartCRMModule extends XmartAbstractModule {
    @Override
    protected void additionalConfigure() {
        bind(new TypeLiteral<RichMapFunction<CRMSourceEvent, XmartGenericSet>>() {
        }).annotatedWith(Names.named("XmartSourceEventMapper")).to(XmartCRMMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement")).to(CRMXmlInsertStatement.class);
    }
}
