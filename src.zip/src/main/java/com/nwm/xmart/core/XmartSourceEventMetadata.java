package com.nwm.xmart.core;

import java.io.Serializable;

/**
 * Interface to mark objects to be treated as metadata, implementing classes to decide what to store and how to get
 */
public interface XmartSourceEventMetadata extends Serializable {

}
