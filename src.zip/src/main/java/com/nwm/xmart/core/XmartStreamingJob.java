package com.nwm.xmart.core;

import com.nwm.xmart.bean.BeanProvider;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.processor.ProcessorProvider;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.streaming.common.job.StreamJob;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class XmartStreamingJob extends StreamJob {

    private BeanProvider beanProvider;
    private Class processorClass;

    /**
     * @param beanProvider
     * @param processorClass
     *
     * @deprecated Deprecated by {@link XmartStreamingJob#XmartStreamingJob(BeanProvider)}
     * <br>Caller should not need to provide the processorClass. Processor selection should be driven from the config
     */
    @Deprecated
    public XmartStreamingJob(BeanProvider beanProvider, Class processorClass) {
        this.beanProvider = beanProvider;
        this.processorClass = processorClass;
    }

    public XmartStreamingJob(BeanProvider beanProvider) {
        this.beanProvider = beanProvider;
    }

    @Override
    protected void configureAndExecuteStream(StreamExecutionEnvironment streamExecutionEnvironment) {
        try {
            /* TODO This if put here for compatibilty with the integration tests.
            Should be removed when the processor classes have the generic sources*/
            XmartProcessor processor = null;
            String processorType = configuration.getString("flink.job.processor.type", "");

            if (processorClass != null) {
                processor = ProcessorProvider.getProcessor(beanProvider, processorClass, processorType);
            } else {
                processor = ProcessorProvider.getProcessor(beanProvider, processorType);
            }

            processor.configureAndExecuteStream(streamExecutionEnvironment, configuration);
        } catch (XmartException e) {
            String jobName = configuration.getString("flink.job.name", "");
            logger.error("Exception running the flink job {}", jobName, e);
            throw new RuntimeException("Exception running the flink job " + jobName, e);
        }
    }
}
