package com.nwm.xmart.core;

public abstract class XmartXmlSet<T extends XmartSet> implements BindObject {
    /**
     * Property to control if the XML should be outputted to the logs
     */
    protected Boolean logXML;

    /**
     * Utility constructor to provide if the XML generated here should be logged to the log files.
     *
     * @param logXML {@link Boolean} {@code true}: Log XML to file, {@code false}: Do not log it
     */
    public XmartXmlSet(Boolean logXML) {
        this.logXML = logXML;
    }

    /**
     * Method to add the {@link XmartODCSet} object to the XML set for further processing.
     *
     * @param xmartSet the pojo set whose constituents' xml are to be stored in the xml set
     */
    public abstract void add(T xmartSet);
}
