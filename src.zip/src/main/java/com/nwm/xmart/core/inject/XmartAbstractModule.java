package com.nwm.xmart.core.inject;

import com.google.inject.AbstractModule;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.mapper.common.XmartGenericAggregateProcessFunction;
import com.nwm.xmart.mapper.common.XmartGenericXmlMapper;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.streaming.api.functions.ProcessFunction;

import java.util.List;

/**
 * Class to provide common injection shared among the different job loaders.
 * Provides injections for {@link XmartGenericAggregateProcessFunction} and {@link XmartGenericXmlMapper}.
 * <p>
 * Child classes should provide additional injections in additionalConfigure method
 */
public abstract class XmartAbstractModule extends AbstractModule {
    @Override
    protected void configure() {
        bind(new TypeLiteral<ProcessFunction<XmartGenericSet, List<XmartGenericSet>>>() {
        }).annotatedWith(Names.named("XmartWindowMapper")).to(XmartGenericAggregateProcessFunction.class);

        bind(new TypeLiteral<RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet>>() {
        }).annotatedWith(Names.named("XmartXmlMapper")).to(XmartGenericXmlMapper.class);

        additionalConfigure();
    }

    /**
     * Method to provide further injections then those provided by {@link XmartAbstractModule#configure()}
     */
    protected abstract void additionalConfigure();
}
