package com.nwm.xmart.core;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Retention(RUNTIME)
@Target({ FIELD })
public @interface XmartAttribute {
    String name() default "##default";

    boolean usedInJoin() default false;

    boolean mandatory() default false;

    /**
     * If the field's value is non-null and this property is set to true, then the entity containing the field is a valida candidate for XML set. Hence an entry would be created for entity in the XML set.
     *
     * @return
     */
    boolean xmlTrigger() default true;
}
