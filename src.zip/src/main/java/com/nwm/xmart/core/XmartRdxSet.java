package com.nwm.xmart.core;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;

/**
 * Super class providing core functionality.
 */
public abstract class XmartRdxSet<T> implements XmartSet {

    /**
     * Adds an event to the stream processing
     *
     * @param streamEvent
     * @param sourceTopicId ID of the source topic that this record was read from
     *
     * @throws XmartException because every other method does, so this should not feel deprived.
     */
    public abstract void addStreamEvent(T streamEvent, int sourceTopicId, MappingNode mappingHierarchy)
            throws XmartException;

    public abstract String getXmlEntities(String entityCollectionName);
}
