package com.nwm.xmart.core;

import java.io.Serializable;

/**
 * Provides a mechanism to define any interfaces that must be supported by the BDX classes
 *
 * @author aslammh on 10/08/17
 */
public interface BindObject extends Serializable {
}
