package com.nwm.xmart.core;

import com.nwm.xmart.bean.XmartBeanProvider;
import com.nwm.xmart.streaming.common.job.StreamJob;

/**
 * <p>Defined the main method that is useed by the Flink framework to run a Xmart Data Load job.</p>
 * <p>The class consists of a single main method that defines the stream processing pipeline. <p/>
 *
 * @author heskets
 */
public class XmartStreaming {

    /**
     * Determines the processing to be completed from the job parameter file and then sets up the Flink
     * procesing pipeline using the StreamJob class of the datafabric streaming library.
     *
     * @param args command line paremeters providing the location of the properties file to be run
     *
     * @throws Exception TODO may chnge after error handling introduced
     */
    public static void main(String[] args) throws Exception {
        // StreamJob implementation can override any abstract method as long as it calls super() first
        // TODO We do not need to provide the processor class
        // StreamJob streamJob = new XmartStreamingJob(beanProvider, OdcTransactionProcessor.class);
        StreamJob streamJob = new XmartStreamingJob(new XmartBeanProvider());
        streamJob.run(args);
    }
}
