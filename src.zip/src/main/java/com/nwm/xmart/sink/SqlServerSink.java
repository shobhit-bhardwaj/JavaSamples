package com.nwm.xmart.sink;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.database.dao.XmartDao;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

/**
 * Created by aslammh on 21/09/17.
 */
public class SqlServerSink extends XmartSink {

    private static final Logger log = LoggerFactory.getLogger(SqlServerSink.class);

    @Inject
    @Named("SqlServerDao")
    private XmartDao writer;

    public SqlServerSink() {
        super();
    }

    public void setWriter() {
        super.setWriter(writer);
    }

    @Override
    public void open(Configuration configuration) throws XmartException {
        //TODO: the configuration received here is empty, invetigate why
        ParameterTool parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        putJobNameInMDC(parameters);
        log.debug("Entering open()");
        setWriter();
        super.open(configuration);
    }
}
