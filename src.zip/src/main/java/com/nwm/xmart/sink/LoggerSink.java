package com.nwm.xmart.sink;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.database.dao.XmartDao;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.configuration.Configuration;

/**
 * Created by aslammh on 20/09/17.
 */
public class LoggerSink extends XmartSink {

    @Inject
    @Named("LoggerDao")
    private XmartDao writer;

    public LoggerSink() {
        super();
    }

    public void setWriter() {
        super.setWriter(writer);
    }

    @Override
    public void open(Configuration configuration) throws XmartException {

        setWriter();

        super.open(configuration);
    }
}
