package com.nwm.xmart.processor.kdb;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.keyselectors.XmartSetKeySelector;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.source.kdb.KDBSource;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.parameters.BdxKdbFunctionDetails;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

/**
 * <p>Provides the stream processing pipeline definition for load of RDX Instruments.</p>
 * <p>The configureAndExecuteStream provides the main processing pipeline.<p/>
 *
 * @author heskets
 */
public class KdbProcessor implements XmartProcessor {

    private static final Logger logger = LoggerFactory.getLogger(KdbProcessor.class);

    @Inject
    @Named("BdxSink")
    private XmartSink sink;

    @Inject
    @Named("KDBSourceEventMapper")
    private RichMapFunction<KDBSourceEvent, XmartGenericSet> sourceEventMapper;

    @Inject
    @Named("XmartWindowMapper")
    private ProcessFunction<XmartGenericSet, List<XmartGenericSet>> windowMapper;

    @Inject
    @Named("XmartXmlMapper")
    private RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> xmlMapper;

    public KdbProcessor() {
        // No initiation required
    }

    /**
     * Defines the procesing steps to complete and executes
     *
     * @param env           the Flink procesing stream that is to be initiated
     * @param configuration the flink Configuration used to control the processing
     *
     * @throws RuntimeException for hard Flink process failures not handled
     */

    @Override
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration configuration)
            throws XmartException {

        // Create stream counter and stream to merge in sources
        DataStream<KDBSourceEvent> kdbMergedSourceStream = null;

        putJobNameInMDC(configuration);
        logger.debug("Entering configureAndExecuteStream.");

        /* ******************************************************************************
         * STEP 1 - Set up KDB Consumer sources
         ****************************************************************************** */

        // Type info reqd for the FlinkDeserializer
        final TypeInformation<KDBSourceEvent> kdbSourceEventType = TypeInformation.of(new TypeHint<KDBSourceEvent>() {
        });

        ConcurrentMap<String, String> parameterMap = new ConcurrentHashMap<>();
        parameterMap.put(configuration.getString("kdb.parameter.startDate.key", null),
                configuration.getString("kdb.parameter.startDate.value", null));
        parameterMap.put(configuration.getString("kdb.parameter.endDate.key", null),
                configuration.getString("kdb.parameter.endDate.value", null));

        String currentUserDomain = System.getenv("USERDOMAIN");
        String currentUser = System.getenv("USERNAME");

        logger.info("User credentials: {} {}", currentUserDomain, currentUser);

        if ("FI".equals(configuration.getString("kdb.source.type", null))) {
            //////////////////////
            // FIXED INCOME JOB //
            //////////////////////

            // list of FI functions that will form part of the Fixed Income KDBSource.
            List<BdxKdbFunctionDetails> fixedIncomeFunctionsList = new ArrayList<BdxKdbFunctionDetails>();

            // FI_MIFID_RFQ
            if (configuration.getBoolean("kdb.source1.enabled", false)) {
                BdxKdbFunctionDetails fiMifidRfqDetails = new BdxKdbFunctionDetails("1",
                        configuration.getString("kdb.source1.functionName", null),
                        configuration.getString("kdb.source1.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source1.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source1.mdxEnvironmentName", null),
                        configuration.getString("kdb.source1.kdbEnvironmentName", null),
                        configuration.getString("kdb.source1.tableName.value", null));

                fixedIncomeFunctionsList.add(fiMifidRfqDetails);
            }

            // FI_MIFID_QEC
            if (configuration.getBoolean("kdb.source2.enabled", false)) {
                BdxKdbFunctionDetails fiMifidQecDetails = new BdxKdbFunctionDetails("2",
                        configuration.getString("kdb.source2.functionName", null),
                        configuration.getString("kdb.source2.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source2.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source2.mdxEnvironmentName", null),
                        configuration.getString("kdb.source2.kdbEnvironmentName", null),
                        configuration.getString("kdb.source2.tableName.value", null));

                fixedIncomeFunctionsList.add(fiMifidQecDetails);
            }

            // FI_MIFID_FICC
            if (configuration.getBoolean("kdb.source7.enabled", false)) {

                parameterMap.put(configuration.getString("kdb.source7.tableName.key", null),
                        configuration.getString("kdb.source7.tableName.value", null));
                parameterMap.put(configuration.getString("kdb.source7.timePrecision.key", null),
                        configuration.getString("kdb.source7.timePrecision.value", null));

                BdxKdbFunctionDetails fiMifidFICCDetails = new BdxKdbFunctionDetails("7",
                        configuration.getString("kdb.source7.functionName", null),
                        configuration.getString("kdb.source7.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source7.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source7.mdxEnvironmentName", null),
                        configuration.getString("kdb.source7.kdbEnvironmentName", null),
                        configuration.getString("kdb.source7.tableName.value", null));

                fixedIncomeFunctionsList.add(fiMifidFICCDetails);
            }

            // FI_MIFID_FICC_D2D
            if (configuration.getBoolean("kdb.source8.enabled", false)) {
                parameterMap.put(configuration.getString("kdb.source8.tableName.key", null),
                        configuration.getString("kdb.source8.tableName.value", null));
                parameterMap.put(configuration.getString("kdb.source8.timePrecision.key", null),
                        configuration.getString("kdb.source8.timePrecision.value", null));
                BdxKdbFunctionDetails fiMifidFICCD2DDetails = new BdxKdbFunctionDetails("7",
                        configuration.getString("kdb.source8.functionName", null),
                        configuration.getString("kdb.source8.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source8.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source8.mdxEnvironmentName", null),
                        configuration.getString("kdb.source8.kdbEnvironmentName", null),
                        configuration.getString("kdb.source8.tableName.value", null));

                fixedIncomeFunctionsList.add(fiMifidFICCD2DDetails);
            }

            if (fixedIncomeFunctionsList.size() > 0) {
                // Fixed Income Functions for the FI GATEWAY ONLY
                ParameterTool parametersFI = ParameterTool.fromMap(configuration.toMap());
                SourceFunction<KDBSourceEvent> fiSourceFunction = new KDBSource(parametersFI, fixedIncomeFunctionsList);
                kdbMergedSourceStream = env.addSource(fiSourceFunction, kdbSourceEventType)
                                           .uid(configuration.getString("kdb.fi.source.uid", null))
                                           .name(configuration.getString("kdb.fi.source.name", null)).setParallelism(
                                configuration.getInteger("operator.fi.source.parallelism", 1));
            }
        } else if ("FX".equals(configuration.getString("kdb.source.type", null))) {
            ////////////
            // FX JOB //
            ////////////

            // list of FX functions that will form part of the Fixed Income KDBSource.
            List<BdxKdbFunctionDetails> fxFunctionsList = new ArrayList<BdxKdbFunctionDetails>();

            // FX_MIFID_RFQ
            if (configuration.getBoolean("kdb.source3.enabled", false)) {
                BdxKdbFunctionDetails fiMifidRfqDetails = new BdxKdbFunctionDetails("3",
                        configuration.getString("kdb.source3.functionName", null),
                        configuration.getString("kdb.source3.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source3.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source3.mdxEnvironmentName", null),
                        configuration.getString("kdb.source3.kdbEnvironmentName", null),
                        configuration.getString("kdb.source3.tableName.value", null));

                fxFunctionsList.add(fiMifidRfqDetails);
            }

            // FX_MIFID_OMS
            if (configuration.getBoolean("kdb.source4.enabled", false)) {
                BdxKdbFunctionDetails fiMifidRfqDetails = new BdxKdbFunctionDetails("4",
                        configuration.getString("kdb.source4.functionName", null),
                        configuration.getString("kdb.source4.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source4.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source4.mdxEnvironmentName", null),
                        configuration.getString("kdb.source4.kdbEnvironmentName", null),
                        configuration.getString("kdb.source4.tableName.value", null));

                fxFunctionsList.add(fiMifidRfqDetails);
            }

            // FX_MIFID_TRADE
            if (configuration.getBoolean("kdb.source5.enabled", false)) {
                BdxKdbFunctionDetails fiMifidRfqDetails = new BdxKdbFunctionDetails("5",
                        configuration.getString("kdb.source5.functionName", null),
                        configuration.getString("kdb.source5.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source5.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source5.mdxEnvironmentName", null),
                        configuration.getString("kdb.source5.kdbEnvironmentName", null),
                        configuration.getString("kdb.source5.tableName.value", null));

                fxFunctionsList.add(fiMifidRfqDetails);
            }

            // FX_MIFID_TRADE_ELIGIBILITY
            if (configuration.getBoolean("kdb.source6.enabled", false)) {
                BdxKdbFunctionDetails fiMifidRfqDetails = new BdxKdbFunctionDetails("6",
                        configuration.getString("kdb.source6.functionName", null),
                        configuration.getString("kdb.source6.name", null),
                        KDBFunctionType.valueOf(configuration.getString("kdb.source6.functionType", null)),
                        MDXSessionType.SSO, parameterMap,
                        configuration.getString("kdb.source6.mdxEnvironmentName", null),
                        configuration.getString("kdb.source6.kdbEnvironmentName", null),
                        configuration.getString("kdb.source6.tableName.value", null));

                fxFunctionsList.add(fiMifidRfqDetails);
            }

            if (fxFunctionsList.size() > 0) {
                // Fixed Income Functions for the FI GATEWAY ONLY
                ParameterTool parametersFX = ParameterTool.fromMap(configuration.toMap());
                SourceFunction<KDBSourceEvent> fxSourceFunction = new KDBSource(parametersFX, fxFunctionsList);
                kdbMergedSourceStream = env.addSource(fxSourceFunction, kdbSourceEventType)
                                           .uid(configuration.getString("kdb.fx.source.uid", null))
                                           .name(configuration.getString("kdb.fx.source.name", null)).setParallelism(
                                configuration.getInteger("operator.fx.source.parallelism", 1));
            }
        }

        /* ******************************************************************************
         * STEP 2 - This will map the KDB events to the flattened structures
         *          required by BDX
         ****************************************************************************** */

        // No source streams
        if (kdbMergedSourceStream == null) {
            logger.error("No sources configured in the job {}", configuration.getString("flink.job.name", null));
            throw new RuntimeException(
                    "No sources configured in the job " + configuration.getString("flink.job.name", null));
        }

        // Configuration of the mapper function in the stream
        DataStream<XmartGenericSet> xmartTransactionStream = kdbMergedSourceStream.map(sourceEventMapper)
                                                                                  .returns(XmartGenericSet.class)
                                                                                  .uid(configuration.getString(
                                                                                          "operator.mapper.name", null))
                                                                                  .name(configuration.getString(
                                                                                          "operator.mapper.name", null))
                                                                                  .setParallelism(configuration
                                                                                          .getInteger(
                                                                                                  "operator.mapper.parallelism",
                                                                                                  1));

        /* ******************************************************************************
         * STEP 3 - Aggregate using a count and time based window
         ****************************************************************************** */

        // Configuration of the keyed aggregation function in the stream
        DataStream<List<XmartGenericSet>> xmartBatchedTransactionStream = xmartTransactionStream
                .keyBy(new XmartSetKeySelector()).process(windowMapper)
                .uid(configuration.getString("operator.aggregate.window.name", null))
                .name(configuration.getString("operator.aggregate.window.name", null))
                .setParallelism(configuration.getInteger("operator.aggregate.window.parallelism", 1));

        /* ******************************************************************************
         * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
         *          database in the sink
         ****************************************************************************** */

        // Configuration of the XML mapper function in the stream
        DataStream<XmartGenericXmlSet> xmartXmlStream = xmartBatchedTransactionStream.map(xmlMapper).uid(configuration
                .getString("operator.convertor.xml.name", null)).name(configuration
                .getString("operator.convertor.xml.name", null)).setParallelism(
                configuration.getInteger("operator.convertor.xml.parallelism", 1));

        /* ******************************************************************************
         * STEP 5 - Add the output sink
         ****************************************************************************** */

        xmartXmlStream.addSink(sink).uid(configuration.getString("operator.sink.name", null))
                      .name(configuration.getString("operator.sink.name", null))
                      .setParallelism(configuration.getInteger("operator.sink.parallelism", 1));

        // TODO move this step up in hieararchy. (add method doBeforeExuctionStart)
        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {

            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(configuration.getString("flink.job.name", null));
        } catch (Exception e) {

            logger.error("Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException(
                    "Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
        }
    }
}
