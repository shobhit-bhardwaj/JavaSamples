package com.nwm.xmart.processor.argon;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.processor.file.XmartFileProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.source.argon.XmartArgonAttributes;
import com.nwm.xmart.source.argon.XmartArgonEvent;
import com.nwm.xmart.source.argon.XmartArgonPropertyNames;
import com.nwm.xmart.source.argon.XmartArgonSource;
import com.nwm.xmart.source.file.exeption.XmartFileAttributeException;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.nwm.xmart.source.file.util.XmartFileUtil.directoryExists;
import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;
import static java.util.Objects.isNull;

/**
 * <p>Provides the stream processing pipeline definition for load of RDX Instruments.</p>
 * <p>The configureAndExecuteStream provides the main processing pipeline.<p/>
 *
 * @author heskets
 */
public class XmartArgonProcessor implements XmartProcessor {

    private static final Logger logger = LoggerFactory.getLogger(XmartFileProcessor.class);

    @Inject
    @Named("LoggerSink")
    private XmartSink sink;

    @Inject
    @Named("XmartSourceEventMapper")
    private RichMapFunction<XmartArgonEvent, XmartGenericSet> sourceEventMapper;

    public XmartArgonProcessor() {
        // No initiation required
    }

    @Override
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration configuration)
            throws XmartException {
        putJobNameInMDC(configuration);
        logger.debug("Entering configureAndExecuteStream.");

        // Type info reqd for the FlinkDeserializer
        final TypeInformation<XmartArgonEvent> eventTypeInformation = TypeInformation
                .of(new TypeHint<XmartArgonEvent>() {
                });

        DataStream<XmartArgonEvent> argonEventDataStream = unionSources(env, eventTypeInformation, configuration,
                configuration.getInteger("argon.source.count", 0));

        DataStream<XmartGenericSet> xmartArgonStream = argonEventDataStream.map(sourceEventMapper)
                                                                           .returns(XmartGenericSet.class)
                                                                           .uid(configuration
                                                                                   .getString("operator.mapper.name",
                                                                                           null)).name(configuration
                        .getString("operator.mapper.name", null)).setParallelism(
                        configuration.getInteger("operator.mapper.parallelism", 1));

        xmartArgonStream.addSink(sink).uid(configuration.getString("operator.sink.name", null))
                        .name(configuration.getString("operator.sink.name", null))
                        .setParallelism(configuration.getInteger("operator.sink.parallelism", 1));

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {

            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(configuration.getString("flink.job.name", null));
        } catch (Exception e) {
            logger.error("Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException(
                    "Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
        }
    }

    private DataStream<XmartArgonEvent> unionSources(StreamExecutionEnvironment env,
            TypeInformation<XmartArgonEvent> typeInfo, Configuration config, int count) {
        DataStream<XmartArgonEvent> firstStream = null;
        for (int j = 1; j <= count; j++) {
            final String sourcePref = "argonsource" + j + ".";
            XmartArgonAttributes xmartArgonAttributes = new XmartArgonAttributes(sourcePref, config);

            if (!xmartArgonAttributes.getEnabled()) {
                logger.info("{} marked as disabled, not creating in exeuction");
                continue;
            } else {
                if (!directoryExists(xmartArgonAttributes.getDirectory())) {
                    throw new XmartFileAttributeException(
                            "Folders do not exist or are not directories [" + xmartArgonAttributes.getDirectory()
                                    + "]");
                }
            }

            if (isNull(firstStream)) {
                //initialze stream with first source
                firstStream = env.addSource(new XmartArgonSource(xmartArgonAttributes), typeInfo)
                                 .setParallelism(config.getInteger(sourcePref + XmartArgonPropertyNames.PARALLELISM, 1))
                                 .uid(config.getString(sourcePref + XmartArgonPropertyNames.ID, null))
                                 .name(config.getString(sourcePref + XmartArgonPropertyNames.NAME, null));
            } else {
                //Create and Union firststream other source streams.
                DataStream<XmartArgonEvent> otherStream = env
                        .addSource(new XmartArgonSource(xmartArgonAttributes), typeInfo)
                        .setParallelism(config.getInteger(sourcePref + XmartArgonPropertyNames.PARALLELISM, 1))
                        .uid(config.getString(sourcePref + XmartArgonPropertyNames.ID, null))
                        .name(config.getString(sourcePref + XmartArgonPropertyNames.NAME, null));
                firstStream = firstStream.union(otherStream);
            }
        }
        return firstStream;
    }
}
