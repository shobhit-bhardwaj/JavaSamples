package com.nwm.xmart.processor.crm;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.keyselectors.CRMKeySelector;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.source.crm.CRMSource;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public class CRMProcessor implements XmartProcessor {
    private static final Logger logger = LoggerFactory.getLogger(CRMProcessor.class);

    @Inject
    @Named("BdxSink")
    private XmartSink sink;

    @Inject
    @Named("XmartSourceEventMapper")
    private RichMapFunction<CRMSourceEvent, XmartGenericSet> crmMapper;

    @Inject
    @Named("XmartWindowMapper")
    private ProcessFunction<XmartGenericSet, List<XmartGenericSet>> windowMapper;

    @Inject
    @Named("XmartXmlMapper")
    private RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> xmlMapper;

    @Override
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration configuration)
            throws XmartException {
        putJobNameInMDC(configuration);
        logger.debug("Entering configureAndExecuteStream.");

        /* ******************************************************************************
         * STEP 1 - Set up Kafka Consumer source
         ****************************************************************************** */

        // Type info reqd for the FlinkDeserializer
        final TypeInformation<CRMSourceEvent> info = TypeInformation.of(new TypeHint<CRMSourceEvent>() {
        });

        DataFabricUtil dataFabricUtil = new DataFabricUtil(configuration);

        // Configuration of the source function in the stream
        String sourceName = configuration.getString("operator.source.name", null);
        Integer sourceParallelism = configuration.getInteger("operator.source.parallelism", 1);
        String kafkaConsumerGroup = configuration.getString("kafka.consumer.group.id", null);

        List<DataStream<CRMSourceEvent>> dataStreams = new ArrayList<>();
        List<CRMSource> crmSources = new ArrayList<>();

        String topic = null;
        String topicName = null;
        boolean isSpecificOffset = false;
        Long specificOffset = 0L;
        String topicId = null;
        // Configuration of the source function in the stream
        if (configuration.getBoolean("flink.kafka.consumer.account.coverage.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.account.coverage.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.account.coverage.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.account.coverage.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.account.coverage.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.account.coverage.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.call.log.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.call.log.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.call.log.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.call.log.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.call.log.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.call.log.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.call.report.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.call.report.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.call.report.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.call.report.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.call.report.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.call.report.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.contact.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.contact.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.contact.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.contact.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.contact.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.contact.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.contact.coverage.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.contact.coverage.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.contact.coverage.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.contact.coverage.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.contact.coverage.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.contact.coverage.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.organization.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.organization.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.organization.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.organization.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.organization.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.organization.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.user.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.user.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.user.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.user.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.user.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.user.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.user.role.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.user.role.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.user.role.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.user.role.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.user.role.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.user.role.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }
        if (configuration.getBoolean("flink.kafka.consumer.interest.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.interest.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.interest.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.interest.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.interest.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.interest.topic.ID", null);

            /*dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));*/
        }
        if (configuration.getBoolean("flink.kafka.consumer.account.desk.topic.status", false)) {
            topic = configuration.getString("flink.kafka.consumer.account.desk.topic", null);
            topicName = configuration.getString("flink.kafka.consumer.account.desk.topic.name", null);
            isSpecificOffset = configuration.getBoolean("flink.kafka.consumer.account.desk.topic.is.offset", false);
            specificOffset = configuration.getLong("flink.kafka.consumer.account.desk.topic.offset", 0L);
            topicId = configuration.getString("flink.kafka.consumer.account.desk.topic.ID", null);

            dataStreams.add(env.addSource(
                    new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                            specificOffset), info).uid(topicId).name(topicName).setParallelism(sourceParallelism));
            crmSources.add(new CRMSource(topic, topicName, kafkaConsumerGroup, dataFabricUtil, isSpecificOffset,
                    specificOffset));
        }

        DataStream<CRMSourceEvent> crmValueStream = null;
        if (dataStreams.size() > 0) {
            crmValueStream = dataStreams.get(0);
            for (int i = 1; i < dataStreams.size(); i++) {
                crmValueStream = crmValueStream.union(dataStreams.get(i));
            }
        } else {
            throw new RuntimeException("Exception running the " + configuration.getString("flink.job.name", null)
                    + " No Source Topic enabled");
        }

        DataStream<List<CRMSourceEvent> crmValueStream = null;
        if (crmSources.size() > 0) {
            crmValueStream = dataStreams.get(0);
            for (int i = 1; i < dataStreams.size(); i++) {
                crmValueStream = crmValueStream.union(dataStreams.get(i));
            }
        } else {
            throw new RuntimeException("Exception running the " + configuration.getString("flink.job.name", null)
                    + " No Source Topic enabled");
        }

        /* ******************************************************************************
         * STEP 2 - This will map the CRM Event to the flattened structures
         *          required by BDX
         ****************************************************************************** */

        // Configuration of the mapper function in the stream
        DataStream<XmartGenericSet> xmartCrmStream = crmValueStream.map(crmMapper).returns(XmartGenericSet.class)
                                                                   .uid(configuration
                                                                           .getString("operator.mapper.name", null))
                                                                   .name(configuration
                                                                           .getString("operator.mapper.name", null))
                                                                   .setParallelism(configuration
                                                                           .getInteger("operator.mapper.parallelism",
                                                                                   1));

        /* ******************************************************************************
         * STEP 3 - Aggregate using a count and time based window
         ****************************************************************************** */

        // Configuration of the keyed aggregation function in the stream
        DataStream<List<XmartGenericSet>> xmartBatchedCRMStream = xmartCrmStream.keyBy(new CRMKeySelector())
                                                                                .process(windowMapper).uid(configuration
                        .getString("operator.aggregate.window.name", null)).name(configuration
                        .getString("operator.aggregate.window.name", null)).setParallelism(
                        configuration.getInteger("operator.aggregate.window.parallelism", 1));

        /* ******************************************************************************
         * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
         *          database in the sink
         ****************************************************************************** */

        // Configuration of the XML mapper function in the stream
        String xmlConvOperator = configuration.getString("operator.convertor.xml.name", null);
        Integer xmlConvParallelism = configuration.getInteger("operator.convertor.xml.parallelism", 1);
        DataStream<XmartGenericXmlSet> xmartXmlStream = xmartBatchedCRMStream.map(xmlMapper).uid(xmlConvOperator)
                                                                             .name(xmlConvOperator)
                                                                             .setParallelism(xmlConvParallelism);

        /* ******************************************************************************
         * STEP 5 - Add the output sink
         ****************************************************************************** */
        String sinkName = configuration.getString("operator.sink.name", null);
        Integer sinkParallelism = configuration.getInteger("operator.sink.parallelism", 1);
        xmartXmlStream.addSink(sink).uid(sinkName).name(sinkName).setParallelism(sinkParallelism);

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {
            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(configuration.getString("flink.job.name", null));
        } catch (Exception e) {
            logger.error("Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException(
                    "Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
        }
    }
}
