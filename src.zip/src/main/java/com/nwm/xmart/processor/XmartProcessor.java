package com.nwm.xmart.processor;

import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * Created by aslammh on 04/08/17.
 */
public interface XmartProcessor extends BindObject {

    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration configuration)
            throws XmartException;
}
