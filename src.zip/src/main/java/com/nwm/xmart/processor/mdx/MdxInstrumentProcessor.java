package com.nwm.xmart.processor.mdx;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.keyselectors.XmartSetKeySelector;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.source.mdx.MdxRegulatorySource;
import com.nwm.xmart.streaming.source.mdx.MdxIsinSource;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.MdxEventType;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public class MdxInstrumentProcessor implements XmartProcessor {
    private static final Logger logger = LoggerFactory.getLogger(MdxInstrumentProcessor.class);
    private static final long serialVersionUID = 2788820519193417235L;

    private RichParallelSourceFunction sourceFunction;

    @Inject
    @Named("BdxSink")
    private XmartSink sink;

    @Inject
    @Named("XmartSourceEventMapper")
    private RichMapFunction<MdxDocumentEvent, XmartGenericSet> mdxMapper;

    @Inject
    @Named("XmartWindowMapper")
    private ProcessFunction<XmartGenericSet, List<XmartGenericSet>> windowMapper;

    @Inject
    @Named("XmartXmlMapper")
    private RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> xmlMapper;

    public MdxInstrumentProcessor() {
        // No initiation required
    }

    /**
     * Defines the procesing steps to complete and executes
     *
     * @param env    the Flink procesing stream that is to be initiated
     * @param config the flink Configuration used to control the processing
     *
     * @throws RuntimeException for hard Flink process failures not handled
     */
    @Override
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration config) throws XmartException {

        putJobNameInMDC(config);
        logger.debug("Entering configureAndExecuteStream MDX");

        /* ******************************************************************************
         * STEP 1 - Set up Mdx Consumer source
         ****************************************************************************** */

        final TypeInformation<MdxDocumentEvent> mdxSourceEventType = TypeInformation
                .of(new TypeHint<MdxDocumentEvent>() {
                });
        Class<MdxDocumentEvent> mdxSourceClassRef = mdxSourceEventType.getTypeClass();

        Integer sourceParallelism = config.getInteger("operator.source.parallelism", 1);

        List<DataStream<MdxDocumentEvent>> dataStreams = new ArrayList<>();

        if (config.getBoolean("mdx.src1.status", false)) {
            dataStreams.add(configureSrc1(env, config, mdxSourceClassRef, mdxSourceEventType, sourceParallelism));
        }
        if (config.getBoolean("mdx.src2.status", false)) {
            dataStreams.add(configureSrc2(env, config, mdxSourceClassRef, mdxSourceEventType, sourceParallelism));
        }
        if (config.getBoolean("mdx.src3.status", false)) {
            dataStreams.add(configureSrc3(env, config, mdxSourceClassRef, mdxSourceEventType, sourceParallelism));
        }
        if (config.getBoolean("mdx.src4.status", false)) {
            dataStreams.add(configureSrc4(env, config, mdxSourceClassRef, mdxSourceEventType, sourceParallelism));
        }
        if (config.getBoolean("mdx.src5.status", false)) {
            dataStreams.add(configureSrc5(env, config, mdxSourceClassRef, mdxSourceEventType, sourceParallelism));
        }

        DataStream<MdxDocumentEvent> joinedMdxStream = null;

        if (dataStreams.size() > 0) {
            joinedMdxStream = dataStreams.get(0);
            for (int i = 1; i < dataStreams.size(); i++) {
                joinedMdxStream = joinedMdxStream.union(dataStreams.get(i));
            }
        } else {
            throw new RuntimeException(
                    "Exception running the " + config.getString("flink.job.name", null) + " No Source enabled");
        }

        /* ******************************************************************************
         * STEP 2 - This will map the MDX Event to the flattened structures
         *          required by BDX
         ****************************************************************************** */
        DataStream<XmartGenericSet> xmartMdxStream = joinedMdxStream.map(mdxMapper).returns(XmartGenericSet.class)
                                                                    .uid(config.getString("operator.mapper.name", null))
                                                                    .name(config
                                                                            .getString("operator.mapper.name", null))
                                                                    .setParallelism(config.getInteger(
                                                                            "operator.mapper.parallelism", 1));

        /* ******************************************************************************
         * STEP 3 - Aggregate using a count and time based window
         ****************************************************************************** */
        // Configuration of the keyed aggregation function in the stream
        DataStream<List<XmartGenericSet>> xmartBatchedMdxStream = xmartMdxStream.keyBy(new XmartSetKeySelector())
                                                                                .process(windowMapper).uid(config
                        .getString("operator.aggregate.window.name", null)).name(config
                        .getString("operator.aggregate.window.name", null)).setParallelism(
                        config.getInteger("operator.aggregate.window.parallelism", 1));

        /* ******************************************************************************
         * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
         *          database in the sink
         ****************************************************************************** */
        // Configuration of the XML mapper function in the stream
        String xmlConvOperator = config.getString("operator.convertor.xml.name", null);
        Integer xmlConvParallelism = config.getInteger("operator.convertor.xml.parallelism", 1);
        DataStream<XmartGenericXmlSet> xmartXmlStream = xmartBatchedMdxStream.map(xmlMapper).uid(xmlConvOperator)
                                                                             .name(xmlConvOperator)
                                                                             .setParallelism(xmlConvParallelism);

        /* ******************************************************************************
         * STEP 5 - Add the output sink
         ****************************************************************************** */
        String sinkName = config.getString("operator.sink.name", null);
        Integer sinkParallelism = config.getInteger("operator.sink.parallelism", 1);
        xmartXmlStream.addSink(sink).uid(sinkName).name(sinkName).setParallelism(sinkParallelism);

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {
            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(config.getString("flink.job.name", null));
        } catch (Exception e) {
            logger.error("Exception running the " + config.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException("Exception running the " + config.getString("flink.job.name", null) + " job", e);
        }
    }

    private DataStream<MdxDocumentEvent> configureSrc1(StreamExecutionEnvironment env, Configuration configuration,
            Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType,
            Integer sourceParallelism) {
        String sourceName = configuration.getString("mdx.src1.sourceName", null);
        String sourceId = configuration.getString("mdx.src1.sourceId", null);

        SourceFunction<MdxDocumentEvent> src1 = new MdxIsinSource(sourceId, mdxSourceClassRef,
                configuration.getString("mdx.src1.initialLoad.identifier", null),
                configuration.getString("mdx.src1.initialLoad.identifier.wildcard", null),
                configuration.getString("mdx.src1.subscription.identifier", null),
                configuration.getString("mdx.src1.subscription.identifier.wildcard", null),
                configuration.getString("mdx.src1.sourceName", null), MdxEventType.SERIES_VIEW, MDXSessionType.SSO,
                configuration.getString("mdx.src1.sql.isin.query", null));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src1, mdxSourceEventType).uid(sourceId).name(sourceName)
                                                     .setParallelism(sourceParallelism);
        return dateStream;
    }

    private DataStream<MdxDocumentEvent> configureSrc2(StreamExecutionEnvironment env, Configuration configuration,
            Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType,
            Integer sourceParallelism) {
        String sourceName = configuration.getString("mdx.src2.sourceName", null);
        String sourceId = configuration.getString("mdx.src2.sourceId", null);

        SourceFunction<MdxDocumentEvent> src2 = new MdxIsinSource(sourceId, mdxSourceClassRef,
                configuration.getString("mdx.src2.initialLoad.identifier", null),
                configuration.getString("mdx.src2.initialLoad.identifier.wildcard", null),
                configuration.getString("mdx.src2.subscription.identifier", null),
                configuration.getString("mdx.src2.subscription.identifier.wildcard", null),
                configuration.getString("mdx.src2.sourceName", null), MdxEventType.SERIES_VIEW, MDXSessionType.SSO,
                configuration.getString("mdx.src2.sql.isin.query", null));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src2, mdxSourceEventType).uid(sourceId).name(sourceName)
                                                     .setParallelism(sourceParallelism);
        return dateStream;
    }

    private DataStream<MdxDocumentEvent> configureSrc3(StreamExecutionEnvironment env, Configuration configuration,
            Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType,
            Integer sourceParallelism) {
        String sourceName = configuration.getString("mdx.src3.sourceName", null);
        String sourceId = configuration.getString("mdx.src3.sourceId", null);

        SourceFunction<MdxDocumentEvent> src3 = new MdxIsinSource(sourceId, mdxSourceClassRef,
                configuration.getString("mdx.src3.initialLoad.identifier", null),
                configuration.getString("mdx.src3.initialLoad.identifier.wildcard", null),
                configuration.getString("mdx.src3.subscription.identifier", null),
                configuration.getString("mdx.src3.subscription.identifier.wildcard", null),
                configuration.getString("mdx.src3.sourceName", null), MdxEventType.SERIES_VIEW, MDXSessionType.SSO,
                configuration.getString("mdx.src3.sql.isin.query", null));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src3, mdxSourceEventType).uid(sourceId).name(sourceName)
                                                     .setParallelism(sourceParallelism);
        return dateStream;
    }

    private DataStream<MdxDocumentEvent> configureSrc4(StreamExecutionEnvironment env, Configuration configuration,
            Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType,
            Integer sourceParallelism) {
        String sourceName = configuration.getString("mdx.src4.sourceName", null);
        String sourceId = configuration.getString("mdx.src4.sourceId", null);

        SourceFunction<MdxDocumentEvent> src4 = new MdxIsinSource(sourceId, mdxSourceClassRef,
                configuration.getString("mdx.src4.initialLoad.identifier", null),
                configuration.getString("mdx.src4.initialLoad.identifier.wildcard", null),
                configuration.getString("mdx.src4.subscription.identifier", null),
                configuration.getString("mdx.src4.subscription.identifier.wildcard", null),
                configuration.getString("mdx.src4.sourceName", null), MdxEventType.TIME_SERIES, MDXSessionType.SSO,
                configuration.getString("mdx.src4.sql.isin.query", null));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src4, mdxSourceEventType).uid(sourceId).name(sourceName)
                                                     .setParallelism(sourceParallelism);
        return dateStream;
    }

    private DataStream<MdxDocumentEvent> configureSrc5(StreamExecutionEnvironment env, Configuration configuration,
            Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType,
            Integer sourceParallelism) {
        String sourceName = configuration.getString("mdx.src5.sourceName", null);
        String sourceId = configuration.getString("mdx.src5.sourceId", null);

        SourceFunction<MdxDocumentEvent> src5 = new MdxRegulatorySource(sourceId,
                configuration.getString("mdx.src5.sql.isin.query", null));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src5, mdxSourceEventType).uid(sourceId).name(sourceName)
                                                     .setParallelism(sourceParallelism);
        return dateStream;
    }
}
