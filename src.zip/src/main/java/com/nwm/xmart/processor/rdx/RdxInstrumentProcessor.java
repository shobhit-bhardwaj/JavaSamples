package com.nwm.xmart.processor.rdx;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.keyselectors.XmartSetKeySelector;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.nwm.xmart.streaming.source.rdx.RdxSource;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

/**
 * <p>Provides the stream processing pipeline definition for load of RDX Instruments.</p>
 * <p>The configureAndExecuteStream provides the main processing pipeline.<p/>
 *
 * @author heskets
 */
public class RdxInstrumentProcessor implements XmartProcessor {

    private static final Logger logger = LoggerFactory.getLogger(RdxInstrumentProcessor.class);

    //    @Inject
    //    @Named("XmartSource")
    //    private RichParallelSourceFunction sourceFunction;

    @Inject
    @Named("BdxSink")
    private XmartSink sink;

    @Inject
    @Named("XmartSourceEventMapper")
    private RichMapFunction<RDXSourceEvent, XmartGenericSet> transactionMapper;

    @Inject
    @Named("XmartWindowMapper")
    private ProcessFunction<XmartGenericSet, List<XmartGenericSet>> windowMapper;

    @Inject
    @Named("XmartXmlMapper")
    private RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> xmlMapper;

    public RdxInstrumentProcessor() {
        // No initiation required
    }

    /**
     * Defines the procesing steps to complete and executes
     *
     * @param env           the Flink procesing stream that is to be initiated
     * @param configuration the flink Configuration used to control the processing
     *
     * @throws RuntimeException for hard Flink process failures not handled
     */

    @Override
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration configuration)
            throws XmartException {

        putJobNameInMDC(configuration);
        logger.debug("Entering configureAndExecuteStream.");

        /* ******************************************************************************
         * STEP 1 - Set up Kafka Consumer source
         ****************************************************************************** */

        // Type info reqd for the FlinkDeserializer
        final TypeInformation<RDXSourceEvent> rdxSourceEventType = TypeInformation.of(new TypeHint<RDXSourceEvent>() {
        });
        Class<RDXSourceEvent> rdxSourceClassRef = rdxSourceEventType.getTypeClass();

        RichParallelSourceFunction<RDXSourceEvent> sourceFunction = new RdxSource<>(rdxSourceClassRef,
                "RDX Instrument Source");

        // Configuration of the source function in the stream
        DataStream<RDXSourceEvent> odcValueStream = env.addSource(sourceFunction, rdxSourceEventType)
                                                       .uid(configuration.getString("operator.source.name", null))
                                                       .name(configuration.getString("operator.source.name", null))
                                                       .setParallelism(configuration
                                                               .getInteger("operator.source.parallelism", 1));

        /* ******************************************************************************
         * STEP 2 - This will map the ODC Transaction to the flattened structures
         *          required by BDX
         ****************************************************************************** */

        // Configuration of the mapper function in the stream
        DataStream<XmartGenericSet> xmartTransactionStream = odcValueStream.map(transactionMapper)
                                                                           .returns(XmartGenericSet.class)
                                                                           .uid(configuration
                                                                                   .getString("operator.mapper.name",
                                                                                           null)).name(configuration
                        .getString("operator.mapper.name", null)).setParallelism(
                        configuration.getInteger("operator.mapper.parallelism", 1));

        /* ******************************************************************************
         * STEP 3 - Aggregate using a count and time based window
         ****************************************************************************** */

        // Configuration of the keyed aggregation function in the stream
        DataStream<List<XmartGenericSet>> xmartBatchedTransactionStream = xmartTransactionStream
                .keyBy(new XmartSetKeySelector()).process(windowMapper)
                .uid(configuration.getString("operator.aggregate.window.name", null))
                .name(configuration.getString("operator.aggregate.window.name", null))
                .setParallelism(configuration.getInteger("operator.aggregate.window.parallelism", 1));

        /* ******************************************************************************
         * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
         *          database in the sink
         ****************************************************************************** */

        // Configuration of the XML mapper function in the stream
        DataStream<XmartGenericXmlSet> xmartXmlStream = xmartBatchedTransactionStream.map(xmlMapper).uid(configuration
                .getString("operator.convertor.xml.name", null)).name(configuration
                .getString("operator.convertor.xml.name", null)).setParallelism(
                configuration.getInteger("operator.convertor.xml.parallelism", 1));

        /* ******************************************************************************
         * STEP 5 - Add the output sink
         ****************************************************************************** */

        xmartXmlStream.addSink(sink).uid(configuration.getString("operator.sink.name", null))
                      .name(configuration.getString("operator.sink.name", null))
                      .setParallelism(configuration.getInteger("operator.sink.parallelism", 1));

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {

            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(configuration.getString("flink.job.name", null));
        } catch (Exception e) {

            logger.error("Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException(
                    "Exception running the " + configuration.getString("flink.job.name", null) + " job", e);
        }
    }
}
