package com.nwm.xmart.processor.cashflows;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.keyselectors.CashFlowsKeySelector;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.monitor.GeneosPersistenceFile;
import com.nwm.xmart.streaming.monitor.InactiveKafkaMonitor;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.source.df.DataFabricFlinkKafkaSource;
import com.nwm.xmart.streaming.source.df.KafkaProperties;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.serialisation.FlinkDeserializer;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.rbs.odc.core.domain.ODCValue;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

//TODO This processor can be re-used for similar topologies.
public class CashFlowsProcessor implements XmartProcessor {

    private static final Logger logger = LoggerFactory.getLogger(CashFlowsProcessor.class);
    private static final long serialVersionUID = -469318148152677531L;

    @Inject
    @Named("BdxSink")
    private XmartSink sink;

    @Inject
    @Named("XmartOdcMapper")
    private RichMapFunction<DataFabricStreamEvent<ODCValue>, XmartGenericSet> cashFlowsMapper;

    @Inject
    @Named("XmartWindowMapper")
    private ProcessFunction<XmartGenericSet, List<XmartGenericSet>> windowMapper;

    @Inject
    @Named("XmartXmlMapper")
    private RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> xmlMapper;

    public CashFlowsProcessor() {
        // No initiation required
    }

    /**
     * Defines the procesing steps to complete and executes
     *
     * @param env    the Flink procesing stream that is to be initiated
     * @param config the flink Configuration used to control the processing
     *
     * @throws RuntimeException for hard Flink process failures not handled
     */
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration config)
            throws RuntimeException {

        putJobNameInMDC(config);
        logger.debug("Entering configureAndExecuteStream.");

        /* ******************************************************************************
         * STEP 1 - Set up Kafka Consumer source
         ****************************************************************************** */

        DataFabricUtil dataFabricUtil = new DataFabricUtil(config);

        // Type info reqd for the FlinkDeserializer
        final TypeInformation<DataFabricStreamEvent<ODCValue>> info = TypeInformation
                .of(new TypeHint<DataFabricStreamEvent<ODCValue>>() {
                });

        // Get the deserializer  source function and register with the error handling
        KeyedDeserializationSchema<DataFabricStreamEvent<ODCValue>> deserialiser = getDeserializer(config,
                dataFabricUtil, info);

        RichParallelSourceFunction sourceFunction = new DataFabricFlinkKafkaSource<DataFabricStreamEvent<ODCValue>>(
                dataFabricUtil, config, new KafkaProperties(config), deserialiser);

        // Configuration of the source function in the stream
        String sourceName = config.getString("operator.source.name", null);
        Integer sourceParallelism = config.getInteger("operator.source.parallelism", 1);

        DataStream<DataFabricStreamEvent<ODCValue>> odcValueStream = env.addSource(sourceFunction, info).uid(sourceName)
                                                                        .name(sourceName)
                                                                        .setParallelism(sourceParallelism);

        /* ******************************************************************************
         * STEP 2 - This will map the ODC Transaction to the flattened structures
         *          required by BDX
         ****************************************************************************** */

        // Configuration of the mapper function in the stream
        DataStream<XmartGenericSet> xmartCashFlowsStream = odcValueStream.map(cashFlowsMapper)
                                                                         .returns(XmartGenericSet.class).uid(config
                        .getString("operator.mapper.name", null)).name(config.getString("operator.mapper.name", null))
                                                                         .setParallelism(config.getInteger(
                                                                                 "operator.mapper.parallelism", 1));

        /* ******************************************************************************
         * STEP 3 - Aggregate using a count and time based window
         ****************************************************************************** */

        // Configuration of the keyed aggregation function in the stream
        DataStream<List<XmartGenericSet>> xmartBatchedCashFlowsStream = xmartCashFlowsStream
                .keyBy(new CashFlowsKeySelector()).process(windowMapper)
                .uid(config.getString("operator.aggregate.window.name", null))
                .name(config.getString("operator.aggregate.window.name", null))
                .setParallelism(config.getInteger("operator.aggregate.window.parallelism", 1));

        /* ******************************************************************************
         * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
         *          database in the sink
         ****************************************************************************** */

        // Configuration of the XML mapper function in the stream
        String xmlConvOperator = config.getString("operator.convertor.xml.name", null);
        Integer xmlConvParallelism = config.getInteger("operator.convertor.xml.parallelism", 1);
        DataStream<XmartGenericXmlSet> xmartXmlStream = xmartBatchedCashFlowsStream.map(xmlMapper).uid(xmlConvOperator)
                                                                                   .name(xmlConvOperator)
                                                                                   .setParallelism(xmlConvParallelism);

        /* ******************************************************************************
         * STEP 5 - Add the output sink
         ****************************************************************************** */
        String sinkName = config.getString("operator.sink.name", null);
        Integer sinkParallelism = config.getInteger("operator.sink.parallelism", 1);
        xmartXmlStream.addSink(sink).uid(sinkName).name(sinkName).setParallelism(sinkParallelism);

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {

            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(config.getString("flink.job.name", null));
        } catch (Exception e) {

            logger.error("Exception running the " + config.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException("Exception running the " + config.getString("flink.job.name", null) + " job", e);
        }
    }

    /**
     * initialises a Deserialisation object to use against the Fafka consumer
     *
     * @param configuration  the flink Configuration used to control the processing
     * @param dataFabricUtil utilities for DF Source Connection and Error Handling
     * @param info           identifies the type of object to be deserialised
     *
     * @return KeyedDeserializationSchema    the deserialiser class that is used by the Kafka consumer to convert the stored DF recrds to ODCValue objects
     */
    private KeyedDeserializationSchema<DataFabricStreamEvent<ODCValue>> getDeserializer(Configuration configuration,
            DataFabricUtil dataFabricUtil, TypeInformation<DataFabricStreamEvent<ODCValue>> info) {

        InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration,
                new GeneosPersistenceFile(configuration));

        Class<DataFabricStreamEvent<ODCValue>> sourceRef = info.getTypeClass();

        // get the deserializer itself
        return new FlinkDeserializer<DataFabricStreamEvent<ODCValue>, ODCValue, ODCValue>(dataFabricUtil, sourceRef,
                ODCValue.class, inactivityMonitor, configuration);
    }
}
