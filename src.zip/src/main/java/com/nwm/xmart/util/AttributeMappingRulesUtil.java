package com.nwm.xmart.util;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.BusinessDate;
import com.rbs.odc.access.domain.ODCEnumeration;
import rbs.gbm.mdx.webService.impl.MdxValuationDate;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.DateUtil.formatDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

/**
 * Created by heskets on 15/01/2018.
 */
public class AttributeMappingRulesUtil {
    private static final DateTimeFormatter MDX_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

    public static String mapBusinessDate(Object businessDate) throws XmartException {

        if (isNull(businessDate)) {
            return null;
        }

        Date date = convertBusinessDate((BusinessDate) businessDate);

        return formatDate(date);
    }

    public static String mapTestString(Object testString) throws XmartException {

        if (isNull(testString)) {
            return "MODIFIED";
        }

        return "MODIFIED-" + testString;
    }

    public static String mapODCEnumeration(Object enumeration) throws XmartException {

        if (isNull(enumeration)) {
            return null;
        }

        return getStr((ODCEnumeration) enumeration);
    }

    public static String mapCharArray(Object charArray) throws XmartException {

        if (isNull(charArray)) {
            return null;
        }

        if (!charArray.getClass().getSimpleName().equals("char[]")) {
            throw new XmartException(
                    "KDB object does not include a char array - type: " + charArray.getClass().getSimpleName());
        }

        return String.valueOf((char[]) charArray);
    }

    public static String mapKdbObjectArrayFirstString(Object stringArray) throws XmartException {

        if (isNull(stringArray)) {
            return null;
        }

        if (((Object[]) stringArray).length <= 0) {
            return null;
        }

        if (!((Object[]) stringArray)[0].getClass().getSimpleName().equals("char[]")) {
            throw new XmartException(
                    "KDB array does not include a char array - type: " + ((Object[]) stringArray)[0].getClass()
                                                                                                    .getSimpleName());
        }

        return new String((char[]) ((Object[]) stringArray)[0]);
    }

    public static String mapKdbStringArrayFirstString(Object stringArray) throws XmartException {

        if (isNull(stringArray)) {
            return null;
        }

        if (((String[]) stringArray).length <= 0) {
            return null;
        }

        if (!((String[]) stringArray)[0].getClass().getSimpleName().equals("String")) {
            throw new XmartException(
                    "KDB array does not include a char array - type: " + ((Object[]) stringArray)[0].getClass()
                                                                                                    .getSimpleName());
        }

        return ((String[]) stringArray)[0];
    }

    public static LocalDate mapMdxValuationDate(Object obj) throws XmartException {

        if (isNull(obj)) {
            return null;
        }

        if (!MdxValuationDate.class.isInstance(obj)) {
            throw new XmartException("Object is not a valid MdxValuationDate");
        }

        MdxValuationDate mdxValuationDate = (MdxValuationDate) obj;

        return LocalDate.of(mdxValuationDate.getYear(), mdxValuationDate.getMonth(), mdxValuationDate.getDay());
    }

    public static LocalDate mapMdxQuoteDate(Object quoteDate) throws XmartException {

        if (isNull(quoteDate)) {
            return null;
        }

        if (!String.class.isInstance(quoteDate)) {
            throw new XmartException("Object is not a valid String");
        }

        return LocalDate.parse((String) quoteDate, MDX_DATE_FORMATTER);
    }

    public static String getStringAfterLastForwardSlash(Object input) throws XmartException {

        if (isNull(input)) {
            return null;
        }

        String inputString = (String) input;
        if (inputString.isEmpty()) {
            return null;
        }

        String[] splitString = inputString.split("/");

        return splitString[splitString.length - 1];
    }
}
