package com.nwm.xmart.util;

import com.nwm.xmart.core.BindObject;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.util.Objects.nonNull;

public class ReflectionUtil implements BindObject {

    private ReflectionUtil() {
        // do not allow to create the instance
    }

    public static <T> boolean isPopulated(Field field, T entity) {
        field.setAccessible(true);
        try {
            Object fieldValue = field.get(entity);
            return (nonNull(fieldValue));
        } catch (IllegalAccessException e) {
            //e.printStackTrace();
            // Can be ignored as the access to the current field has already given.
        }
        return false;
    }

    // Helper method just to check if the required no of fields are marked with XmlAttribute. This will help in unit and functional testing
    public static int getAnnotatedFieldCount(Class theClass, Class annotationClass) {
        Field[] allFields = getFields(theClass);
        int count = 0;
        if (allFields != null && allFields.length > 0) {
            for (Field field : allFields) {
                Annotation[] allAnnotationsOnThisField = field.getAnnotationsByType(annotationClass);
                if (allAnnotationsOnThisField != null && allAnnotationsOnThisField.length > 0) {
                    count = count + allAnnotationsOnThisField.length;
                }
            }
        }
        return count;
    }

    /*
    Fetches all the fields declared in the class and its parent
     */
    public static <T> Field[] getFields(Class clazz) {
        List<Field> fieldList = new ArrayList<>();

        while (clazz != Object.class) {
            fieldList.addAll(Arrays.asList(clazz.getDeclaredFields()));
            clazz = clazz.getSuperclass();
        }
        Field[] fields = new Field[fieldList.size()];
        return fieldList.toArray(fields);
    }
}
