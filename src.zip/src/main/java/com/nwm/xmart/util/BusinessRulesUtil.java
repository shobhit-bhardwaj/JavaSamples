package com.nwm.xmart.util;

import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.entities.kdb.*;
import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.core.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.kdb.c;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.StringTokenizer;

import static com.nwm.xmart.util.DateUtil.formatTime;
import static com.nwm.xmart.util.DateUtil.parseStringAsLocalDate;
import static java.util.Objects.isNull;

/**
 * This class contains a set of static methods that are used by the BDX Mapping Nodes to apply
 * business logic to incoming data.
 *
 * @author heskets
 */
public class BusinessRulesUtil {

    private static final Logger logger = LoggerFactory.getLogger(BusinessRulesUtil.class);

    public static XmartKdbInquiryLegs extractFiRfqInquiryLegs(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String[] isin = (String[]) entity.getAttributeValue("raw_isin");
        int[] leg = (int[]) entity.getAttributeValue("raw_leg");
        double[] qty = (double[]) entity.getAttributeValue("raw_qty");
        String[] currency = (String[]) entity.getAttributeValue("raw_currency");
        double[] lastSentQuote = (double[]) entity.getAttributeValue("raw_lastSentQuote");
        double[] bestBidPrice = (double[]) entity.getAttributeValue("raw_bestBidPrice");
        double[] bestAskPrice = (double[]) entity.getAttributeValue("raw_bestAskPrice");
        double[] coverPrice = (double[]) entity.getAttributeValue("raw_coverPrice");
        String[] buySell = (String[]) entity.getAttributeValue("raw_buySell");
        double[] executedYield = (double[]) entity.getAttributeValue("raw_executedYield");
        Object[] reportingWaiverType = (Object[]) entity.getAttributeValue("raw_reportingWaiverType");

        // Check for NULL records
        if (isKdbNull(leg) || leg.length <= 0) {
            // No legs - return NULL
            return null;
        }

        if (isKdbNull(isin) || isKdbNull(qty) || isKdbNull(currency) || isKdbNull(lastSentQuote) || isKdbNull(
                bestBidPrice) || isKdbNull(bestAskPrice) || isKdbNull(coverPrice) || isKdbNull(buySell) || isKdbNull(
                executedYield) || isKdbNull(reportingWaiverType)) {
            throw new XmartException("Difference in number of inquiry Legs in leg arrays - one of the arrays is null");
        }

        if (isin.length != leg.length || qty.length != leg.length || currency.length != leg.length
                || lastSentQuote.length != leg.length || bestBidPrice.length != leg.length
                || bestAskPrice.length != leg.length || coverPrice.length != leg.length || buySell.length != leg.length
                || executedYield.length != leg.length || reportingWaiverType.length != leg.length) {
            throw new XmartException("Difference in number of inquiry Legs in leg arrays.");
        }

        XmartKdbInquiryLegs xmartKdbInquiryLegs = new XmartKdbInquiryLegs();

        for (int i = 0; i < leg.length; i++) {

            if (isKdbNull(leg[i])) {
                throw new XmartException("Missing leg Id in inquiry leg: " + i);
            }

            xmartKdbInquiryLegs.addInquiryLeg(
                    new XmartKdbInquiryLeg.XmartKdbInquiryLegBuilder().legIndex(Integer.toString(leg[i]))
                                                                      .notionalCcy(currency[i]).isin(isin[i])
                                                                      .notional(qty[i]).price(lastSentQuote[i])
                                                                      .buySell(buySell[i]).bestBidPrice(bestBidPrice[i])
                                                                      .bestAskPrice(bestAskPrice[i])
                                                                      .coverPrice(coverPrice[i]).yield(executedYield[i])
                                                                      .reportingWaiverType(
                                                                              !isKdbNull(reportingWaiverType[i]) ?
                                                                              String.valueOf(
                                                                                      (char[]) reportingWaiverType[i]) :
                                                                              null).create());
        }

        return xmartKdbInquiryLegs;
    }

    public static XmartKdbInquiryStates extractFiRfqInquiryStates(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        Object[] quotetype = (Object[]) entity.getAttributeValue("quotetype");
        java.util.Date[] convEventTime = (java.util.Date[]) entity.getAttributeValue("convEventTime");
        java.util.Date[] ecnEventTime = (java.util.Date[]) entity.getAttributeValue("ecnEventTime");
        java.util.Date[] executionTime = (java.util.Date[]) entity.getAttributeValue("executionTime");
        Object[] uniqueConvId = (Object[]) entity.getAttributeValue("uniqueConvId");

        // Check for NULL records
        if (isKdbNull(quotetype) || quotetype.length <= 0) {
            // No states - return NULL
            return null;
        }

        if (isKdbNull(convEventTime) || isKdbNull(ecnEventTime) || isKdbNull(executionTime) || isKdbNull(
                uniqueConvId)) {
            throw new XmartException(
                    "Difference in number of inquiry states in state arrays - one of the arrays is null");
        }

        if (convEventTime.length != quotetype.length || ecnEventTime.length != quotetype.length
                || executionTime.length != quotetype.length || uniqueConvId.length != quotetype.length) {
            throw new XmartException("Difference in number of inquiry states in state arrays.");
        }

        XmartKdbInquiryStates xmartKdbInquiryStates = new XmartKdbInquiryStates();

        for (int i = 0; i < quotetype.length; i++) {

            xmartKdbInquiryStates.addInquiryState(
                    new XmartKdbInquiryState(!isKdbNull(quotetype[i]) ? String.valueOf((char[]) quotetype[i]) : null,
                            ecnEventTime[i], null, null,
                            !isKdbNull(uniqueConvId[i]) ? String.valueOf((char[]) uniqueConvId[i]) : null, null,
                            executionTime[i]));
        }

        return xmartKdbInquiryStates;
    }

    public static XmartKdbInquiryStates extractFiQecInquiryStates(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        java.util.Date created_ts_modified = (java.util.Date) entity.getAttributeValue("created_ts_modified");
        java.util.Date quoted_ts_modified = (java.util.Date) entity.getAttributeValue("quoted_ts_modified");
        java.util.Date finished_ts_modified = (java.util.Date) entity.getAttributeValue("finished_ts_modified");
        java.util.Date executed_ts_modified = (java.util.Date) entity.getAttributeValue("executed_ts_modified");
        java.util.Date created_ts_original = (java.util.Date) entity.getAttributeValue("created_ts_original");
        java.util.Date quoted_ts_original = (java.util.Date) entity.getAttributeValue("quoted_ts_original");
        java.util.Date finished_ts_original = (java.util.Date) entity.getAttributeValue("finished_ts_original");
        java.util.Date executed_ts_original = (java.util.Date) entity.getAttributeValue("executed_ts_original");
        LocalDateTime kdbDateTime = extractKdbDateTime(entity);

        XmartKdbInquiryStates xmartKdbInquiryStates = new XmartKdbInquiryStates();

        if (!isKdbNull(created_ts_modified)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Created Modified", created_ts_modified));
        }
        if (!isKdbNull(quoted_ts_modified)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Quoted Modified", quoted_ts_modified));
        }
        if (!isKdbNull(finished_ts_modified)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Finished Modified", finished_ts_modified));
        }
        if (!isKdbNull(executed_ts_modified)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Executed Modified", executed_ts_modified));
        }
        if (!isKdbNull(created_ts_original)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Created Original", created_ts_original));
        }
        if (!isKdbNull(quoted_ts_original)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Quoted Original", quoted_ts_original));
        }
        if (!isKdbNull(finished_ts_original)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Finished Original", finished_ts_original));
        }
        if (!isKdbNull(executed_ts_original)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Executed Original", executed_ts_original));
        }
        if (!isKdbNull(kdbDateTime)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("KDB DateTime", kdbDateTime));
        }

        return xmartKdbInquiryStates;
    }

    public static XmartKdbInquiryStates extractFxRfqInquiryStates(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        java.sql.Timestamp rfq_quote_request_transact_time = (java.sql.Timestamp) entity
                .getAttributeValue("rfq_quote_request_transact_time");
        java.sql.Time rfq_order_time = (java.sql.Time) entity.getAttributeValue("rfq_order_time");
        java.sql.Timestamp rfq_order_transact_time = (java.sql.Timestamp) entity
                .getAttributeValue("rfq_order_transact_time");
        java.sql.Timestamp sending_time = (java.sql.Timestamp) entity.getAttributeValue("sending_time");
        java.sql.Timestamp received_time = (java.sql.Timestamp) entity.getAttributeValue("received_time");
        java.sql.Timestamp rfq_execution_ack_transact_time = (java.sql.Timestamp) entity
                .getAttributeValue("rfq_execution_ack_transact_time");
        java.sql.Timestamp rfq_execution_report_transact_time = (java.sql.Timestamp) entity
                .getAttributeValue("rfq_execution_report_transact_time");

        java.sql.Date date = (java.sql.Date) entity.getAttributeValue("quoteDate");

        java.sql.Timestamp[] rate_send_time = (java.sql.Timestamp[]) entity.getAttributeValue("rate_send_time");
        String[] status = (String[]) entity.getAttributeValue("status");
        java.sql.Timestamp[] request_time = (java.sql.Timestamp[]) entity.getAttributeValue("request_time");
        int[] rfq_price_quote_idx = (int[]) entity.getAttributeValue("rfq_price_quote_idx");
        String[] tradability_status = (String[]) entity.getAttributeValue("tradability_status");

        XmartKdbInquiryStates xmartKdbInquiryStates = new XmartKdbInquiryStates();

        if (!isKdbNull(rfq_quote_request_transact_time)) {
            xmartKdbInquiryStates.addInquiryState(
                    new XmartKdbInquiryState("Rfq Quote Request Transact Time", rfq_quote_request_transact_time));
        }
        if (!isKdbNull(rfq_order_time) && !isKdbNull(date)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Rfq Order Time",
                    date.toLocalDate().atTime(LocalTime.parse(formatTime(rfq_order_time)))));
        }
        if (!isKdbNull(rfq_order_transact_time)) {
            xmartKdbInquiryStates
                    .addInquiryState(new XmartKdbInquiryState("Rfq Order Transact Time", rfq_order_transact_time));
        }
        if (!isKdbNull(sending_time)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Sending Time", sending_time));
        }
        if (!isKdbNull(received_time)) {
            xmartKdbInquiryStates.addInquiryState(new XmartKdbInquiryState("Received Time", received_time));
        }
        if (!isKdbNull(rfq_execution_ack_transact_time)) {
            xmartKdbInquiryStates.addInquiryState(
                    new XmartKdbInquiryState("Rfq Execution Ack Transact Time", rfq_execution_ack_transact_time));
        }
        if (!isKdbNull(rfq_execution_report_transact_time)) {
            xmartKdbInquiryStates.addInquiryState(
                    new XmartKdbInquiryState("Rfq Execution Report Transact Time", rfq_execution_report_transact_time));
        }

        if (!isKdbNull(rate_send_time) && rate_send_time.length > 0) {

            if (isKdbNull(status) || isKdbNull(request_time) || isKdbNull(rfq_price_quote_idx) || isKdbNull(
                    tradability_status)) {
                throw new XmartException(
                        "Difference in number of inquiry states in state arrays - one of the arrays is null");
            }

            if (status.length != rate_send_time.length || request_time.length != rate_send_time.length
                    || rfq_price_quote_idx.length != rate_send_time.length
                    || tradability_status.length != rate_send_time.length) {
                throw new XmartException("Difference in number of inquiry states in state arrays.");
            }

            if (!status[0].getClass().getSimpleName().equals("String")) {
                throw new XmartException(
                        "KDB status array does not include a String array - type: " + status[0].getClass()
                                                                                               .getSimpleName());
            }

            for (int i = 0; i < rate_send_time.length; i++) {
                if (!isKdbNull(status[i]) && !isKdbNull(rate_send_time[i])) {
                    xmartKdbInquiryStates.addInquiryState(
                            new XmartKdbInquiryState(status[i], rate_send_time[i], tradability_status[i], null,
                                    ((Integer) rfq_price_quote_idx[i]).toString(), null, request_time[i]));
                }
            }
        }

        return xmartKdbInquiryStates;
    }

    public static XmartKdbInquiryStates extractFxOmsInquiryStates(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String[] exec_type = (String[]) entity.getAttributeValue("exec_type");
        String[] ord_status = (String[]) entity.getAttributeValue("ord_status");
        Object[] exec_id = (Object[]) entity.getAttributeValue("exec_id");
        double[] avg_fill_price = (double[]) entity.getAttributeValue("avg_fill_price");

        // Check for NULL records
        if (isKdbNull(exec_type) || exec_type.length <= 0) {
            // No states - return NULL
            return null;
        }

        if (isKdbNull(ord_status) || isKdbNull(exec_id) || isKdbNull(avg_fill_price)) {
            throw new XmartException(
                    "Difference in number of inquiry states in state arrays - one of the arrays is null");
        }

        if (ord_status.length != exec_type.length || exec_id.length != exec_type.length
                || avg_fill_price.length != exec_type.length) {
            throw new XmartException("Difference in number of inquiry states in state arrays.");
        }

        XmartKdbInquiryStates xmartKdbInquiryStates = new XmartKdbInquiryStates();

        for (int i = 0; i < exec_type.length; i++) {
            if (!isKdbNull(exec_type[i]) && exec_type[i].length() > 0) {
                xmartKdbInquiryStates.addInquiryState(
                        new XmartKdbInquiryState(exec_type[i], ord_status[i], String.valueOf((char[]) exec_id[i]),
                                avg_fill_price[i]));
            }
        }

        return xmartKdbInquiryStates;
    }

    public static XmartKdbInquiryStates extractFxHftInquiryStates(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        java.sql.Timestamp[] src_sent_ts = (java.sql.Timestamp[]) entity.getAttributeValue("src_sent_ts");
        short[] sample_id = (short[]) entity.getAttributeValue("sample_id");

        // Check for NULL records
        if (isKdbNull(src_sent_ts) || src_sent_ts.length <= 0) {
            // No states - return NULL
            return null;
        }

        if (isKdbNull(sample_id)) {
            throw new XmartException(
                    "Difference in number of inquiry states in state arrays - one of the arrays is null");
        }

        if (sample_id.length != src_sent_ts.length) {
            throw new XmartException("Difference in number of inquiry states in state arrays.");
        }

        XmartKdbInquiryStates xmartKdbInquiryStates = new XmartKdbInquiryStates();

        for (int i = 0; i < src_sent_ts.length; i++) {
            if (!isKdbNull(sample_id[i]) && !isKdbNull(src_sent_ts[i])) {
                xmartKdbInquiryStates
                        .addInquiryState(new XmartKdbInquiryState(String.valueOf(sample_id[i]), src_sent_ts[i]));
            }
        }

        return xmartKdbInquiryStates;
    }

    public static XmartKdbInquiryAltRefs extractFxOmsInquiryAltRefs(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String order_id = (String) entity.getAttributeValue("order_id");
        String parent_order_id = (String) entity.getAttributeValue("parent_order_id");
        String ord_link_id = (String) entity.getAttributeValue("ord_link_id");
        String parent_ord_link_id = (String) entity.getAttributeValue("parent_ord_link_id");

        XmartKdbInquiryAltRefs xmartKdbInquiryAltRefs = new XmartKdbInquiryAltRefs();

        if (!isKdbNull(order_id) && !order_id.isEmpty()) {
            xmartKdbInquiryAltRefs.addInquiryAltRef(new XmartKdbInquiryAltRef("Order Identifier", order_id));
        }
        if (!isKdbNull(parent_order_id) && !parent_order_id.isEmpty()) {
            xmartKdbInquiryAltRefs
                    .addInquiryAltRef(new XmartKdbInquiryAltRef("Parent Order Identifier", parent_order_id));
        }
        if (!isKdbNull(ord_link_id) && !ord_link_id.isEmpty()) {
            xmartKdbInquiryAltRefs.addInquiryAltRef(new XmartKdbInquiryAltRef("Order Link Identifier", ord_link_id));
        }
        if (!isKdbNull(parent_ord_link_id) && !parent_ord_link_id.isEmpty()) {
            xmartKdbInquiryAltRefs
                    .addInquiryAltRef(new XmartKdbInquiryAltRef("Parent Order Link Identifier", parent_ord_link_id));
        }

        return xmartKdbInquiryAltRefs;
    }

    public static XmartKdbInquiryAltRefs extractFxRfqInquiryAltRefs(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String rfq_req_id = (String) entity.getAttributeValue("rfq_req_id");
        String quote_request_id = (String) entity.getAttributeValue("quote_request_id");

        XmartKdbInquiryAltRefs xmartKdbInquiryAltRefs = new XmartKdbInquiryAltRefs();

        if (!isKdbNull(rfq_req_id) && !rfq_req_id.isEmpty()) {
            xmartKdbInquiryAltRefs.addInquiryAltRef(new XmartKdbInquiryAltRef("RFQ Request Identifier", rfq_req_id));
        }
        if (!isKdbNull(quote_request_id) && !quote_request_id.isEmpty()) {
            xmartKdbInquiryAltRefs.addInquiryAltRef(new XmartKdbInquiryAltRef("Quote Request ID", quote_request_id));
        }

        return xmartKdbInquiryAltRefs;
    }

    public static XmartKdbInquiryLegs extractFiQecInquiryLegs(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String[] cfi_code = (String[]) entity.getAttributeValue("cfi_code");
        String[] delivery_type = (String[]) entity.getAttributeValue("delivery_type");
        java.sql.Timestamp[] maturity_ts = (java.sql.Timestamp[]) entity.getAttributeValue("maturity_ts");
        String[] instrument_identification_code = (String[]) entity.getAttributeValue("instrument_identification_code");
        Object[] component_id = (Object[]) entity.getAttributeValue("component_id");
        double[] initial_quantity = (double[]) entity.getAttributeValue("initial_quantity");
        String[] currency = (String[]) entity.getAttributeValue("currency");
        double[] raw_price = (double[]) entity.getAttributeValue("raw_price");
        double[] strike_price_of_option = (double[]) entity.getAttributeValue("strike_price_of_option");
        String[] option_type = (String[]) entity.getAttributeValue("option_type");
        String[] direction_of_trade = (String[]) entity.getAttributeValue("direction_of_trade");
        String[] leg_products = (String[]) entity.getAttributeValue("leg_products");

        XmartKdbInquiryLegs xmartKdbInquiryLegs = new XmartKdbInquiryLegs();

        if (!isKdbNull(cfi_code) && cfi_code.length > 0) {

            if (isKdbNull(delivery_type) || isKdbNull(maturity_ts) || isKdbNull(instrument_identification_code)
                    || isKdbNull(component_id) || isKdbNull(initial_quantity) || isKdbNull(currency) || isKdbNull(
                    raw_price) || isKdbNull(strike_price_of_option) || isKdbNull(option_type) || isKdbNull(
                    direction_of_trade) || isKdbNull(leg_products)) {
                throw new XmartException(
                        "Difference in number of inquiry Legs in leg arrays - one of the arrays is null");
            }

            if (delivery_type.length != cfi_code.length || maturity_ts.length != cfi_code.length
                    || instrument_identification_code.length != cfi_code.length
                    || component_id.length != cfi_code.length || initial_quantity.length != cfi_code.length
                    || currency.length != cfi_code.length || raw_price.length != cfi_code.length
                    || strike_price_of_option.length != cfi_code.length || option_type.length != cfi_code.length
                    || direction_of_trade.length != cfi_code.length || leg_products.length != cfi_code.length) {

                throw new XmartException("Difference in number of inquiry legs in leg arrays.");
            }

            for (int i = 0; i < cfi_code.length; i++) {

                if (!isKdbNull(component_id[i]) && !component_id[i].getClass().getSimpleName().equals("char[]")) {
                    throw new XmartException(
                            "KDB component_id array does not include a char[] array - type: " + component_id[i]
                                    .getClass().getSimpleName());
                }

                xmartKdbInquiryLegs.addInquiryLeg(new XmartKdbInquiryLeg.XmartKdbInquiryLegBuilder()
                        .legIndex(!isKdbNull(component_id[i]) ? new String((char[]) component_id[i]) : null)
                        .notionalCcy(currency[i]).cfiCode(cfi_code[i]).deliveryType(delivery_type[i])
                        .expiryDate(maturity_ts[i]).isin(instrument_identification_code[i])
                        .notional(initial_quantity[i]).price(raw_price[i]).strike(strike_price_of_option[i])
                        .buySell(direction_of_trade[i]).optionType(option_type[i]).product(leg_products[i]).create());
            }
        }

        return xmartKdbInquiryLegs;
    }

    public static XmartKdbInquiryLegs extractFxHftInquiryLegs(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String currencyPair = (String) entity.getAttributeValue("currencyPair");
        Double volume = (Double) entity.getAttributeValue("volume");
        Double volume_in_terms_currency = (Double) entity.getAttributeValue("volume_in_terms_currency");

        if (isKdbNull(currencyPair) || currencyPair.length() != 6) {
            logger.warn("Missing or invalid FX HFT currency pair:" + currencyPair);
            return null;
        }

        XmartKdbInquiryLegs xmartKdbInquiryLegs = new XmartKdbInquiryLegs();

        xmartKdbInquiryLegs.addInquiryLeg(new XmartKdbInquiryLeg.XmartKdbInquiryLegBuilder().legIndex("Base")
                                                                                            .notionalCcy(currencyPair
                                                                                                    .substring(0, 3))
                                                                                            .notional(volume).create());
        xmartKdbInquiryLegs.addInquiryLeg(new XmartKdbInquiryLeg.XmartKdbInquiryLegBuilder().legIndex("Terms")
                                                                                            .notionalCcy(currencyPair
                                                                                                    .substring(3, 6))
                                                                                            .notional(
                                                                                                    volume_in_terms_currency)
                                                                                            .create());

        return xmartKdbInquiryLegs;
    }

    public static XmartKdbInquiryLegs extractFxRfqInquiryLegs(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        Object[] leg_security_id = (Object[]) entity.getAttributeValue("raw_leg_security_id");
        String[] security_type = (String[]) entity.getAttributeValue("raw_security_type");
        Date[] settl_date = (Date[]) entity.getAttributeValue("raw_settl_date");
        String[] isin_code = (String[]) entity.getAttributeValue("raw_isin_code");
        double[] quantity = (double[]) entity.getAttributeValue("raw_quantity");
        String[] bank_buy_sell = (String[]) entity.getAttributeValue("raw_bank_buy_sell");
        Date[] option_date = (Date[]) entity.getAttributeValue("raw_option_date");

        // Check for NULL records
        if (isKdbNull(leg_security_id) || leg_security_id.length <= 0) {
            // No legs - return NULL
            return null;
        }

        if (isKdbNull(security_type) || isKdbNull(settl_date) || isKdbNull(isin_code) || isKdbNull(quantity)
                || isKdbNull(bank_buy_sell) || isKdbNull(option_date)) {
            throw new XmartException("Difference in number of inquiry legs in leg arrays - one of the arrays is null");
        }

        if (security_type.length != leg_security_id.length || settl_date.length != leg_security_id.length
                || isin_code.length != leg_security_id.length || quantity.length != leg_security_id.length
                || bank_buy_sell.length != leg_security_id.length || option_date.length != leg_security_id.length) {
            throw new XmartException("Difference in number of inquiry legs in leg arrays.");
        }

        XmartKdbInquiryLegs xmartKdbInquiryLegs = new XmartKdbInquiryLegs();

        for (int i = 0; i < leg_security_id.length; i++) {

            xmartKdbInquiryLegs.addInquiryLeg(new XmartKdbInquiryLeg.XmartKdbInquiryLegBuilder().legIndex(
                    !isKdbNull(leg_security_id) && !isKdbNull(leg_security_id[i]) ?
                    new String((char[]) leg_security_id[i]) : null).deliveryType(
                    !isKdbNull(security_type) && !isKdbNull(security_type[i]) ? security_type[i] : null).expiryDate(
                    !isKdbNull(settl_date) && !isKdbNull(settl_date[i]) ? settl_date[i] : null).isin(!isKdbNull(
                    isin_code) && !isKdbNull(isin_code[i]) ? isin_code[i] : null).notional(
                    !isKdbNull(quantity) && !isKdbNull(quantity[i]) ? quantity[i] : null).buySell(
                    !isKdbNull(bank_buy_sell) && !isKdbNull(bank_buy_sell[i]) ? bank_buy_sell[i] : null).optionDate(
                    !isKdbNull(option_date) && !isKdbNull(option_date[i]) ? option_date[i] : null).create());
        }
        return xmartKdbInquiryLegs;
    }

    public static java.time.LocalDate extractKdbQecQuoteDate(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        java.sql.Timestamp created_ts = (java.sql.Timestamp) entity.getAttributeValue("created_ts_modified");

        if (isNull(created_ts)) {
            created_ts = (java.sql.Timestamp) entity.getAttributeValue("created_ts_original");
        }

        if (isNull(created_ts)) {
            return null;
        }

        return created_ts.toLocalDateTime().toLocalDate();
    }

    public static java.time.LocalDateTime extractKdbQecQuoteTime(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        java.sql.Timestamp created_ts = (java.sql.Timestamp) entity.getAttributeValue("created_ts_modified");

        if (isNull(created_ts)) {
            created_ts = (java.sql.Timestamp) entity.getAttributeValue("created_ts_original");
        }

        if (isNull(created_ts)) {
            return null;
        }

        return created_ts.toLocalDateTime();
    }

    public static java.time.LocalDateTime extractKdbDateTime(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

        java.sql.Date date = (java.sql.Date) entity.getAttributeValue("rawDate");
        java.sql.Time time = (java.sql.Time) entity.getAttributeValue("rawTime");

        String dateString = new SimpleDateFormat("yyyy-MM-dd").format(date);
        String timeString = new SimpleDateFormat("HH:mm:ss.SSS").format(time);

        // Check for NULL records
        if (isKdbNull(date) || isKdbNull(time)) {
            // Both arrays NULL - no Inquiry States
            return null;
        }

        return java.time.LocalDateTime.parse(dateString + " " + timeString, formatter);
    }

    public static java.time.LocalDateTime extractKdbDateTimeFromTimeStamp(XmartMappedEntity entity)
            throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

        java.sql.Date date = (java.sql.Date) entity.getAttributeValue("rawDate");
        java.sql.Timestamp timestamp = (java.sql.Timestamp) entity.getAttributeValue("rawTimestamp");

        String dateString = new SimpleDateFormat("yyyy-MM-dd").format(date);
        String timestampString = new SimpleDateFormat("HH:mm:ss.SSS").format(timestamp);

        // Check for NULL records
        if (isKdbNull(date) || isKdbNull(timestampString)) {
            // Both arrays NULL - no Inquiry States
            return null;
        }

        return java.time.LocalDateTime.parse(dateString + " " + timestampString, formatter);
    }

    public static java.time.LocalDateTime extractTDXAgreementDateTime(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

        String date = (String) entity.getAttributeValue("agreementDate");
        String time = (String) entity.getAttributeValue("agreementTime");
        String dateString = null;
        String timeString = null;

        if (StringUtils.isNotEmpty(date)) {
            StringTokenizer st = new StringTokenizer(date, "T");
            dateString = st.nextToken();

            if (StringUtils.isNotEmpty(time)) {
                timeString = time;
            } else {
                timeString = "00:00:00.000Z";
            }
        } else {
            return null;
        }

        return java.time.LocalDateTime.parse(dateString + " " + timeString, formatter);
    }

    public static String getTxStateEffectiveDateTime(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String stateTransitionEffectiveDateTime = (String) entity.getAttributeValue("stateTransitionEffectiveDateTime");
        String stateTransitionDateTime = (String) entity.getAttributeValue("stateTransitionDateTime");
        if (StringUtils.isNotEmpty(stateTransitionEffectiveDateTime)) {
            return stateTransitionEffectiveDateTime;
        }

        if (StringUtils.isNotEmpty(stateTransitionDateTime)) {
            return stateTransitionDateTime;
        }

        return null;
    }

    public static String getTxStateEffectiveDate(XmartMappedEntity entity) throws XmartException {

        if (isNull(entity)) {
            return null;
        }

        String date = (String) entity.getAttributeValue("transactionStateEffectiveDateTime");
        if (StringUtils.isNotEmpty(date)) {
            StringTokenizer st = new StringTokenizer(date, "T");
            return st.nextToken();
        } else {
            return null;
        }
    }

    public static String extractKdbSourceReference(XmartMappedEntity entity) throws XmartException {
        if (isNull(entity)) {
            return null;
        }
        Date quoteDate = (Date) entity.getAttributeValue("quoteDate");
        String clientOrderId = (String) entity.getAttributeValue("clientOrderId");

        // Check for NULL
        if (isKdbNull(quoteDate) || isKdbNull(clientOrderId)) {
            return null;
        }

        return quoteDate + "-" + clientOrderId;
    }

    public static boolean isKdbNull(Object obj) {
        return isNull(obj) || c.qn(obj);
    }

    public static LocalDate parseKdbStringAsLocalDate(XmartMappedEntity entity) throws XmartException {
        if (isNull(entity)) {
            return null;
        }
        String deliveryDateString = (String) entity.getAttributeValue("deliveryDateString");

        return parseStringAsLocalDate(deliveryDateString);
    }
}
