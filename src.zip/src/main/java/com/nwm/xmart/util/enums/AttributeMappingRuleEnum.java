package com.nwm.xmart.util.enums;

import com.rbs.odc.access.domain.BusinessDate;
import com.rbs.odc.access.domain.ODCEnumeration;

import java.lang.reflect.Type;

/**
 * Created by heskets on 16/01/2018.
 */
public enum AttributeMappingRuleEnum {

    mapBusinessDate("mapBusinessDate", BusinessDate.class),
    mapODCEnumeration("mapODCEnumeration", ODCEnumeration.class), mapTestString("mapTestString", String.class),
    mapKdbObjectArrayFirstString("mapKdbObjectArrayFirstString", String.class),
    mapKdbStringArrayFirstString("mapKdbStringArrayFirstString", String.class),
    mapMdxValuationDate("mapMdxValuationDate", String.class), mapMdxQuoteDate("mapMdxQuoteDate", String.class),
    getStringAfterLastForwardSlash("getStringAfterLastForwardSlash", String.class);

    private final String method;
    private final Type returnType;

    AttributeMappingRuleEnum(String method, Type returnType) {
        this.method = method;
        this.returnType = returnType;
    }

    public static boolean contains(String s) {
        for (AttributeMappingRuleEnum type : values())
            if (type.method.equals(s))
                return true;
        return false;
    }

    public static Type returnType(String s) {
        for (AttributeMappingRuleEnum type : values())
            if (type.method.equals(s))
                return type.returnType;
        return null;
    }

}
