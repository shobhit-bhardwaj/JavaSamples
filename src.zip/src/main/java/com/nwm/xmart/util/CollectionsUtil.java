package com.nwm.xmart.util;

import com.nwm.xmart.core.BindObject;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;

/**
 * Created by aslammh on 15/11/17.
 */
public class CollectionsUtil implements BindObject {

    private static final long serialVersionUID = 828623650284061291L;

    private CollectionsUtil() {
        // do not allow to create an instance
    }

    public static <T> boolean isNotEmpty(Collection<T> collection) {
        return !isEmptyOrNull(collection);
    }

    public static boolean isEmptyOrNull(Collection collection) {
        return (collection == null || collection.isEmpty());
    }

    public static <T> boolean isNotNull(T t) {
        return (t != null);
    }

    /**
     * Takes a collection and returns an empty collection when the collection is null.
     * Saves many null checks before the non mandatory collection items.
     *
     * @param coll {@link Collection} to check for null
     * @param <T>  Type.
     *
     * @return Empty collection {@link Collections#emptyList()} if the supplied collection is null.
     * The supplied collection is returned  otherwise.
     */
    public static <T> Collection<T> nullCollToEmpty(Collection<T> coll) {
        return coll == null ? Collections.<T>emptyList() : coll;
    }

    /**
     * Takes a map and returns an empty collection when the map is null.
     * Saves null checks before the non mandatory map items.
     *
     * @param map {@link Map} to be checked for
     * @param <K> Key
     * @param <V> Value
     *
     * @return Typed Empty map from {@link Collections#emptyMap()}
     */
    public static <K, V> Map<K, V> nullMapToEmpty(Map<K, V> map) {
        return map == null ? Collections.<K, V>emptyMap() : map;
    }

    /**
     * Takes a map and returns an empty collection when the map is null. It also logs this
     * conversion using the supplied {@link Logger} in the parameters.
     * Saves null checks before the non mandatory map items.
     *
     * @param map     {@link Map} to be checked for
     * @param logger  The logger using which the logging will be done. can be null.
     * @param <K>     Key
     * @param <V>     Value
     * @param message String that will be printed to the log in such case
     *
     * @return Typed Empty map from {@link Collections#emptyMap()}
     */
    public static <K, V> Map<K, V> nullMapToEmpty(Map<K, V> map, Logger logger, String message) {
        if (map == null && logger != null) {
            logger.warn(message);
        }
        return map == null ? Collections.<K, V>emptyMap() : map;
    }

    /**
     * Takes a collection and returns an empty collection when the collection is null. It also logs this
     * conversion using the supplied {@link Logger} in the parameters.
     * Saves many null checks before the non mandatory collection items.
     * Useful also for mandatory value containing collections.
     *
     * @param coll    {@link Collection} to check for null
     * @param logger  The logger using which the logging will be done. can be null.
     * @param <T>     Type of elements in the collection
     * @param message String that will be printed to the log in such case
     *
     * @return Empty collection {@link Collections#emptyList()} if the supplied collection is null.
     * The supplied collection is returned  otherwise.
     *
     * @apiNote Logging can be suppressed by supplying a null {@link Logger} in param,
     * or using {@link CollectionsUtil#nullCollToEmpty(Collection)}
     */
    public static <T> Collection<T> nullCollToEmpty(Collection<T> coll, Logger logger, String message) {
        if (coll == null && logger != null) {
            logger.warn(message);
        }
        return nullCollToEmpty(coll);
    }
}
