package com.nwm.xmart.util;

import com.nwm.xmart.core.BindObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;

public class XMLHelper implements BindObject {
    private static final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    private static final long serialVersionUID = 8190394644097432076L;
    private static final Logger logger = LoggerFactory.getLogger(XMLHelper.class);

    private static ThreadLocal<XPathFactory> xpathFactory = ThreadLocal.withInitial(() -> XPathFactory.newInstance());

    public static NodeList getAttributeNodeList(String xmlContent, String exprString) {
        DocumentBuilder builder;
        Document doc = null;
        NodeList nodeList = null;
        try {
            builder = factory.newDocumentBuilder();
            doc = builder.parse(new ByteArrayInputStream(xmlContent.getBytes("UTF-8")));

            XPath xpath = xpathFactory.get().newXPath();

            XPathExpression expr = xpath.compile(exprString);
            nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        } catch (SAXException | ParserConfigurationException | XPathExpressionException | IOException e) {
            logger.error("Xml Parsing Error {} {} ", e.getCause(), e.getMessage());
            throw new RuntimeException("Xml Parsing Error");
        }
        return nodeList;
    }
}
