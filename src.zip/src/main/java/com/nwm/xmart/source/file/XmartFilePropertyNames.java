package com.nwm.xmart.source.file;

/**
 * Property names for file processing jobs
 * mostly because of avoiding typos while using the property names in thousand places.
 *
 * @author vashpan
 */
public interface XmartFilePropertyNames {

    /**
     * Enabled or disabled
     */
    String ENABLED = "enabled";

    /**
     * source id
     */
    String ID = "sourceId";
    /**
     * source name
     */
    String NAME = "name";
    /**
     * source parallelism
     */
    String PARALLELISM = "parallelism";
    /**
     * file extension of the file to process e.g. CSV, DAT, MP4 etc
     */
    String FILE_EXTENSION = "extension";
    /**
     * Directory prefix to process.
     * <p>
     * e.g. RGLSegmentValues Zip in RGL File Processor
     */
    String DIR_PREFIX = "prefix.dir";
    /**
     * File name prefix to process.
     * <p>
     * e.g. CremantCVA in CremantCVA<date>.CSV
     */
    String FILE_PREFIX = "prefix";
    /**
     * File name suffix to add to the processed files to process.
     * <p>
     * e.g. CremantCVA in CremantCVA<date>-SMART_SALESDAY<date>.CSV
     */
    String PROCESSED_FILE_SUFFIX = "suffix";
    /**
     * Separator used in file records ', '|', ':' etc.
     */
    String SEPARATOR = "separator";
    /**
     * Location of the file to process and marker file.
     */
    String SHARED_FILE_LOCATION = "process.dir";
    /**
     * Folder location to move the processed file to.
     */
    String DONE_FILE_LOCATION = "done.dir";
    /**
     * folder location to put the error files in
     */
    String ERROR_FILE_LOCATION = "error.dir";
    /**
     * extension of the marker file for starting processing
     */
    String MARKER_FILE_EXT = "marker.ext";
    /**
     * threshold records for this file
     */
    String THRESHOLD_RECORDS = "threshold";
    /**
     * threshold deviation in percent
     */
    String DEVIATION_PERCENT_ERROR = "deviation.error";
    /**
     * Folder poll interval for looking up marker file
     */
    String FOLDER_POLL_INTERVAL = "poll.interval";
    /**
     * file source event type
     */
    String FILE_EVENT = "eventtype";
    /**
     * Minimun number of records that should be present in the file
     */
    String MIN_RECORDS = "minrecords";

    /**
     * Ignore lines starting with this prefix e.g. TAIL etc
     */
    String LINE_IGNORE_PREFIX = "ignore.prefix";

    /**
     * Date format to append to procesed file
     */
    String PROCESS_DATE_FORMAT = "date.format";
    /**
     * DB handler to handle the xml of this kind in database
     */
    String FILE_HANDLER_NAME = "db.handler";
    /**
     * Perform check for record count or for file size. can be one of RECORD_COUNT FILE_SIZE or NONE, both are picked from Database
     */
    String QUANTA_CHECK_TYPE = "quanta.check";
    /**
     * Record deviation for warning
     */
    String DEVIATION_PERCENT_WARN = "deviation.warn";
    /**
     * Environment to include in mail subject e.g UAT PROD DEV
     */
    String ENVIRONMENT = "mail.environment";
    /**
     * from mail address
     */
    String MAIL_FROM = "mail.from";
    /**
     * to mail address
     */
    String MAIL_TO = "mail.to";
    /**
     * how old file in days is to be rejected
     */
    String DAYS_OLD = "days.old";
    /**
     * Sort files on basis of. Can be one of MODIFIED_DATE (file modifed date) or BUSINESS_DATE (date in file name)
     */
    String FILE_SORT_TYPE = "sort.type";

    /**
     * Below variable holds the columns names from the Property file if the header is not available given file
     */
    String COLUMN_NAMES = "columnNames";
}
