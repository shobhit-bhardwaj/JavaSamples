package com.nwm.xmart.source.argon;

public enum ArgonMessageType {

    file_xfer("file_xfer"), sdmprod_file("sdmprod_file"), glproduct_file("glproduct_file"),
    ledgerbook_file("ledgerbook_file"), file_glbookset("file_glbookset"), message("message"),
    BDX_SDM_PRODUCT("BDX_SDM_PRODUCT"), BDX_SDM_GLPRODUCT("BDX_SDM_GLPRODUCT"),
    BDX_SDM_LEDGERBOOK("BDX_SDM_LEDGERBOOK"), BDX_SDM_GLBOOKSET("BDX_SDM_GLBOOKSET");

    private String typeStr;

    ArgonMessageType(String typeStr) {
        this.typeStr = typeStr;
    }

    public static boolean checkAvailability(String msgType) {
        for (ArgonMessageType argonMessageType : ArgonMessageType.values())
            if (msgType.equals(argonMessageType.name())) {
                return true;
            }

        return false;
    }

    public static boolean checkSDMAvailability(String msgType) {
        for (ArgonMessageType argonMessageType : ArgonMessageType.values())
            if (msgType.equals(BDX_SDM_PRODUCT.typeStr) || msgType.equals(BDX_SDM_GLPRODUCT.typeStr) || msgType
                    .equals(BDX_SDM_LEDGERBOOK.typeStr) || msgType.equals(BDX_SDM_GLBOOKSET.typeStr)) {
                return true;
            }

        return false;
    }

    @Override
    public String toString() {
        return this.typeStr;
    }
}

