package com.nwm.xmart.source.file.db.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * Entity for storing the resulset recievd from audit/extract proc
 * and additial details as updated during processing
 */
public class FileExtractEntity implements Serializable {

    // fields for old files record found in extract table
    //SELECT TOP 1 [FileExtractID], [FileName], [ExtractStart], [ExtractEnd], [RowCount]
    //           , [FileLastModified], [FileSize]
    private String previousFileName;
    private Date previousFileExtractStartDate;
    private Date previousFileExtractEndDate;
    private int previousFileRowCount;
    private Date previousFileLastModifiedDate;
    private int previousfileSize;
    private int previousFileExtractId;

    private int newFileExtractId;
    private long newFileRecordCount;
    private long newFileSize;
    private Date newFileModifiedDate;
    private Date newFileBusinessDate;

    public Date getNewFileModifiedDate() {
        return newFileModifiedDate;
    }

    public void setNewFileModifiedDate(Date newFileModifiedDate) {
        this.newFileModifiedDate = newFileModifiedDate;
    }

    public Date getNewFileBusinessDate() {
        return newFileBusinessDate;
    }

    public void setNewFileBusinessDate(Date newFileBusinessDate) {
        this.newFileBusinessDate = newFileBusinessDate;
    }

    /**
     * @return Count of records in curret file
     */
    public long getRecordCount() {
        return newFileRecordCount;
    }

    public void setRecordCount(long newFileRecorddCount) {
        this.newFileRecordCount = newFileRecorddCount;
    }

    public long getFileSize() {
        return newFileSize;
    }

    public void setFileSize(long newFileSize) {
        this.newFileSize = newFileSize;
    }

    public int getPreviousFileExtractId() {
        return previousFileExtractId;
    }

    public void setPreviousFileExtractId(int previousFileExtractId) {
        this.previousFileExtractId = previousFileExtractId;
    }

    public String getPreviousFileName() {
        return previousFileName;
    }

    public void setPreviousFileName(String previousFileName) {
        this.previousFileName = previousFileName;
    }

    public Date getPreviousFileExtractStartDate() {
        return previousFileExtractStartDate;
    }

    public void setPreviousFileExtractStartDate(Date previousFileExtractStartDate) {
        this.previousFileExtractStartDate = previousFileExtractStartDate;
    }

    public Date getPreviousFileExtractEndDate() {
        return previousFileExtractEndDate;
    }

    public void setPreviousFileExtractEndDate(Date previousFileExtractEndDate) {
        this.previousFileExtractEndDate = previousFileExtractEndDate;
    }

    public int getPreviousFileRowCount() {
        return previousFileRowCount;
    }

    public void setPreviousFileRowCount(int previousFileRowCount) {
        this.previousFileRowCount = previousFileRowCount;
    }

    public Date getPreviousFileLastModifiedDate() {
        return previousFileLastModifiedDate;
    }

    public void setPreviousFileLastModifiedDate(Date previousFileLastModifiedDate) {
        this.previousFileLastModifiedDate = previousFileLastModifiedDate;
    }

    public int getPreviousfileSize() {
        return previousfileSize;
    }

    public void setPreviousfileSize(int previousfileSize) {
        this.previousfileSize = previousfileSize;
    }

    public int getNewFileExtractId() {
        return newFileExtractId;
    }

    public void setNewFileExtractId(int newFileExtractId) {
        this.newFileExtractId = newFileExtractId;
    }

    @Override
    public String toString() {
        return "FileExtractEntity{" + "previousFileName='" + previousFileName + '\'' + ", previousFileExtractStartDate="
                + previousFileExtractStartDate + ", previousFileExtractEndDate=" + previousFileExtractEndDate
                + ", previousFileRowCount=" + previousFileRowCount + ", previousFileLastModifiedDate="
                + previousFileLastModifiedDate + ", previousfileSize=" + previousfileSize + ", previousFileExtractId="
                + previousFileExtractId + ", newFileExtractId=" + newFileExtractId + ", newFileRecordCount="
                + newFileRecordCount + ", newFileSize=" + newFileSize + ", newFileModifiedDate=" + newFileModifiedDate
                + ", newFileBusinessDate=" + newFileBusinessDate + '}';
    }
}
