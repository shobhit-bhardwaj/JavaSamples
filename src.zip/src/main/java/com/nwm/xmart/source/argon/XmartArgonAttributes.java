package com.nwm.xmart.source.argon;

import com.nwm.xmart.source.file.exeption.XmartFileAttributeException;
import com.nwm.xmart.sso.EncryptDecryptAES;
import org.apache.flink.configuration.Configuration;

import java.io.Serializable;

import static com.nwm.xmart.util.ParameterUtil.getValidLongParameter;
import static com.nwm.xmart.util.ParameterUtil.getValidStringParameter;
import static java.util.Objects.isNull;

/**
 * utilty class to hold the parameters related to a file for the specific source
 * source should be created with this object
 */
public class XmartArgonAttributes implements Serializable {

    private final Configuration parameters;
    private final Boolean enabled;
    private final String directory;
    private final String markerFileExtension;
    private final String argonSink;
    private final String argonSource;
    private final String argonPassword;
    private final Boolean ackMessages;
    private final String argonSettings;
    private final String argonConnectionSettings;
    private final String messageType;
    private final Long messageReceiveTimeout;
    private final String argonLogLevel;
    private final long sleepTime;
    private final Boolean enableFileSSL;
    private final String sourceId;

    private final String ignorefileExtension;

    /*
     * @param sourcePrefix the prefix that is appended to source specific configs in the properties, e.g. 'filesource1.', should include the '.'
     * @param parameters   Configuration to get from .
     */
    public XmartArgonAttributes(String sourcePrefix, Configuration config) {
        this.parameters = config;
        enabled = getValidBooleanParameter(sourcePrefix + XmartArgonPropertyNames.ENABLED, config);
        directory = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.DIRECTORY, config);
        markerFileExtension = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.MARKER_EXT, config);
        argonSink = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.RT_SINK, config);
        argonSource = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.RT_SOURCE, config);
        argonPassword = EncryptDecryptAES
                .decrypt(getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.RT_PASSWORD, config));
        ackMessages = getValidBooleanParameter(sourcePrefix + XmartArgonPropertyNames.ACK_MSG, config);
        argonSettings = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.ARGON_SETTINGS, config);
        argonConnectionSettings = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.ARGON_CONN_SETTINGS,
                config);
        messageType = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.MSG_TYPE, config);
        messageReceiveTimeout = getValidLongParameter(sourcePrefix + XmartArgonPropertyNames.MSG_TIMEOUT, config);
        argonLogLevel = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.LOG_LEVEL, config);
        sleepTime = getValidLongParameter(sourcePrefix + XmartArgonPropertyNames.SLEEP_TIME, config);
        enableFileSSL = getValidBooleanParameter(sourcePrefix + XmartArgonPropertyNames.FILE_SSL, config);
        ignorefileExtension = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.FILE_EXT, config);
        sourceId = getValidStringParameter(sourcePrefix + XmartArgonPropertyNames.SOURCE_ID, config);
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public Boolean getEnableFileSSL() {
        return enableFileSSL;
    }

    public long getSleepTime() {
        return sleepTime;
    }

    public String getArgonLogLevel() {
        return argonLogLevel;
    }

    public Long getMessageReceiveTimeout() {
        return messageReceiveTimeout;
    }

    public String getMessageType() {
        return messageType;
    }

    public String getArgonSettings() {
        return argonSettings;
    }

    public String getArgonConnectionSettings() {
        return argonConnectionSettings;
    }

    public Configuration getParameters() {
        return parameters;
    }

    public String getDirectory() {
        return directory;
    }

    public String getArgonSink() {
        return argonSink;
    }

    public String getArgonSource() {
        return argonSource;
    }

    public String getArgonPassword() {
        return argonPassword;
    }

    public Boolean getAckMessages() {
        return ackMessages;
    }

    public String getMarkerFileExtension() {
        return markerFileExtension;
    }

    public String getIgnorefileExtension() {
        return ignorefileExtension;
    }

    public String getSourceId() {
        return sourceId;
    }

    private Boolean getValidBooleanParameter(String paramName, Configuration parameters) {
        if (isNull(parameters)) {
            throw new XmartFileAttributeException(paramName + "is null");
        }
        return parameters.getBoolean(paramName, false);
    }

    @Override
    public String toString() {
        return "XmartArgonAttributes{" + "parameters=" + parameters + ", directory='" + directory + '\''
                + ", markerFileExtension='" + markerFileExtension + '\'' + ", argonSink='" + argonSink + '\''
                + ", argonSource='" + argonSource + '\'' + ", argonPassword='" + argonPassword + '\'' + ", ackMessages="
                + ackMessages + ", argonSettings='" + argonSettings + '\'' + ", argonConnectionSettings='"
                + argonConnectionSettings + '\'' + ", messageType='" + messageType + '\'' + ", messageReceiveTimeout="
                + messageReceiveTimeout + ", argonLogLevel='" + argonLogLevel + '\'' + ", sleepTime=" + sleepTime
                + ", enableFileSSL=" + enableFileSSL + ", sourceId=" + sourceId + ", ignorefileExtension="
                + ignorefileExtension + '}';
    }
}


