package com.nwm.xmart.source.argon;

import com.rbsfm.argon.client.cga.ReceivedMessage;

import java.io.Serializable;

public class XmartArgonEvent implements Serializable {
    private final String messageType;
    private final String sourceMessageType;
    private final String applicationId;
    private final int messageTypeVersion;
    private final String sourceClienNodeAddress;
    private final int sourceMessageTypVersion;

    //TODO will be used in future for different messages for file messages this has no relevance
    public XmartArgonEvent(ReceivedMessage receivedMessage) {
        this.messageType = receivedMessage.getMessageType();
        this.applicationId = receivedMessage.getApplicationID();
        this.sourceMessageType = receivedMessage.getSourceMessageType();
        this.messageTypeVersion = receivedMessage.getMessageTypeVersion();
        this.sourceClienNodeAddress = receivedMessage.getSourceClientNodeAddress().toString();
        this.sourceMessageTypVersion = receivedMessage.getSourceMessageTypeVersion();
    }

    @Override
    public String toString() {
        return "XmartArgonEvent{" + "messageType='" + messageType + '\'' + ", sourceMessageType='" + sourceMessageType
                + '\'' + ", applicationId='" + applicationId + '\'' + ", messageTypeVersion=" + messageTypeVersion
                + ", sourceClienNodeAddress='" + sourceClienNodeAddress + '\'' + ", sourceMessageTypVersion="
                + sourceMessageTypVersion + '}';
    }
}
