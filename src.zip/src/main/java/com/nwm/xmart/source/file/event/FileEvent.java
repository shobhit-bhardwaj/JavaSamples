package com.nwm.xmart.source.file.event;

import com.nwm.xmart.entities.file.XmartFileEventMetadata;
import com.nwm.xmart.source.file.exeption.XmartFileProcessingException;
import com.nwm.xmart.streaming.source.file.event.FileEventType;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static java.util.Objects.isNull;

/**
 * Event class to store the row from the fileInProcess being processed.
 * <p>
 * Attribute values are mapped to attribute names and can be got acordinlgy
 *
 * @author vashpan
 */
public class FileEvent implements Serializable {
    private final FileEventType fileEventType;
    private final int recordNumber;
    private final int auditId;
    private final String fileInProcess;
    private final long totalRecords;
    private final Map<String, String> attributeMap;
    private final XmartFileEventMetadata fileMetadata;

    /**
     * COntruct a new event with fileInProcess row
     *
     * @param fileEventType Event to be matched against source object value
     * @param recordNumber  number of this record in the file ( including the header)
     * @param fileInProcess Full canonical path of fileInProcess including the fileInProcess name.
     * @param recordCount   Total numbers of records that were in this fileInProcess
     * @param attribNames   String Array containing the names of attributes in this record
     * @param attribValues  String Array containing the values of attributes in this record
     *
     * @throws XmartFileProcessingException When the object can not be constructed due to mismatch in length of the attribNames and attribValues arrays.
     *                                      If the other parameters supplied are null
     */
    public FileEvent(FileEventType fileEventType, int recordNumber, String fileInProcess, int fileAuditId,
            long recordCount, String[] attribNames, String[] attribValues,
            XmartFileEventMetadata xmartFileEventMetadata) throws XmartFileProcessingException {
        this.fileEventType = fileEventType;
        this.recordNumber = recordNumber;
        this.fileInProcess = fileInProcess;
        this.auditId = fileAuditId;
        this.totalRecords = recordCount;
        this.attributeMap = new HashMap<>(attribNames.length);
        this.fileMetadata = xmartFileEventMetadata;
        addAttributes(attribNames, attribValues);
    }

    public int getRecordNumber() {
        return recordNumber;
    }

    public XmartFileEventMetadata getFileMetadata() {
        return fileMetadata;
    }

    public int getAuditId() {
        return auditId;
    }

    public String getFileInProcess() {
        return fileInProcess;
    }

    public long getTotalRecords() {
        return totalRecords;
    }

    private void addAttributes(String[] attribNames, String[] attribValues) throws XmartFileProcessingException {
        if (isNull(attribNames) || isNull(attribValues)) {
            //Just ignore null values instead of reporting. so that nothing is collected in the stream
            return;
        }

        if (attribNames.length != attribValues.length) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "Mismatch in column values",
                    "Mismatch in column count at record number " + recordNumber + " in file " + fileInProcess
                            + ". Header contains " + attribNames.length + " records, value contain "
                            + attribValues.length + " records.");
        }
        for (int i = 0; i < attribNames.length; i++) {
            attributeMap.put(attribNames[i], attribValues[i]);
        }
    }

    public FileEventType getEventType() {
        return fileEventType;
    }

    /**
     * to get the value mapped against an attriute name
     *
     * @param attributeName Name of attribute to get the valuew from
     *
     * @return Value of the attribute if found, null otherwise
     */
    public String getMappedValue(String attributeName) {
        return isNull(attributeName) ? null : attributeMap.get(attributeName);
    }

    @Override
    public String toString() {
        return "FileEvent{" + "fileEventType=" + fileEventType + ", auditId=" + auditId + ", fileInProcess='"
                + fileInProcess + '\'' + ", totalRecords=" + totalRecords + ", attributeMap=" + attributeMap
                + ", fileMetadata=" + fileMetadata + '}';
    }
}
