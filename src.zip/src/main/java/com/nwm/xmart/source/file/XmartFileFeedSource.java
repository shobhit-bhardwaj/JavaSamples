package com.nwm.xmart.source.file;

import com.nwm.xmart.entities.file.XmartFileEventMetadata;
import com.nwm.xmart.source.file.db.entity.FileExtractEntity;
import com.nwm.xmart.source.file.event.FileEvent;
import com.nwm.xmart.source.file.event.XmartMarkerFileWrapper;
import com.nwm.xmart.source.file.exeption.XmartFileProcessingException;
import com.nwm.xmart.source.file.util.XmartFileDBUtil;
import com.nwm.xmart.streaming.source.file.event.FileEventType;
import org.apache.commons.io.FilenameUtils;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.nwm.xmart.source.file.util.XmartFileUtil.*;
import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;
import static java.util.Objects.nonNull;

/**
 * Flink source for processing files. Use {@link XmartFileAttributes} for creating instance of this class
 *
 * @author vashpan
 */
public class XmartFileFeedSource extends RichParallelSourceFunction<FileEvent> implements Serializable {

    private static final Logger logger = LoggerFactory.getLogger(XmartFileFeedSource.class);
    private XmartFileAttributes fileAttribs;
    private AtomicBoolean isCancelled = new AtomicBoolean(false);
    private XmartFileDBUtil xmartFileDBUtil;
    private AtomicBoolean alertRaisedForFilesInErrorFolder = new AtomicBoolean(false);

    /**
     * Craete a file source instance with the supplied {@link XmartFileAttributes} object
     */
    public XmartFileFeedSource(XmartFileAttributes fileAttributes) {
        this.fileAttribs = fileAttributes;
    }

    private static String getProcessedFileName(File fileToProcess, XmartFileAttributes fileAttributes) {
        return FilenameUtils.getBaseName(fileToProcess.getPath()) + "_" + fileAttributes.getProcessedFileSuffix()
                + fileAttributes.getFormattedDateStr(new Date()) + "." + FilenameUtils
                .getExtension(fileToProcess.getPath());
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        ParameterTool params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        xmartFileDBUtil = new XmartFileDBUtil(params);
    }

    @Override
    public void run(SourceContext<FileEvent> ctx) throws Exception {
        putJobNameInMDC(fileAttribs.getParameters());
        logger.info("Starting source Monitoring directory {} for files of type  {} with poll interval {}",
                fileAttribs.getFileLocation(), fileAttribs.getFilePrefix(), fileAttribs.getPollInterval());

        while (!isCancelled.get()) {
            if (reportExistingErrorFiles()) {
                sleep();
                continue;
            }
            //reset
            alertRaisedForFilesInErrorFolder.set(false);

            List<XmartMarkerFileWrapper> markerFiles = null;
            try {
                markerFiles = findFiles(fileAttribs, false);
            } catch (XmartFileProcessingException e) {
                logger.warn("Exception in getting in finding files", e);
                xmartFileDBUtil.sendMailUsingSBL(fileAttribs, e);
                break;
            }

            Iterator<XmartMarkerFileWrapper> markerFilesIterator = markerFiles.iterator();

            while (markerFilesIterator.hasNext()) {
                XmartMarkerFileWrapper markerFile = markerFilesIterator.next();

                try {
                    validateFileDateWithCurrentDate(fileAttribs, markerFile);
                } catch (XmartFileProcessingException e) {
                    moveAllFilesAndEmail(markerFiles, e);
                    break;
                }

                File fileToProcess = null;
                try {
                    fileToProcess = findFileForMarker(markerFile.getMarkerFile(), fileAttribs.getFileExtension());
                } catch (XmartFileProcessingException e) {
                    try {
                        moveFiles(markerFiles, fileAttribs.getErrorFolder());
                    } catch (XmartFileProcessingException e1) {
                        e.include(e1);
                    }
                    logger.warn("Exception in getting file for marker {}", markerFile, e);
                    xmartFileDBUtil.sendMailUsingSBL(fileAttribs, e);
                    break;
                }

                FileExtractEntity fileExtractEntity = null;
                try {
                    long recordCount = getRecordCount(fileToProcess, fileAttribs.getLineIgnorePrefix(),
                            fileAttribs.getSeparator());
                    //  Removing 1 record due to extra column header in source file
                    if (FileEventType.XMART_RGL_ORGUNIT_HIERARCHY.toString()
                                                                 .equals(fileAttribs.getFileEventType().name())) {
                        recordCount -= 1;
                    }

                    basicValidations(fileToProcess, fileAttribs, recordCount);

                    logger.debug("File {} contains {} records ", fileToProcess.getName(), recordCount);
                    fileExtractEntity = xmartFileDBUtil
                            .getFileExtractFromDB(fileAttribs.getSblHandlerName(), fileToProcess.getPath(), new Date(),
                                    new Date(fileToProcess.lastModified()), fileToProcess.length());

                    logger.debug("File extract entity return from database {} ", fileExtractEntity);

                   /* if (fileExtractEntity.getNewFileExtractId() == 0 && nonNull(
                            fileExtractEntity.getPreviousFileName())) {
                        // This is a special case where db returns last file detail due to duplicate file presented for processing
                        // Need to move files in error and not send mail (analysis is here, action is here, then notification should also be here)
                        // But this is nt how DB wants it :D
                        logger.warn("Duplicate file {} presented for processing  ", fileToProcess.getPath());
                        moveMarkerAndRelatedFiles(markerFiles, fileAttribs.getErrorFolder(),
                                fileAttribs.getFileExtension());
                        break;
                    }*/

                    fileExtractEntity.setRecordCount(recordCount);
                    fileExtractEntity.setFileSize(fileToProcess.length());

                    validationWithExtractProcResult(fileToProcess, fileAttribs, fileExtractEntity);

                    fileExtractEntity.setNewFileExtractId(1);
                    if (fileExtractEntity.getNewFileExtractId() == 0) {
                        logger.warn("Previous file in same category of file " + fileToProcess.getPath()
                                + "  not processed yet, will try in next iteration");
                        break;
                    }
                } catch (XmartFileProcessingException outerE) {
                    if (outerE.getPriority() == XmartFileProcessingException.Priority.WARN) {
                        logger.warn("Validation returned warning ", outerE);
                        xmartFileDBUtil.sendMailUsingSBL(fileAttribs, outerE);
                    } else {
                        moveAllFilesAndEmail(markerFiles, outerE);
                        break;
                    }
                }

                try {
                    processFileAndCollectRecords(fileExtractEntity, fileToProcess, ctx);
                } catch (XmartFileProcessingException outerE) {
                    moveAllFilesAndEmail(markerFiles, outerE);
                    break;
                }

                markerFilesIterator.remove();
                deleteMarkerAndMoveFile(markerFile, fileToProcess);
                logger.info("Processed file {} with {} records ", fileToProcess.getPath(),
                        fileExtractEntity.getRecordCount());
            }

            logger.debug("Sleeping for processing later");
            sleep();
        }
        logger.info("Cancel job received, stopping source, cleaning up file handles");
    }

    private void deleteMarkerAndMoveFile(XmartMarkerFileWrapper markerFile, File fileToProcess) {
        try {
            delete(markerFile.getMarkerFile());
        } catch (XmartFileProcessingException e) {
            logger.error(e.getMessage(), e);
            xmartFileDBUtil.sendMailUsingSBL(fileAttribs, e);
        }
        /*Try to move processed file even if marker file delete has failed*/
        try {
            moveFile(fileToProcess, fileAttribs.getDoneFolder(), getProcessedFileName(fileToProcess, fileAttribs));
            if (FileEventType.XMART_RGL_ORGUNIT_HIERARCHY.toString().equals(fileAttribs.getFileEventType().name())) {
                File zipFile = findZipFile(fileToProcess, FileEventType.XMART_RGL_ORGUNIT_HIERARCHY.toString());
                moveFile(zipFile, fileAttribs.getDoneFolder(), getProcessedFileName(zipFile, fileAttribs));

                File markerFileForZip = new File(
                        zipFile.getPath().substring(0, zipFile.getPath().lastIndexOf(".") + 1) + fileAttribs
                                .getMarkerFileExtension());
                delete(markerFileForZip);
            }
        } catch (XmartFileProcessingException e) {
            logger.warn(e.getMessage(), e);
            xmartFileDBUtil.sendMailUsingSBL(fileAttribs, e);
        }
    }

    private void moveAllFilesAndEmail(Collection<XmartMarkerFileWrapper> markerFiles,
            XmartFileProcessingException outerE) {
        try {
            moveMarkerAndRelatedFiles(markerFiles, fileAttribs.getErrorFolder(), fileAttribs.getFileExtension());
        } catch (XmartFileProcessingException innerE) {
            outerE.include(innerE);
        }
        logger.warn(outerE.getMessage(), outerE);
        xmartFileDBUtil.sendMailUsingSBL(fileAttribs, outerE);
    }

    private boolean reportExistingErrorFiles() {
        File[] filesInError = new File(fileAttribs.getErrorFolder()).listFiles();
        if (nonNull(filesInError) && filesInError.length != 0) {
            logger.warn("Error Files present in {}, skipping until cleared", fileAttribs.getErrorFolder());
            if (!alertRaisedForFilesInErrorFolder.get()) {
                xmartFileDBUtil.sendMailUsingSBL("ERROR", fileAttribs, "Files present in error folder",
                        "Error folder " + fileAttribs.getErrorFolder() + " contains files.\n" + Arrays
                                .asList(filesInError) + "\n Resolve files in error folder for continuous processing.");
                /*to avoid sending mail repeatedly*/
                alertRaisedForFilesInErrorFolder.set(true);
            }
            return true;
        }
        return false;
    }

    private void sleep() {
        try {
            TimeUnit.SECONDS.sleep(fileAttribs.getPollInterval());
        } catch (InterruptedException e) {
            logger.warn("Interrupted sleep ");
            Thread.currentThread().interrupt();
        }
    }

    private void processFileAndCollectRecords(FileExtractEntity fileExtractEntity, File fileToProcess,
            SourceContext<FileEvent> ctx) throws XmartFileProcessingException {
        if (logger.isDebugEnabled()) {
            logger.debug("Processing file {}", fileToProcess);
        }
        //try (LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(fileToProcess))) {
        LineNumberReader lineNumberReader = null;
        try {
            if (FileEventType.XMART_SDM_PRODUCT.toString().equals(fileAttribs.getFileEventType().name())
                    || FileEventType.XMART_SDM_GLPRODUCT.toString().equals(fileAttribs.getFileEventType().name())
                    || FileEventType.XMART_SDM_LEDGERBOOK.toString().equals(fileAttribs.getFileEventType().name())
                    || FileEventType.XMART_SDM_GLBOOKSET.toString().equals(fileAttribs.getFileEventType().name())
                    || FileEventType.XMART_CNC_ANNUAL_REPORT.toString().equals(fileAttribs.getFileEventType().name())) {
                lineNumberReader = new LineNumberReader(
                        new InputStreamReader(new FileInputStream(fileToProcess), "Cp1252"));
            } else {
                lineNumberReader = new LineNumberReader(new FileReader(fileToProcess));
            }
            String line = null;
            String columnNameSDM = null;
            String[] columnNames = null;
            String[] values = null;
            while ((line = lineNumberReader.readLine()) != null) {
                if (lineNumberReader.getLineNumber() == 1) {
                    if (FileEventType.XMART_RGL_ORGUNIT_HIERARCHY.toString()
                                                                 .equals(fileAttribs.getFileEventType().name())) {
                        columnNameSDM = fileAttribs.getColumnNames();
                        columnNames = columnNameSDM.split("\\|");
                    } else if (FileEventType.checkMessageType(fileAttribs.getFileEventType())) {
                        columnNameSDM = fileAttribs.getColumnNames();
                        columnNames = columnNameSDM.split(fileAttribs.getSeparator());
                    } else {
                        columnNames = line.split(fileAttribs.getSeparator());
                    }
                    if (logger.isDebugEnabled()) {
                        logger.debug("Read the column names {} count {}", line, columnNames.length);
                    }
                } else {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Processing line number {} record {}", lineNumberReader.getLineNumber(), line);
                    }

                    if ("XMART_SDM_GLPRODUCT".equals(fileAttribs.getFileEventType().name())) {
                        values = line.replaceAll("\\|$", "").split(fileAttribs.getSeparator(), -1);
                    } else if (FileEventType.XMART_RGL_ORGUNIT_HIERARCHY.toString()
                                                                        .equals(fileAttribs.getFileEventType().name())
                            && lineNumberReader.getLineNumber() == 2) {
                        continue;
                    } else {
                        values = line.split(fileAttribs.getSeparator(), -1);
                    }
                    if (line.startsWith(fileAttribs.getLineIgnorePrefix()) || (columnNames.length != 1
                            && values.length == 1)) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("Skipping line {}, as is blank or ignore line {}", line,
                                    fileAttribs.getLineIgnorePrefix());
                        }
                        continue;
                    }

                    XmartFileEventMetadata xmartFileEventMetadata = new XmartFileEventMetadata(fileToProcess.getName(),
                            fileToProcess.getPath(), fileAttribs.getSblHandlerName(),
                            fileExtractEntity.getRecordCount(), fileExtractEntity.getNewFileExtractId(),
                            fileExtractEntity.getNewFileBusinessDate());

                    ctx.collect(new FileEvent(fileAttribs.getFileEventType(), lineNumberReader.getLineNumber(),
                            fileToProcess.getPath(), fileExtractEntity.getNewFileExtractId(),
                            fileExtractEntity.getRecordCount(), columnNames, values, xmartFileEventMetadata));
                }
            }
        } catch (IOException ioe) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "File Processing failed",
                    "File " + fileToProcess + " could not be processed due " + ioe.getMessage()
                            + ". Please try to correct this.", ioe);
        } finally {
            try {
                if (lineNumberReader != null)
                    lineNumberReader.close();
            } catch (IOException ioe) {
                throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                        "Error in closing lineNumberReader",
                        "File " + fileToProcess + " could not be processed due " + ioe.getMessage()
                                + ". Error in closing lineNumberReader. ", ioe);
            }
        }
    }

    @Override
    public void cancel() {
        putJobNameInMDC(fileAttribs.getParameters());
        logger.info("Cancelled received for job");
        isCancelled.set(true);
    }
}
