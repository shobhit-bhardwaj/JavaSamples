package com.nwm.xmart.source.argon;

public class XmartArgonException extends Exception {

    public XmartArgonException(String message, Throwable cause) {
        super(message, cause);
    }

    public XmartArgonException(String message) {
        super(message);
    }
}

