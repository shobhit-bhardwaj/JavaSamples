package com.nwm.xmart.source.file.event;

import com.nwm.xmart.source.file.XmartFileAttributes;

import java.io.File;
import java.io.Serializable;
import java.text.ParseException;
import java.util.Date;

public class XmartMarkerFileWrapper implements Serializable {
    private final File markerFile;
    private final Date fileDate;

    /**
     * Construct object with date in file name as the business date.
     *
     * @param fileAttributes attributs of this source
     * @param markerFile     the file
     *
     * @throws ParseException if date could not be extracted from file name
     */
    public XmartMarkerFileWrapper(XmartFileAttributes fileAttributes, File markerFile) throws ParseException {
        String dateStr = markerFile.getName().substring(fileAttributes.getFilePrefix().length(),
                markerFile.getName().lastIndexOf('.'));
        this.fileDate = fileAttributes.getdateFromString(dateStr);
        this.markerFile = markerFile;
    }

    /**
     * Construct object with business date as marker file modification date.
     *
     * @param markerFile
     */
    public XmartMarkerFileWrapper(File markerFile) {
        this.fileDate = new Date(markerFile.lastModified());
        this.markerFile = markerFile;
    }

    @Override
    public String toString() {
        return "XmartMarkerFileWrapper{" + "markerFile=" + markerFile + ", fileDate=" + fileDate + '}';
    }

    public File getMarkerFile() {
        return markerFile;
    }

    /**
     * @return File modified date if running with MODIFIED_DATE, business date if running with BUSINESS_DATE
     */
    public Date getFileDate() {
        return fileDate;
    }
}
