package com.nwm.xmart.source.file.exeption;

/**
 * Exception to be thrown when there is any issue during the file processing,
 * this can be used to mail error scenario to support so it needs to be catched at differnt specific
 * scenarios and the messages should be well detailed for use in email messgae
 */
public class XmartFileProcessingException extends Exception {

    private final Priority priority;
    private String emailSubject;
    private String emailBody;

    public XmartFileProcessingException(Priority priority, String emailSubject, String message) {
        super(message);
        this.priority = priority;
        this.emailSubject = emailSubject;
        this.emailBody = message;
    }

    public XmartFileProcessingException(Priority priority, String emailSubject, String message, Throwable cause) {
        super(message, cause);
        this.priority = priority;
        this.emailSubject = emailSubject;
        this.emailBody = message;
    }

    public Priority getPriority() {
        return priority;
    }

    @Override
    public String getMessage() {
        return this.emailBody;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    /**
     * Adds detail from the other exception to this exception so that both error scan be included i the outoing message
     *
     * @param e
     */
    public void include(XmartFileProcessingException e) {
        this.emailSubject += " || " + e.emailSubject;
        this.emailBody += ".\n" + e.emailBody;
    }

    public enum Priority {

        /**
         * stop processing move files to error folder
         */
        ERROR("ERROR"), /**
         * Log, mail and continue
         */
        WARN("WARNING");

        private String myStr;

        Priority(String myStr) {
            this.myStr = myStr;
        }

        @Override
        public String toString() {
            return myStr;
        }
    }
}
