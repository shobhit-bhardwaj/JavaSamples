package com.nwm.xmart.keyselectors;

import com.nwm.xmart.entities.XmartTransactionSet;
import org.apache.flink.api.java.functions.KeySelector;

public class ODCKeySelector implements KeySelector<XmartTransactionSet, Long> {

    /**
     *
     */
    private static final long serialVersionUID = 531336472775497184L;

    public ODCKeySelector() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public Long getKey(XmartTransactionSet value) throws Exception {
        if (value == null) {
            return 0L;
        }
        return value.getWindowKey();
    }
}
