package com.nwm.xmart.keyselectors;

import com.nwm.xmart.core.XmartSet;
import com.nwm.xmart.entities.common.XmartGenericSet;
import org.apache.flink.api.java.functions.KeySelector;

public class XmartSetKeySelector implements KeySelector<XmartGenericSet, Long> {

    /**
     *
     */
    private static final long serialVersionUID = 531336472775497184L;

    public XmartSetKeySelector() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public Long getKey(XmartGenericSet value) throws Exception {
        if (value == null) {
            return 0L;
        }
        return value.getWindowKey();
    }
}
