package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.BookReportObligation;
import com.rbs.odc.access.domain.RegimeBookRole;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartBookReportObligations
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartBookReportObligation> {
    private static final Logger logger = LoggerFactory.getLogger(XmartBookReportObligations.class);
    private static final long serialVersionUID = -1242655175093045300L;

    public XmartBookReportObligations(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {
        Boolean regimeImpact = regulatoryRegimeImpact.getRegimeImpact();
        String regimeImpactId = regulatoryRegimeImpact.getRegimeImpactId();
        String regulatoryRegimeImpactid = regulatoryRegimeImpact.getId();

        Collection<RegimeBookRole> regimeBookRoles = nullCollToEmpty(regulatoryRegimeImpact.getRegimeBookRoles(),
                logger, "Regime Book Roles not received for document key : " + getDocumentKey());

        addRegimeBookRoles(regimeImpact, regimeImpactId, regulatoryRegimeImpactid, regimeBookRoles);
    }

    private void addRegimeBookRoles(Boolean regimeImpact, String regimeImpactId, String regulatoryRegimeImpactId,
            Collection<RegimeBookRole> regimeBookRoles) throws XmartException {

        for (RegimeBookRole regimeBookRole : regimeBookRoles) {

            if (isNull(regimeBookRole)) {
                // nothing to do more.
                continue;
            }

            Collection<BookReportObligation> bookReportObligations = nullCollToEmpty(
                    regimeBookRole.getBookReportObligations());

            for (BookReportObligation bookReportObligation : bookReportObligations) {

                XmartBookReportObligation xmartBookReportObligation = new XmartBookReportObligation(getDocumentKey());
                xmartBookReportObligation.setRegimeImpact(regimeImpact);
                xmartBookReportObligation.setRegulatoryRegimeImpactId(regulatoryRegimeImpactId);

                xmartBookReportObligation.setReportingRoleScheme(getStr(regimeBookRole.getReportingRoleScheme()));

                xmartBookReportObligation.setRegimeImpactId(regimeImpactId);

                if (nonNull(bookReportObligation)) {
                    xmartBookReportObligation.setRegulatoryReportName(bookReportObligation.getRegulatoryReportName());
                }
                addEntity(xmartBookReportObligation);
            }
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
