package com.nwm.xmart.entities.tdx;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.streaming.source.tdx.event.TDXSourceEvent;
import com.nwm.xmart.util.CollectionsUtil;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class XmartTdxEventSet extends XmartGenericSet<TDXSourceEvent> {

    private static final long serialVersionUID = -2957788404037807712L;

    private Long documentKey;

    public XmartTdxEventSet() {
        // Nothing in default constructor
    }

    @Override
    public void addStreamEvent(TDXSourceEvent streamEvent, int sourceTopicId, MappingNode mappingHierarchy)
            throws XmartException {

        XmartTdxSourceEvent xmartTdxSourceEvent = new XmartTdxSourceEvent(sourceTopicId, streamEvent);

        documentKey = xmartTdxSourceEvent.getDocumentKey();

        xmartMappedEntities.addAll(mappingHierarchy.mapSourceObject("cashflow-vat-status", xmartTdxSourceEvent, null));
    }

    @Override
    public Long getWindowKey() {
        return documentKey;
    }

    public Long getDocumentKey() {
        return documentKey;
    }

    public List<XmartMappedEntity> getXmartMappedEntities() {
        return xmartMappedEntities;
    }

    public Collection<XmartMappedEntity> getRequiredEntities(String requiredEntityCollectionName) {
        return xmartMappedEntities.stream().filter(child -> child.isMatchingXmlEntity(requiredEntityCollectionName))
                                  .collect(Collectors.toList());
    }

    public String getXmlEntities(String requiredEntityCollectionName) {

        Collection<XmartMappedEntity> requiredEntities = getRequiredEntities(requiredEntityCollectionName);

        if (CollectionsUtil.isEmptyOrNull(requiredEntities)) {
            return null;
        }

        StringBuilder builder = new StringBuilder();

        for (XmartMappedEntity entity : requiredEntities) {
            builder.append(entity.toString());
        }

        return builder.toString();
    }

    @Override
    public String toString() {
        return "XmartTransactionSet [" + documentKey + "]";
    }
}
