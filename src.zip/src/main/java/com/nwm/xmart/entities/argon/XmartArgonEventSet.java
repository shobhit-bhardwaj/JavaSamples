package com.nwm.xmart.entities.argon;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.source.argon.XmartArgonEvent;
import com.nwm.xmart.util.CollectionsUtil;

import java.util.Collection;
import java.util.List;

public class XmartArgonEventSet extends XmartGenericSet<XmartArgonEvent> {
    private static final long serialVersionUID = -2957788404037807712L;

    private XmartArgonEvent xmartArgonEvent;

    public XmartArgonEventSet() {
        // Nothing in default constructor
    }

    @Override
    public void addStreamEvent(XmartArgonEvent streamEvent, int jobId, MappingNode mappingHierarchy)
            throws XmartException {
        this.xmartArgonEvent = streamEvent;
    }

    @Override
    public Long getWindowKey() {
        return 1l;
    }

    public Long getDocumentKey() {
        return 1l;
    }

    public List<XmartMappedEntity> getXmartMappedEntities() {
        return null;
    }

    public Collection<XmartMappedEntity> getRequiredEntities(String requiredEntityCollectionName) {
        return null;
    }

    public String getXmlEntities(String requiredEntityCollectionName) {
        return "Not implemented yet";
    }
}
