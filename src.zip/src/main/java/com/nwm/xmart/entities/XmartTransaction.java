package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.ODCValue;
import com.rbs.odc.core.domain.TransactionImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlTransient;

import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartTransaction extends XmartEntity {

    private static final long serialVersionUID = 7845851523286650033L;
    @XmlTransient
    private String sourceTopic = null;
    @XmlTransient
    private int sourcePartition = 0;
    @XmlTransient
    private int sourceTopicId = 0;
    @XmlTransient
    private long sourcePosition = 0;
    @XmlTransient
    private long sourceTimestamp = 0;
    @XmartAttribute(usedInJoin = true, mandatory = true)
    private String sourceSystemTransactionId;
    @XmartAttribute(usedInJoin = true, mandatory = true)
    private String sourceSystemId;
    @XmartAttribute(usedInJoin = true)
    private String version = null;

    @XmartAttribute
    private String instance = null;

    @XmartAttribute
    private String location = null;

    @XmartAttribute
    private String placeOfTrade = null;

    @XmartAttribute
    private Date bookingDate = null;

    @XmartAttribute
    private Date bookingDateTime = null;

    @XmartAttribute
    private String bookLocation = null;

    @XmartAttribute
    private String tradeOriginationLocation = null;

    @XmartAttribute
    private Date agreementDate = null;

    @XmartAttribute
    private Date agreementDateTime = null;

    @XmartAttribute
    private Date legalStartDate = null;

    @XmartAttribute
    private Date legalEndDate = null;

    @XmartAttribute
    private String legalEndDateMode = null;

    @XmartAttribute
    private Date lastExpectedValuationDate = null;

    @XmartAttribute
    private String lastExpectedValuationMode = null;

    @XmartAttribute
    private Date originalLegalEndDate = null;

    @XmartAttribute
    private Date currentLastEventDate = null;

    @XmartAttribute
    private Date exposureEndDate = null;

    @XmartAttribute
    private Date confirmationDate = null;

    @XmartAttribute
    private Date confirmationDateTime = null;

    @XmartAttribute
    private Date clearingDateTime = null;

    @XmartAttribute
    private Date settlementDate = null;

    @XmartAttribute
    private Date lastEventDate = null;

    @XmartAttribute
    private Date sourceVersionEffectiveDate = null;

    @XmartAttribute
    private Date versionEffectiveDateTime = null;

    @XmartAttribute
    private Date executionDate = null;

    @XmartAttribute
    private Date executionDateTime = null;

    @XmartAttribute
    private Date originalExecutionDateTime = null;

    @XmartAttribute
    private String originationMethod = null;

    @XmartAttribute
    private String nettingGroupId = null;

    @XmartAttribute
    private String compressionType = null;

    @XmartAttribute
    private String underlyingProductClass = null;

    @XmartAttribute
    private String backOfficeType = null;

    @XmartAttribute
    private String atomicProductIdentifier = null;

    @XmartAttribute
    private String productSourceSystemId = null;

    @XmartAttribute
    private String productSubType = null;

    @XmartAttribute
    private String traderComment = null;

    @XmartAttribute
    private String sourceSystemBookId = null;

    @XmartAttribute
    private String bookSourceSystemId = null;

    @XmartAttribute
    private String partyIdClassification = null;

    @XmartAttribute
    private String partyId = null;

    @XmartAttribute
    private String bookTradingPartyIdClassification = null;

    @XmartAttribute
    private String bookTradingPartyId = null;

    @XmartAttribute
    private String buySellIndicator = null;

    @XmartAttribute
    private String desk = null;

    @XmartAttribute
    private String strategyName = null;

    @XmartAttribute
    private String opsBusinessArea = null;

    @XmartAttribute
    private String partyAccountId = null;

    @XmartAttribute
    private String validatorName = null;

    @XmartAttribute
    private Date independentAmountAdjustedPaymentDate = null;

    @XmartAttribute
    private String independentAmountCurrencyCode = null;

    @XmartAttribute
    private BigDecimal independentAmountValue = null;

    @XmartAttribute
    private String independentAmountBasis = null;

    @XmartAttribute
    private BigDecimal independentAmountPercentage = null;

    @XmartAttribute
    private BigDecimal initialMargin = null;

    @XmartAttribute
    private Boolean doddFrankEligible = null;

    @XmartAttribute
    private String doddFrankFoAssetClassification = null;

    @XmartAttribute
    private String doddFrankFoUniqueProductId = null;

    @XmartAttribute
    private String doddFrankLegalEntityIdentifier = null;

    @XmartAttribute
    private String doddFrankLegalEntityIdentifierPrefix = null;

    @XmartAttribute
    private Boolean doddFrankElectronicReportable = null;

    @XmartAttribute
    private Boolean doddFrankPaperReportable = null;

    @XmartAttribute
    private Boolean doddFrankNonStandardTerms = null;

    @XmartAttribute
    private String doddFrankMessageType = null;

    @XmartAttribute
    private String doddFrankAction = null;

    @XmartAttribute
    private String doddFrankTransactionType = null;

    @XmartAttribute
    private String doddFrankFoSubProductId = null;

    @XmartAttribute
    private Boolean doddFrankJfsaEligible = null;

    @XmartAttribute
    private Boolean doddFrankLargeSizeTrade = null;

    @XmartAttribute
    private Boolean doddFrankAccountingHedge = null;

    @XmartAttribute
    private String doddFrankBeneficiaryId = null;

    @XmartAttribute
    private String doddFrankBeneficiaryIdPrefix = null;

    @XmartAttribute
    private String doddFrankFoTransactionType = null;

    @XmartAttribute
    private Boolean doddFrankPriceForming = null;

    @XmartAttribute
    private String doddFrankFoSettlementType = null;

    @XmartAttribute
    private Boolean doddFrankTradeClearingException = null;

    @XmartAttribute
    private Boolean doddFrankOurSideAccountingHedge = null;

    @XmartAttribute
    private String doddFrankOurSideBeneficiaryId = null;

    @XmartAttribute
    private String doddFrankOurSideBeneficiaryIdPrefix = null;

    @XmartAttribute
    private Boolean repurchaseAgreementTriParty = null;

    @XmartAttribute
    private Boolean clearingRequired = null;

    @XmartAttribute
    private Boolean clearingFoReviewRequired = null;

    @XmartAttribute
    private Boolean clearingConfirmationRequired = null;

    @XmartAttribute
    private String clearingMethod = null;

    @XmartAttribute
    private String clearingMatchingConfirmationService = null;

    @XmartAttribute
    private String clearingMatchingServiceType = null;

    @XmartAttribute
    private String clearingDocumentEvent = null;

    @XmartAttribute
    private String clearingContractualMatrixType = null;

    @XmartAttribute
    private String clearingContractualDefinitions = null;

    @XmartAttribute
    private Boolean clearingHasNonStandardTerms = null;

    @XmartAttribute
    private String clearingMasterConfirmationType = null;

    @XmartAttribute
    private String clearingContracturalMatrixTerm = null;

    @XmartAttribute
    private Date clearingMatrixPublicationDate = null;

    @XmartAttribute
    private String clearingAdditionalComments = null;

    @XmartAttribute
    private Boolean clearingManualConfirmationRequired = null;

    @XmartAttribute
    private String clearingManualConfirmationRequiredComment = null;

    @XmartAttribute
    private Boolean verified = null;

    @XmartAttribute
    private String collateralizationType = null;

    @XmartAttribute
    private Boolean isSystemGenerated = null;

    @XmartAttribute
    private String tradePositionType = null;

    @XmartAttribute
    private Boolean blockTrade = null;

    @XmartAttribute
    private String transactionLegalAgreementType = null;

    @XmartAttribute
    private Date transactionLegalAgreementEffectiveDate = null;

    @XmartAttribute
    private Boolean standardSwaptionExpiry = null;

    @XmartAttribute
    private Boolean swaptionClearedPhysSettlement = null;

    @XmartAttribute
    private String transactionType = null;

    @XmartAttribute
    private String pricingModel = null;

    @XmartAttribute
    private String masterConfirmationType = null;

    @XmartAttribute
    private String masterAgreementType = null;

    @XmartAttribute
    private String businessCategory = null;

    @XmartAttribute
    private String standardProductDescription = null;

    @XmartAttribute
    private String standardProductId = null;

    @XmartAttribute
    private String standardProductSourceSystemId = null;

    @XmartAttribute
    private Boolean baselImmEligible = null;

    @XmartAttribute
    private Boolean closeoutNettingEnforceable = null;

    @XmartAttribute
    private Boolean closeoutNettingProductCovered = null;

    @XmartAttribute
    private String xvaBook = null;

    @XmartAttribute
    private Integer creditSupportId = null;

    @XmartAttribute
    private String sourceMessageType = null;

    @XmartAttribute
    private Boolean securitiesFinancingTransactionInd = null;

    @XmartAttribute
    private String executionAlgorithmId = null;

    @XmartAttribute
    private String executionAlgorithmSystemId = null;

    @XmartAttribute
    private Boolean miFIRReportingExemption = null;

    @XmartAttribute
    private Boolean positionWinddownIndicator = null;

    @XmartAttribute
    private String transactionExecutionStyle = null;

    @XmartAttribute
    private Boolean isGoodsAndServicesTransaction = null;

    @XmartAttribute
    private String investmentDecisionAlgorithmId = null;

    @XmartAttribute
    private String investmentDecisionAlgorithmSystemId = null;

    @XmartAttribute
    private String interCompanyStatusIndicator = null;

    @XmartAttribute
    private Boolean affirmationRequired = null;

    @XmartAttribute
    private String affirmationService = null;

    @XmartAttribute
    private Boolean cvaExemption = null;

    @XmartAttribute
    private String riskClassification = null;

    @XmartAttribute
    private BigDecimal priceMultiplier = null;

    @XmartAttribute
    private Boolean houseTradeIndicator = null;

    @XmartAttribute
    private String tradingCounterpartyId = null;

    @XmartAttribute
    private Date clearingDate = null;

    @XmartAttribute
    private Boolean directExchangeAccessIndicator = null;

    @XmartAttribute
    private Long cashflowOdcVersion = null;

    @XmartAttribute
    private Boolean tdxOrigin;

    @XmartAttribute
    private String reserve;

    @XmartAttribute
    private Date attestationDateTime;

    @XmartAttribute
    private String attestationSource;

    @XmartAttribute
    private String atomicProductAttestationValue;

    @XmartAttribute
    private String bookingEntityAttestationValue;

    @XmartAttribute
    private String cashflowPayerAttestationValue;

    @XmartAttribute
    private String cashflowReceiverAttestationValue;

    @XmartAttribute
    private String instrumentIdAttestationValue;

    @XmartAttribute
    private String legPayerAttestationValue;

    @XmartAttribute
    private String legReceiverAttestationValue;

    @XmartAttribute
    private String masterAgreementIdAttestationValue;

    @XmartAttribute
    private String sourceBookAttestationValue;

    @XmartAttribute
    private String tradingCptyAttestationValue;

    @XmartAttribute
    private String underlyingInsIdAttestationValue;

    @XmartAttribute
    private String transactionCounterparty1AttestationValue;

    @XmartAttribute
    private String transactionCounterparty1Id;

    @XmartAttribute
    private String transactionCounterparty1IdPath;

    @XmartAttribute
    private String transactionCounterparty2AttestationValue;

    @XmartAttribute
    private String transactionCounterparty2Id;

    @XmartAttribute
    private String transactionCounterparty2IdPath;

    @XmartAttribute
    private String accountingProductClassification;


    public XmartTransaction(String sourceTopic, int sourcePartition, int sourceTopicId, long sourcePosition,
            long sourceTimestamp, long documentKey, Transaction odcTransaction,
            DataFabricStreamEvent<ODCValue<TransactionId, Transaction>> dfStreamEvent) throws XmartException {
        super(documentKey);
        TransactionId transactionId = odcTransaction.getId();

        if (isNull(transactionId)) {
            throw new XmartException("Transaction Id is missing.");
        }

        sourceSystemTransactionId = transactionId.getSourceSystemTransactionId();
        sourceSystemId = getStr(transactionId.getSourceSystemId());

        this.sourceTopic = sourceTopic;

        this.sourcePartition = sourcePartition;

        this.sourceTopicId = sourceTopicId;
        this.sourcePosition = sourcePosition;
        this.sourceTimestamp = sourceTimestamp;

        version = odcTransaction.getVersion();

        instance = odcTransaction.getInstance();

        location = getStr(odcTransaction.getLocation());

        placeOfTrade = odcTransaction.getPlaceOfTrade();

        bookingDate = convertBusinessDate(odcTransaction.getBookingDate());

        bookingDateTime = odcTransaction.getBookingDateTime();

        bookLocation = odcTransaction.getBookLocation();

        tradeOriginationLocation = odcTransaction.getTradeOriginationLocation();

        agreementDate = convertBusinessDate(odcTransaction.getAgreementDate());

        agreementDateTime = odcTransaction.getAgreementDateTime();

        legalStartDate = convertBusinessDate(odcTransaction.getLegalStartDate());

        legalEndDate = convertBusinessDate(odcTransaction.getLegalEndDate());

        legalEndDateMode = getStr(odcTransaction.getLegalEndDateMode());

        lastExpectedValuationDate = convertBusinessDate(odcTransaction.getLastExpectedValuationDate());

        lastExpectedValuationMode = getStr(odcTransaction.getLastExpectedValuationMode());

        originalLegalEndDate = convertBusinessDate(odcTransaction.getOriginalLegalEndDate());

        currentLastEventDate = convertBusinessDate(odcTransaction.getCurrentLastEventDate());

        exposureEndDate = convertBusinessDate(odcTransaction.getExposureEndDate());

        confirmationDate = convertBusinessDate(odcTransaction.getConfirmationDate());

        confirmationDateTime = odcTransaction.getConfirmationDateTime();

        clearingDateTime = odcTransaction.getClearingDateTime();

        settlementDate = convertBusinessDate(odcTransaction.getSettlementDate());

        lastEventDate = convertBusinessDate(odcTransaction.getLastEventDate());

        sourceVersionEffectiveDate = convertBusinessDate(odcTransaction.getSourceVersionEffectiveDate());

        versionEffectiveDateTime = odcTransaction.getVersionEffectiveDateTime();

        executionDate = convertBusinessDate(odcTransaction.getExecutionDate());

        executionDateTime = odcTransaction.getExecutionDateTime();

        originalExecutionDateTime = odcTransaction.getOriginalExecutionDateTime();

        originationMethod = odcTransaction.getOriginationMethod();

        nettingGroupId = odcTransaction.getNettingGroupId();

        compressionType = getStr(odcTransaction.getCompressionType());

        underlyingProductClass = getStr(odcTransaction.getUnderlyingProductClass());

        backOfficeType = odcTransaction.getBackOfficeType();

        ProductId productId = odcTransaction.getProductId();
        if (productId != null) {
            atomicProductIdentifier = productId.getAtomicProductIdentifier();
            productSourceSystemId = getStr(productId.getProductSourceSystemId());
        }
        productSubType = odcTransaction.getProductSubType();

        traderComment = odcTransaction.getTraderComment();

        SourceBookId sourceBookId = odcTransaction.getSourceBookId();
        if (sourceBookId != null) {
            sourceSystemBookId = sourceBookId.getSourceSystemBookId();
            bookSourceSystemId = getStr(sourceBookId.getBookSourceSystemId());
        }

        PartyId bookPartyId = odcTransaction.getBookPartyId();
        if (bookPartyId != null) {
            partyIdClassification = getStr(bookPartyId.getScheme());
            partyId = bookPartyId.getPartyId();
        }

        BookTradingPartyId bookTrading = odcTransaction.getBookTrading();
        if (bookTrading != null) {
            bookTradingPartyIdClassification = bookTrading.getClassification();
            bookTradingPartyId = bookTrading.getId();
        }

        buySellIndicator = getStr(odcTransaction.getBuySellIndicator());

        desk = odcTransaction.getDesk();

        strategyName = odcTransaction.getStrategyName();

        opsBusinessArea = odcTransaction.getOpsBusinessArea();

        partyAccountId = odcTransaction.getPartyAccountId();

        validatorName = odcTransaction.getValidatorName();

        IndependentAmount independentAmount = odcTransaction.getIndependentAmount();
        if (independentAmount != null) {
            Amount amount = independentAmount.getAmount();
            if (amount != null) {
                CurrencyId currencyId = amount.getCurrencyId();
                if (currencyId != null) {
                    independentAmountCurrencyCode = currencyId.getCurrencyCode();
                }
                independentAmountValue = amount.getValue();
            }
            independentAmountAdjustedPaymentDate = convertBusinessDate(independentAmount.getAdjustedPaymentDate());
            independentAmountBasis = getStr(independentAmount.getBasis());
            independentAmountPercentage = independentAmount.getPercentage();
        }
        initialMargin = odcTransaction.getInitialMargin();

        DoddFrankReporting doddFrankReporting = odcTransaction.getDoddFrankReporting();
        if (doddFrankReporting != null) {
            doddFrankEligible = doddFrankReporting.isDoddFrankEligible();
            doddFrankFoAssetClassification = getStr(doddFrankReporting.getFoAssetClassification());
            doddFrankFoUniqueProductId = doddFrankReporting.getFoUniqueProductId();
            doddFrankLegalEntityIdentifier = doddFrankReporting.getLegalEntityIdentifier();
            doddFrankLegalEntityIdentifierPrefix = doddFrankReporting.getLegalEntityIdentifierPrefix();
            doddFrankElectronicReportable = doddFrankReporting.isElectronicReportable();
            doddFrankPaperReportable = doddFrankReporting.isPaperReportable();
            doddFrankNonStandardTerms = doddFrankReporting.isNonStandardTerms();
            doddFrankMessageType = doddFrankReporting.getMessageType();
            doddFrankAction = doddFrankReporting.getAction();
            doddFrankTransactionType = doddFrankReporting.getTransactionType();
            doddFrankFoSubProductId = doddFrankReporting.getFoSubProductId();
            doddFrankJfsaEligible = doddFrankReporting.isJfsaEligible();
            doddFrankLargeSizeTrade = doddFrankReporting.isLargeSizeTrade();
            doddFrankAccountingHedge = doddFrankReporting.isAccountingHedge();
            doddFrankBeneficiaryId = doddFrankReporting.getBeneficiaryId();
            doddFrankBeneficiaryIdPrefix = doddFrankReporting.getBeneficiaryIdPrefix();
            doddFrankFoTransactionType = doddFrankReporting.getFoTransactionType();
            doddFrankPriceForming = doddFrankReporting.isPriceForming();
            doddFrankFoSettlementType = doddFrankReporting.getFoSettlementType();
            doddFrankTradeClearingException = doddFrankReporting.isTradeClearingException();
            doddFrankOurSideAccountingHedge = doddFrankReporting.isOurSideAccountingHedge();
            doddFrankOurSideBeneficiaryId = doddFrankReporting.getOurSideBeneficiaryId();
            doddFrankOurSideBeneficiaryIdPrefix = doddFrankReporting.getOurSideBeneficiaryIdPrefix();
        }
        LendingTrade repurchaseAgreement = odcTransaction.getRepurchaseAgreement();
        if (repurchaseAgreement != null) {
            repurchaseAgreementTriParty = repurchaseAgreement.isTriParty();
        }

        ClearingConfirmation clearingConfirmation = odcTransaction.getClearingConfirmation();
        if (clearingConfirmation != null) {
            clearingRequired = clearingConfirmation.isClearingRequired();
            clearingFoReviewRequired = clearingConfirmation.isFoReviewRequired();
            clearingConfirmationRequired = clearingConfirmation.isConfirmationRequired();
            clearingMethod = clearingConfirmation.getClearingMethod();
            clearingMatchingConfirmationService = clearingConfirmation.getMatchingConfirmationService();
            clearingMatchingServiceType = clearingConfirmation.getMatchingServiceType();
            clearingDocumentEvent = clearingConfirmation.getDocumentEvent();
            clearingContractualMatrixType = clearingConfirmation.getContractualMatrixType();
            clearingContractualDefinitions = clearingConfirmation.getContractualDefinitions();
            clearingHasNonStandardTerms = clearingConfirmation.getHasNonStandardTerms();
            clearingMasterConfirmationType = clearingConfirmation.getMasterConfirmationType();
            clearingContracturalMatrixTerm = clearingConfirmation.getContractualMatrixTerm();
            clearingMatrixPublicationDate = convertBusinessDate(clearingConfirmation.getMatrixPublicationDate());
            clearingAdditionalComments = clearingConfirmation.getAdditionalComments();
            clearingManualConfirmationRequired = clearingConfirmation.isManualConfirmationRequired();
            clearingManualConfirmationRequiredComment = clearingConfirmation.getManualConfirmationRequiredComment();
        }

        verified = odcTransaction.isVerified();

        collateralizationType = getStr(odcTransaction.getCollateralizationType());

        isSystemGenerated = odcTransaction.getIsSystemGenerated();

        tradePositionType = getStr(odcTransaction.getTradePositionType());

        blockTrade = odcTransaction.getBlockTrade();

        TransactionLegalAgreement transactionLegalAgreement = odcTransaction.getTransactionLegalAgreement();
        if (transactionLegalAgreement != null) {
            transactionLegalAgreementType = transactionLegalAgreement.getAgreementType();
            transactionLegalAgreementEffectiveDate = convertBusinessDate(transactionLegalAgreement.getEffectiveDate());
        }

        Swaption swaption = odcTransaction.getSwaption();
        if (swaption != null) {
            standardSwaptionExpiry = swaption.isStandardSwaptionExpiry();
            swaptionClearedPhysSettlement = swaption.isClearedPhysSettlement();
        }

        transactionType = odcTransaction.getTransactionType();

        pricingModel = odcTransaction.getPricingModel();

        masterConfirmationType = getStr(odcTransaction.getMasterConfirmationType());

        masterAgreementType = getStr(odcTransaction.getMasterAgreementType());

        businessCategory = getStr(odcTransaction.getBusinessCategory());

        StandardProduct standardProduct = odcTransaction.getStandardProduct();
        if (standardProduct != null) {
            standardProductDescription = standardProduct.getDescription();
            standardProductId = standardProduct.getProductId();
            standardProductSourceSystemId = getStr(standardProduct.getProductSourceSystemId());
        }

        baselImmEligible = odcTransaction.isBaselImmEligible();

        closeoutNettingEnforceable = odcTransaction.isCloseoutNettingEnforceable();

        closeoutNettingProductCovered = odcTransaction.isCloseoutNettingProductCovered();

        xvaBook = odcTransaction.getXvaBook();

        CreditSupportId creditSupport = odcTransaction.getCreditSupportId();
        if (creditSupport != null) {
            creditSupportId = creditSupport.getCreditSupportId().intValue();
        }

        sourceMessageType = getStr(odcTransaction.getSourceMessageType());

        securitiesFinancingTransactionInd = odcTransaction.isSecuritiesFinancingTransactionInd();

        executionAlgorithmId = odcTransaction.getExecutionAlgorithmId();

        executionAlgorithmSystemId = getStr(odcTransaction.getExecutionAlgorithmSystemId());

        miFIRReportingExemption = odcTransaction.isMiFIRReportingExemption();

        positionWinddownIndicator = odcTransaction.isPositionWinddownIndicator();

        transactionExecutionStyle = odcTransaction.getTransactionExecutionStyle();

        isGoodsAndServicesTransaction = odcTransaction.isIsGoodsAndServicesTransaction();

        investmentDecisionAlgorithmId = odcTransaction.getInvestmentDecisionAlgorithmId();

        investmentDecisionAlgorithmSystemId = getStr(odcTransaction.getInvestmentDecisionAlgorithmSystemId());

        interCompanyStatusIndicator = odcTransaction.getInterCompanyStatusIndicator();

        AffirmationInformation affirmationInformation = odcTransaction.getAffirmationInformation();
        if (affirmationInformation != null) {
            affirmationRequired = affirmationInformation.getAffirmationRequired();
            affirmationService = getStr(affirmationInformation.getAffirmationService());
        }

        cvaExemption = odcTransaction.isCvaExemption();

        riskClassification = odcTransaction.getRiskClassification();

        priceMultiplier = odcTransaction.getPriceMultiplier();

        houseTradeIndicator = odcTransaction.isHouseTradeIndicator();

        tradingCounterpartyId = odcTransaction.getTheirSideTradingCounterpartyNucleusId1();

        clearingDate = odcTransaction.getClearingDateTime();

        directExchangeAccessIndicator = odcTransaction.isDirectExchangeAccessIndicator();

        cashflowOdcVersion = ((TransactionImpl) odcTransaction).getCashflowOdcVersion();

        tdxOrigin = odcTransaction.isTDXOrigin();

        reserve = odcTransaction.getReserve();

        Attestation attestation = odcTransaction.getAttestation();
        if (attestation != null) {
            attestationDateTime = attestation.getAttestationDateTime();
            attestationSource = getStr(attestation.getAttestationSource());

            MandatedCatAttestation mandatedCatAttestation = attestation.getMandatedCatAttestation();
            if (mandatedCatAttestation != null) {
                atomicProductAttestationValue = getStr(mandatedCatAttestation.getAtomicProductAttestationValue());
                bookingEntityAttestationValue = getStr(mandatedCatAttestation.getBookingEntityAttestationValue());
                cashflowPayerAttestationValue = getStr(mandatedCatAttestation.getCashflowPayerAttestationValue());
                cashflowReceiverAttestationValue = getStr(mandatedCatAttestation.getCashflowReceiverAttestationValue());
                instrumentIdAttestationValue = getStr(mandatedCatAttestation.getInstrumentIdAttestationValue());
                legPayerAttestationValue = getStr(mandatedCatAttestation.getLegPayerAttestationValue());
                legReceiverAttestationValue = getStr(mandatedCatAttestation.getLegReceiverAttestationValue());
                masterAgreementIdAttestationValue = getStr(
                        mandatedCatAttestation.getMasterAgreementIdAttestationValue());
                sourceBookAttestationValue = getStr(mandatedCatAttestation.getSourceBookAttestationValue());
                tradingCptyAttestationValue = getStr(mandatedCatAttestation.getTradingCptyAttestationValue());
                underlyingInsIdAttestationValue = getStr(mandatedCatAttestation.getUnderlyingInsIdAttestationValue());
                TradingPartyAttestation tradingPartyAttestation1 = mandatedCatAttestation.getTransactionCounterparty1();
                if (tradingPartyAttestation1 != null) {
                    transactionCounterparty1AttestationValue = getStr(tradingPartyAttestation1.getAttestationValue());
                    transactionCounterparty1Id = tradingPartyAttestation1.getId();
                    transactionCounterparty1IdPath = tradingPartyAttestation1.getIdPath();
                }
                TradingPartyAttestation tradingPartyAttestation2 = mandatedCatAttestation.getTransactionCounterparty2();
                if (tradingPartyAttestation2 != null) {
                    transactionCounterparty2AttestationValue = getStr(tradingPartyAttestation2.getAttestationValue());
                    transactionCounterparty2Id = tradingPartyAttestation2.getId();
                    transactionCounterparty2IdPath = tradingPartyAttestation2.getIdPath();
                }
            }
        }

        accountingProductClassification = getStr(odcTransaction.getAccountingProductClassification());

    }

    public String getSourceSystemTransactionId() {

        return sourceSystemTransactionId;
    }

    public long getSourcePosition() {
        return sourcePosition;
    }

    public int getSourcePartition() {
        return sourcePartition;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public String getVersion() {
        return version;
    }

    public String getInstance() {
        return instance;
    }

    public String getLocation() {
        return location;
    }

    public String getPlaceOfTrade() {
        return placeOfTrade;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public Date getBookingDateTime() {
        return bookingDateTime;
    }

    public Date getAgreementDate() {
        return agreementDate;
    }

    public Date getAgreementDateTime() {
        return agreementDateTime;
    }

    public Date getLegalStartDate() {
        return legalStartDate;
    }

    public Date getLegalEndDate() {
        return legalEndDate;
    }

    public String getLegalEndDateMode() {
        return legalEndDateMode;
    }

    public Date getLastExpectedValuationDate() {
        return lastExpectedValuationDate;
    }

    public String getLastExpectedValuationMode() {
        return lastExpectedValuationMode;
    }

    public Date getOriginalLegalEndDate() {
        return originalLegalEndDate;
    }

    public Date getCurrentLastEventDate() {
        return currentLastEventDate;
    }

    public Date getExposureEndDate() {
        return exposureEndDate;
    }

    public Date getConfirmationDate() {
        return confirmationDate;
    }

    public Date getConfirmationDateTime() {
        return confirmationDateTime;
    }

    public Date getClearingDateTime() {
        return clearingDateTime;
    }

    public Date getSettlementDate() {
        return settlementDate;
    }

    public Date getLastEventDate() {
        return lastEventDate;
    }

    public Date getSourceVersionEffectiveDate() {
        return sourceVersionEffectiveDate;
    }

    public Date getVersionEffectiveDateTime() {
        return versionEffectiveDateTime;
    }

    public Date getExecutionDate() {
        return executionDate;
    }

    public Date getExecutionDateTime() {
        return executionDateTime;
    }

    public Date getOriginalExecutionDateTime() {
        return originalExecutionDateTime;
    }

    public String getOriginationMethod() {
        return originationMethod;
    }

    public String getNettingGroupId() {
        return nettingGroupId;
    }

    public String getCompressionType() {
        return compressionType;
    }

    public String getUnderlyingProductClass() {
        return underlyingProductClass;
    }

    public String getBackOfficeType() {
        return backOfficeType;
    }

    public String getAtomicProductIdentifier() {
        return atomicProductIdentifier;
    }

    public String getProductSourceSystemId() {
        return productSourceSystemId;
    }

    public String getProductSubType() {
        return productSubType;
    }

    public String getTraderComment() {
        return traderComment;
    }

    public String getSourceSystemBookId() {
        return sourceSystemBookId;
    }

    public String getBookSourceSystemId() {
        return bookSourceSystemId;
    }

    public String getPartyIdClassification() {
        return partyIdClassification;
    }

    public String getPartyId() {
        return partyId;
    }

    public String getBookTradingPartyIdClassification() {
        return bookTradingPartyIdClassification;
    }

    public String getBookTradingPartyId() {
        return bookTradingPartyId;
    }

    public String getBuySellIndicator() {
        return buySellIndicator;
    }

    public String getDesk() {
        return desk;
    }

    public String getStrategyName() {
        return strategyName;
    }

    public String getOpsBusinessArea() {
        return opsBusinessArea;
    }

    public String getPartyAccountId() {
        return partyAccountId;
    }

    public String getValidatorName() {
        return validatorName;
    }

    public Date getIndependentAmountAdjustedPaymentDate() {
        return independentAmountAdjustedPaymentDate;
    }

    public String getIndependentAmountCurrencyCode() {
        return independentAmountCurrencyCode;
    }

    public BigDecimal getIndependentAmountValue() {
        return independentAmountValue;
    }

    public String getIndependentAmountBasis() {
        return independentAmountBasis;
    }

    public BigDecimal getIndependentAmountPercentage() {
        return independentAmountPercentage;
    }

    public BigDecimal getInitialMargin() {
        return initialMargin;
    }

    public Boolean getDoddFrankEligible() {
        return doddFrankEligible;
    }

    public String getDoddFrankFoAssetClassification() {
        return doddFrankFoAssetClassification;
    }

    public String getDoddFrankFoUniqueProductId() {
        return doddFrankFoUniqueProductId;
    }

    public String getDoddFrankLegalEntityIdentifier() {
        return doddFrankLegalEntityIdentifier;
    }

    public String getDoddFrankLegalEntityIdentifierPrefix() {
        return doddFrankLegalEntityIdentifierPrefix;
    }

    public Boolean getDoddFrankElectronicReportable() {
        return doddFrankElectronicReportable;
    }

    public Boolean getDoddFrankPaperReportable() {
        return doddFrankPaperReportable;
    }

    public Boolean getDoddFrankNonStandardTerms() {
        return doddFrankNonStandardTerms;
    }

    public String getDoddFrankMessageType() {
        return doddFrankMessageType;
    }

    public String getDoddFrankAction() {
        return doddFrankAction;
    }

    public String getDoddFrankTransactionType() {
        return doddFrankTransactionType;
    }

    public String getDoddFrankFoSubProductId() {
        return doddFrankFoSubProductId;
    }

    public Boolean getDoddFrankJfsaEligible() {
        return doddFrankJfsaEligible;
    }

    public Boolean getDoddFrankLargeSizeTrade() {
        return doddFrankLargeSizeTrade;
    }

    public Boolean getDoddFrankAccountingHedge() {
        return doddFrankAccountingHedge;
    }

    public String getDoddFrankBeneficiaryId() {
        return doddFrankBeneficiaryId;
    }

    public String getDoddFrankBeneficiaryIdPrefix() {
        return doddFrankBeneficiaryIdPrefix;
    }

    public String getDoddFrankFoTransactionType() {
        return doddFrankFoTransactionType;
    }

    public Boolean getDoddFrankPriceForming() {
        return doddFrankPriceForming;
    }

    public String getDoddFrankFoSettlementType() {
        return doddFrankFoSettlementType;
    }

    public Boolean getDoddFrankTradeClearingException() {
        return doddFrankTradeClearingException;
    }

    public Boolean getDoddFrankOurSideAccountingHedge() {
        return doddFrankOurSideAccountingHedge;
    }

    public String getDoddFrankOurSideBeneficiaryId() {
        return doddFrankOurSideBeneficiaryId;
    }

    public String getDoddFrankOurSideBeneficiaryIdPrefix() {
        return doddFrankOurSideBeneficiaryIdPrefix;
    }

    public Boolean getRepurchaseAgreementTriParty() {
        return repurchaseAgreementTriParty;
    }

    public Boolean getClearingRequired() {
        return clearingRequired;
    }

    public Boolean getClearingFoReviewRequired() {
        return clearingFoReviewRequired;
    }

    public Boolean getClearingConfirmationRequired() {
        return clearingConfirmationRequired;
    }

    public String getClearingMethod() {
        return clearingMethod;
    }

    public String getClearingMatchingConfirmationService() {
        return clearingMatchingConfirmationService;
    }

    public String getClearingMatchingServiceType() {
        return clearingMatchingServiceType;
    }

    public String getClearingDocumentEvent() {
        return clearingDocumentEvent;
    }

    public String getClearingContractualMatrixType() {
        return clearingContractualMatrixType;
    }

    public String getClearingContractualDefinitions() {
        return clearingContractualDefinitions;
    }

    public Boolean getClearingHasNonStandardTerms() {
        return clearingHasNonStandardTerms;
    }

    public String getClearingMasterConfirmationType() {
        return clearingMasterConfirmationType;
    }

    public String getClearingContracturalMatrixTerm() {
        return clearingContracturalMatrixTerm;
    }

    public Date getClearingMatrixPublicationDate() {
        return clearingMatrixPublicationDate;
    }

    public String getClearingAdditionalComments() {
        return clearingAdditionalComments;
    }

    public Boolean getClearingManualConfirmationRequired() {
        return clearingManualConfirmationRequired;
    }

    public String getClearingManualConfirmationRequiredComment() {
        return clearingManualConfirmationRequiredComment;
    }

    public Boolean getVerified() {
        return verified;
    }

    public String getCollateralizationType() {
        return collateralizationType;
    }

    public Boolean getIsSystemGenerated() {
        return isSystemGenerated;
    }

    public String getTradePositionType() {
        return tradePositionType;
    }

    public Boolean getBlockTrade() {
        return blockTrade;
    }

    public String getTransactionLegalAgreementType() {
        return transactionLegalAgreementType;
    }

    public Date getTransactionLegalAgreementEffectiveDate() {
        return transactionLegalAgreementEffectiveDate;
    }

    public Boolean getStandardSwaptionExpiry() {
        return standardSwaptionExpiry;
    }

    public Boolean getSwaptionClearedPhysSettlement() {
        return swaptionClearedPhysSettlement;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public String getPricingModel() {
        return pricingModel;
    }

    public String getMasterConfirmationType() {
        return masterConfirmationType;
    }

    public String getMasterAgreementType() {
        return masterAgreementType;
    }

    public String getBusinessCategory() {
        return businessCategory;
    }

    public String getStandardProductDescription() {
        return standardProductDescription;
    }

    public String getStandardProductId() {
        return standardProductId;
    }

    public String getStandardProductSourceSystemId() {
        return standardProductSourceSystemId;
    }

    public Boolean getBaselImmEligible() {
        return baselImmEligible;
    }

    public Boolean getCloseoutNettingEnforceable() {
        return closeoutNettingEnforceable;
    }

    public Boolean getCloseoutNettingProductCovered() {
        return closeoutNettingProductCovered;
    }

    public String getXvaBook() {
        return xvaBook;
    }

    public Integer getCreditSupportId() {
        return creditSupportId;
    }

    public String getSourceMessageType() {
        return sourceMessageType;
    }

    public Boolean getSecuritiesFinancingTransactionInd() {
        return securitiesFinancingTransactionInd;
    }

    public String getExecutionAlgorithmId() {
        return executionAlgorithmId;
    }

    public String getExecutionAlgorithmSystemId() {
        return executionAlgorithmSystemId;
    }

    public Boolean getMiFIRReportingExemption() {
        return miFIRReportingExemption;
    }

    public Boolean getPositionWinddownIndicator() {
        return positionWinddownIndicator;
    }

    public String getTransactionExecutionStyle() {
        return transactionExecutionStyle;
    }

    public Boolean getIsGoodsAndServicesTransaction() {
        return isGoodsAndServicesTransaction;
    }

    public String getInvestmentDecisionAlgorithmId() {
        return investmentDecisionAlgorithmId;
    }

    public String getInvestmentDecisionAlgorithmSystemId() {
        return investmentDecisionAlgorithmSystemId;
    }

    public String getInterCompanyStatusIndicator() {
        return interCompanyStatusIndicator;
    }

    public Boolean getAffirmationRequired() {
        return affirmationRequired;
    }

    public String getAffirmationService() {
        return affirmationService;
    }

    public Boolean getCvaExemption() {
        return cvaExemption;
    }

    public String getRiskClassification() {
        return riskClassification;
    }

    public BigDecimal getPriceMultiplier() {
        return priceMultiplier;
    }

    public Boolean getHouseTradeIndicator() {
        return houseTradeIndicator;
    }

    public String getTradingCounterpartyId() {
        return tradingCounterpartyId;
    }

    public Date getClearingDate() {
        return clearingDate;
    }

    public Boolean getDirectExchangeAccessIndicator() {
        return directExchangeAccessIndicator;
    }

    public Long getCashflowOdcVersion() {
        return cashflowOdcVersion;
    }

    public Boolean getTdxOrigin() {
        return tdxOrigin;
    }

    public String getReserve() {
        return reserve;
    }

    public String getBookLocation() {
        return bookLocation;
    }

    public String getTradeOriginationLocation() {
        return tradeOriginationLocation;
    }

    public Date getAttestationDateTime() {
        return attestationDateTime;
    }

    public String getAttestationSource() {
        return attestationSource;
    }

    public String getAtomicProductAttestationValue() {
        return atomicProductAttestationValue;
    }

    public String getBookingEntityAttestationValue() {
        return bookingEntityAttestationValue;
    }

    public String getCashflowPayerAttestationValue() {
        return cashflowPayerAttestationValue;
    }

    public String getCashflowReceiverAttestationValue() {
        return cashflowReceiverAttestationValue;
    }

    public String getInstrumentIdAttestationValue() {
        return instrumentIdAttestationValue;
    }

    public String getLegPayerAttestationValue() {
        return legPayerAttestationValue;
    }

    public String getLegReceiverAttestationValue() {
        return legReceiverAttestationValue;
    }

    public String getMasterAgreementIdAttestationValue() {
        return masterAgreementIdAttestationValue;
    }

    public String getSourceBookAttestationValue() {
        return sourceBookAttestationValue;
    }

    public String getTradingCptyAttestationValue() {
        return tradingCptyAttestationValue;
    }

    public String getUnderlyingInsIdAttestationValue() {
        return underlyingInsIdAttestationValue;
    }

    public String getTransactionCounterparty1AttestationValue() {
        return transactionCounterparty1AttestationValue;
    }

    public String getTransactionCounterparty1Id() {
        return transactionCounterparty1Id;
    }

    public String getTransactionCounterparty1IdPath() {
        return transactionCounterparty1IdPath;
    }

    public String getTransactionCounterparty2AttestationValue() {
        return transactionCounterparty2AttestationValue;
    }

    public String getTransactionCounterparty2Id() {
        return transactionCounterparty2Id;
    }

    public String getTransactionCounterparty2IdPath() {
        return transactionCounterparty2IdPath;
    }

    public String getAccountingProductClassification() {
        return accountingProductClassification;
    }
}
