package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTransactionInstanceLink extends XmartEntity {
    private static final long serialVersionUID = -6573578269447657177L;

    @XmartAttribute
    private String linkageReasonScheme;

    @XmartAttribute
    private String linkSourceSystemId;

    @XmartAttribute
    private String linkTransactionId;

    @XmartAttribute
    private String linkTransactionLegId;

    @XmartAttribute
    private String linkTransactionVersion;

    @XmartAttribute
    private String linkTransactionInstance;

    @XmartAttribute
    private String tradeIdClassification;

    protected XmartTransactionInstanceLink(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getLinkageReasonScheme() {
        return linkageReasonScheme;
    }

    public void setLinkageReasonScheme(String linkageReasonScheme) {
        this.linkageReasonScheme = linkageReasonScheme;
    }

    public String getLinkSourceSystemId() {
        return linkSourceSystemId;
    }

    public void setLinkSourceSystemId(String linkSourceSystemId) {
        this.linkSourceSystemId = linkSourceSystemId;
    }

    public String getLinkTransactionId() {
        return linkTransactionId;
    }

    public void setLinkTransactionId(String linkTransactionId) {
        this.linkTransactionId = linkTransactionId;
    }

    public String getLinkTransactionLegId() {
        return linkTransactionLegId;
    }

    public void setLinkTransactionLegId(String linkTransactionLegId) {
        this.linkTransactionLegId = linkTransactionLegId;
    }

    public String getLinkTransactionVersion() {
        return linkTransactionVersion;
    }

    public void setLinkTransactionVersion(String linkTransactionVersion) {
        this.linkTransactionVersion = linkTransactionVersion;
    }

    public String getLinkTransactionInstance() {
        return linkTransactionInstance;
    }

    public void setLinkTransactionInstance(String linkTransactionInstance) {
        this.linkTransactionInstance = linkTransactionInstance;
    }

    public String getTradeIdClassification() {
        return tradeIdClassification;
    }

    public void setTradeIdClassification(String tradeIdClassification) {
        this.tradeIdClassification = tradeIdClassification;
    }
}
