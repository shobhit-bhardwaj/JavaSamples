package com.nwm.xmart.entities.schedule_entries;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.util.Date;

public class XmartFxFixingScheduleEntry extends XmartEntity {

    private static final long serialVersionUID = 6216066335289084008L;

    @XmartAttribute(usedInJoin = true, mandatory = true, xmlTrigger = false)
    private final String legIdentifier, sourceSystemTransactionId, sourceSystemId, scheduleEntryType;
    @XmartAttribute(usedInJoin = true, mandatory = true, xmlTrigger = false)
    private final long odcVersion;
    @XmartAttribute
    private Date fxFixingScheduleEntriesFixingDate;
    @XmartAttribute
    private Date startDate;
    @XmartAttribute
    private String fxFixingScheduleEntriesFixingTime, currency1IdCurrencyCode, currency2IdCurrencyCode,
            fxFixingScheduleEntriesQuoteBasis, informationSource, informationSourcePage;

    public XmartFxFixingScheduleEntry(Long documentKey, String legIdentifier, String sourceSystemId,
            String sourceSystemTransactionId, long odcVersion, String scheduleEntryType) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
        this.sourceSystemTransactionId = sourceSystemTransactionId;
        this.sourceSystemId = sourceSystemId;
        this.odcVersion = odcVersion;
        this.scheduleEntryType = scheduleEntryType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public long getOdcVersion() {
        return odcVersion;
    }

    public Date getFxFixingScheduleEntriesFixingDate() {
        return fxFixingScheduleEntriesFixingDate;
    }

    public void setFxFixingScheduleEntriesFixingDate(Date fxFixingScheduleEntriesFixingDate) {
        this.fxFixingScheduleEntriesFixingDate = fxFixingScheduleEntriesFixingDate;
    }

    public String getFxFixingScheduleEntriesFixingTime() {
        return fxFixingScheduleEntriesFixingTime;
    }

    public void setFxFixingScheduleEntriesFixingTime(String fxFixingScheduleEntriesFixingTime) {
        this.fxFixingScheduleEntriesFixingTime = fxFixingScheduleEntriesFixingTime;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getScheduleEntryType() {
        return scheduleEntryType;
    }

    public String getCurrency1IdCurrencyCode() {
        return currency1IdCurrencyCode;
    }

    public void setCurrency1IdCurrencyCode(String currency1IdCurrencyCode) {
        this.currency1IdCurrencyCode = currency1IdCurrencyCode;
    }

    public String getCurrency2IdCurrencyCode() {
        return currency2IdCurrencyCode;
    }

    public void setCurrency2IdCurrencyCode(String currency2IdCurrencyCode) {
        this.currency2IdCurrencyCode = currency2IdCurrencyCode;
    }

    public String getFxFixingScheduleEntriesQuoteBasis() {
        return fxFixingScheduleEntriesQuoteBasis;
    }

    public void setFxFixingScheduleEntriesQuoteBasis(String fxFixingScheduleEntriesQuoteBasis) {
        this.fxFixingScheduleEntriesQuoteBasis = fxFixingScheduleEntriesQuoteBasis;
    }

    public String getInformationSource() {
        return informationSource;
    }

    public void setInformationSource(String informationSource) {
        this.informationSource = informationSource;
    }

    public String getInformationSourcePage() {
        return informationSourcePage;
    }

    public void setInformationSourcePage(String informationSourcePage) {
        this.informationSourcePage = informationSourcePage;
    }
}