package com.nwm.xmart.entities;

import com.nwm.xmart.bean.schedule_entries.domain.XmartODCScheduleEntries;
import com.nwm.xmart.core.XmartODCSet;
import com.nwm.xmart.entities.schedule_entries.XmartFxFixingScheduleEntries;
import com.nwm.xmart.entities.schedule_entries.XmartScheduleEntries;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.XmlUtil;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.event.StreamEvent;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionId;
import com.rbs.odc.core.domain.ODCValue;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartTransactionSet extends XmartODCSet<TransactionId, Transaction> {

    private static final long serialVersionUID = -2957788404037807712L;
    private XmartTransaction xmartTransaction;
    private XmartOdcEntityCollection xmartTransactionLegs;
    private XmartOdcEntityCollection xmartLegInformationSources;
    private XmartOdcEntityCollection xmartAlternateTransactionIdentifiers;
    private XmartOdcEntityCollection xmartAgreementTransactionContexts;
    private XmartOdcEntityCollection xmartTransactionStatuses;
    private XmartOdcEntityCollection xmartTransactionLegalEntities;
    private XmartOdcEntityCollection xmartFxLegs;
    private XmartOdcEntityCollection xmartBookCounterParties;
    private XmartOdcEntityCollection xmartRegulatoryRegimeImpacts;
    private XmartOdcEntityCollection xmartRegimePartyRoles;
    private XmartOdcEntityCollection xmartRegimeBookRoles;
    private XmartOdcEntityCollection xmartInterestRateLegs;
    private XmartOdcEntityCollection xmartReportableInstruments;
    private XmartOdcEntityCollection xmartVarianceLegs;
    private XmartOdcEntityCollection xmartUnderliers;
    private XmartOdcEntityCollection xmartTxnRegMarImp;
    private XmartOdcEntityCollection xmartTxnSourceSystems;
    private XmartOdcEntityCollection xmartBookReportObligations;
    private XmartOdcEntityCollection xmartCreditDerivativeAdditionalTerms;
    private XmartOdcEntityCollection xmartCompoundUnderlierMembers;
    private XmartOdcEntityCollection xmartCreditEventPublicSources;
    private XmartOdcEntityCollection xmartTransactionProcessDirectives;
    private XmartOdcEntityCollection xmartTransactionProcessRolePlayers;
    private XmartOdcEntityCollection xmartTransactionMarginElections;
    private XmartOdcEntityCollection xmartTransactionMarginJurisdictions;
    private XmartOdcEntityCollection xmartTransactionLegCurves;
    private XmartOdcEntityCollection xmartTransactionLifecycleEvents;
    private XmartOdcEntityCollection xmartTransactionInstanceLinks;
    private XmartOdcEntityCollection xmartSettlementSystemMigrationDatas;

    private XmartOdcEntityCollection xmartReportingWaivers;
    private XmartOdcEntityCollection xmartRoutingAttributes;
    private XmartOdcEntityCollection xmartSalesCreditComponents;
    // FROBI-7369
    private XmartOdcEntityCollection xmartCreditDerivativeLegs;
    private XmartOdcEntityCollection xmartDeliverableObligations;
    private XmartOdcEntityCollection xmartEmployeeIdEntries;
    private XmartOdcEntityCollection xmartExceptionalTermsDetails;
    private XmartOdcEntityCollection xmartExternalTransactionIdentifiers;
    // FROBI-7375
    private XmartOdcEntityCollection xmartForwardFeatures;
    private XmartOdcEntityCollection xmartFuturesLegs;
    private XmartOdcEntityCollection xmartInflationRateLegs;
    private XmartOdcEntityCollection xmartLegBusinessCentres;
    // FROBI-7441
    private XmartOdcEntityCollection xmartLegParameters;
    private XmartOdcEntityCollection xmartLinkedTransactions;
    private XmartOdcEntityCollection xmartNotionalResets;
    private XmartOdcEntityCollection xmartOptionFeatures;
    private XmartOdcEntityCollection xmartPartyReportObligations;
    //FROBI-7445
    private XmartOdcEntityCollection xmartPostTradeClassifications;
    private XmartOdcEntityCollection xmartPrincipalMovementEvents;
    private XmartOdcEntityCollection xmartRegulatoryAuthorities;
    private XmartOdcEntityCollection xmartRelatedCurrencies;
    private XmartOdcEntityCollection xmartReportableIndexes;
    //FROBI-7449
    private XmartOdcEntityCollection xmartReportableUnderlyingInstruments;

    private XmartOdcEntityCollection xmartTradingParties;

    private XmartOdcEntityCollection xmartReportableTransactionStates;

    private XmartOdcEntityCollection xmartScheduleEntries;
    private XmartOdcEntityCollection xmartFxFixingScheduleEntries;

    private XmartOdcEntityCollection xmartTradingPartyAttestations;

    public XmartTransactionSet() {
        // No default constructor
    }

    public XmartTransactionSet(String topic, int partition, int clientId, long position, long consumeTimestamp) {

    }

    public void addOdcTransaction(String sourceTopic, int sourcePartition, int sourceTopicId, long sourcePosition,
            long sourceTimestamp, Transaction odcTransaction,
            DataFabricStreamEvent<ODCValue<TransactionId, Transaction>> dfStreamEvent) throws XmartException {

        long documentKey = generateDocumentKey(sourcePartition, sourceTopicId, sourcePosition, sourceTimestamp);

        xmartTransaction = new XmartTransaction(sourceTopic, sourcePartition, sourceTopicId, sourcePosition,
                sourceTimestamp, documentKey, odcTransaction, dfStreamEvent);

        if (!XmlUtil.isValidEntity(xmartTransaction)) {
            throw new XmartException(
                    "Invalid Xmart Transaction - no trigger attribute set even though keys are mandatory.");
        }

        xmartTransactionLegs = new XmartTransactionLegs(documentKey, odcTransaction).build();
        xmartLegInformationSources = new XmartLegInformationSources(documentKey, odcTransaction).build();
        xmartAlternateTransactionIdentifiers = new XmartAlternateTransactionIdentifiers(documentKey, odcTransaction)
                .build();

        xmartAgreementTransactionContexts = new XmartAgreementTransactionContexts(documentKey, odcTransaction).build();
        xmartTransactionStatuses = new XmartTransactionStatuses(documentKey, odcTransaction).build();
        xmartTransactionLegalEntities = new XmartTransactionLegalEntities(documentKey, odcTransaction).build();
        xmartFxLegs = new XmartFxLegs(documentKey, odcTransaction).build();
        xmartBookCounterParties = new XmartBookCounterParties(documentKey, odcTransaction).build();
        xmartRegulatoryRegimeImpacts = new XmartRegulatoryRegimeImpacts(documentKey, odcTransaction).build();
        xmartRegimePartyRoles = new XmartRegimePartyRoles(documentKey, odcTransaction).build();
        xmartRegimeBookRoles = new XmartRegimeBookRoles(documentKey, odcTransaction).build();
        xmartInterestRateLegs = new XmartInterestRateLegs(documentKey, odcTransaction).build();
        xmartReportableInstruments = new XmartReportableInstruments(documentKey, odcTransaction).build();
        xmartBookReportObligations = new XmartBookReportObligations(documentKey, odcTransaction).build();
        xmartCreditDerivativeAdditionalTerms = new XmartCreditDerivativeAdditionalTerms(documentKey, odcTransaction)
                .build();
        xmartCompoundUnderlierMembers = new XmartCompoundUnderlierMembers(documentKey, odcTransaction).build();
        xmartCreditEventPublicSources = new XmartCreditEventPublicSources(documentKey, odcTransaction).build();
        xmartVarianceLegs = new XmartVarianceLegs(documentKey, odcTransaction).build();
        xmartUnderliers = new XmartUnderliers(documentKey, odcTransaction).build();
        xmartTxnRegMarImp = new XmartTransactionRegulatoryMarginImpacts(documentKey, odcTransaction).build();
        xmartTxnSourceSystems = new XmartTransactionSourceSystems(documentKey, odcTransaction).build();
        xmartTransactionProcessDirectives = new XmartTransactionProcessDirectives(documentKey, odcTransaction).build();
        xmartTransactionProcessRolePlayers = new XmartTransactionProcessRolePlayers(documentKey, odcTransaction)
                .build();

        xmartTransactionMarginElections = new XmartTransactionMarginElections(documentKey, odcTransaction).build();
        xmartTransactionMarginJurisdictions = new XmartTransactionMarginJurisdictions(documentKey, odcTransaction)
                .build();
        xmartTransactionLegCurves = new XmartTransactionLegCurves(documentKey, odcTransaction).build();
        xmartTransactionLifecycleEvents = new XmartTransactionLifecycleEvents(documentKey, odcTransaction).build();
        xmartTransactionInstanceLinks = new XmartTransactionInstanceLinks(documentKey, odcTransaction).build();
        xmartSettlementSystemMigrationDatas = new XmartSettlementSystemMigrationDatas(documentKey, odcTransaction)
                .build();
        xmartReportingWaivers = new XmartReportingWaivers(documentKey, odcTransaction).build();

        xmartRoutingAttributes = new XmartRoutingAttributes(documentKey, odcTransaction).build();
        xmartSalesCreditComponents = new XmartSalesCreditComponents(documentKey, odcTransaction).build();
        //FROBI 7369
        xmartCreditDerivativeLegs = new XmartCreditDerivativeLegs(documentKey, odcTransaction).build();
        xmartDeliverableObligations = new XmartDeliverableObligations(documentKey, odcTransaction).build();
        xmartEmployeeIdEntries = new XmartEmployeeIdEntries(documentKey, odcTransaction).build();
        xmartExceptionalTermsDetails = new XmartExceptionalTermsDetails(documentKey, odcTransaction).build();
        xmartExternalTransactionIdentifiers = new XmartExternalTransactionIdentifiers(documentKey, odcTransaction)
                .build();

        //FROBI-7375
        xmartForwardFeatures = new XmartForwardFeatures(documentKey, odcTransaction).build();
        xmartFuturesLegs = new XmartFuturesLegs(documentKey, odcTransaction).build();
        xmartInflationRateLegs = new XmartInflationRateLegs(documentKey, odcTransaction).build();
        xmartLegBusinessCentres = new XmartLegBusinessCentres(documentKey, odcTransaction).build();

        // FROBI-7441
        xmartLegParameters = new XmartLegParameters(documentKey, odcTransaction).build();
        xmartLinkedTransactions = new XmartLinkedTransactions(documentKey, odcTransaction).build();
        xmartNotionalResets = new XmartNotionalResets(documentKey, odcTransaction).build();
        xmartOptionFeatures = new XmartOptionFeatures(documentKey, odcTransaction).build();
        xmartPartyReportObligations = new XmartPartyReportObligations(documentKey, odcTransaction).build();

        //FROBI-7445
        xmartPostTradeClassifications = new XmartPostTradeClassifications(documentKey, odcTransaction).build();
        xmartPrincipalMovementEvents = new XmartPrincipalMovementEvents(documentKey, odcTransaction).build();
        xmartRegulatoryAuthorities = new XmartRegulatoryAuthorities(documentKey, odcTransaction).build();
        xmartRelatedCurrencies = new XmartRelatedCurrencies(documentKey, odcTransaction).build();
        xmartReportableIndexes = new XmartReportableIndexes(documentKey, odcTransaction).build();

        // FROBI-7449
        xmartReportableUnderlyingInstruments = new XmartReportableUnderlyingInstruments(documentKey, odcTransaction)
                .build();
        xmartTradingParties = new XmartTradingParties(documentKey, odcTransaction).build();

        xmartReportableTransactionStates = new XmartReportableTransactionStates(documentKey, odcTransaction).build();

        xmartTradingPartyAttestations = new XmartTradingPartyAttestations(documentKey, odcTransaction).build();
    }

    @Override
    public void addOdcAttribute(String sourceTopic, int sourcePartition, int sourceTopicId, long sourcePosition,
            long sourceTimestamp, Transaction transaction,
            DataFabricStreamEvent<ODCValue<TransactionId, Transaction>> dfStreamEvent, Long odcVersion)
            throws XmartException {
        addOdcTransaction(sourceTopic, sourcePartition, sourceTopicId, sourcePosition, sourceTimestamp, transaction,
                dfStreamEvent);
    }

    public Long getWindowKey() {
        if (nonNull(xmartTransaction)) {
            return xmartTransaction.getDocumentKey();
        } else {
            return xmartScheduleEntries.getDocumentKey();
        }
    }

    public String getSourceSystemTransactionId() {
        return xmartTransaction.getSourceSystemTransactionId();
    }

    public String getSourceSystemId() {
        return xmartTransaction.getSourceSystemId();
    }

    public String getVersion() {
        return xmartTransaction.getVersion();
    }

    public Long getDocumentKey() {
        return xmartTransaction.getDocumentKey();
    }

    public XmartTransaction getXmartTransaction() {
        return xmartTransaction;
    }

    public XmartOdcEntityCollection getXmartTransactionLegs() {
        return xmartTransactionLegs;
    }

    public XmartOdcEntityCollection getXmartLegInformationSources() {
        return xmartLegInformationSources;
    }

    public XmartOdcEntityCollection getXmartAlternateTransactionIdentifiers() {
        return xmartAlternateTransactionIdentifiers;
    }

    public XmartOdcEntityCollection getXmartAgreementTransactionContexts() {
        return xmartAgreementTransactionContexts;
    }

    public XmartOdcEntityCollection getXmartTransactionStatuses() {
        return xmartTransactionStatuses;
    }

    public XmartOdcEntityCollection getXmartTransactionLegalEntities() {
        return xmartTransactionLegalEntities;
    }

    public XmartOdcEntityCollection getXmartFxLegs() {
        return xmartFxLegs;
    }

    public XmartOdcEntityCollection getXmartBookCounterParties() {
        return xmartBookCounterParties;
    }

    public XmartOdcEntityCollection getXmartRegulatoryRegimeImpacts() {
        return xmartRegulatoryRegimeImpacts;
    }

    public XmartOdcEntityCollection getXmartRegimePartyRoles() {
        return xmartRegimePartyRoles;
    }

    public XmartOdcEntityCollection getXmartRegimeBookRoles() {
        return xmartRegimeBookRoles;
    }

    public XmartOdcEntityCollection getXmartInterestRateLegs() {
        return xmartInterestRateLegs;
    }

    public XmartOdcEntityCollection getXmartReportableInstruments() {
        return xmartReportableInstruments;
    }

    public XmartOdcEntityCollection getXmartVarianceLegs() {
        return xmartVarianceLegs;
    }

    public XmartOdcEntityCollection getXmartUnderliers() {
        return xmartUnderliers;
    }

    public XmartOdcEntityCollection getXmartTxnRegMarImp() {
        return xmartTxnRegMarImp;
    }

    public XmartOdcEntityCollection getXmartTxnSourceSystems() {
        return xmartTxnSourceSystems;
    }

    public XmartOdcEntityCollection getXmartBookReportObligations() {
        return xmartBookReportObligations;
    }

    public XmartOdcEntityCollection getXmartCreditDerivativeAdditionalTerms() {
        return xmartCreditDerivativeAdditionalTerms;
    }

    public XmartOdcEntityCollection getXmartCompoundUnderlierMembers() {
        return xmartCompoundUnderlierMembers;
    }

    public XmartOdcEntityCollection getXmartCreditEventPublicSources() {
        return xmartCreditEventPublicSources;
    }

    public XmartOdcEntityCollection getXmartTransactionProcessDirectives() {
        return xmartTransactionProcessDirectives;
    }

    public XmartOdcEntityCollection getXmartTransactionProcessRolePlayers() {
        return xmartTransactionProcessRolePlayers;
    }

    public XmartOdcEntityCollection getXmartTransactionMarginElections() {
        return xmartTransactionMarginElections;
    }

    public XmartOdcEntityCollection getXmartTransactionMarginJurisdictions() {
        return xmartTransactionMarginJurisdictions;
    }

    public XmartOdcEntityCollection getXmartTransactionLegCurves() {
        return xmartTransactionLegCurves;
    }

    public XmartOdcEntityCollection getXmartTransactionLifecycleEvents() {
        return xmartTransactionLifecycleEvents;
    }

    public XmartOdcEntityCollection getXmartTransactionInstanceLinks() {
        return xmartTransactionInstanceLinks;
    }

    public XmartOdcEntityCollection getXmartSettlementSystemMigrationDatas() {
        return xmartSettlementSystemMigrationDatas;
    }

    public XmartOdcEntityCollection getXmartReportingWaivers() {
        return xmartReportingWaivers;
    }

    public XmartOdcEntityCollection getXmartRoutingAttributes() {
        return xmartRoutingAttributes;
    }

    public XmartOdcEntityCollection getXmartSalesCreditComponents() {
        return xmartSalesCreditComponents;
    }

    public XmartOdcEntityCollection getXmartCreditDerivativeLegs() {
        return xmartCreditDerivativeLegs;
    }

    public XmartOdcEntityCollection getXmartDeliverableObligations() {
        return xmartDeliverableObligations;
    }

    public XmartOdcEntityCollection getXmartEmployeeIdEntries() {
        return xmartEmployeeIdEntries;
    }

    public XmartOdcEntityCollection getXmartExceptionalTermsDetails() {
        return xmartExceptionalTermsDetails;
    }

    public XmartOdcEntityCollection getXmartExternalTransactionIdentifiers() {
        return xmartExternalTransactionIdentifiers;
    }

    public XmartOdcEntityCollection getXmartForwardFeatures() {
        return xmartForwardFeatures;
    }

    public XmartOdcEntityCollection getXmartFuturesLegs() {
        return xmartFuturesLegs;
    }

    public XmartOdcEntityCollection getXmartInflationRateLegs() {
        return xmartInflationRateLegs;
    }

    public XmartOdcEntityCollection getXmartLegBusinessCentres() {
        return xmartLegBusinessCentres;
    }

    public XmartOdcEntityCollection getXmartLegParameters() {
        return xmartLegParameters;
    }

    public XmartOdcEntityCollection getXmartLinkedTransactions() {
        return xmartLinkedTransactions;
    }

    public XmartOdcEntityCollection getXmartNotionalResets() {
        return xmartNotionalResets;
    }

    public XmartOdcEntityCollection getXmartOptionFeatures() {
        return xmartOptionFeatures;
    }

    public XmartOdcEntityCollection getXmartPartyReportObligations() {
        return xmartPartyReportObligations;
    }

    public XmartOdcEntityCollection getXmartPostTradeClassifications() {
        return xmartPostTradeClassifications;
    }

    public XmartOdcEntityCollection getXmartPrincipalMovementEvents() {
        return xmartPrincipalMovementEvents;
    }

    public XmartOdcEntityCollection getXmartRegulatoryAuthorities() {
        return xmartRegulatoryAuthorities;
    }

    public XmartOdcEntityCollection getXmartRelatedCurrencies() {
        return xmartRelatedCurrencies;
    }

    public XmartOdcEntityCollection getXmartReportableIndexes() {
        return xmartReportableIndexes;
    }

    public XmartOdcEntityCollection getXmartReportableUnderlyingInstruments() {
        return xmartReportableUnderlyingInstruments;
    }

    public XmartOdcEntityCollection getXmartTradingParties() {
        return xmartTradingParties;
    }

    public XmartOdcEntityCollection getXmartReportableTransactionStates() {
        return xmartReportableTransactionStates;
    }

    public XmartOdcEntityCollection getXmartTradingPartyAttestations() {
        return xmartTradingPartyAttestations;
    }

    public XmartOdcEntityCollection getXmartScheduleEntries() {
        return xmartScheduleEntries;
    }

    public XmartOdcEntityCollection getXmartFxFixingScheduleEntries() {
        return xmartFxFixingScheduleEntries;
    }

    /**
     * Overloaded version for specifically handling the Schedule Entries collection.
     *
     * @param streamEvent
     */
    public void addOdcAttribute(DataFabricStreamEvent<XmartODCScheduleEntries> streamEvent, int topicId)
            throws XmartException {
        if (isNull(streamEvent) || isNull(streamEvent.getEventPayload()) || isNull(
                streamEvent.getEventPayload().getParentKey())) {
            return;
        }

        long documentKey = generateDocumentKey(streamEvent.getPartition(), topicId, streamEvent.getStreamPosition(),
                streamEvent.getTimestamp());

        xmartScheduleEntries = new XmartScheduleEntries(documentKey, streamEvent).build();
        xmartFxFixingScheduleEntries = new XmartFxFixingScheduleEntries(documentKey, streamEvent).build();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("XmartTransactionSet [");
        if (xmartTransaction != null)
            builder.append(xmartTransaction);
        builder.append("]");
        return builder.toString();
    }
}
