package com.nwm.xmart.entities.kdb;

import java.io.Serializable;
import java.time.LocalDateTime;

import static com.nwm.xmart.util.BusinessRulesUtil.isKdbNull;
import static com.nwm.xmart.util.DateUtil.formatDate;

/**
 * Simple class that holds a single KDB INquiry State
 *
 * @author heskets
 */
public class XmartKdbInquiryState implements Serializable {

    private final String stateCode;
    private final LocalDateTime stateDateTime;
    private final String stateType;
    private final String stateConversationReference;
    private final String stateExecutionReference;
    private final Double statePrice;
    private final LocalDateTime lastAcceptedAppDateLocal;

    public XmartKdbInquiryState(String stateCode, LocalDateTime stateDateTime, String stateType,
            String stateExecutionReference, String stateConversationReference, Double statePrice,
            LocalDateTime lastAcceptedAppDateLocal) {
        this.stateCode = stateCode;
        this.stateDateTime = stateDateTime;
        this.stateType = stateType;
        this.stateExecutionReference = stateExecutionReference;
        this.stateConversationReference = stateConversationReference;
        this.statePrice = statePrice;
        this.lastAcceptedAppDateLocal = lastAcceptedAppDateLocal;
    }

    public XmartKdbInquiryState(String stateCode, java.sql.Timestamp stateDateTime, String stateType,
            String stateExecutionReference, String stateConversationReference, Double statePrice,
            java.sql.Timestamp lastAcceptedAppDateLocal) {
        this.stateCode = stateCode;
        this.stateDateTime = !isKdbNull(stateDateTime) ? stateDateTime.toLocalDateTime() : null;
        this.stateType = stateType;
        this.stateExecutionReference = stateExecutionReference;
        this.stateConversationReference = stateConversationReference;
        this.statePrice = statePrice;
        this.lastAcceptedAppDateLocal = !isKdbNull(lastAcceptedAppDateLocal) ?
                                        lastAcceptedAppDateLocal.toLocalDateTime() : null;
    }

    public XmartKdbInquiryState(String stateCode, java.util.Date stateDate, String stateType,
            String stateExecutionReference, String stateConversationReference, Double statePrice,
            java.util.Date lastAcceptedAppDateLocal) {
        this.stateCode = stateCode;

        this.stateDateTime = !isKdbNull(stateDate) ? new java.sql.Timestamp(stateDate.getTime()).toLocalDateTime() :
                             null;

        new java.sql.Timestamp(stateDate.getTime()).toLocalDateTime();
        formatDate(stateDate);
        this.stateType = stateType;
        this.stateExecutionReference = stateExecutionReference;
        this.stateConversationReference = stateConversationReference;
        this.statePrice = statePrice;

        this.lastAcceptedAppDateLocal = !isKdbNull(lastAcceptedAppDateLocal) ?
                                        new java.sql.Timestamp(lastAcceptedAppDateLocal.getTime()).toLocalDateTime() :
                                        null;
    }

    public XmartKdbInquiryState(String stateCode, String stateType, String stateExecutionReference, Double statePrice) {
        this.stateCode = stateCode;
        this.stateDateTime = null;
        this.stateType = stateType;
        this.stateExecutionReference = stateExecutionReference;
        this.stateConversationReference = null;
        this.statePrice = statePrice;
        this.lastAcceptedAppDateLocal = null;
    }

    public XmartKdbInquiryState(String stateCode, java.sql.Timestamp stateTimestamp) {
        this.stateCode = stateCode;
        this.stateDateTime = !isKdbNull(stateTimestamp) ? stateTimestamp.toLocalDateTime() : null;
        this.stateType = null;
        this.stateExecutionReference = null;
        this.stateConversationReference = null;
        this.statePrice = null;
        this.lastAcceptedAppDateLocal = null;
    }

    public XmartKdbInquiryState(String stateCode, LocalDateTime stateDateTime) {
        this.stateCode = stateCode;
        this.stateDateTime = stateDateTime;
        this.stateType = null;
        this.stateExecutionReference = null;
        this.stateConversationReference = null;
        this.statePrice = null;
        this.lastAcceptedAppDateLocal = null;
    }

    public XmartKdbInquiryState(String stateCode, java.util.Date stateDate) {
        this.stateCode = stateCode;
        this.stateDateTime = new java.sql.Timestamp(stateDate.getTime()).toLocalDateTime();
        this.stateType = null;
        this.stateExecutionReference = null;
        this.stateConversationReference = null;
        this.statePrice = null;
        this.lastAcceptedAppDateLocal = null;
    }

    public String getStateCode() {
        return stateCode;
    }

    public LocalDateTime getStateDateTime() {
        return stateDateTime;
    }

    public String getStateType() {
        return stateType;
    }

    public String getStateExecutionReference() {
        return stateExecutionReference;
    }

    public String getStateConversationReference() {
        return stateConversationReference;
    }

    public Double getStatePrice() {
        return statePrice;
    }

    public LocalDateTime getLastAcceptedAppDateLocal() {
        return lastAcceptedAppDateLocal;
    }
}
