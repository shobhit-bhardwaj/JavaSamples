package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.PartyReportObligation;
import com.rbs.odc.access.domain.RegimePartyRole;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartPartyReportObligations
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartPartyReportObligation> {

    private static final long serialVersionUID = 3666067845779577592L;
    private static final Logger logger = LoggerFactory.getLogger(XmartPartyReportObligations.class);

    public XmartPartyReportObligations(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "Regulatory Regime Impacts not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {

        Collection<RegimePartyRole> regimePartyRoles = nullCollToEmpty(regulatoryRegimeImpact.getRegimePartyRoles(),
                logger, "RegimePartyRoles not received for document key : " + getDocumentKey());

        for (RegimePartyRole regimePartyRole : regimePartyRoles) {
            if (nonNull(regimePartyRole)) {
                for (PartyReportObligation partyReportObligation : nullCollToEmpty(
                        regimePartyRole.getPartyReportObligations())) {
                    XmartPartyReportObligation xmartPartyReportObligation = new XmartPartyReportObligation(
                            getDocumentKey());
                    xmartPartyReportObligation.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
                    xmartPartyReportObligation.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
                    xmartPartyReportObligation.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());
                    xmartPartyReportObligation.setReportingRoleScheme(getStr(regimePartyRole.getReportingRoleScheme()));
                    if (nonNull(partyReportObligation)) {
                        xmartPartyReportObligation
                                .setRegulatoryReportName(partyReportObligation.getRegulatoryReportName());
                    }
                    addEntity(xmartPartyReportObligation);
                }
            }
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
