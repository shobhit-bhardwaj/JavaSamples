package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

public class XmartUnderlier extends XmartEntity {
    private static final long serialVersionUID = 3688643073480575370L;
    @XmartAttribute(xmlTrigger = false, usedInJoin = true)
    private String legIdentifier;
    @XmartAttribute(usedInJoin = true)
    private String underlierId;
    @XmartAttribute
    private BigDecimal basketWeightPercentage;
    @XmartAttribute
    private String basketWeightCurrencyCode;
    @XmartAttribute
    private BigDecimal basketWeightValue;
    @XmartAttribute
    private BigDecimal openUnits;
    @XmartAttribute
    private BigDecimal referencePricePercentage;
    @XmartAttribute
    private String originalFaceAmountCurrencyCode;
    @XmartAttribute
    private Boolean standardReferenceObligation;
    @XmartAttribute
    private String securityName;
    @XmartAttribute
    private String seniority;
    @XmartAttribute
    private Boolean isWithholdingTaxApplicable;
    @XmartAttribute
    private String instrumentUnderlierInstrumentScheme;
    @XmartAttribute
    private String instrumentUnderlierInstrumentId;
    @XmartAttribute
    private String alternateIdentifier;
    @XmartAttribute
    private String tradeableIndexName;
    @XmartAttribute
    private Long indexVersion;
    @XmartAttribute
    private BigDecimal attachmentPoint;
    @XmartAttribute
    private BigDecimal exhaustionPoint;
    @XmartAttribute
    private Date indexAnnexDate;
    @XmartAttribute
    private Date indexEffectiveDate;
    @XmartAttribute
    private String indexDayCountConvention;
    @XmartAttribute
    private Integer tenorPeriodMultiplier;
    @XmartAttribute
    private String tenorPeriodScheme;
    @XmartAttribute
    private Integer initialLagPeriodMultiplier;
    @XmartAttribute
    private String initialLagPeriodScheme;
    @XmartAttribute
    private Integer finalLagPeriodMultiplier;
    @XmartAttribute
    private String finalLagPeriodScheme;
    @XmartAttribute
    private Integer paymentPeriodMultiplier;
    @XmartAttribute
    private String paymentPeriodScheme;
    @XmartAttribute
    private String tradeableIndexInstrumentScheme;
    @XmartAttribute
    private String tradeableIndexInstrumentId;
    @XmartAttribute
    private Long indexSeries;
    @XmartAttribute
    private BigDecimal currentTrancheStart;
    @XmartAttribute
    private BigDecimal currentTrancheEnd;
    @XmartAttribute
    private BigDecimal origPoolAmount;
    @XmartAttribute
    private BigDecimal currentPoolAmount;
    @XmartAttribute
    private BigDecimal basketConstituentCount;
    @XmartAttribute
    private BigDecimal indexFactor;
    @XmartAttribute
    private Date maturityDate;
    @XmartAttribute
    private Date creditAgreementDate;
    @XmartAttribute
    private String tranche;
    @XmartAttribute
    private String outstandingInstrumentId;
    @XmartAttribute
    private String facilityInstrumentId;
    @XmartAttribute
    private String lxrefInstrumentId;
    @XmartAttribute
    private String dealInstrumentId;
    @XmartAttribute
    private String outstandingInstrumentName;
    @XmartAttribute
    private String facilityInstrumentName;
    @XmartAttribute
    private String lxrefInstrumentName;
    @XmartAttribute
    private String dealInstrumentName;
    @XmartAttribute
    private String incomeStreamCurrencyCode;
    @XmartAttribute
    private String underlyerAssetClass;

    public XmartUnderlier(long documentKey) throws XmartException {
        super(documentKey);
    }

    public Boolean getStandardReferenceObligation() {
        return standardReferenceObligation;
    }

    public void setStandardReferenceObligation(Boolean standardReferenceObligation) {
        this.standardReferenceObligation = standardReferenceObligation;
    }

    public Boolean getWithholdingTaxApplicable() {
        return isWithholdingTaxApplicable;
    }

    public void setWithholdingTaxApplicable(Boolean withholdingTaxApplicable) {
        isWithholdingTaxApplicable = withholdingTaxApplicable;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public void setLegIdentifier(String legIdentifier) {
        this.legIdentifier = legIdentifier;
    }

    public String getUnderlierId() {
        return underlierId;
    }

    public void setUnderlierId(String underlierId) {
        this.underlierId = underlierId;
    }

    public BigDecimal getBasketWeightPercentage() {
        return basketWeightPercentage;
    }

    public void setBasketWeightPercentage(BigDecimal basketWeightPercentage) {
        this.basketWeightPercentage = basketWeightPercentage;
    }

    public String getBasketWeightCurrencyCode() {
        return basketWeightCurrencyCode;
    }

    public void setBasketWeightCurrencyCode(String basketWeightCurrencyCode) {
        this.basketWeightCurrencyCode = basketWeightCurrencyCode;
    }

    public BigDecimal getBasketWeightValue() {
        return basketWeightValue;
    }

    public void setBasketWeightValue(BigDecimal basketWeightValue) {
        this.basketWeightValue = basketWeightValue;
    }

    public BigDecimal getOpenUnits() {
        return openUnits;
    }

    public void setOpenUnits(BigDecimal openUnits) {
        this.openUnits = openUnits;
    }

    public BigDecimal getReferencePricePercentage() {
        return referencePricePercentage;
    }

    public void setReferencePricePercentage(BigDecimal referencePricePercentage) {
        this.referencePricePercentage = referencePricePercentage;
    }

    public String getOriginalFaceAmountCurrencyCode() {
        return originalFaceAmountCurrencyCode;
    }

    public void setOriginalFaceAmountCurrencyCode(String originalFaceAmountCurrencyCode) {
        this.originalFaceAmountCurrencyCode = originalFaceAmountCurrencyCode;
    }

    public Boolean isStandardReferenceObligation() {
        return standardReferenceObligation;
    }

    public String getSecurityName() {
        return securityName;
    }

    public void setSecurityName(String securityName) {
        this.securityName = securityName;
    }

    public String getSeniority() {
        return seniority;
    }

    public void setSeniority(String seniority) {
        this.seniority = seniority;
    }

    public Boolean isWithholdingTaxApplicable() {
        return isWithholdingTaxApplicable;
    }

    public String getInstrumentUnderlierInstrumentScheme() {
        return instrumentUnderlierInstrumentScheme;
    }

    public void setInstrumentUnderlierInstrumentScheme(String instrumentUnderlierInstrumentScheme) {
        this.instrumentUnderlierInstrumentScheme = instrumentUnderlierInstrumentScheme;
    }

    public String getInstrumentUnderlierInstrumentId() {
        return instrumentUnderlierInstrumentId;
    }

    public void setInstrumentUnderlierInstrumentId(String instrumentUnderlierInstrumentId) {
        this.instrumentUnderlierInstrumentId = instrumentUnderlierInstrumentId;
    }

    public String getAlternateIdentifier() {
        return alternateIdentifier;
    }

    public void setAlternateIdentifier(String alternateIdentifier) {
        this.alternateIdentifier = alternateIdentifier;
    }

    public String getTradeableIndexName() {
        return tradeableIndexName;
    }

    public void setTradeableIndexName(String tradeableIndexName) {
        this.tradeableIndexName = tradeableIndexName;
    }

    public Long getIndexVersion() {
        return indexVersion;
    }

    public void setIndexVersion(Long indexVersion) {
        this.indexVersion = indexVersion;
    }

    public BigDecimal getAttachmentPoint() {
        return attachmentPoint;
    }

    public void setAttachmentPoint(BigDecimal attachmentPoint) {
        this.attachmentPoint = attachmentPoint;
    }

    public BigDecimal getExhaustionPoint() {
        return exhaustionPoint;
    }

    public void setExhaustionPoint(BigDecimal exhaustionPoint) {
        this.exhaustionPoint = exhaustionPoint;
    }

    public Date getIndexAnnexDate() {
        return indexAnnexDate;
    }

    public void setIndexAnnexDate(Date indexAnnexDate) {
        this.indexAnnexDate = indexAnnexDate;
    }

    public Date getIndexEffectiveDate() {
        return indexEffectiveDate;
    }

    public void setIndexEffectiveDate(Date indexEffectiveDate) {
        this.indexEffectiveDate = indexEffectiveDate;
    }

    public String getIndexDayCountConvention() {
        return indexDayCountConvention;
    }

    public void setIndexDayCountConvention(String indexDayCountConvention) {
        this.indexDayCountConvention = indexDayCountConvention;
    }

    public Integer getTenorPeriodMultiplier() {
        return tenorPeriodMultiplier;
    }

    public void setTenorPeriodMultiplier(Integer tenorPeriodMultiplier) {
        this.tenorPeriodMultiplier = tenorPeriodMultiplier;
    }

    public String getTenorPeriodScheme() {
        return tenorPeriodScheme;
    }

    public void setTenorPeriodScheme(String tenorPeriodScheme) {
        this.tenorPeriodScheme = tenorPeriodScheme;
    }

    public Integer getInitialLagPeriodMultiplier() {
        return initialLagPeriodMultiplier;
    }

    public void setInitialLagPeriodMultiplier(Integer initialLagPeriodMultiplier) {
        this.initialLagPeriodMultiplier = initialLagPeriodMultiplier;
    }

    public String getInitialLagPeriodScheme() {
        return initialLagPeriodScheme;
    }

    public void setInitialLagPeriodScheme(String initialLagPeriodScheme) {
        this.initialLagPeriodScheme = initialLagPeriodScheme;
    }

    public Integer getFinalLagPeriodMultiplier() {
        return finalLagPeriodMultiplier;
    }

    public void setFinalLagPeriodMultiplier(Integer finalLagPeriodMultiplier) {
        this.finalLagPeriodMultiplier = finalLagPeriodMultiplier;
    }

    public String getFinalLagPeriodScheme() {
        return finalLagPeriodScheme;
    }

    public void setFinalLagPeriodScheme(String finalLagPeriodScheme) {
        this.finalLagPeriodScheme = finalLagPeriodScheme;
    }

    public Integer getPaymentPeriodMultiplier() {
        return paymentPeriodMultiplier;
    }

    public void setPaymentPeriodMultiplier(Integer paymentPeriodMultiplier) {
        this.paymentPeriodMultiplier = paymentPeriodMultiplier;
    }

    public String getPaymentPeriodScheme() {
        return paymentPeriodScheme;
    }

    public void setPaymentPeriodScheme(String paymentPeriodScheme) {
        this.paymentPeriodScheme = paymentPeriodScheme;
    }

    public String getTradeableIndexInstrumentScheme() {
        return tradeableIndexInstrumentScheme;
    }

    public void setTradeableIndexInstrumentScheme(String tradeableIndexInstrumentScheme) {
        this.tradeableIndexInstrumentScheme = tradeableIndexInstrumentScheme;
    }

    public String getTradeableIndexInstrumentId() {
        return tradeableIndexInstrumentId;
    }

    public void setTradeableIndexInstrumentId(String tradeableIndexInstrumentId) {
        this.tradeableIndexInstrumentId = tradeableIndexInstrumentId;
    }

    public Long getIndexSeries() {
        return indexSeries;
    }

    public void setIndexSeries(Long indexSeries) {
        this.indexSeries = indexSeries;
    }

    public BigDecimal getCurrentTrancheStart() {
        return currentTrancheStart;
    }

    public void setCurrentTrancheStart(BigDecimal currentTrancheStart) {
        this.currentTrancheStart = currentTrancheStart;
    }

    public BigDecimal getCurrentTrancheEnd() {
        return currentTrancheEnd;
    }

    public void setCurrentTrancheEnd(BigDecimal currentTrancheEnd) {
        this.currentTrancheEnd = currentTrancheEnd;
    }

    public BigDecimal getOrigPoolAmount() {
        return origPoolAmount;
    }

    public void setOrigPoolAmount(BigDecimal origPoolAmount) {
        this.origPoolAmount = origPoolAmount;
    }

    public BigDecimal getCurrentPoolAmount() {
        return currentPoolAmount;
    }

    public void setCurrentPoolAmount(BigDecimal currentPoolAmount) {
        this.currentPoolAmount = currentPoolAmount;
    }

    public BigDecimal getBasketConstituentCount() {
        return basketConstituentCount;
    }

    public void setBasketConstituentCount(BigDecimal basketConstituentCount) {
        this.basketConstituentCount = basketConstituentCount;
    }

    public BigDecimal getIndexFactor() {
        return indexFactor;
    }

    public void setIndexFactor(BigDecimal indexFactor) {
        this.indexFactor = indexFactor;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public Date getCreditAgreementDate() {
        return creditAgreementDate;
    }

    public void setCreditAgreementDate(Date creditAgreementDate) {
        this.creditAgreementDate = creditAgreementDate;
    }

    public String getTranche() {
        return tranche;
    }

    public void setTranche(String tranche) {
        this.tranche = tranche;
    }

    public String getOutstandingInstrumentId() {
        return outstandingInstrumentId;
    }

    public void setOutstandingInstrumentId(String outstandingInstrumentId) {
        this.outstandingInstrumentId = outstandingInstrumentId;
    }

    public String getFacilityInstrumentId() {
        return facilityInstrumentId;
    }

    public void setFacilityInstrumentId(String facilityInstrumentId) {
        this.facilityInstrumentId = facilityInstrumentId;
    }

    public String getLxrefInstrumentId() {
        return lxrefInstrumentId;
    }

    public void setLxrefInstrumentId(String lxrefInstrumentId) {
        this.lxrefInstrumentId = lxrefInstrumentId;
    }

    public String getDealInstrumentId() {
        return dealInstrumentId;
    }

    public void setDealInstrumentId(String dealInstrumentId) {
        this.dealInstrumentId = dealInstrumentId;
    }

    public String getOutstandingInstrumentName() {
        return outstandingInstrumentName;
    }

    public void setOutstandingInstrumentName(String outstandingInstrumentName) {
        this.outstandingInstrumentName = outstandingInstrumentName;
    }

    public String getFacilityInstrumentName() {
        return facilityInstrumentName;
    }

    public void setFacilityInstrumentName(String facilityInstrumentName) {
        this.facilityInstrumentName = facilityInstrumentName;
    }

    public String getLxrefInstrumentName() {
        return lxrefInstrumentName;
    }

    public void setLxrefInstrumentName(String lxrefInstrumentName) {
        this.lxrefInstrumentName = lxrefInstrumentName;
    }

    public String getDealInstrumentName() {
        return dealInstrumentName;
    }

    public void setDealInstrumentName(String dealInstrumentName) {
        this.dealInstrumentName = dealInstrumentName;
    }

    public String getIncomeStreamCurrencyCode() {
        return incomeStreamCurrencyCode;
    }

    public void setIncomeStreamCurrencyCode(String incomeStreamCurrencyCode) {
        this.incomeStreamCurrencyCode = incomeStreamCurrencyCode;
    }

    public String getUnderlyerAssetClass() {
        return underlyerAssetClass;
    }

    public void setUnderlyerAssetClass(String underlyerAssetClass) {
        this.underlyerAssetClass = underlyerAssetClass;
    }
}
