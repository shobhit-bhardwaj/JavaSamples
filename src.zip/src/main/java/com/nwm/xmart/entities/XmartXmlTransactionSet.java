package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartXmlSet;

import static com.nwm.xmart.util.XmlUtil.getXmlDocument;
import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartXmlTransactionSet extends XmartXmlSet<XmartTransactionSet> {

    private static final long serialVersionUID = 4288719456060415484L;
    private StringBuilder xmartTransactionsXml = new StringBuilder();
    private StringBuilder xmartTransactionLegsXml = new StringBuilder();
    private StringBuilder xmartLegInformationSourcesXml = new StringBuilder();
    private StringBuilder xmartAlternateTransactionIdentifiersXml = new StringBuilder();
    private StringBuilder xmartAgreementTransactionContextsXml = new StringBuilder();
    private StringBuilder xmartTransactionStatusesXml = new StringBuilder();
    private StringBuilder xmartBookCounterPartiesXml = new StringBuilder();
    private StringBuilder xmartTransactionLegalEntitiesXml = new StringBuilder();
    private StringBuilder xmartFxLegsXml = new StringBuilder();
    private StringBuilder xmartRegulatoryRegimeImpactsXml = new StringBuilder();
    private StringBuilder xmartReportableInstrumentsXml = new StringBuilder();
    private StringBuilder xmartRegimeBookRolesXml = new StringBuilder();
    private StringBuilder xmartRegimePartyRolesXml = new StringBuilder();
    private StringBuilder xmartInterestRateLegsXml = new StringBuilder();
    private StringBuilder xmartVarianceLegsXml = new StringBuilder();
    private StringBuilder xmartUnderliersXml = new StringBuilder();
    private StringBuilder xmartTransactionRegulatoryMarginImpactsXml = new StringBuilder();
    private StringBuilder xmartTransactionSourceSystemsXml = new StringBuilder();
    private StringBuilder xmartBookReportObligationsXml = new StringBuilder();
    private StringBuilder xmartCreditDerivativeAdditionalTermsXml = new StringBuilder();
    private StringBuilder xmartCompoundUnderlierMembersXml = new StringBuilder();
    private StringBuilder xmartCreditEventPublicSourcesXml = new StringBuilder();
    private StringBuilder xmartTransactionMarginJurisdictionsXml = new StringBuilder();
    private StringBuilder xmartTransactionInstanceLinksXml = new StringBuilder();
    private StringBuilder xmartSettlementSystemMigrationDatasXml = new StringBuilder();
    private StringBuilder xmartReportingWaiversXml = new StringBuilder();
    private StringBuilder xmartRegulatoryAuthoritiesXml = new StringBuilder();
    private StringBuilder xmartRoutingAttributesXml = new StringBuilder();
    private StringBuilder xmartSalesCreditComponentsXml = new StringBuilder();
    private StringBuilder xmartReportableUnderlyingInstrumentsXml = new StringBuilder();
    private StringBuilder xmartCreditDerivativeLegsXml = new StringBuilder();
    private StringBuilder xmartDeliverableObligationsXml = new StringBuilder();
    private StringBuilder xmartEmployeeIdEntries = new StringBuilder();
    private StringBuilder xmartExceptionalTermsDetailsXml = new StringBuilder();
    private StringBuilder xmartExternalTransactionIdentifiersXml = new StringBuilder();
    //FROBI-7375
    private StringBuilder xmartForwardFeaturesXml = new StringBuilder();
    private StringBuilder xmartFuturesLegsXml = new StringBuilder();
    private StringBuilder xmartInflationRateLegsXml = new StringBuilder();
    private StringBuilder xmartLegBusinessCentresXml = new StringBuilder();

    //FROBI-7440
    private StringBuilder xmartLegParametersXml = new StringBuilder();
    private StringBuilder xmartLinkedTransactionsXml = new StringBuilder();
    private StringBuilder xmartNotionalResetsXml = new StringBuilder();
    private StringBuilder xmartOptionFeaturesXml = new StringBuilder();
    private StringBuilder xmartPartyReportObligationsXml = new StringBuilder();

    //FROBI-7445
    private StringBuilder xmartPostTradeClassificationsXml = new StringBuilder();
    private StringBuilder xmartPrincipalMovementEventsXml = new StringBuilder();
    private StringBuilder xmartRelatedCurrenciesXml = new StringBuilder();
    private StringBuilder xmartReportableIndexesXml = new StringBuilder();

    //FROBI-7453
    private StringBuilder xmartTradingPartiesXml = new StringBuilder();
    private StringBuilder xmartTransactionLegCurvesXml = new StringBuilder();
    private StringBuilder xmartTransactionLifecycleEventsXml = new StringBuilder();

    //FROBI-7457
    private StringBuilder xmartTransactionMarginElectionsXml = new StringBuilder();
    private StringBuilder xmartTransactionProcessDirectivesXml = new StringBuilder();
    private StringBuilder xmartTransactionProcessRolePlayersXml = new StringBuilder();

    private StringBuilder xmartReportableTransactionStatesXml = new StringBuilder();

    private StringBuilder xmartScheduleEntriesXml = new StringBuilder();
    private StringBuilder xmartFxFixingScheduleEntriesXml = new StringBuilder();

    private StringBuilder xmartTradingPartyAttestationsXml = new StringBuilder();

    /**
     * Utility constructor to provide if the XML generated here should be logged to the log files.
     *
     * @param logXML {@link Boolean} {@code true}: Log XML to file, {@code false}: Do not log it
     */
    public XmartXmlTransactionSet(Boolean logXML) {
        super(logXML);
    }

    @Override
    public void add(XmartTransactionSet xmartTransactionSet) {
        xmartTransactionsXml.append(xmartTransactionSet.getXmartTransaction());
        xmartTransactionLegsXml.append(xmartTransactionSet.getXmartTransactionLegs());
        xmartLegInformationSourcesXml.append(xmartTransactionSet.getXmartLegInformationSources());
        xmartAlternateTransactionIdentifiersXml.append(xmartTransactionSet.getXmartAlternateTransactionIdentifiers());
        xmartAgreementTransactionContextsXml.append(xmartTransactionSet.getXmartAgreementTransactionContexts());
        xmartTransactionStatusesXml.append(xmartTransactionSet.getXmartTransactionStatuses());
        xmartBookCounterPartiesXml.append(xmartTransactionSet.getXmartBookCounterParties());
        xmartTransactionLegalEntitiesXml.append(xmartTransactionSet.getXmartTransactionLegalEntities());
        xmartFxLegsXml.append(xmartTransactionSet.getXmartFxLegs());
        xmartRegulatoryRegimeImpactsXml.append(xmartTransactionSet.getXmartRegulatoryRegimeImpacts());
        xmartReportableInstrumentsXml.append(xmartTransactionSet.getXmartReportableInstruments());
        xmartRegimeBookRolesXml.append(xmartTransactionSet.getXmartRegimeBookRoles());
        xmartRegimePartyRolesXml.append(xmartTransactionSet.getXmartRegimePartyRoles());
        xmartInterestRateLegsXml.append(xmartTransactionSet.getXmartInterestRateLegs());
        xmartVarianceLegsXml.append(xmartTransactionSet.getXmartVarianceLegs());
        xmartUnderliersXml.append(xmartTransactionSet.getXmartUnderliers());
        xmartTransactionRegulatoryMarginImpactsXml.append(xmartTransactionSet.getXmartTxnRegMarImp());
        xmartTransactionSourceSystemsXml.append(xmartTransactionSet.getXmartTxnSourceSystems());
        xmartBookReportObligationsXml.append(xmartTransactionSet.getXmartBookReportObligations());
        xmartCreditDerivativeAdditionalTermsXml.append(xmartTransactionSet.getXmartCreditDerivativeAdditionalTerms());
        xmartCompoundUnderlierMembersXml.append(xmartTransactionSet.getXmartCompoundUnderlierMembers());
        xmartCreditEventPublicSourcesXml.append(xmartTransactionSet.getXmartCreditEventPublicSources());
        xmartExceptionalTermsDetailsXml.append(xmartTransactionSet.getXmartExceptionalTermsDetails());
        xmartExternalTransactionIdentifiersXml.append(xmartTransactionSet.getXmartExternalTransactionIdentifiers());
        xmartCreditDerivativeLegsXml.append(xmartTransactionSet.getXmartCreditDerivativeLegs());
        xmartDeliverableObligationsXml.append(xmartTransactionSet.getXmartDeliverableObligations());
        xmartEmployeeIdEntries.append(xmartTransactionSet.getXmartEmployeeIdEntries());
        xmartRegulatoryAuthoritiesXml.append(xmartTransactionSet.getXmartRegulatoryAuthorities());
        xmartRoutingAttributesXml.append(xmartTransactionSet.getXmartRoutingAttributes());
        xmartSalesCreditComponentsXml.append(xmartTransactionSet.getXmartSalesCreditComponents());

        //FROBI-7375
        xmartForwardFeaturesXml.append(xmartTransactionSet.getXmartForwardFeatures());
        xmartFuturesLegsXml.append(xmartTransactionSet.getXmartFuturesLegs());

        xmartInflationRateLegsXml.append(xmartTransactionSet.getXmartInflationRateLegs());
        xmartLegBusinessCentresXml.append(xmartTransactionSet.getXmartLegBusinessCentres());

        //FROBI-7441
        xmartLegParametersXml.append(xmartTransactionSet.getXmartLegParameters());
        xmartLinkedTransactionsXml.append(xmartTransactionSet.getXmartLinkedTransactions());
        xmartNotionalResetsXml.append(xmartTransactionSet.getXmartNotionalResets());
        xmartOptionFeaturesXml.append(xmartTransactionSet.getXmartOptionFeatures());
        xmartPartyReportObligationsXml.append(xmartTransactionSet.getXmartPartyReportObligations());
        //FROBI-7445
        xmartPostTradeClassificationsXml.append(xmartTransactionSet.getXmartPostTradeClassifications());
        xmartPrincipalMovementEventsXml.append(xmartTransactionSet.getXmartPrincipalMovementEvents());
        xmartRelatedCurrenciesXml.append(xmartTransactionSet.getXmartRelatedCurrencies());
        xmartReportableIndexesXml.append(xmartTransactionSet.getXmartReportableIndexes());

        //FROBI-7449
        xmartReportableUnderlyingInstrumentsXml.append(xmartTransactionSet.getXmartReportableUnderlyingInstruments());
        xmartReportingWaiversXml.append(xmartTransactionSet.getXmartReportingWaivers());

        //FROBI-7453
        xmartSettlementSystemMigrationDatasXml.append(xmartTransactionSet.getXmartSettlementSystemMigrationDatas());
        xmartTradingPartiesXml.append(xmartTransactionSet.getXmartTradingParties());
        xmartTransactionInstanceLinksXml.append(xmartTransactionSet.getXmartTransactionInstanceLinks());
        xmartTransactionLegCurvesXml.append(xmartTransactionSet.getXmartTransactionLegCurves());
        xmartTransactionLifecycleEventsXml.append(xmartTransactionSet.getXmartTransactionLifecycleEvents());

        //FROBI-7457
        xmartTransactionMarginElectionsXml.append(xmartTransactionSet.getXmartTransactionMarginElections());
        xmartTransactionMarginJurisdictionsXml.append(xmartTransactionSet.getXmartTransactionMarginJurisdictions());
        xmartTransactionProcessDirectivesXml.append(xmartTransactionSet.getXmartTransactionProcessDirectives());
        xmartTransactionProcessRolePlayersXml.append(xmartTransactionSet.getXmartTransactionProcessRolePlayers());

        xmartReportableTransactionStatesXml.append(xmartTransactionSet.getXmartReportableTransactionStates());

        xmartTradingPartyAttestationsXml.append(xmartTransactionSet.getXmartTradingPartyAttestations());

        if (nonNull(xmartTransactionSet.getXmartScheduleEntries())) {
            xmartScheduleEntriesXml.append(xmartTransactionSet.getXmartScheduleEntries());
        }
        if (nonNull(xmartTransactionSet.getXmartFxFixingScheduleEntries())) {
            xmartFxFixingScheduleEntriesXml.append(xmartTransactionSet.getXmartFxFixingScheduleEntries());
        }
    }

    public String getXmartTransactionsXml() {
        return getXmlDocument("XmartTransactions", xmartTransactionsXml.toString(), logXML);
    }

    public String getXmartTransactionLegsXml() {
        return getXmlDocument("XmartTransactionLegs", xmartTransactionLegsXml.toString(), logXML);
    }

    public String getXmartLegInformationSourcesXml() {
        return getXmlDocument("XmartLegInformationSources", xmartLegInformationSourcesXml.toString(), logXML);
    }

    public String getXmartAlternateTransactionIdentifiersXml() {
        return getXmlDocument("XmartAlternateTransactionIdentifiers",
                xmartAlternateTransactionIdentifiersXml.toString(), logXML);
    }

    public String getXmartAgreementTransactionContextsXml() {
        return getXmlDocument("XmartAgreementTransactionContexts", xmartAgreementTransactionContextsXml.toString(),
                logXML);
    }

    public String getXmartTransactionStatusesXml() {
        return getXmlDocument("XmartTransactionStatuses", xmartTransactionStatusesXml.toString(), logXML);
    }

    public String getXmartBookCounterPartiesXml() {
        return getXmlDocument("XmartBookCounterParties", xmartBookCounterPartiesXml.toString(), logXML);
    }

    public String getXmartTransactionLegalEntitiesXml() {
        return getXmlDocument("XmartTransactionLegalEntities", xmartTransactionLegalEntitiesXml.toString(), logXML);
    }

    public String getXmartFxLegsXml() {
        return getXmlDocument("XmartFxLegs", xmartFxLegsXml.toString(), logXML);
    }

    public String getXmartRegulatoryRegimeImpactsXml() {
        return getXmlDocument("XmartRegulatoryRegimeImpacts", xmartRegulatoryRegimeImpactsXml.toString(), logXML);
    }

    public String getXmartReportableInstrumentsXml() {
        return getXmlDocument("XmartReportableInstruments", xmartReportableInstrumentsXml.toString(), logXML);
    }

    public String getXmartRegimeBookRolesXml() {
        return getXmlDocument("XmartRegimeBookRoles", xmartRegimeBookRolesXml.toString(), logXML);
    }

    public String getXmartRegimePartyRolesXml() {
        return getXmlDocument("XmartRegimePartyRoles", xmartRegimePartyRolesXml.toString(), logXML);
    }

    public String getXmartInterestRateLegsXml() {
        return getXmlDocument("XmartInterestRateLegs", xmartInterestRateLegsXml.toString(), logXML);
    }

    public String getXmartVarianceLegsXml() {
        return getXmlDocument("XmartVarianceLegs", xmartVarianceLegsXml.toString(), logXML);
    }

    public String getXmartUnderliersXml() {
        return getXmlDocument("XmartUnderliers", xmartUnderliersXml.toString(), logXML);
    }

    public String getXmartTransactionRegulatoryMarginImpactsXml() {
        return getXmlDocument("XmartTransactionRegulatoryMarginImpacts",
                xmartTransactionRegulatoryMarginImpactsXml.toString(), logXML);
    }

    public String getXmartTransactionSourceSystemsXml() {
        return getXmlDocument("XmartTransactionSourceSystems", xmartTransactionSourceSystemsXml.toString(), logXML);
    }

    public String getXmartBookReportObligationsXml() {
        return getXmlDocument("XmartBookReportObligations", xmartBookReportObligationsXml.toString(), logXML);
    }

    public String getXmartCreditDerivativeAdditionalTermsXml() {
        return getXmlDocument("XmartCreditDerivativeAdditionalTerms",
                xmartCreditDerivativeAdditionalTermsXml.toString(), logXML);
    }

    public String getXmartCompoundUnderlierMembersXml() {
        return getXmlDocument("XmartCompoundUnderlierMembers", xmartCompoundUnderlierMembersXml.toString(), logXML);
    }

    public String getXmartCreditEventPublicSourcesXml() {
        return getXmlDocument("XmartCreditEventPublicSources", xmartCreditEventPublicSourcesXml.toString(), logXML);
    }

    public String getXmartExceptionalTermsDetailsXml() {
        return getXmlDocument("XmartExceptionalTermsDetails", xmartExceptionalTermsDetailsXml.toString(), logXML);
    }

    public String getXmartExternalTransactionIdentifiersXml() {
        return getXmlDocument("XmartExternalTransactionIdentifiers", xmartExternalTransactionIdentifiersXml.toString(),
                logXML);
    }

    public String getXmartDeliverableObligationsXml() {
        return getXmlDocument("XmartDeliverableObligations", xmartDeliverableObligationsXml.toString(), logXML);
    }

    public String getXmartEmployeeIdEntriesXml() {
        return getXmlDocument("XmartEmployeeIdEntries", xmartEmployeeIdEntries.toString(), logXML);
    }

    public String getXmartTransactionMarginElectionsXml() {
        return getXmlDocument("XmartTransactionMarginElections", xmartTransactionMarginElectionsXml.toString(), logXML);
    }

    public String getXmartTransactionMarginJurisdictionsXml() {
        return getXmlDocument("XmartTransactionMarginJurisdictions", xmartTransactionMarginJurisdictionsXml.toString(),
                logXML);
    }

    public String getXmartTransactionLegCurvesXml() {
        return getXmlDocument("XmartTransactionLegCurves", xmartTransactionLegCurvesXml.toString(), logXML);
    }

    public String getXmartTransactionLifecycleEventsXml() {
        return getXmlDocument("XmartTransactionLifecycleEvents", xmartTransactionLifecycleEventsXml.toString(), logXML);
    }

    public String getXmartTransactionInstanceLinksXml() {
        return getXmlDocument("XmartTransactionInstanceLinks", xmartTransactionInstanceLinksXml.toString(), logXML);
    }

    public String getXmartSettlementSystemMigrationDatasXml() {
        return getXmlDocument("XmartSettlementSystemMigrationDatas", xmartSettlementSystemMigrationDatasXml.toString(),
                logXML);
    }

    public String getXmartReportingWaiversXml() {
        return getXmlDocument("XmartReportingWaivers", xmartReportingWaiversXml.toString(), logXML);
    }

    public String getXmartRoutingAttributesXml() {
        return getXmlDocument("XmartRoutingAttributes", xmartRoutingAttributesXml.toString(), logXML);
    }

    public String getXmartSalesCreditComponentsXml() {
        return getXmlDocument("XmartSalesCreditComponents", xmartSalesCreditComponentsXml.toString(), logXML);
    }

    public String getXmartReportableUnderlyingInstrumentsXml() {
        return getXmlDocument("XmartReportableUnderlyingInstruments",
                xmartReportableUnderlyingInstrumentsXml.toString(), logXML);
    }

    public String getXmartCreditDerivativeLegsXml() {
        return getXmlDocument("XmartCreditDerivativeLegs", xmartCreditDerivativeLegsXml.toString(), logXML);
    }

    public String getXmartForwardFeaturesXml() {
        return getXmlDocument("XmartForwardFeatures", xmartForwardFeaturesXml.toString(), logXML);
    }

    public String getXmartFuturesLegsXml() {
        return getXmlDocument("XmartFuturesLegs", xmartFuturesLegsXml.toString(), logXML);
    }

    public String getXmartFxFixingScheduleEntriesXml() {
        return getXmlDocument("XmartFxFixingScheduleEntries", xmartFxFixingScheduleEntriesXml.toString(), logXML);
    }

    public String getXmartInflationRateLegsXml() {
        return getXmlDocument("XmartInflationRateLegs", xmartInflationRateLegsXml.toString(), logXML);
    }

    public String getXmartLegBusinessCentresXml() {
        return getXmlDocument("XmartLegBusinessCentres", xmartLegBusinessCentresXml.toString(), logXML);
    }

    public String getXmartLegParametersXml() {
        return getXmlDocument("XmartLegParameters", xmartLegParametersXml.toString(), logXML);
    }

    public String getXmartLinkedTransactionsXml() {
        return getXmlDocument("XmartLinkedTransactions", xmartLinkedTransactionsXml.toString(), logXML);
    }

    public String getXmartNotionalResetsXml() {
        return getXmlDocument("XmartNotionalResets", xmartNotionalResetsXml.toString(), logXML);
    }

    public String getXmartOptionFeaturesXml() {
        return getXmlDocument("XmartOptionFeatures", xmartOptionFeaturesXml.toString(), logXML);
    }

    public String getXmartPartyReportObligationsXml() {
        return getXmlDocument("XmartPartyReportObligations", xmartPartyReportObligationsXml.toString(), logXML);
    }

    public String getXmartPostTradeClassificationsXml() {
        return getXmlDocument("XmartPostTradeClassifications", xmartPostTradeClassificationsXml.toString(), logXML);
    }

    public String getXmartPrincipalMovementEventsXml() {
        return getXmlDocument("XmartPrincipalMovementEvents", xmartPrincipalMovementEventsXml.toString(), logXML);
    }

    public String getXmartRegulatoryAuthoritiesXml() {
        return getXmlDocument("XmartRegulatoryAuthorities", xmartRegulatoryAuthoritiesXml.toString(), logXML);
    }

    public String getXmartRelatedCurrenciesXml() {
        return getXmlDocument("XmartRelatedCurrencies", xmartRelatedCurrenciesXml.toString(), logXML);
    }

    public String getXmartReportableIndexesXml() {
        return getXmlDocument("XmartReportableIndexes", xmartReportableIndexesXml.toString(), logXML);
    }

    public String getXmartScheduleEntriesXml() {
        return getXmlDocument("XmartScheduleEntries", xmartScheduleEntriesXml.toString(), logXML);
    }

    public String getXmartTradingPartiesXml() {
        return getXmlDocument("XmartTradingParties", xmartTradingPartiesXml.toString(), logXML);
    }

    public String getXmartTransactionProcessDirectivesXml() {
        return getXmlDocument("XmartTransactionProcessDirectives", xmartTransactionProcessDirectivesXml.toString(),
                logXML);
    }

    public String getXmartTransactionProcessRolePlayersXml() {
        return getXmlDocument("XmartTransactionProcessRolePlayers", xmartTransactionProcessRolePlayersXml.toString(),
                logXML);
    }

    public String getXmartReportableTransactionStatesXml() {
        return getXmlDocument("XmartReportableTransactionStates", xmartReportableTransactionStatesXml.toString(),
                logXML);
    }

    public String getXmartTradingPartyAttestationsXml() {
        return getXmlDocument("XmartTradingPartyAttestations", xmartTradingPartyAttestationsXml.toString(), logXML);
    }
}
