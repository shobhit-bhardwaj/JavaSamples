package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartReportableIndex extends XmartEntity {

    private static final long serialVersionUID = -8715548710651650509L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private Boolean regimeImpact;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regimeImpactId;

    @XmartAttribute
    private Integer periodMultiplier;

    @XmartAttribute
    private String indexName;

    @XmartAttribute
    private String periodScheme;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regulatoryRegimeImpactId;

    public XmartReportableIndex(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getRegulatoryRegimeImpactId() {
        return regulatoryRegimeImpactId;
    }

    public void setRegulatoryRegimeImpactId(String regulatoryRegimeImpactId) {
        this.regulatoryRegimeImpactId = regulatoryRegimeImpactId;
    }

    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    public void setRegimeImpact(Boolean regimeImpact) {
        this.regimeImpact = regimeImpact;
    }

    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    public void setRegimeImpactId(String regimeImpactId) {
        this.regimeImpactId = regimeImpactId;
    }

    public Integer getPeriodMultiplier() {
        return periodMultiplier;
    }

    public void setPeriodMultiplier(Integer periodMultiplier) {
        this.periodMultiplier = periodMultiplier;
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public String getPeriodScheme() {
        return periodScheme;
    }

    public void setPeriodScheme(String periodScheme) {
        this.periodScheme = periodScheme;
    }
}
