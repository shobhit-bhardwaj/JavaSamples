package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartCompoundUnderlierMembers
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartCompoundUnderlierMember> {
    private static final Logger logger = LoggerFactory.getLogger(XmartCompoundUnderlierMembers.class);
    private static final long serialVersionUID = 3076862103836834754L;

    public XmartCompoundUnderlierMembers(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return CollectionsUtil.nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for documentkey :" + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        addXmartCompoundUnderlierMembers(getDocumentKey(), transactionLeg);
    }

    private void addXmartCompoundUnderlierMembers(long documentKey, TransactionLeg transactionLeg)
            throws XmartException {
        for (Underlier underlier : nullCollToEmpty(transactionLeg.getUnderliers())) {
            if (isNull(underlier)) {
                continue;
            }

            if (isNull(underlier.getCompoundUnderlier())) {
                continue;
            }

            CompoundUnderlier compoundUnderlier = underlier.getCompoundUnderlier();

            for (CompoundUnderlierMember compoundUnderlierMember : nullCollToEmpty(
                    compoundUnderlier.getCompoundUnderlierMembers())) {

                XmartCompoundUnderlierMember xmartCompoundUnderlierMember = new XmartCompoundUnderlierMember(
                        documentKey);
                xmartCompoundUnderlierMember.setLegIdentifier(transactionLeg.getLegIdentifier());
                xmartCompoundUnderlierMember.setUnderlierId(underlier.getUnderlierId());
                xmartCompoundUnderlierMember.setAttachmentPoint(compoundUnderlier.getAttachmentPoint());
                xmartCompoundUnderlierMember.setExhaustionPoint(compoundUnderlier.getExhaustionPoint());

                if (nonNull(compoundUnderlierMember)) {

                    if (nonNull(compoundUnderlierMember.getBasketWeight())) {
                        xmartCompoundUnderlierMember
                                .setBasketWeightPercentage(compoundUnderlierMember.getBasketWeight().getPercentage());
                        xmartCompoundUnderlierMember
                                .setBasketWeightOpenUnits(compoundUnderlierMember.getBasketWeight().getOpenUnits());
                        if (nonNull(compoundUnderlierMember.getBasketWeight().getAmount())) {
                            Amount amount = compoundUnderlierMember.getBasketWeight().getAmount();
                            xmartCompoundUnderlierMember.setBasketWeightValue(amount.getValue());
                            if (nonNull(amount.getCurrencyId())) {
                                xmartCompoundUnderlierMember
                                        .setBasketWeightCurrencyCode(amount.getCurrencyId().getCurrencyCode());
                            }
                        }
                    }

                    if (nonNull(compoundUnderlierMember.getInstrumentId())) {
                        xmartCompoundUnderlierMember.setInstrumentScheme(
                                getStr(compoundUnderlierMember.getInstrumentId().getInstrumentScheme()));
                        xmartCompoundUnderlierMember
                                .setInstrumentId(compoundUnderlierMember.getInstrumentId().getInstrumentId());
                    }
                }
                addEntity(xmartCompoundUnderlierMember);
            }
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
