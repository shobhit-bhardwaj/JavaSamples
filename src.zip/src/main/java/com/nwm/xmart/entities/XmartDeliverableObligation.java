package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartDeliverableObligation extends XmartEntity {

    private static final long serialVersionUID = -1542725786122640859L;

    @XmartAttribute
    private String legIdentifier;

    @XmartAttribute
    private String category;
    @XmartAttribute
    private String excluded;
    @XmartAttribute
    private String otherCategory;
    @XmartAttribute
    private String otherCharacteristic;
    @XmartAttribute
    private Boolean accruedInterest;
    @XmartAttribute
    private String obligationLiabilityScheme;
    @XmartAttribute
    private Boolean notSubordinated;
    @XmartAttribute
    private Boolean notSovereignLender;
    @XmartAttribute
    private Boolean notDomesticCurrency;
    @XmartAttribute
    private Boolean notDomesticLaw;
    @XmartAttribute
    private Boolean notDomesticIssue;
    @XmartAttribute
    private Boolean listed;
    @XmartAttribute
    private Boolean notContingent;
    @XmartAttribute
    private Boolean transferable;
    @XmartAttribute
    private Boolean acceleratedOrMatured;
    @XmartAttribute
    private Boolean notBearer;
    @XmartAttribute
    private Boolean indirectLoanParticipation;
    @XmartAttribute
    private String qualifyingParticipnSeller;
    @XmartAttribute
    private Boolean partCashAssignableLoans;
    @XmartAttribute
    private Boolean partCashConsentRequired;
    @XmartAttribute
    private Boolean partCashLoanParticipations;

    public XmartDeliverableObligation(Long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getExcluded() {
        return excluded;
    }

    public void setExcluded(String excluded) {
        this.excluded = excluded;
    }

    public String getOtherCategory() {
        return otherCategory;
    }

    public void setOtherCategory(String otherCategory) {
        this.otherCategory = otherCategory;
    }

    public String getOtherCharacteristic() {
        return otherCharacteristic;
    }

    public void setOtherCharacteristic(String otherCharacteristic) {
        this.otherCharacteristic = otherCharacteristic;
    }

    public Boolean isAccruedInterest() {
        return accruedInterest;
    }

    public void setAccruedInterest(Boolean accruedInterest) {
        this.accruedInterest = accruedInterest;
    }

    public String isObligationLiabilityScheme() {
        return obligationLiabilityScheme;
    }

    public void setObligationLiabilityScheme(String obligationLiabilityScheme) {
        this.obligationLiabilityScheme = obligationLiabilityScheme;
    }

    public Boolean isNotSubordinated() {
        return notSubordinated;
    }

    public void setNotSubordinated(Boolean notSubordinated) {
        this.notSubordinated = notSubordinated;
    }

    public Boolean isNotSovereignLender() {
        return notSovereignLender;
    }

    public void setNotSovereignLender(Boolean notSovereignLender) {
        this.notSovereignLender = notSovereignLender;
    }

    public Boolean isNotDomesticCurrency() {
        return notDomesticCurrency;
    }

    public void setNotDomesticCurrency(Boolean notDomesticCurrency) {
        this.notDomesticCurrency = notDomesticCurrency;
    }

    public Boolean isNotDomesticLaw() {
        return notDomesticLaw;
    }

    public void setNotDomesticLaw(Boolean notDomesticLaw) {
        this.notDomesticLaw = notDomesticLaw;
    }

    public Boolean isNotDomesticIssue() {
        return notDomesticIssue;
    }

    public void setNotDomesticIssue(Boolean notDomesticIssue) {
        this.notDomesticIssue = notDomesticIssue;
    }

    public Boolean isListed() {
        return listed;
    }

    public void setListed(Boolean listed) {
        this.listed = listed;
    }

    public Boolean isNotContingent() {
        return notContingent;
    }

    public void setNotContingent(Boolean notContingent) {
        this.notContingent = notContingent;
    }

    public Boolean isTransferable() {
        return transferable;
    }

    public void setTransferable(Boolean transferable) {
        this.transferable = transferable;
    }

    public Boolean isAcceleratedOrMatured() {
        return acceleratedOrMatured;
    }

    public void setAcceleratedOrMatured(Boolean acceleratedOrMatured) {
        this.acceleratedOrMatured = acceleratedOrMatured;
    }

    public Boolean isNotBearer() {
        return notBearer;
    }

    public void setNotBearer(Boolean notBearer) {
        this.notBearer = notBearer;
    }

    public Boolean isIndirectLoanParticipation() {
        return indirectLoanParticipation;
    }

    public void setIndirectLoanParticipation(Boolean indirectLoanParticipation) {
        this.indirectLoanParticipation = indirectLoanParticipation;
    }

    public String isQualifyingParticipnSeller() {
        return qualifyingParticipnSeller;
    }

    public void setQualifyingParticipnSeller(String qualifyingParticipnSeller) {
        this.qualifyingParticipnSeller = qualifyingParticipnSeller;
    }

    public Boolean isPartCashAssignableLoans() {
        return partCashAssignableLoans;
    }

    public void setPartCashAssignableLoans(Boolean partCashAssignableLoans) {
        this.partCashAssignableLoans = partCashAssignableLoans;
    }

    public Boolean isPartCashConsentRequired() {
        return partCashConsentRequired;
    }

    public void setPartCashConsentRequired(Boolean partCashConsentRequired) {
        this.partCashConsentRequired = partCashConsentRequired;
    }

    public Boolean isPartCashLoanParticipations() {
        return partCashLoanParticipations;
    }

    public void setPartCashLoanParticipations(Boolean partCashLoanParticipations) {
        this.partCashLoanParticipations = partCashLoanParticipations;
    }
}
