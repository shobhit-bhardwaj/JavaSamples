package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.CreditDerivativeAdditionalTerm;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static java.util.Objects.isNull;

public class XmartCreditDerivativeAdditionalTerms
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartCreditDerivativeAdditionalTerm> {

    private static final long serialVersionUID = 6800259872734127503L;
    private static final Logger logger = LoggerFactory.getLogger(XmartCreditDerivativeAdditionalTerms.class);
    private Collection<XmartCreditDerivativeAdditionalTerm> xmartCreditDerivativeAdditionalTerms = new ArrayList<>();

    public XmartCreditDerivativeAdditionalTerms(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction legs not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        if (isNull(transactionLeg)) {
            return;
        }

        if (isNull(transactionLeg.getCreditDerivativeLeg())) {
            return;
        }

        for (CreditDerivativeAdditionalTerm creditDerivativeAdditionalTerm : nullCollToEmpty(
                transactionLeg.getCreditDerivativeLeg().getCreditDerivativeAdditionalTerms())) {
            if (isNull(creditDerivativeAdditionalTerm)) {
                continue;
            }

            XmartCreditDerivativeAdditionalTerm xmartCreditDerivativeAdditionalTerm
                    = new XmartCreditDerivativeAdditionalTerm(getDocumentKey(), transactionLeg.getLegIdentifier());
            xmartCreditDerivativeAdditionalTerm.setAdditionalTerm(creditDerivativeAdditionalTerm.getAdditionalTerm());
            addEntity(xmartCreditDerivativeAdditionalTerm);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
