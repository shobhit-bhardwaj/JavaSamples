package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

public class XmartInflationRateLeg extends XmartEntity {

    private static final long serialVersionUID = -1154614769155078899L;
    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute
    private String inflationIndexLevel;
    @XmartAttribute
    private String interpolationMethod;
    @XmartAttribute
    private String inflationRateSource;
    @XmartAttribute
    private Date baseIndexDate;
    @XmartAttribute
    private BigDecimal inflationRate;
    @XmartAttribute
    private String rpiProductIdentifier;
    @XmartAttribute
    private String roundingDirection;
    @XmartAttribute
    private Integer roundingPrecision;
    @XmartAttribute
    private String negativeRateTreatment;
    @XmartAttribute
    private String mainRatePublication;
    @XmartAttribute
    private BigDecimal rateMultiplier;

    XmartInflationRateLeg(Long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getInflationIndexLevel() {
        return inflationIndexLevel;
    }

    void setInflationIndexLevel(String inflationIndexLevel) {
        this.inflationIndexLevel = inflationIndexLevel;
    }

    public String getInterpolationMethod() {
        return interpolationMethod;
    }

    void setInterpolationMethod(String interpolationMethod) {
        this.interpolationMethod = interpolationMethod;
    }

    public String getInflationRateSource() {
        return inflationRateSource;
    }

    void setInflationRateSource(String inflationRateSource) {
        this.inflationRateSource = inflationRateSource;
    }

    public Date getBaseIndexDate() {
        return baseIndexDate;
    }

    void setBaseIndexDate(Date baseIndexDate) {
        this.baseIndexDate = baseIndexDate;
    }

    public BigDecimal getInflationRate() {
        return inflationRate;
    }

    void setInflationRate(BigDecimal inflationRate) {
        this.inflationRate = inflationRate;
    }

    public String getRpiProductIdentifier() {
        return rpiProductIdentifier;
    }

    void setRpiProductIdentifier(String rpiProductIdentifier) {
        this.rpiProductIdentifier = rpiProductIdentifier;
    }

    public String getRoundingDirection() {
        return roundingDirection;
    }

    void setRoundingDirection(String roundingDirection) {
        this.roundingDirection = roundingDirection;
    }

    public Integer getRoundingPrecision() {
        return roundingPrecision;
    }

    void setRoundingPrecision(Integer roundingPrecision) {
        this.roundingPrecision = roundingPrecision;
    }

    public String getNegativeRateTreatment() {
        return negativeRateTreatment;
    }

    void setNegativeRateTreatment(String negativeRateTreatment) {
        this.negativeRateTreatment = negativeRateTreatment;
    }

    public String getMainRatePublication() {
        return mainRatePublication;
    }

    void setMainRatePublication(String mainRatePublication) {
        this.mainRatePublication = mainRatePublication;
    }

    public BigDecimal getRateMultiplier() {
        return rateMultiplier;
    }

    void setRateMultiplier(BigDecimal rateMultiplier) {
        this.rateMultiplier = rateMultiplier;
    }
}
