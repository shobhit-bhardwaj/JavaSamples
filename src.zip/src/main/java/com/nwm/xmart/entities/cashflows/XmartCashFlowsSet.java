package com.nwm.xmart.entities.cashflows;

import com.nwm.xmart.core.XmartODCSet;
import com.nwm.xmart.entities.XmartOdcEntityCollection;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.event.StreamEvent;
import com.rbs.odc.access.domain.Cashflows;
import com.rbs.odc.access.domain.CashflowsId;
import com.rbs.odc.core.domain.ODCValue;

public class XmartCashFlowsSet extends XmartODCSet<CashflowsId, Cashflows> {
    private static final long serialVersionUID = 2596456721697234063L;
    private XmartOdcEntityCollection xmartCashFlows;

    public XmartCashFlowsSet() {
        // No default constructor
    }

    public XmartOdcEntityCollection getXmartCashFlows() {
        return xmartCashFlows;
    }

    @Override
    public void addOdcAttribute(String sourceTopic, int sourcePartition, int sourceTopicId, long sourcePosition,
            long sourceTimestamp, Cashflows cashflows,
            DataFabricStreamEvent<ODCValue<CashflowsId, Cashflows>> dfStreamEvent, Long odcVersion)
            throws XmartException {
        long documentKey = generateDocumentKey(sourcePartition, sourceTopicId, sourcePosition, sourceTimestamp);
        xmartCashFlows = new XmartCashFlows(documentKey, cashflows, odcVersion).build();
    }

    @Override
    public Long getWindowKey() {
        return xmartCashFlows.getDocumentKey();
    }
}
