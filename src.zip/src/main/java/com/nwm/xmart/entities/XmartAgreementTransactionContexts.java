package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.AgreementTransactionContext;
import com.rbs.odc.access.domain.LegalAgreementId;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 16/11/17.
 */
public class XmartAgreementTransactionContexts
        extends XmartOdcEntityCollection<Transaction, AgreementTransactionContext, XmartAgreementTransactionContext> {

    private static final long serialVersionUID = 1129460610805059242L;
    private static final Logger logger = LoggerFactory.getLogger(XmartAgreementTransactionContexts.class);

    public XmartAgreementTransactionContexts(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<AgreementTransactionContext> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getAgreementTransactionContext(), logger,
                "AgreementTransactionContext not received for documentkey :" + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(AgreementTransactionContext agreementTransactionContext) throws XmartException {
        XmartAgreementTransactionContext xmartAgreementTransactionContext = new XmartAgreementTransactionContext(
                getDocumentKey(), agreementTransactionContext.getId());

        xmartAgreementTransactionContext.setLegId(agreementTransactionContext.getLegId());
        xmartAgreementTransactionContext
                .setTransactionAgreementContext(agreementTransactionContext.getTransactionAgreementContext());

        LegalAgreementId legalAgreementId = agreementTransactionContext.getLegalAgreementId();
        if (nonNull(legalAgreementId)) {
            xmartAgreementTransactionContext.setAgreementId(legalAgreementId.getAgreementId());
        }

        addEntity(xmartAgreementTransactionContext);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
