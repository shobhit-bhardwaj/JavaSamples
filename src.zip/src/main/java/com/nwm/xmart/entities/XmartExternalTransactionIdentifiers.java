package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.rbs.odc.access.domain.ExternalAlternateTransactionId;
import com.rbs.odc.access.domain.TradingCounterpartyId;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartExternalTransactionIdentifiers extends
                                                 XmartOdcEntityCollection<Transaction, ExternalAlternateTransactionId, XmartExternalTransactionIdentifier> {
    private static final long serialVersionUID = -276972067528235464L;
    private static final Logger logger = LoggerFactory.getLogger(XmartExternalTransactionIdentifiers.class);

    public XmartExternalTransactionIdentifiers(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<ExternalAlternateTransactionId> getFromEntities(Transaction transaction) {
        return CollectionsUtil.nullCollToEmpty(transaction.getExternalTransactionIdentifiers(), logger,
                "No ExternalTransactionIdentifiers received for documentkey :" + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(ExternalAlternateTransactionId externalAlternateTransactionId)
            throws XmartException {

        XmartExternalTransactionIdentifier xmartExternalTransactionIdentifier = new XmartExternalTransactionIdentifier(
                getDocumentKey());

        xmartExternalTransactionIdentifier
                .setAlternateIdDescription(getStr(externalAlternateTransactionId.getAlternateIdDescription()));
        xmartExternalTransactionIdentifier
                .setAlternateTransactionId(externalAlternateTransactionId.getAlternateTransactionId());

        TradingCounterpartyId tradingCounterpartyId = externalAlternateTransactionId.getTradingCounterpartyId();

        if (nonNull(tradingCounterpartyId)) {
            xmartExternalTransactionIdentifier
                    .setPartyClassification(getStr(tradingCounterpartyId.getPartyClassification()));
            xmartExternalTransactionIdentifier.setPartyReference(tradingCounterpartyId.getPartyReference());
        }

        addEntity(xmartExternalTransactionIdentifier);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
