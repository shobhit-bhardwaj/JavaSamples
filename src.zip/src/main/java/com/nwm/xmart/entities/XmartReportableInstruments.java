package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.ReportableInstrument;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartReportableInstruments
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartReportableInstrument> {
    private static final long serialVersionUID = 8922927091488277527L;
    private static final Logger logger = LoggerFactory.getLogger(XmartReportableInstruments.class);

    public XmartReportableInstruments(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpact not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {
        for (ReportableInstrument reportableInstrument : nullCollToEmpty(
                regulatoryRegimeImpact.getReportableInstruments())) {

            XmartReportableInstrument xmartReportableInstrument = new XmartReportableInstrument(getDocumentKey());
            xmartReportableInstrument.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartReportableInstrument.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartReportableInstrument.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());

            if (nonNull(reportableInstrument)) {
                xmartReportableInstrument.setInstrumentId(reportableInstrument.getInstrumentId());
                xmartReportableInstrument.setInstrumentScheme(getStr(reportableInstrument.getInstrumentScheme()));
                xmartReportableInstrument.setInstrumentName(reportableInstrument.getInstrumentName());
                xmartReportableInstrument
                        .setInstrumentClassification(reportableInstrument.getInstrumentClassification());
                xmartReportableInstrument.setPriceMultiplier(reportableInstrument.getPriceMultiplier());
                xmartReportableInstrument.setOptionType(getStr(reportableInstrument.getOptionType()));
                xmartReportableInstrument.setOptionExerciseStyle(getStr(reportableInstrument.getOptionExerciseStyle()));
                xmartReportableInstrument.setMaturityDate(convertBusinessDate(reportableInstrument.getMaturityDate()));
                xmartReportableInstrument.setExpiryDate(convertBusinessDate(reportableInstrument.getExpiryDate()));
                xmartReportableInstrument.setSettlementType(getStr(reportableInstrument.getSettlementType()));
            }

            addEntity(xmartReportableInstrument);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
