package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

public class XmartTransactionLifecycleEvent extends XmartEntity {
    private static final long serialVersionUID = 8566966367355998626L;
    @XmartAttribute(usedInJoin = true)
    private String sourceSystemEventId;
    @XmartAttribute(usedInJoin = true)
    private String transactionLifecycleEventsEventType;
    @XmartAttribute
    private Date transactionLifecycleEventsEventDateTime;
    @XmartAttribute
    private String transactionLifecycleEventsStatus;
    @XmartAttribute
    private Date transactionLifecycleEventsEffectiveDate;
    @XmartAttribute
    private Date transactionLifecycleEventsEffectiveDateTime;
    @XmartAttribute
    private String publisherSourceSystemId;
    @XmartAttribute
    private BigDecimal triggerRate;
    @XmartAttribute
    private BigDecimal adjustedTriggerRate;
    @XmartAttribute
    private BigDecimal fixingRate;
    @XmartAttribute
    private Date cancellationDate;
    @XmartAttribute
    private String payAmountCurrencyCode;
    @XmartAttribute
    private BigDecimal payAmountValue;
    @XmartAttribute
    private String receiveAmountCurrencyCode;
    @XmartAttribute
    private BigDecimal receiveAmountValue;
    @XmartAttribute
    private BigDecimal observedValue;
    @XmartAttribute
    private String businessCentre;
    @XmartAttribute
    private String observationLegIdentifier;
    @XmartAttribute
    private String rateResetLegIdentifier;
    @XmartAttribute
    private BigDecimal resetRate;
    @XmartAttribute
    private String quantityMovementLegIdentifier;
    @XmartAttribute
    private String stepDirection;
    @XmartAttribute
    private String quantityUnitOfMeasure;
    @XmartAttribute
    private BigDecimal stepQuantity;
    @XmartAttribute
    private BigDecimal resultantQuantity;
    @XmartAttribute
    private String fxFixingEventLegIdentifier;
    @XmartAttribute
    private BigDecimal fxFixingEventFxRate;
    @XmartAttribute
    private String currency1IdCurrencyCode;
    @XmartAttribute
    private String currency2IdCurrencyCode;
    @XmartAttribute
    private String currencyQuoteBasis;
    @XmartAttribute
    private String eventPriceCurrencyCode;
    @XmartAttribute
    private BigDecimal eventPriceValue;
    @XmartAttribute
    private BigDecimal eventPricePercentage;
    @XmartAttribute
    private String eventPriceType;
    @XmartAttribute
    private BigDecimal eventPricePrice;
    @XmartAttribute
    private String eventPriceCurrency;
    @XmartAttribute
    private Date tradeEventDate;
    @XmartAttribute
    private Boolean fullFirstCoupon;
    @XmartAttribute
    private Date originalTradeDate;
    @XmartAttribute
    private Date originalEffectiveDate;
    @XmartAttribute
    private Date originalTerminationDate;
    @XmartAttribute
    private String originalPrincipalCurrencyCode;
    @XmartAttribute
    private BigDecimal originalPrincipalValue;
    @XmartAttribute
    private String assignmentNotionalCurrencyCode;
    @XmartAttribute
    private BigDecimal assignmentNotionalValue;
    @XmartAttribute
    private String legId;
    @XmartAttribute
    private String underlierId;
    @XmartAttribute
    private String liquidatedQuantityType;
    @XmartAttribute
    private BigDecimal liquidatedQuantityValue;
    @XmartAttribute
    private String realisedPnLCurrencyCode;
    @XmartAttribute
    private BigDecimal realisedPnLValue;
    @XmartAttribute
    private String earnedInterestCurrencyCode;
    @XmartAttribute
    private BigDecimal earnedInterestValue;
    @XmartAttribute
    private String liquidatedCostCurrencyCode;
    @XmartAttribute
    private BigDecimal liquidatedCostValue;
    @XmartAttribute
    private String realAccAmountCurrencyCode;
    @XmartAttribute
    private BigDecimal realAccAmountValue;
    @XmartAttribute
    private Date transactionLifecycleEventsEventDate;

    protected XmartTransactionLifecycleEvent(long documentKey) throws XmartException {
        super(documentKey);
    }

    public Boolean getFullFirstCoupon() {
        return fullFirstCoupon;
    }

    public void setFullFirstCoupon(Boolean fullFirstCoupon) {
        this.fullFirstCoupon = fullFirstCoupon;
    }

    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    public void setSourceSystemEventId(String sourceSystemEventId) {
        this.sourceSystemEventId = sourceSystemEventId;
    }

    public String getTransactionLifecycleEventsEventType() {
        return transactionLifecycleEventsEventType;
    }

    public void setTransactionLifecycleEventsEventType(String transactionLifecycleEventsEventType) {
        this.transactionLifecycleEventsEventType = transactionLifecycleEventsEventType;
    }

    public Date getTransactionLifecycleEventsEventDateTime() {
        return transactionLifecycleEventsEventDateTime;
    }

    public void setTransactionLifecycleEventsEventDateTime(Date transactionLifecycleEventsEventDateTime) {
        this.transactionLifecycleEventsEventDateTime = transactionLifecycleEventsEventDateTime;
    }

    public String getTransactionLifecycleEventsStatus() {
        return transactionLifecycleEventsStatus;
    }

    public void setTransactionLifecycleEventsStatus(String transactionLifecycleEventsStatus) {
        this.transactionLifecycleEventsStatus = transactionLifecycleEventsStatus;
    }

    public Date getTransactionLifecycleEventsEffectiveDate() {
        return transactionLifecycleEventsEffectiveDate;
    }

    public void setTransactionLifecycleEventsEffectiveDate(Date transactionLifecycleEventsEffectiveDate) {
        this.transactionLifecycleEventsEffectiveDate = transactionLifecycleEventsEffectiveDate;
    }

    public Date getTransactionLifecycleEventsEffectiveDateTime() {
        return transactionLifecycleEventsEffectiveDateTime;
    }

    public void setTransactionLifecycleEventsEffectiveDateTime(Date transactionLifecycleEventsEffectiveDateTime) {
        this.transactionLifecycleEventsEffectiveDateTime = transactionLifecycleEventsEffectiveDateTime;
    }

    public String getPublisherSourceSystemId() {
        return publisherSourceSystemId;
    }

    public void setPublisherSourceSystemId(String publisherSourceSystemId) {
        this.publisherSourceSystemId = publisherSourceSystemId;
    }

    public BigDecimal getTriggerRate() {
        return triggerRate;
    }

    public void setTriggerRate(BigDecimal triggerRate) {
        this.triggerRate = triggerRate;
    }

    public BigDecimal getAdjustedTriggerRate() {
        return adjustedTriggerRate;
    }

    public void setAdjustedTriggerRate(BigDecimal adjustedTriggerRate) {
        this.adjustedTriggerRate = adjustedTriggerRate;
    }

    public BigDecimal getFixingRate() {
        return fixingRate;
    }

    public void setFixingRate(BigDecimal fixingRate) {
        this.fixingRate = fixingRate;
    }

    public Date getCancellationDate() {
        return cancellationDate;
    }

    public void setCancellationDate(Date cancellationDate) {
        this.cancellationDate = cancellationDate;
    }

    public String getPayAmountCurrencyCode() {
        return payAmountCurrencyCode;
    }

    public void setPayAmountCurrencyCode(String payAmountCurrencyCode) {
        this.payAmountCurrencyCode = payAmountCurrencyCode;
    }

    public BigDecimal getPayAmountValue() {
        return payAmountValue;
    }

    public void setPayAmountValue(BigDecimal payAmountValue) {
        this.payAmountValue = payAmountValue;
    }

    public String getReceiveAmountCurrencyCode() {
        return receiveAmountCurrencyCode;
    }

    public void setReceiveAmountCurrencyCode(String receiveAmountCurrencyCode) {
        this.receiveAmountCurrencyCode = receiveAmountCurrencyCode;
    }

    public BigDecimal getReceiveAmountValue() {
        return receiveAmountValue;
    }

    public void setReceiveAmountValue(BigDecimal receiveAmountValue) {
        this.receiveAmountValue = receiveAmountValue;
    }

    public BigDecimal getObservedValue() {
        return observedValue;
    }

    public void setObservedValue(BigDecimal observedValue) {
        this.observedValue = observedValue;
    }

    public String getBusinessCentre() {
        return businessCentre;
    }

    public void setBusinessCentre(String businessCentre) {
        this.businessCentre = businessCentre;
    }

    public String getObservationLegIdentifier() {
        return observationLegIdentifier;
    }

    public void setObservationLegIdentifier(String observationLegIdentifier) {
        this.observationLegIdentifier = observationLegIdentifier;
    }

    public String getRateResetLegIdentifier() {
        return rateResetLegIdentifier;
    }

    public void setRateResetLegIdentifier(String rateResetLegIdentifier) {
        this.rateResetLegIdentifier = rateResetLegIdentifier;
    }

    public BigDecimal getResetRate() {
        return resetRate;
    }

    public void setResetRate(BigDecimal resetRate) {
        this.resetRate = resetRate;
    }

    public String getQuantityMovementLegIdentifier() {
        return quantityMovementLegIdentifier;
    }

    public void setQuantityMovementLegIdentifier(String quantityMovementLegIdentifier) {
        this.quantityMovementLegIdentifier = quantityMovementLegIdentifier;
    }

    public String getStepDirection() {
        return stepDirection;
    }

    public void setStepDirection(String stepDirection) {
        this.stepDirection = stepDirection;
    }

    public String getQuantityUnitOfMeasure() {
        return quantityUnitOfMeasure;
    }

    public void setQuantityUnitOfMeasure(String quantityUnitOfMeasure) {
        this.quantityUnitOfMeasure = quantityUnitOfMeasure;
    }

    public BigDecimal getStepQuantity() {
        return stepQuantity;
    }

    public void setStepQuantity(BigDecimal stepQuantity) {
        this.stepQuantity = stepQuantity;
    }

    public BigDecimal getResultantQuantity() {
        return resultantQuantity;
    }

    public void setResultantQuantity(BigDecimal resultantQuantity) {
        this.resultantQuantity = resultantQuantity;
    }

    public String getFxFixingEventLegIdentifier() {
        return fxFixingEventLegIdentifier;
    }

    public void setFxFixingEventLegIdentifier(String fxFixingEventLegIdentifier) {
        this.fxFixingEventLegIdentifier = fxFixingEventLegIdentifier;
    }

    public BigDecimal getFxFixingEventFxRate() {
        return fxFixingEventFxRate;
    }

    public void setFxFixingEventFxRate(BigDecimal fxFixingEventFxRate) {
        this.fxFixingEventFxRate = fxFixingEventFxRate;
    }

    public String getCurrency1IdCurrencyCode() {
        return currency1IdCurrencyCode;
    }

    public void setCurrency1IdCurrencyCode(String currency1IdCurrencyCode) {
        this.currency1IdCurrencyCode = currency1IdCurrencyCode;
    }

    public String getCurrency2IdCurrencyCode() {
        return currency2IdCurrencyCode;
    }

    public void setCurrency2IdCurrencyCode(String currency2IdCurrencyCode) {
        this.currency2IdCurrencyCode = currency2IdCurrencyCode;
    }

    public String getCurrencyQuoteBasis() {
        return currencyQuoteBasis;
    }

    public void setCurrencyQuoteBasis(String currencyQuoteBasis) {
        this.currencyQuoteBasis = currencyQuoteBasis;
    }

    public String getEventPriceCurrencyCode() {
        return eventPriceCurrencyCode;
    }

    public void setEventPriceCurrencyCode(String eventPriceCurrencyCode) {
        this.eventPriceCurrencyCode = eventPriceCurrencyCode;
    }

    public BigDecimal getEventPriceValue() {
        return eventPriceValue;
    }

    public void setEventPriceValue(BigDecimal eventPriceValue) {
        this.eventPriceValue = eventPriceValue;
    }

    public BigDecimal getEventPricePercentage() {
        return eventPricePercentage;
    }

    public void setEventPricePercentage(BigDecimal eventPricePercentage) {
        this.eventPricePercentage = eventPricePercentage;
    }

    public String getEventPriceType() {
        return eventPriceType;
    }

    public void setEventPriceType(String eventPriceType) {
        this.eventPriceType = eventPriceType;
    }

    public BigDecimal getEventPricePrice() {
        return eventPricePrice;
    }

    public void setEventPricePrice(BigDecimal eventPricePrice) {
        this.eventPricePrice = eventPricePrice;
    }

    public String getEventPriceCurrency() {
        return eventPriceCurrency;
    }

    public void setEventPriceCurrency(String eventPriceCurrency) {
        this.eventPriceCurrency = eventPriceCurrency;
    }

    public Date getTradeEventDate() {
        return tradeEventDate;
    }

    public void setTradeEventDate(Date tradeEventDate) {
        this.tradeEventDate = tradeEventDate;
    }

    public Boolean isFullFirstCoupon() {
        return fullFirstCoupon;
    }

    public Date getOriginalTradeDate() {
        return originalTradeDate;
    }

    public void setOriginalTradeDate(Date originalTradeDate) {
        this.originalTradeDate = originalTradeDate;
    }

    public Date getOriginalEffectiveDate() {
        return originalEffectiveDate;
    }

    public void setOriginalEffectiveDate(Date originalEffectiveDate) {
        this.originalEffectiveDate = originalEffectiveDate;
    }

    public Date getOriginalTerminationDate() {
        return originalTerminationDate;
    }

    public void setOriginalTerminationDate(Date originalTerminationDate) {
        this.originalTerminationDate = originalTerminationDate;
    }

    public String getOriginalPrincipalCurrencyCode() {
        return originalPrincipalCurrencyCode;
    }

    public void setOriginalPrincipalCurrencyCode(String originalPrincipalCurrencyCode) {
        this.originalPrincipalCurrencyCode = originalPrincipalCurrencyCode;
    }

    public BigDecimal getOriginalPrincipalValue() {
        return originalPrincipalValue;
    }

    public void setOriginalPrincipalValue(BigDecimal originalPrincipalValue) {
        this.originalPrincipalValue = originalPrincipalValue;
    }

    public String getAssignmentNotionalCurrencyCode() {
        return assignmentNotionalCurrencyCode;
    }

    public void setAssignmentNotionalCurrencyCode(String assignmentNotionalCurrencyCode) {
        this.assignmentNotionalCurrencyCode = assignmentNotionalCurrencyCode;
    }

    public BigDecimal getAssignmentNotionalValue() {
        return assignmentNotionalValue;
    }

    public void setAssignmentNotionalValue(BigDecimal assignmentNotionalValue) {
        this.assignmentNotionalValue = assignmentNotionalValue;
    }

    public String getLegId() {
        return legId;
    }

    public void setLegId(String legId) {
        this.legId = legId;
    }

    public String getUnderlierId() {
        return underlierId;
    }

    public void setUnderlierId(String underlierId) {
        this.underlierId = underlierId;
    }

    public String getLiquidatedQuantityType() {
        return liquidatedQuantityType;
    }

    public void setLiquidatedQuantityType(String liquidatedQuantityType) {
        this.liquidatedQuantityType = liquidatedQuantityType;
    }

    public BigDecimal getLiquidatedQuantityValue() {
        return liquidatedQuantityValue;
    }

    public void setLiquidatedQuantityValue(BigDecimal liquidatedQuantityValue) {
        this.liquidatedQuantityValue = liquidatedQuantityValue;
    }

    public String getRealisedPnLCurrencyCode() {
        return realisedPnLCurrencyCode;
    }

    public void setRealisedPnLCurrencyCode(String realisedPnLCurrencyCode) {
        this.realisedPnLCurrencyCode = realisedPnLCurrencyCode;
    }

    public BigDecimal getRealisedPnLValue() {
        return realisedPnLValue;
    }

    public void setRealisedPnLValue(BigDecimal realisedPnLValue) {
        this.realisedPnLValue = realisedPnLValue;
    }

    public String getEarnedInterestCurrencyCode() {
        return earnedInterestCurrencyCode;
    }

    public void setEarnedInterestCurrencyCode(String earnedInterestCurrencyCode) {
        this.earnedInterestCurrencyCode = earnedInterestCurrencyCode;
    }

    public BigDecimal getEarnedInterestValue() {
        return earnedInterestValue;
    }

    public void setEarnedInterestValue(BigDecimal earnedInterestValue) {
        this.earnedInterestValue = earnedInterestValue;
    }

    public String getLiquidatedCostCurrencyCode() {
        return liquidatedCostCurrencyCode;
    }

    public void setLiquidatedCostCurrencyCode(String liquidatedCostCurrencyCode) {
        this.liquidatedCostCurrencyCode = liquidatedCostCurrencyCode;
    }

    public BigDecimal getLiquidatedCostValue() {
        return liquidatedCostValue;
    }

    public void setLiquidatedCostValue(BigDecimal liquidatedCostValue) {
        this.liquidatedCostValue = liquidatedCostValue;
    }

    public String getRealAccAmountCurrencyCode() {
        return realAccAmountCurrencyCode;
    }

    public void setRealAccAmountCurrencyCode(String realAccAmountCurrencyCode) {
        this.realAccAmountCurrencyCode = realAccAmountCurrencyCode;
    }

    public BigDecimal getRealAccAmountValue() {
        return realAccAmountValue;
    }

    public void setRealAccAmountValue(BigDecimal realAccAmountValue) {
        this.realAccAmountValue = realAccAmountValue;
    }

    public Date getTransactionLifecycleEventsEventDate() {
        return transactionLifecycleEventsEventDate;
    }

    public void setTransactionLifecycleEventsEventDate(Date transactionLifecycleEventsEventDate) {
        this.transactionLifecycleEventsEventDate = transactionLifecycleEventsEventDate;
    }
}
