package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.XmartUtil;
import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.CashSettlementTermsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.DateUtil.convertLocalTime;
import static com.nwm.xmart.util.XmartUtil.getStr;

/**
 * Created by aslammh on 08/08/17.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class XmartTransactionLeg extends XmartEntity {
    /**
     *
     */
    private static final long serialVersionUID = -3113660012898041840L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionLeg.class);
    @XmartAttribute(mandatory = true)
    private String legIdentifier = null;
    @XmartAttribute
    private String legType = null;
    @XmartAttribute
    private String legAtomicProduct = null;
    @XmartAttribute
    private Date effectiveDate = null;
    @XmartAttribute
    private Date unadjustedEffectiveDate = null;
    @XmartAttribute
    private Date valueDate = null;
    @XmartAttribute
    private Date deliveryDate = null;
    @XmartAttribute
    private Date terminationDate = null;
    @XmartAttribute
    private Date terminationAdjustedDate = null;
    @XmartAttribute
    private Date terminationUnadjustedDate = null;
    @XmartAttribute
    private String payerSourceSystemBookId = null;
    @XmartAttribute
    private String payerBookSourceSystemId = null;
    @XmartAttribute
    private String payerPartyClassification = null;
    @XmartAttribute
    private String payerPartyReference = null;
    @XmartAttribute
    private Boolean payerBookCounterparty = null;
    @XmartAttribute
    private String receiverSourceSystemBookId = null;
    @XmartAttribute
    private String receiverBookSourceSystemId = null;
    @XmartAttribute
    private String receiverPartyClassification = null;
    @XmartAttribute
    private String receiverPartyReference = null;
    @XmartAttribute
    private Boolean receiverBookCounterparty = null;
    @XmartAttribute
    private String initialPrincipalType = null;
    @XmartAttribute
    private String initialPrincipalCurrencyCode = null;
    @XmartAttribute
    private BigDecimal initialPrincipalValue = null;
    @XmartAttribute
    private String quantityUnitOfMeasure = null;
    @XmartAttribute
    private BigDecimal quantity = null;
    @XmartAttribute
    private String unitPriceCurrencyCode = null;
    @XmartAttribute
    private BigDecimal unitPriceValue = null;
    @XmartAttribute
    private BigDecimal unitPricePercentage = null;
    @XmartAttribute
    private String unitPriceType = null;
    @XmartAttribute
    private BigDecimal unitPrice = null;
    @XmartAttribute
    private String unitPriceCurrency = null;
    @XmartAttribute
    private String payAmountCurrencyCode = null;
    @XmartAttribute
    private BigDecimal payAmountValue = null;
    @XmartAttribute
    private String receiveAmountCurrencyCode = null;
    @XmartAttribute
    private BigDecimal receiveAmountValue = null;
    @XmartAttribute
    private BigDecimal spotExchangeRate = null;
    @XmartAttribute
    private BigDecimal forwardPoints = null;
    @XmartAttribute
    private BigDecimal forwardExchangeRate = null;
    @XmartAttribute
    private String currencyQuoteBasis = null;
    @XmartAttribute
    private String crossCurrencyType = null;
    @XmartAttribute
    private String settlementCurrencyCode = null;
    @XmartAttribute
    private String referenceRate = null;
    @XmartAttribute
    private Integer referenceRateTenor = null;
    @XmartAttribute
    private String rateSource = null;
    @XmartAttribute
    private BigDecimal spread = null;
    @XmartAttribute
    private String spreadType = null;
    @XmartAttribute
    private BigDecimal haircut = null;
    @XmartAttribute
    private Boolean rehypothecable = null;
    @XmartAttribute
    private Boolean segregated = null;
    @XmartAttribute
    private String principalAmortizationStyle = null;
    @XmartAttribute
    private String averagingMethod = null;
    @XmartAttribute
    private String settlementType = null;
    @XmartAttribute
    private String returnType = null;

    @XmartAttribute
    private Boolean cashflowMatchParameter = null;

    @XmartAttribute
    private Date firstPaymentDate = null;
    @XmartAttribute
    private Date lastPaymentDate = null;
    @XmartAttribute
    private Date lastRegularPaymentDate = null;
    @XmartAttribute
    private Date firstRegularPeriodStartDate = null;
    @XmartAttribute
    private Date lastRegularPeriodEndDate = null;
    @XmartAttribute
    private Date firstCalculationPeriodStartDate = null;
    @XmartAttribute
    private Date firstCompPeriodEndDate = null;
    @XmartAttribute
    private String rollConventionScheme = null;
    @XmartAttribute
    private String weeklyRollConvention = null;
    @XmartAttribute
    private String dayCountConvention = null;
    @XmartAttribute
    private String businessDaysConvention = null;
    @XmartAttribute
    private Integer daysInYear = null;
    @XmartAttribute
    private String instrumentScheme = null;
    @XmartAttribute
    private String instrumentId = null;
    @XmartAttribute
    private String basketName = null;
    @XmartAttribute
    private BigDecimal basketDivisor = null;
    @XmartAttribute
    private String basketCurrencyCode = null;
    @XmartAttribute
    private Boolean collateralLegDeliveryByValueIndicator = null;
    @XmartAttribute
    private BigDecimal collateralLegCouponReinvestmentRate = null;
    @XmartAttribute
    private String incomeStreamLegInitialPriceMethod = null;
    @XmartAttribute
    private String incomeStreamLegInitialPriceCurrencyCode = null;
    @XmartAttribute
    private BigDecimal incomeStreamLegInitialPriceValue = null;
    @XmartAttribute
    private BigDecimal incomeStreamLegInitialPricePercentage = null;
    @XmartAttribute
    private String incomeStreamLegInitialPriceType = null;
    @XmartAttribute
    private BigDecimal incomeStreamLegInitialPrice = null;
    @XmartAttribute
    private String incomeStreamLegInitialPriceCurrency = null;
    @XmartAttribute
    private String incomeStreamLegFinalPriceMethod = null;
    @XmartAttribute
    private String incomeStreamLegFinalPriceCurrencyCode = null;
    @XmartAttribute
    private BigDecimal incomeStreamLegFinalPriceValue = null;
    @XmartAttribute
    private BigDecimal incomeStreamLegFinalPricePercentage = null;
    @XmartAttribute
    private String incomeStreamLegFinalPriceType = null;
    @XmartAttribute
    private BigDecimal incomeStreamLegFinalPricePrice = null;
    @XmartAttribute
    private String incomeStreamLegFinalPriceCurrency = null;
    @XmartAttribute
    private String incomeStreamLegNotionalAmountCurrencyCode = null;
    @XmartAttribute
    private BigDecimal incomeStreamLegNotionalAmountValue = null;
    @XmartAttribute
    private String incomeStreamLegFixedOrFloatingRateType = null;
    @XmartAttribute
    private String incomeStreamLegReferenceEntityIdPartyIdClassification = null;
    @XmartAttribute
    private String incomeStreamLegReferenceEntityIdPartyId = null;
    @XmartAttribute
    private String instrumentLoanLegDeliverOrPayIndicator = null;
    @XmartAttribute
    private BigDecimal instrumentLegQuantoExchangeRate = null;
    @XmartAttribute
    private String instrumentLegInitialPriceMethod = null;
    @XmartAttribute
    private String instrumentLegInitialPriceCurrencyCode = null;
    @XmartAttribute
    private BigDecimal instrumentLegInitialPriceValue = null;
    @XmartAttribute
    private String instrumentLegSettlementAmountCurrencyCode = null;
    @XmartAttribute
    private BigDecimal instrumentLegSettlementAmountValue = null;
    @XmartAttribute
    private String instrumentLegShortSellingClassification = null;
    @XmartAttribute
    private BigDecimal openUnitsQuantity = null;
    @XmartAttribute
    private BigDecimal capInterestRate = null;
    @XmartAttribute
    private BigDecimal maxCapInterestRate = null;
    @XmartAttribute
    private BigDecimal floorInterestRate = null;
    @XmartAttribute
    private BigDecimal minFloorInterestRate = null;
    @XmartAttribute
    private String dividendCurrencyCode = null;
    @XmartAttribute
    private BigDecimal dividendPercentage = null;
    @XmartAttribute
    private BigDecimal digitalPayoutRate = null;
    @XmartAttribute
    private String cashSettlementMethod = null;
    @XmartAttribute
    private BigDecimal accruedInterestPercentage = null;
    @XmartAttribute
    private String paymentIndicator = null;
    @XmartAttribute
    private String sideRateBaseCurrencyIdCurrencyCode = null;
    @XmartAttribute
    private BigDecimal payCurrencySideRate = null;
    @XmartAttribute
    private String paySideRateQuoteBasis = null;
    @XmartAttribute
    private BigDecimal receiveCurrencySideRate = null;
    @XmartAttribute
    private String receiveSideRateQuoteBasis = null;
    @XmartAttribute
    private Boolean nonDeliverable = null;
    @XmartAttribute
    private BigDecimal gentanBondRate = null;
    @XmartAttribute
    private Date cashSettlementTermsValuationDate = null;
    @XmartAttribute
    private Date cashSettlementTermsValuationDateTime = null;
    @XmartAttribute
    private String cashSettlementTermsValuationTimeCentre = null;
    //FROBI-7296, Flink can't handle LocalTime so using String
    @XmartAttribute
    private String cashSettlementTermsValuationTime = null;
    @XmartAttribute
    private String cashSettlementTermsQuotationRateType = null;
    @XmartAttribute
    private String cashSettlementTermsCashValuationMethod = null;
    @XmartAttribute
    private Boolean cashSettlementTermsCashIncludeAccruedInterest = null;
    @XmartAttribute
    private Boolean cashSettlementTermsPartialSettlementAllowed = null;
    @XmartAttribute
    private Boolean cashSettlementTermsPartialAssignableLoans = null;
    @XmartAttribute
    private Boolean cashSettlementTermsPartialLoanParticipations = null;
    @XmartAttribute
    private String cashSettlementTermsQuotationAmountCurrencyCode = null;
    @XmartAttribute
    private BigDecimal cashSettlementTermsQuotationAmountValue = null;
    @XmartAttribute
    private Integer cashSettlementTermsBusinessDays = null;
    @XmartAttribute
    private String cashSettlementTermsCurrency = null;
    @XmartAttribute
    private Date cashSettlementTermsPaymentDate = null;
    @XmartAttribute
    private String cashSettlementTermsRateSource = null;
    @XmartAttribute
    private String cashSettlementTermsRateSourcePage = null;
    @XmartAttribute
    private Boolean intermediateExchange = null;
    @XmartAttribute
    private Boolean finalExchange = null;
    @XmartAttribute
    private Integer contractMultiplier = null;
    @XmartAttribute
    private String notionalSource = null;
    @XmartAttribute
    private String rateTreatment = null;
    @XmartAttribute
    private BigDecimal discountingRate = null;
    @XmartAttribute
    private String discountingType = null;
    @XmartAttribute
    private String discountingRateDayCount = null;
    @XmartAttribute
    private String earlyTerminationBreakDateCalculationMethod = null;
    @XmartAttribute
    private Date earlyTerminationAdjustdDate = null;
    @XmartAttribute
    private Date earlyTerminationUnadjstDate = null;
    @XmartAttribute
    private String initialStubPrimaryReferenceRate = null;
    @XmartAttribute
    private String initialStubSecondaryReferenceRate = null;
    @XmartAttribute
    private BigDecimal initialStubSpread = null;
    @XmartAttribute
    private BigDecimal initialStubRate = null;
    @XmartAttribute
    private String finalStubPrimaryReferenceRate = null;
    @XmartAttribute
    private String finalStubSecondaryReferenceRate = null;
    @XmartAttribute
    private BigDecimal finalStubSpread = null;
    @XmartAttribute
    private BigDecimal finalStubRate = null;
    @XmartAttribute
    private String breakClauseType = null;
    @XmartAttribute
    private String fxLinkedNotionalFixingTimeCentre = null;
    //FROBI-7296, Flink can't handle LocalTime so using String
    @XmartAttribute
    private String fxLinkedNotionalFixingTime = null;
    @XmartAttribute
    private String settlementInstructionType = null;
    @XmartAttribute
    private BigDecimal legForwardPoints;
    @XmartAttribute
    private String standardProductDescription = null;
    @XmartAttribute
    private String standardProductId = null;
    @XmartAttribute
    private String standardProductSourceSystemId = null;
    @XmartAttribute
    private String nettingGroupId = null;
    //FROBI-11165--ODC3.15
    @XmartAttribute
    private String couponTransferType = null;
    @XmartAttribute
    private Boolean closeoutNettingEnforceable = null;
    @XmartAttribute
    private Boolean closeoutNettingProductCovered = null;

    public XmartTransactionLeg(long documentKey) throws XmartException {
        super(documentKey);
    }

    public void setOdcTransactionLeg(TransactionLeg odcTransactionLeg, long documentKey) throws XmartException {

        clearOdcTransactionLeg();

        this.legIdentifier = odcTransactionLeg.getLegIdentifier();
        if (XmartUtil.isEmptyOrNull(this.legIdentifier)) {
            logger.warn("LegIdentifier not received for document key : " + documentKey);
        }

        legType = getStr(odcTransactionLeg.getLegType());

        legAtomicProduct = odcTransactionLeg.getLegAtomicProduct();

        effectiveDate = convertBusinessDate(odcTransactionLeg.getEffectiveDate());

        unadjustedEffectiveDate = convertBusinessDate(odcTransactionLeg.getUnadjustedEffectiveDate());

        valueDate = convertBusinessDate(odcTransactionLeg.getValueDate());

        deliveryDate = convertBusinessDate(odcTransactionLeg.getDeliveryDate());

        terminationDate = convertBusinessDate(odcTransactionLeg.getTerminationDate());

        AdjustableDate terminationDt = odcTransactionLeg.getTerminationDt();
        if (terminationDt != null) {
            terminationAdjustedDate = convertBusinessDate(terminationDt.getAdjustedDate());
            terminationUnadjustedDate = convertBusinessDate(terminationDt.getUnadjustedDate());
        }

        TradingParty payer = odcTransactionLeg.getPayer();
        if (payer != null) {

            TradingCounterpartyId tradingCounterpartyId = payer.getTradingCounterpartyId();
            if (tradingCounterpartyId != null) {
                payerPartyClassification = getStr(tradingCounterpartyId.getPartyClassification());
                payerPartyReference = tradingCounterpartyId.getPartyReference();
            }

            SourceBookId sourceBookId = payer.getSourceBookId();
            if (sourceBookId != null) {
                payerSourceSystemBookId = sourceBookId.getSourceSystemBookId();
                payerBookSourceSystemId = getStr(sourceBookId.getBookSourceSystemId());
            }
            payerBookCounterparty = payer.isBookCounterparty();
        }

        TradingParty receiver = odcTransactionLeg.getReceiver();
        if (receiver != null) {

            TradingCounterpartyId tradingCounterpartyId = receiver.getTradingCounterpartyId();
            if (tradingCounterpartyId != null) {
                receiverPartyClassification = getStr(tradingCounterpartyId.getPartyClassification());
                receiverPartyReference = tradingCounterpartyId.getPartyReference();
            }

            SourceBookId sourceBookId = receiver.getSourceBookId();
            if (sourceBookId != null) {
                receiverSourceSystemBookId = sourceBookId.getSourceSystemBookId();
                receiverBookSourceSystemId = getStr(sourceBookId.getBookSourceSystemId());
            }
            receiverBookCounterparty = receiver.isBookCounterparty();
        }

        initialPrincipalType = getStr(odcTransactionLeg.getInitialPrincipalType());

        Amount initialPrincipal = odcTransactionLeg.getInitialPrincipal();
        if (initialPrincipal != null) {
            CurrencyId currencyId = initialPrincipal.getCurrencyId();
            if (currencyId != null) {
                initialPrincipalCurrencyCode = currencyId.getCurrencyCode();
            }
            initialPrincipalValue = initialPrincipal.getValue();
        }

        quantityUnitOfMeasure = getStr(odcTransactionLeg.getQuantityUnitOfMeasure());

        quantity = odcTransactionLeg.getQuantity();

        UnitPrice legUnitPrice = odcTransactionLeg.getUnitPrice();
        if (legUnitPrice != null) {
            Amount amount = legUnitPrice.getAmount();
            if (amount != null) {
                CurrencyId currencyId = amount.getCurrencyId();
                if (currencyId != null) {
                    unitPriceCurrencyCode = currencyId.getCurrencyCode();
                }
                unitPriceValue = amount.getValue();
            }
            unitPricePercentage = legUnitPrice.getPercentage();
            unitPriceType = getStr(legUnitPrice.getType());
            unitPrice = legUnitPrice.getPrice();
            unitPriceCurrency = legUnitPrice.getCurrency();
        }

        Amount payAmount = odcTransactionLeg.getPayAmount();
        if (payAmount != null) {
            CurrencyId currencyId = payAmount.getCurrencyId();
            if (currencyId != null) {
                payAmountCurrencyCode = currencyId.getCurrencyCode();
            }
            payAmountValue = payAmount.getValue();
        }

        Amount receiveAmount = odcTransactionLeg.getReceiveAmount();
        if (receiveAmount != null) {
            CurrencyId currencyId = receiveAmount.getCurrencyId();
            if (currencyId != null) {
                receiveAmountCurrencyCode = currencyId.getCurrencyCode();
            }
            receiveAmountValue = receiveAmount.getValue();
        }

        spotExchangeRate = odcTransactionLeg.getSpotExchangeRate();

        forwardPoints = odcTransactionLeg.getForwardPoints();

        forwardExchangeRate = odcTransactionLeg.getForwardExchangeRate();

        currencyQuoteBasis = getStr(odcTransactionLeg.getCurrencyQuoteBasis());

        crossCurrencyType = getStr(odcTransactionLeg.getCrossCurrencyType());

        CurrencyId settlementCurrencyId = odcTransactionLeg.getSettlementCurrencyId();
        if (settlementCurrencyId != null) {
            settlementCurrencyCode = settlementCurrencyId.getCurrencyCode();
        }

        referenceRate = odcTransactionLeg.getReferenceRate();

        referenceRateTenor = odcTransactionLeg.getReferenceRateTenor();

        rateSource = odcTransactionLeg.getRateSource();

        spread = odcTransactionLeg.getSpread();

        spreadType = getStr(odcTransactionLeg.getSpreadType());

        haircut = odcTransactionLeg.getHairCut();

        rehypothecable = odcTransactionLeg.isRehypothecable();

        segregated = odcTransactionLeg.isSegregated();

        principalAmortizationStyle = odcTransactionLeg.getPrincipalAmortizationStyle();

        averagingMethod = getStr(odcTransactionLeg.getAveragingMethod());

        settlementType = getStr(odcTransactionLeg.getSettlementType());

        returnType = getStr(odcTransactionLeg.getReturnType());

        cashflowMatchParameter = odcTransactionLeg.isCashflowMatchParameter();

        firstPaymentDate = convertBusinessDate(odcTransactionLeg.getFirstPaymentDate());

        lastPaymentDate = convertBusinessDate(odcTransactionLeg.getLastPaymentDate());

        lastRegularPaymentDate = convertBusinessDate(odcTransactionLeg.getLastRegularPaymentDate());

        firstRegularPeriodStartDate = convertBusinessDate(odcTransactionLeg.getFirstRegPeriodStartDate());

        lastRegularPeriodEndDate = convertBusinessDate(odcTransactionLeg.getLastRegularPeriodEndDate());

        firstCalculationPeriodStartDate = convertBusinessDate(odcTransactionLeg.getFirstCalculationPeriodStartDate());

        firstCompPeriodEndDate = convertBusinessDate(odcTransactionLeg.getFirstCompPeriodEndDate());

        rollConventionScheme = getStr(odcTransactionLeg.getRollConventionScheme());

        weeklyRollConvention = getStr(odcTransactionLeg.getWeeklyRollConvention());

        dayCountConvention = getStr(odcTransactionLeg.getDayCountConvention());

        businessDaysConvention = getStr(odcTransactionLeg.getBusinessDayConvention());

        daysInYear = odcTransactionLeg.getDaysInYear();

        InstrumentId legInstrumentId = odcTransactionLeg.getInstrumentId();
        if (legInstrumentId != null) {
            instrumentScheme = getStr(legInstrumentId.getInstrumentScheme());
            instrumentId = getStr(legInstrumentId.getInstrumentId());
        }

        basketName = odcTransactionLeg.getBasketName();

        basketDivisor = odcTransactionLeg.getBasketDivisor();

        CurrencyId basketCurrencyId = odcTransactionLeg.getBasketCurrencyId();
        if (basketCurrencyId != null) {
            basketCurrencyCode = basketCurrencyId.getCurrencyCode();
        }

        CollateralLeg collateralLeg = odcTransactionLeg.getCollateralLeg();
        if (collateralLeg != null) {
            collateralLegDeliveryByValueIndicator = collateralLeg.getDeliveryByValueIndicator();
            collateralLegCouponReinvestmentRate = collateralLeg.getCouponReinvestmentRate();
        }

        IncomeStreamLeg incomeStreamLeg = odcTransactionLeg.getIncomeStreamLeg();
        if (incomeStreamLeg != null) {
            incomeStreamLegInitialPriceMethod = incomeStreamLeg.getInitialPriceMethod();
            UnitPrice initialPrice = incomeStreamLeg.getInitialPrice();
            if (initialPrice != null) {
                Amount amount = initialPrice.getAmount();
                if (amount != null) {
                    CurrencyId currencyId = amount.getCurrencyId();
                    if (currencyId != null) {
                        incomeStreamLegInitialPriceCurrencyCode = currencyId.getCurrencyCode();
                    }
                    incomeStreamLegInitialPriceValue = amount.getValue();
                }
                incomeStreamLegInitialPricePercentage = initialPrice.getPercentage();
                incomeStreamLegInitialPriceType = getStr(initialPrice.getType());
                incomeStreamLegInitialPrice = initialPrice.getPrice();
                incomeStreamLegInitialPriceCurrency = initialPrice.getCurrency();
            }
            incomeStreamLegFinalPriceMethod = incomeStreamLeg.getFinalPriceMethod();
            UnitPrice finalPrice = incomeStreamLeg.getFinalPrice();
            if (finalPrice != null) {

                Amount amount = finalPrice.getAmount();
                if (amount != null) {
                    CurrencyId currencyId = amount.getCurrencyId();
                    if (currencyId != null) {
                        incomeStreamLegFinalPriceCurrencyCode = currencyId.getCurrencyCode();
                    }
                    incomeStreamLegFinalPriceValue = amount.getValue();
                }
                incomeStreamLegFinalPricePercentage = finalPrice.getPercentage();
                incomeStreamLegFinalPriceType = getStr(finalPrice.getType());
                incomeStreamLegFinalPricePrice = finalPrice.getPrice();
                incomeStreamLegFinalPriceCurrency = finalPrice.getCurrency();
            }
            Amount notionalAmount = incomeStreamLeg.getNotionalAmount();
            if (notionalAmount != null) {
                CurrencyId currencyId = notionalAmount.getCurrencyId();
                if (currencyId != null) {
                    incomeStreamLegNotionalAmountCurrencyCode = currencyId.getCurrencyCode();
                }
                incomeStreamLegNotionalAmountValue = notionalAmount.getValue();
            }
            incomeStreamLegFixedOrFloatingRateType = getStr(incomeStreamLeg.getFixedOrFloatingRateType());
            PartyId referenceEntityId = incomeStreamLeg.getReferenceEntityId();
            if (referenceEntityId != null) {
                incomeStreamLegReferenceEntityIdPartyIdClassification = getStr(referenceEntityId.getScheme());
                incomeStreamLegReferenceEntityIdPartyId = referenceEntityId.getPartyId();
            }
        }

        InstrumentLoanLeg instrumentLoanLeg = odcTransactionLeg.getInstrumentLoanLeg();
        if (instrumentLoanLeg != null) {
            instrumentLoanLegDeliverOrPayIndicator = getStr(instrumentLoanLeg.getDeliverOrPayIndicator());
        }

        InstrumentLeg instrumentLeg = odcTransactionLeg.getInstrumentLeg();
        if (instrumentLeg != null) {
            instrumentLegQuantoExchangeRate = instrumentLeg.getQuantoExchangeRate();
            instrumentLegInitialPriceMethod = getStr(instrumentLeg.getInitialPriceMethod());
            InitialPrice initialPrice = instrumentLeg.getInitialPrice();
            if (initialPrice != null) {
                Amount amount = initialPrice.getAmount();
                if (amount != null) {
                    CurrencyId currencyId = amount.getCurrencyId();
                    if (currencyId != null) {
                        instrumentLegInitialPriceCurrencyCode = currencyId.getCurrencyCode();
                    }
                    instrumentLegInitialPriceValue = amount.getValue();
                }
            }
            Amount settlementAmount = instrumentLeg.getSettlementAmount();
            if (settlementAmount != null) {
                CurrencyId currencyId = settlementAmount.getCurrencyId();
                if (currencyId != null) {
                    instrumentLegSettlementAmountCurrencyCode = currencyId.getCurrencyCode();
                }
                instrumentLegSettlementAmountValue = settlementAmount.getValue();
            }
            instrumentLegShortSellingClassification = getStr(instrumentLeg.getShortSellingClassification());
        }

        openUnitsQuantity = odcTransactionLeg.getOpenUnitsQuantity();

        capInterestRate = odcTransactionLeg.getCapInterestRate();

        maxCapInterestRate = odcTransactionLeg.getMaxCapInterestRate();

        floorInterestRate = odcTransactionLeg.getFloorInterestRate();

        minFloorInterestRate = odcTransactionLeg.getMinFloorInterestRate();

        Dividend dividend = odcTransactionLeg.getDividend();
        if (dividend != null) {
            CurrencyId currencyId = dividend.getCurrencyId();
            if (currencyId != null) {
                dividendCurrencyCode = currencyId.getCurrencyCode();
            }
            dividendPercentage = dividend.getPercentage();
        }

        digitalPayoutRate = odcTransactionLeg.getDigitalPayoutRate();

        cashSettlementMethod = odcTransactionLeg.getCashSettlementMethod();

        accruedInterestPercentage = odcTransactionLeg.getAccruedInterestPercentage();

        paymentIndicator = odcTransactionLeg.getPaymentIndicator();

        CurrencyId sideRateBaseCurrencyId = odcTransactionLeg.getSideRateBaseCurrencyId();
        if (sideRateBaseCurrencyId != null) {
            sideRateBaseCurrencyIdCurrencyCode = sideRateBaseCurrencyId.getCurrencyCode();
        }

        payCurrencySideRate = odcTransactionLeg.getPayCurrencySideRate();

        paySideRateQuoteBasis = getStr(odcTransactionLeg.getPaySideRateQuoteBasis());

        receiveCurrencySideRate = odcTransactionLeg.getReceiveCurrencySideRate();

        receiveSideRateQuoteBasis = getStr(odcTransactionLeg.getReceiveSideRateQuoteBasis());

        nonDeliverable = odcTransactionLeg.isNonDeliverable();

        gentanBondRate = odcTransactionLeg.getGentanBondRate();

        CashSettlementTerms cashSettlementTerms = odcTransactionLeg.getCashSettlementTerms();
        if (cashSettlementTerms != null) {
            // TODO move required method(getValuationDateTime) to interface(TransactionLeg) instead of downcasting
            cashSettlementTermsValuationDate = ((CashSettlementTermsImpl) cashSettlementTerms).getValuationDateTime();
            cashSettlementTermsValuationDateTime = ((CashSettlementTermsImpl) cashSettlementTerms)
                    .getValuationDateTime();

            BusinessCentreTime valuationTime = cashSettlementTerms.getValuationTime();
            if (valuationTime != null) {
                cashSettlementTermsValuationTimeCentre = valuationTime.getCentre();
                cashSettlementTermsValuationTime = valuationTime.getTime() != null ?
                                                   convertLocalTime(valuationTime.getTime().getLocalTime()) : null;
            }
            cashSettlementTermsQuotationRateType = getStr(cashSettlementTerms.getQuotationRateType());
            cashSettlementTermsCashValuationMethod = getStr(cashSettlementTerms.getCashValuationMethod());
            cashSettlementTermsCashIncludeAccruedInterest = cashSettlementTerms.getCashIncludeAccruedInterest();
            cashSettlementTermsPartialSettlementAllowed = cashSettlementTerms.getPartialSettlementAllowed();
            cashSettlementTermsPartialAssignableLoans = cashSettlementTerms.getPartialAssignableLoans();
            cashSettlementTermsPartialLoanParticipations = cashSettlementTerms.getPartialLoanParticipations();
            Amount quotationAmount = cashSettlementTerms.getQuotationAmount();
            if (quotationAmount != null) {
                CurrencyId currencyId = quotationAmount.getCurrencyId();
                if (currencyId != null) {
                    cashSettlementTermsQuotationAmountCurrencyCode = currencyId.getCurrencyCode();
                }
                cashSettlementTermsQuotationAmountValue = quotationAmount.getValue();
            }
            cashSettlementTermsBusinessDays = cashSettlementTerms.getBusinessDays();
            cashSettlementTermsCurrency = cashSettlementTerms.getCurrency();
            cashSettlementTermsPaymentDate = cashSettlementTerms.getPaymentDate();
            cashSettlementTermsRateSource = cashSettlementTerms.getRateSource();
            cashSettlementTermsRateSourcePage = cashSettlementTerms.getRateSourcePage();
        }

        intermediateExchange = odcTransactionLeg.isIntermediateExchange();

        finalExchange = odcTransactionLeg.isFinalExchange();

        contractMultiplier = odcTransactionLeg.getContractMultiplier();

        notionalSource = getStr(odcTransactionLeg.getNotionalSource());

        rateTreatment = getStr(odcTransactionLeg.getRateTreatment());

        Discounting discounting = odcTransactionLeg.getDiscounting();
        if (discounting != null) {
            discountingRate = discounting.getDiscountRate();
            discountingType = getStr(discounting.getDiscountingType());
            discountingRateDayCount = discounting.getRateDayCount();
        }

        EarlyTermination earlyTermination = odcTransactionLeg.getEarlyTermination();
        if (earlyTermination != null) {
            earlyTerminationBreakDateCalculationMethod = getStr(earlyTermination.getBreakDateCalculationMethod());
            earlyTerminationAdjustdDate = convertBusinessDate(earlyTermination.getAdjustdDate());
            earlyTerminationUnadjstDate = convertBusinessDate(earlyTermination.getUnadjstDate());
        }

        Stub initialStub = odcTransactionLeg.getInitialStub();
        if (initialStub != null) {
            initialStubPrimaryReferenceRate = initialStub.getPrimaryRateReference();
            initialStubSecondaryReferenceRate = initialStub.getSecondaryRateReference();
            initialStubSpread = initialStub.getSpread();
            initialStubRate = initialStub.getRate();
        }

        Stub finalStub = odcTransactionLeg.getFinalStub();
        if (finalStub != null) {
            finalStubPrimaryReferenceRate = finalStub.getPrimaryRateReference();
            finalStubSecondaryReferenceRate = finalStub.getSecondaryRateReference();
            finalStubSpread = finalStub.getSpread();
            finalStubRate = finalStub.getRate();
        }

        breakClauseType = getStr(odcTransactionLeg.getBreakClauseType());

        FXLinkedNotional fxLinkedNotional = odcTransactionLeg.getFxLinkedNotional();
        if (fxLinkedNotional != null) {
            BusinessCentreTime fixingTime = fxLinkedNotional.getFixingTime();
            if (fixingTime != null) {
                fxLinkedNotionalFixingTimeCentre = fixingTime.getCentre();
                fxLinkedNotionalFixingTime = fixingTime.getTime() != null ?
                                             convertLocalTime(fixingTime.getTime().getLocalTime()) : null;
                //                fxLinkedNotionalFixingTime = fixingTime.getTime() != null ? fixingTime.getTime().getTime() : null;
            }
        }
        settlementInstructionType = odcTransactionLeg.getSettlementInstructionType();

        legForwardPoints = odcTransactionLeg.getLegForwardPoints();

        StandardProduct standardProduct = odcTransactionLeg.getStandardProduct();
        if (standardProduct != null) {
            standardProductDescription = standardProduct.getDescription();
            standardProductId = standardProduct.getProductId();
            standardProductSourceSystemId = getStr(standardProduct.getProductSourceSystemId());
        }

        nettingGroupId = odcTransactionLeg.getNettingGroupId();
        couponTransferType = getStr(odcTransactionLeg.getCouponTransferType());
        closeoutNettingEnforceable = odcTransactionLeg.isCloseoutNettingEnforceable();
        closeoutNettingProductCovered = odcTransactionLeg.isCloseoutNettingProductCovered();
    }

    private void clearOdcTransactionLeg() {

        legIdentifier = null;

        legType = null;

        legAtomicProduct = null;

        effectiveDate = null;

        unadjustedEffectiveDate = null;

        valueDate = null;

        deliveryDate = null;

        terminationDate = null;

        terminationAdjustedDate = null;

        terminationUnadjustedDate = null;

        payerSourceSystemBookId = null;

        payerBookSourceSystemId = null;

        payerPartyClassification = null;

        payerPartyReference = null;

        payerBookCounterparty = null;

        receiverSourceSystemBookId = null;

        receiverBookSourceSystemId = null;

        receiverPartyClassification = null;

        receiverPartyReference = null;

        receiverBookCounterparty = null;

        initialPrincipalType = null;

        initialPrincipalCurrencyCode = null;

        initialPrincipalValue = null;

        quantityUnitOfMeasure = null;

        quantity = null;

        unitPriceCurrencyCode = null;

        unitPriceValue = null;

        unitPricePercentage = null;

        unitPriceType = null;

        unitPrice = null;

        unitPriceCurrency = null;

        payAmountCurrencyCode = null;

        payAmountValue = null;

        receiveAmountCurrencyCode = null;

        receiveAmountValue = null;

        spotExchangeRate = null;

        forwardPoints = null;

        forwardExchangeRate = null;

        currencyQuoteBasis = null;

        crossCurrencyType = null;

        settlementCurrencyCode = null;

        referenceRate = null;

        referenceRateTenor = null;

        rateSource = null;

        spread = null;

        spreadType = null;

        haircut = null;

        rehypothecable = null;

        segregated = null;

        principalAmortizationStyle = null;

        averagingMethod = null;

        settlementType = null;

        returnType = null;

        cashflowMatchParameter = null;

        firstPaymentDate = null;

        lastPaymentDate = null;

        lastRegularPaymentDate = null;

        firstRegularPeriodStartDate = null;

        lastRegularPeriodEndDate = null;

        firstCalculationPeriodStartDate = null;

        firstCompPeriodEndDate = null;

        rollConventionScheme = null;

        weeklyRollConvention = null;

        dayCountConvention = null;

        businessDaysConvention = null;

        daysInYear = null;

        instrumentScheme = null;

        instrumentId = null;

        basketName = null;

        basketDivisor = null;

        basketCurrencyCode = null;

        collateralLegDeliveryByValueIndicator = null;

        collateralLegCouponReinvestmentRate = null;

        incomeStreamLegInitialPriceMethod = null;

        incomeStreamLegInitialPriceCurrencyCode = null;

        incomeStreamLegInitialPriceValue = null;

        incomeStreamLegInitialPricePercentage = null;

        incomeStreamLegInitialPriceType = null;

        incomeStreamLegInitialPrice = null;

        incomeStreamLegInitialPriceCurrency = null;

        incomeStreamLegFinalPriceMethod = null;

        incomeStreamLegFinalPriceCurrencyCode = null;

        incomeStreamLegFinalPriceValue = null;

        incomeStreamLegFinalPricePercentage = null;

        incomeStreamLegFinalPriceType = null;

        incomeStreamLegFinalPricePrice = null;

        incomeStreamLegFinalPriceCurrency = null;

        incomeStreamLegNotionalAmountCurrencyCode = null;

        incomeStreamLegNotionalAmountValue = null;

        incomeStreamLegFixedOrFloatingRateType = null;

        incomeStreamLegReferenceEntityIdPartyIdClassification = null;

        incomeStreamLegReferenceEntityIdPartyId = null;

        instrumentLoanLegDeliverOrPayIndicator = null;

        instrumentLegQuantoExchangeRate = null;

        instrumentLegInitialPriceMethod = null;

        instrumentLegInitialPriceCurrencyCode = null;

        instrumentLegInitialPriceValue = null;

        instrumentLegSettlementAmountCurrencyCode = null;

        instrumentLegSettlementAmountValue = null;

        instrumentLegShortSellingClassification = null;

        openUnitsQuantity = null;

        capInterestRate = null;

        maxCapInterestRate = null;

        floorInterestRate = null;

        minFloorInterestRate = null;

        dividendCurrencyCode = null;

        dividendPercentage = null;

        digitalPayoutRate = null;

        cashSettlementMethod = null;

        accruedInterestPercentage = null;

        paymentIndicator = null;

        sideRateBaseCurrencyIdCurrencyCode = null;

        payCurrencySideRate = null;

        paySideRateQuoteBasis = null;

        receiveCurrencySideRate = null;

        receiveSideRateQuoteBasis = null;

        nonDeliverable = null;

        gentanBondRate = null;

        cashSettlementTermsValuationDate = null;

        cashSettlementTermsValuationDateTime = null;

        cashSettlementTermsValuationTimeCentre = null;

        cashSettlementTermsValuationTime = null;

        cashSettlementTermsQuotationRateType = null;

        cashSettlementTermsCashValuationMethod = null;

        cashSettlementTermsCashIncludeAccruedInterest = null;

        cashSettlementTermsPartialSettlementAllowed = null;

        cashSettlementTermsPartialAssignableLoans = null;

        cashSettlementTermsPartialLoanParticipations = null;

        cashSettlementTermsQuotationAmountCurrencyCode = null;

        cashSettlementTermsQuotationAmountValue = null;

        cashSettlementTermsBusinessDays = null;

        cashSettlementTermsCurrency = null;

        cashSettlementTermsPaymentDate = null;

        cashSettlementTermsRateSource = null;

        cashSettlementTermsRateSourcePage = null;

        intermediateExchange = null;

        finalExchange = null;

        contractMultiplier = null;

        notionalSource = null;

        rateTreatment = null;

        discountingRate = null;

        discountingType = null;

        discountingRateDayCount = null;

        earlyTerminationBreakDateCalculationMethod = null;

        earlyTerminationAdjustdDate = null;

        earlyTerminationUnadjstDate = null;

        initialStubPrimaryReferenceRate = null;

        initialStubSecondaryReferenceRate = null;

        initialStubSpread = null;

        initialStubRate = null;

        finalStubPrimaryReferenceRate = null;

        finalStubSecondaryReferenceRate = null;

        finalStubSpread = null;

        finalStubRate = null;

        breakClauseType = null;

        fxLinkedNotionalFixingTimeCentre = null;

        fxLinkedNotionalFixingTime = null;

        settlementInstructionType = null;

        legForwardPoints = null;

        standardProductDescription = null;

        standardProductId = null;

        standardProductSourceSystemId = null;

        nettingGroupId = null;

        couponTransferType = null;

        closeoutNettingEnforceable = null;

        closeoutNettingProductCovered = null;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getLegType() {
        return legType;
    }

    public String getLegAtomicProduct() {
        return legAtomicProduct;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public Date getUnadjustedEffectiveDate() {
        return unadjustedEffectiveDate;
    }

    public Date getValueDate() {
        return valueDate;
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public Date getTerminationDate() {
        return terminationDate;
    }

    public Date getTerminationAdjustedDate() {
        return terminationAdjustedDate;
    }

    public Date getTerminationUnadjustedDate() {
        return terminationUnadjustedDate;
    }

    public String getPayerSourceSystemBookId() {
        return payerSourceSystemBookId;
    }

    public String getPayerBookSourceSystemId() {
        return payerBookSourceSystemId;
    }

    public String getPayerPartyClassification() {
        return payerPartyClassification;
    }

    public String getPayerPartyReference() {
        return payerPartyReference;
    }

    public Boolean getPayerBookCounterparty() {
        return payerBookCounterparty;
    }

    public String getReceiverSourceSystemBookId() {
        return receiverSourceSystemBookId;
    }

    public String getReceiverBookSourceSystemId() {
        return receiverBookSourceSystemId;
    }

    public String getReceiverPartyClassification() {
        return receiverPartyClassification;
    }

    public String getReceiverPartyReference() {
        return receiverPartyReference;
    }

    public Boolean getReceiverBookCounterparty() {
        return receiverBookCounterparty;
    }

    public String getInitialPrincipalType() {
        return initialPrincipalType;
    }

    public String getInitialPrincipalCurrencyCode() {
        return initialPrincipalCurrencyCode;
    }

    public BigDecimal getInitialPrincipalValue() {
        return initialPrincipalValue;
    }

    public String getQuantityUnitOfMeasure() {
        return quantityUnitOfMeasure;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public String getUnitPriceCurrencyCode() {
        return unitPriceCurrencyCode;
    }

    public BigDecimal getUnitPriceValue() {
        return unitPriceValue;
    }

    public BigDecimal getUnitPricePercentage() {
        return unitPricePercentage;
    }

    public String getUnitPriceType() {
        return unitPriceType;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public String getUnitPriceCurrency() {
        return unitPriceCurrency;
    }

    public String getPayAmountCurrencyCode() {
        return payAmountCurrencyCode;
    }

    public BigDecimal getPayAmountValue() {
        return payAmountValue;
    }

    public String getReceiveAmountCurrencyCode() {
        return receiveAmountCurrencyCode;
    }

    public BigDecimal getReceiveAmountValue() {
        return receiveAmountValue;
    }

    public BigDecimal getSpotExchangeRate() {
        return spotExchangeRate;
    }

    public BigDecimal getForwardPoints() {
        return forwardPoints;
    }

    public BigDecimal getForwardExchangeRate() {
        return forwardExchangeRate;
    }

    public String getCurrencyQuoteBasis() {
        return currencyQuoteBasis;
    }

    public String getCrossCurrencyType() {
        return crossCurrencyType;
    }

    public String getSettlementCurrencyCode() {
        return settlementCurrencyCode;
    }

    public String getReferenceRate() {
        return referenceRate;
    }

    public Integer getReferenceRateTenor() {
        return referenceRateTenor;
    }

    public String getRateSource() {
        return rateSource;
    }

    public BigDecimal getSpread() {
        return spread;
    }

    public String getSpreadType() {
        return spreadType;
    }

    public BigDecimal getHaircut() {
        return haircut;
    }

    public Boolean getRehypothecable() {
        return rehypothecable;
    }

    public Boolean getSegregated() {
        return segregated;
    }

    public String getPrincipalAmortizationStyle() {
        return principalAmortizationStyle;
    }

    public String getAveragingMethod() {
        return averagingMethod;
    }

    public String getSettlementType() {
        return settlementType;
    }

    public String getReturnType() {
        return returnType;
    }

    public Boolean getCashflowMatchParameter() {
        return cashflowMatchParameter;
    }

    public Date getFirstPaymentDate() {
        return firstPaymentDate;
    }

    public Date getLastPaymentDate() {
        return lastPaymentDate;
    }

    public Date getLastRegularPaymentDate() {
        return lastRegularPaymentDate;
    }

    public Date getFirstRegularPeriodStartDate() {
        return firstRegularPeriodStartDate;
    }

    public Date getLastRegularPeriodEndDate() {
        return lastRegularPeriodEndDate;
    }

    public Date getFirstCalculationPeriodStartDate() {
        return firstCalculationPeriodStartDate;
    }

    public Date getFirstCompPeriodEndDate() {
        return firstCompPeriodEndDate;
    }

    public String getRollConventionScheme() {
        return rollConventionScheme;
    }

    public String getWeeklyRollConvention() {
        return weeklyRollConvention;
    }

    public String getDayCountConvention() {
        return dayCountConvention;
    }

    public String getBusinessDaysConvention() {
        return businessDaysConvention;
    }

    public Integer getDaysInYear() {
        return daysInYear;
    }

    public String getInstrumentScheme() {
        return instrumentScheme;
    }

    public String getInstrumentId() {
        return instrumentId;
    }

    public String getBasketName() {
        return basketName;
    }

    public BigDecimal getBasketDivisor() {
        return basketDivisor;
    }

    public String getBasketCurrencyCode() {
        return basketCurrencyCode;
    }

    public Boolean getCollateralLegDeliveryByValueIndicator() {
        return collateralLegDeliveryByValueIndicator;
    }

    public BigDecimal getCollateralLegCouponReinvestmentRate() {
        return collateralLegCouponReinvestmentRate;
    }

    public String getIncomeStreamLegInitialPriceMethod() {
        return incomeStreamLegInitialPriceMethod;
    }

    public String getIncomeStreamLegInitialPriceCurrencyCode() {
        return incomeStreamLegInitialPriceCurrencyCode;
    }

    public BigDecimal getIncomeStreamLegInitialPriceValue() {
        return incomeStreamLegInitialPriceValue;
    }

    public BigDecimal getIncomeStreamLegInitialPricePercentage() {
        return incomeStreamLegInitialPricePercentage;
    }

    public String getIncomeStreamLegInitialPriceType() {
        return incomeStreamLegInitialPriceType;
    }

    public BigDecimal getIncomeStreamLegInitialPrice() {
        return incomeStreamLegInitialPrice;
    }

    public String getIncomeStreamLegInitialPriceCurrency() {
        return incomeStreamLegInitialPriceCurrency;
    }

    public String getIncomeStreamLegFinalPriceMethod() {
        return incomeStreamLegFinalPriceMethod;
    }

    public String getIncomeStreamLegFinalPriceCurrencyCode() {
        return incomeStreamLegFinalPriceCurrencyCode;
    }

    public BigDecimal getIncomeStreamLegFinalPriceValue() {
        return incomeStreamLegFinalPriceValue;
    }

    public BigDecimal getIncomeStreamLegFinalPricePercentage() {
        return incomeStreamLegFinalPricePercentage;
    }

    public String getIncomeStreamLegFinalPriceType() {
        return incomeStreamLegFinalPriceType;
    }

    public BigDecimal getIncomeStreamLegFinalPricePrice() {
        return incomeStreamLegFinalPricePrice;
    }

    public String getIncomeStreamLegFinalPriceCurrency() {
        return incomeStreamLegFinalPriceCurrency;
    }

    public String getIncomeStreamLegNotionalAmountCurrencyCode() {
        return incomeStreamLegNotionalAmountCurrencyCode;
    }

    public BigDecimal getIncomeStreamLegNotionalAmountValue() {
        return incomeStreamLegNotionalAmountValue;
    }

    public String getIncomeStreamLegFixedOrFloatingRateType() {
        return incomeStreamLegFixedOrFloatingRateType;
    }

    public String getIncomeStreamLegReferenceEntityIdPartyIdClassification() {
        return incomeStreamLegReferenceEntityIdPartyIdClassification;
    }

    public String getIncomeStreamLegReferenceEntityIdPartyId() {
        return incomeStreamLegReferenceEntityIdPartyId;
    }

    public String getInstrumentLoanLegDeliverOrPayIndicator() {
        return instrumentLoanLegDeliverOrPayIndicator;
    }

    public BigDecimal getInstrumentLegQuantoExchangeRate() {
        return instrumentLegQuantoExchangeRate;
    }

    public String getInstrumentLegInitialPriceMethod() {
        return instrumentLegInitialPriceMethod;
    }

    public String getInstrumentLegInitialPriceCurrencyCode() {
        return instrumentLegInitialPriceCurrencyCode;
    }

    public BigDecimal getInstrumentLegInitialPriceValue() {
        return instrumentLegInitialPriceValue;
    }

    public String getInstrumentLegSettlementAmountCurrencyCode() {
        return instrumentLegSettlementAmountCurrencyCode;
    }

    public BigDecimal getInstrumentLegSettlementAmountValue() {
        return instrumentLegSettlementAmountValue;
    }

    public String getInstrumentLegShortSellingClassification() {
        return instrumentLegShortSellingClassification;
    }

    public BigDecimal getOpenUnitsQuantity() {
        return openUnitsQuantity;
    }

    public BigDecimal getCapInterestRate() {
        return capInterestRate;
    }

    public BigDecimal getMaxCapInterestRate() {
        return maxCapInterestRate;
    }

    public BigDecimal getFloorInterestRate() {
        return floorInterestRate;
    }

    public BigDecimal getMinFloorInterestRate() {
        return minFloorInterestRate;
    }

    public String getDividendCurrencyCode() {
        return dividendCurrencyCode;
    }

    public BigDecimal getDividendPercentage() {
        return dividendPercentage;
    }

    public BigDecimal getDigitalPayoutRate() {
        return digitalPayoutRate;
    }

    public String getCashSettlementMethod() {
        return cashSettlementMethod;
    }

    public BigDecimal getAccruedInterestPercentage() {
        return accruedInterestPercentage;
    }

    public String getPaymentIndicator() {
        return paymentIndicator;
    }

    public String getSideRateBaseCurrencyIdCurrencyCode() {
        return sideRateBaseCurrencyIdCurrencyCode;
    }

    public BigDecimal getPayCurrencySideRate() {
        return payCurrencySideRate;
    }

    public String getPaySideRateQuoteBasis() {
        return paySideRateQuoteBasis;
    }

    public BigDecimal getReceiveCurrencySideRate() {
        return receiveCurrencySideRate;
    }

    public String getReceiveSideRateQuoteBasis() {
        return receiveSideRateQuoteBasis;
    }

    public Boolean getNonDeliverable() {
        return nonDeliverable;
    }

    public BigDecimal getGentanBondRate() {
        return gentanBondRate;
    }

    public Date getCashSettlementTermsValuationDate() {
        return cashSettlementTermsValuationDate;
    }

    public Date getCashSettlementTermsValuationDateTime() {
        return cashSettlementTermsValuationDateTime;
    }

    public String getCashSettlementTermsValuationTimeCentre() {
        return cashSettlementTermsValuationTimeCentre;
    }

    public String getCashSettlementTermsValuationTime() {
        return cashSettlementTermsValuationTime;
    }

    public String getCashSettlementTermsQuotationRateType() {
        return cashSettlementTermsQuotationRateType;
    }

    public String getCashSettlementTermsCashValuationMethod() {
        return cashSettlementTermsCashValuationMethod;
    }

    public Boolean getCashSettlementTermsCashIncludeAccruedInterest() {
        return cashSettlementTermsCashIncludeAccruedInterest;
    }

    public Boolean getCashSettlementTermsPartialSettlementAllowed() {
        return cashSettlementTermsPartialSettlementAllowed;
    }

    public Boolean getCashSettlementTermsPartialAssignableLoans() {
        return cashSettlementTermsPartialAssignableLoans;
    }

    public Boolean getCashSettlementTermsPartialLoanParticipations() {
        return cashSettlementTermsPartialLoanParticipations;
    }

    public String getCashSettlementTermsQuotationAmountCurrencyCode() {
        return cashSettlementTermsQuotationAmountCurrencyCode;
    }

    public BigDecimal getCashSettlementTermsQuotationAmountValue() {
        return cashSettlementTermsQuotationAmountValue;
    }

    public Integer getCashSettlementTermsBusinessDays() {
        return cashSettlementTermsBusinessDays;
    }

    public String getCashSettlementTermsCurrency() {
        return cashSettlementTermsCurrency;
    }

    public Date getCashSettlementTermsPaymentDate() {
        return cashSettlementTermsPaymentDate;
    }

    public String getCashSettlementTermsRateSource() {
        return cashSettlementTermsRateSource;
    }

    public String getCashSettlementTermsRateSourcePage() {
        return cashSettlementTermsRateSourcePage;
    }

    public Boolean getIntermediateExchange() {
        return intermediateExchange;
    }

    public Boolean getFinalExchange() {
        return finalExchange;
    }

    public Integer getContractMultiplier() {
        return contractMultiplier;
    }

    public String getNotionalSource() {
        return notionalSource;
    }

    public String getRateTreatment() {
        return rateTreatment;
    }

    public BigDecimal getDiscountingRate() {
        return discountingRate;
    }

    public String getDiscountingType() {
        return discountingType;
    }

    public String getDiscountingRateDayCount() {
        return discountingRateDayCount;
    }

    public String getEarlyTerminationBreakDateCalculationMethod() {
        return earlyTerminationBreakDateCalculationMethod;
    }

    public Date getEarlyTerminationAdjustdDate() {
        return earlyTerminationAdjustdDate;
    }

    public Date getEarlyTerminationUnadjstDate() {
        return earlyTerminationUnadjstDate;
    }

    public String getInitialStubPrimaryReferenceRate() {
        return initialStubPrimaryReferenceRate;
    }

    public String getInitialStubSecondaryReferenceRate() {
        return initialStubSecondaryReferenceRate;
    }

    public BigDecimal getInitialStubSpread() {
        return initialStubSpread;
    }

    public BigDecimal getInitialStubRate() {
        return initialStubRate;
    }

    public String getFinalStubPrimaryReferenceRate() {
        return finalStubPrimaryReferenceRate;
    }

    public String getFinalStubSecondaryReferenceRate() {
        return finalStubSecondaryReferenceRate;
    }

    public BigDecimal getFinalStubSpread() {
        return finalStubSpread;
    }

    public BigDecimal getFinalStubRate() {
        return finalStubRate;
    }

    public String getBreakClauseType() {
        return breakClauseType;
    }

    public String getFxLinkedNotionalFixingTimeCentre() {
        return fxLinkedNotionalFixingTimeCentre;
    }

    public String getFxLinkedNotionalFixingTime() {
        return fxLinkedNotionalFixingTime;
    }

    public String getSettlementInstructionType() {
        return settlementInstructionType;
    }

    public BigDecimal getLegForwardPoints() {
        return legForwardPoints;
    }

    public String getStandardProductDescription() {
        return standardProductDescription;
    }

    public String getStandardProductId() {
        return standardProductId;
    }

    public String getStandardProductSourceSystemId() {
        return standardProductSourceSystemId;
    }

    public String getNettingGroupId() {
        return nettingGroupId;
    }

    public String getCouponTransferType() {
        return couponTransferType;
    }

    public Boolean getCloseoutNettingEnforceable() { return closeoutNettingEnforceable;}

    public Boolean getCloseoutNettingProductCovered() { return closeoutNettingProductCovered;}


}
