package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTransactionMarginJurisdiction extends XmartEntity {
    private static final long serialVersionUID = 6272336734130464230L;

    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = false)
    private final Integer agreementTransactionContextId;
    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = true)
    private final String marginType;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String jurisdictoryPartyApplicabilityScope;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String regulatoryAuthority;

    protected XmartTransactionMarginJurisdiction(long documentKey, Integer agreementTransactionContextId,
            String marginType) throws XmartException {
        super(documentKey);
        this.agreementTransactionContextId = agreementTransactionContextId;
        this.marginType = marginType;
    }

    public Integer getAgreementTransactionContextId() {
        return agreementTransactionContextId;
    }

    public String getMarginType() {
        return marginType;
    }

    public String getJurisdictoryPartyApplicabilityScope() {
        return jurisdictoryPartyApplicabilityScope;
    }

    public void setJurisdictoryPartyApplicabilityScope(String jurisdictoryPartyApplicabilityScope) {
        this.jurisdictoryPartyApplicabilityScope = jurisdictoryPartyApplicabilityScope;
    }

    public String getRegulatoryAuthority() {
        return regulatoryAuthority;
    }

    public void setRegulatoryAuthority(String regulatoryAuthority) {
        this.regulatoryAuthority = regulatoryAuthority;
    }
}
