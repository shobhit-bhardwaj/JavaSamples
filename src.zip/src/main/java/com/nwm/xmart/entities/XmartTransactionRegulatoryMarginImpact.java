package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTransactionRegulatoryMarginImpact extends XmartEntity {
    private static final long serialVersionUID = -8931990992047474501L;

    @XmartAttribute
    private String regulatoryAuthority, marginType, payOrReceiveType;

    public XmartTransactionRegulatoryMarginImpact(Long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getRegulatoryAuthority() {
        return regulatoryAuthority;
    }

    public void setRegulatoryAuthority(String regulatoryAuthority) {
        this.regulatoryAuthority = regulatoryAuthority;
    }

    public String getMarginType() {
        return marginType;
    }

    public void setMarginType(String marginType) {
        this.marginType = marginType;
    }

    public String getPayOrReceiveType() {
        return payOrReceiveType;
    }

    public void setPayOrReceiveType(String payOrReceiveType) {
        this.payOrReceiveType = payOrReceiveType;
    }
}
