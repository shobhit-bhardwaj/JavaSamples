package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.CurrencyId;
import com.rbs.odc.access.domain.FXLeg;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartFxLegs extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartFxLeg> {

    private static final long serialVersionUID = 5586303707475799664L;
    private static final Logger logger = LoggerFactory.getLogger(XmartFxLegs.class);

    public XmartFxLegs(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        FXLeg fxLeg = transactionLeg.getFxLeg();
        if (isNull(fxLeg)) {
            // This is possible when LegType of this transactionLeg is not of type Fx_Leg
            return;
        }

        XmartFxLeg xmartFxLeg = new XmartFxLeg(getDocumentKey(), transactionLeg.getLegIdentifier());
        xmartFxLeg.setExchangeRateDate(convertBusinessDate(fxLeg.getExchangeRateDate()));
        xmartFxLeg.setLegType(getStr(fxLeg.getLegType()));
        xmartFxLeg.setVolatilitySwapModelBasis(getStr(fxLeg.getVolatilitySwapModelBasis()));
        xmartFxLeg.setForwardVolatilityBasis(getStr(fxLeg.getForwardVolatilityBasis()));
        xmartFxLeg.setForwardVolatility(fxLeg.getForwardVolatility());
        xmartFxLeg.setFirstDrawdownDate(convertBusinessDate(fxLeg.getFirstDrawdownDate()));
        CurrencyId fixedCurrencyId = fxLeg.getFixedCurrencyId();
        if (nonNull(fixedCurrencyId)) {
            xmartFxLeg.setFixedCurrencyIdCurrencyCode(fixedCurrencyId.getCurrencyCode());
        }
        xmartFxLeg.setForwardFixingDate(convertBusinessDate(fxLeg.getForwardFixingDate()));
        xmartFxLeg.setForwardFixingDateTime(fxLeg.getForwardFixingDateTime());
        xmartFxLeg.setInstrumentClass1(fxLeg.getInstrumentClass1());
        xmartFxLeg.setInstrumentClass2(fxLeg.getInstrumentClass2());
        xmartFxLeg.setFxLegSubType(getStr(fxLeg.getFxLegSubType()));
        xmartFxLeg.setMeanSubtractionApplies(fxLeg.isMeanSubtractionApplies());
        xmartFxLeg.setHistoricRollRateIndicator(fxLeg.isHistoricRollRateIndicator());

        addEntity(xmartFxLeg);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
