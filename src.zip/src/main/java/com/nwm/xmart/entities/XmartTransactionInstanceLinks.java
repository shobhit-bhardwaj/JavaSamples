package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionInstanceLink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartTransactionInstanceLinks
        extends XmartOdcEntityCollection<Transaction, TransactionInstanceLink, XmartTransactionInstanceLink> {
    private static final long serialVersionUID = 1188266415994762538L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionInstanceLinks.class);

    public XmartTransactionInstanceLinks(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionInstanceLink> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionInstanceLink(), logger,
                "TransactionInstanceLink not received for documentKey : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionInstanceLink transactionInstanceLink) throws XmartException {

        XmartTransactionInstanceLink entity = new XmartTransactionInstanceLink(getDocumentKey());
        entity.setLinkageReasonScheme(getStr(transactionInstanceLink.getLinkageReasonScheme()));
        entity.setLinkSourceSystemId(getStr(transactionInstanceLink.getLinkSourceSystemId()));
        entity.setLinkTransactionId(transactionInstanceLink.getLinkTransactionId());
        entity.setLinkTransactionLegId(transactionInstanceLink.getLinkTransactionLegId());
        entity.setLinkTransactionVersion(transactionInstanceLink.getLinkTransactionVersion());
        entity.setLinkTransactionInstance(transactionInstanceLink.getLinkTransactionInstance());
        entity.setTradeIdClassification(getStr(transactionInstanceLink.getTradeIdClassification()));
        addEntity(entity);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
