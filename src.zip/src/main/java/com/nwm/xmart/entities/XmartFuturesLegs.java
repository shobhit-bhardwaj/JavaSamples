package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

public class XmartFuturesLegs extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartFuturesLeg> {

    private static final Logger logger = LoggerFactory.getLogger(XmartFuturesLegs.class);
    private static final long serialVersionUID = -115321831840690570L;

    public XmartFuturesLegs(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "transaction legs not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        if (isNull(transactionLeg.getFuturesLeg())) {
            // This is possible when legType of this transactionLeg is not of type Futures_Leg
            return;
        }
        FuturesLeg futuresLeg = transactionLeg.getFuturesLeg();

        XmartFuturesLeg xmartFuturesLeg = new XmartFuturesLeg(getDocumentKey(), transactionLeg.getLegIdentifier());
        xmartFuturesLeg.setQuantityOfMeasure(futuresLeg.getQuantityOfMeasure());
        xmartFuturesLeg.setUpFrontPaymentApplicable(futuresLeg.isUpFrontPaymentApplicable());
        if (futuresLeg.getClosingPrice() != null) {
            ClosingPrice closingPrice = futuresLeg.getClosingPrice();
            xmartFuturesLeg.setClosingPricePercentage(closingPrice.getPercentage());
            xmartFuturesLeg.setType(getStr(closingPrice.getType()));
            xmartFuturesLeg.setClosingPricePrice(closingPrice.getPrice());
            xmartFuturesLeg.setClosingPriceCurrency(closingPrice.getCurrency());
            if (closingPrice.getAmount() != null) {
                Amount amount = closingPrice.getAmount();
                xmartFuturesLeg.setClosingPriceValue(amount.getValue());
                if (amount.getCurrencyId() != null) {
                    xmartFuturesLeg.setClosingPriceAmountCurrencyCode(amount.getCurrencyId().getCurrencyCode());
                }
            }
        }
        addEntity(xmartFuturesLeg);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
