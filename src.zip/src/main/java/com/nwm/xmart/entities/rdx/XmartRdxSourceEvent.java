package com.nwm.xmart.entities.rdx;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.temporal.ChronoField;

import static java.util.Objects.isNull;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartRdxSourceEvent extends XmartEntity {
    private static final Logger logger = LoggerFactory.getLogger(XmartRdxSourceEvent.class);

    private static final long serialVersionUID = 7845851523286650033L;
    long documentKey = 0;

    private RDXSourceEvent streamEvent;

    private int topicId = 0;
    private long changeId = 0;

    public XmartRdxSourceEvent(int topicId, RDXSourceEvent streamEvent) throws XmartException {

        super();

        if (isNull(streamEvent)) {
            throw new XmartException("NULL source record provided to XmartRdxSourceEvent.");
        }

        this.streamEvent = streamEvent;

        this.topicId = topicId;

        this.changeId = streamEvent.getChangeID();
        //      streamEvent.getRdxBond().getFacets().getInstrumentClassification().get(0).getBdlIndustrySubGroup()

        StringBuilder documentKeyString = new StringBuilder(19);
        String documentKeyComponent = null;

        LocalDateTime consumeTime = LocalDateTime.now();
        //        LocalDateTime consumeTime = LocalDateTime
        //                .ofInstant(Instant.ofEpochMilli(sourceTimestamp), ZoneId.systemDefault());

        documentKeyString.setLength(0);

        documentKeyComponent = String.format("%02d", consumeTime.get(ChronoField.YEAR));
        documentKeyString.insert(0, documentKeyComponent.substring(documentKeyComponent.length() - 2));

        documentKeyComponent = String.format("%03d", consumeTime.getDayOfYear());
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 3));

        documentKeyComponent = String.format("%03d", topicId);
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 3));

        documentKeyComponent = String.format("%011d", changeId);
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 11));

        documentKey = Long.parseLong(documentKeyString.toString());
    }

    public RDXSourceEvent getStreamEvent() {
        return streamEvent;
    }

    public int getTopicId() {
        return topicId;
    }

    public long getChangeId() {
        return changeId;
    }

    public long getDocumentKey() {
        return documentKey;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("XmartOdcTransactionSourceEvent [");
        builder.append(" topicId=\"").append(getTopicId()).append("\"");
        builder.append(" changeId=\"").append(getChangeId()).append("\"");
        builder.append(" documentKey=\"").append(getDocumentKey()).append("\"");
        builder.append("]");
        return builder.toString();
    }
}
