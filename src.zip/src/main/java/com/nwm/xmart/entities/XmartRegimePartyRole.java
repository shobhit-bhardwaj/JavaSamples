package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

/**
 * Created by aslammh on 17/11/17.
 */
public class XmartRegimePartyRole extends XmartEntity {

    private static final long serialVersionUID = -7211675037268241666L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regulatoryRegimeImpactId;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private Boolean regimeImpact;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regimeImpactId;

    @XmartAttribute(usedInJoin = true)
    private String reportingRoleScheme;

    @XmartAttribute
    private String tradingCapacity;

    @XmartAttribute
    private String partyClassification;

    @XmartAttribute
    private String partyReference;

    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String reportableTradingRole;

    public XmartRegimePartyRole(long documentKey) throws XmartException {
        super(documentKey);
    }

    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    public void setRegimeImpact(Boolean regimeImpact) {
        this.regimeImpact = regimeImpact;
    }

    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    public void setRegimeImpactId(String regimeImpactId) {
        this.regimeImpactId = regimeImpactId;
    }

    public String getReportingRoleScheme() {
        return reportingRoleScheme;
    }

    public void setReportingRoleScheme(String reportingRoleScheme) {
        this.reportingRoleScheme = reportingRoleScheme;
    }

    public String getTradingCapacity() {
        return tradingCapacity;
    }

    public void setTradingCapacity(String tradingCapacity) {
        this.tradingCapacity = tradingCapacity;
    }

    public String getPartyClassification() {
        return partyClassification;
    }

    public void setPartyClassification(String partyClassification) {
        this.partyClassification = partyClassification;
    }

    public String getPartyReference() {
        return partyReference;
    }

    public void setPartyReference(String partyReference) {
        this.partyReference = partyReference;
    }

    public String getReportableTradingRole() {
        return reportableTradingRole;
    }

    public void setReportableTradingRole(String reportableTradingRole) {
        this.reportableTradingRole = reportableTradingRole;
    }

    public String getRegulatoryRegimeImpactId() {
        return regulatoryRegimeImpactId;
    }

    public void setRegulatoryRegimeImpactId(String regulatoryRegimeImpactId) {
        this.regulatoryRegimeImpactId = regulatoryRegimeImpactId;
    }
}
