package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RegulatoryAuthority;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartRegulatoryAuthorities
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartRegulatoryAuthority> {
    private static final long serialVersionUID = -48751181944685116L;
    private static final Logger logger = LoggerFactory.getLogger(XmartRegulatoryAuthorities.class);

    public XmartRegulatoryAuthorities(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpact NOT received for documentkey : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {

        for (RegulatoryAuthority regulatoryAuthority : nullCollToEmpty(
                regulatoryRegimeImpact.getRegulatoryAuthorities())) {
            XmartRegulatoryAuthority xmartRegulatoryAuthority = new XmartRegulatoryAuthority(getDocumentKey());
            xmartRegulatoryAuthority.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartRegulatoryAuthority.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartRegulatoryAuthority.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());

            if (nonNull(regulatoryAuthority)) {
                xmartRegulatoryAuthority.setRegulatoryAuthority(getStr(regulatoryAuthority.getRegulatoryAuthority()));
            }
            addEntity(xmartRegulatoryAuthority);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
