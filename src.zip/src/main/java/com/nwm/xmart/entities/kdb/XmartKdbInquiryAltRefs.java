package com.nwm.xmart.entities.kdb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Simple class that holds a list of KDB Inquiry Legs
 *
 * @author heskets
 */
public class XmartKdbInquiryAltRefs implements Serializable {

    private ArrayList<XmartKdbInquiryAltRef> inquiryAltRefs = new ArrayList<>();

    public XmartKdbInquiryAltRefs() {
    }

    public void addInquiryAltRef(XmartKdbInquiryAltRef newInquiryAltRef) {
        inquiryAltRefs.add(newInquiryAltRef);
    }

    public Collection<XmartKdbInquiryAltRef> getInquiryAltRefs() {
        return inquiryAltRefs;
    }
}
