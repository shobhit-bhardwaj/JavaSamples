package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import com.rbs.odc.access.domain.TransactionLegCurve;
import com.rbs.odc.core.domain.TransactionLegCurveImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartTransactionLegCurves
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartTransactionLegCurve> {
    private static final long serialVersionUID = 3132163566520928936L;

    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionLegCurves.class);

    public XmartTransactionLegCurves(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "TransactionLegs not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        for (TransactionLegCurve transactionLegCurve : nullCollToEmpty(transactionLeg.getTransactionLegCurves())) {
            if (isNull(transactionLegCurve)) {
                continue;
            }

            XmartTransactionLegCurve xmarttransactionLegCurve = new XmartTransactionLegCurve(getDocumentKey(),
                    transactionLeg.getLegIdentifier());

            if (nonNull(transactionLegCurve.getCurve())) {
                xmarttransactionLegCurve.setCurveId(transactionLegCurve.getCurve().getCurveId());
                xmarttransactionLegCurve.setCurveSystemId(getStr(transactionLegCurve.getCurve().getCurveSystemId()));
            }

            xmarttransactionLegCurve
                    .setCurveCurrencyIdCurrencyCode(getCurrencyCode(transactionLegCurve.getCurveCurrencyId()));
            xmarttransactionLegCurve.setCurveRole(getStr(transactionLegCurve.getCurveRole()));
            xmarttransactionLegCurve.setCurveCcyIdCurrencyCode(
                    getCurrencyCode(((TransactionLegCurveImpl) transactionLegCurve).getCurveCcyId()));
            xmarttransactionLegCurve.setProjectionType(transactionLegCurve.getProjectionType());
            xmarttransactionLegCurve.setCurveOverrideReason(transactionLegCurve.getCurveOverrideReason());
            xmarttransactionLegCurve.setCurveOverrideApprover(transactionLegCurve.getCurveOverrideApprover());
            xmarttransactionLegCurve
                    .setCurveOverrideApprovalDateTime(transactionLegCurve.getCurveOverrideApprovalDateTime());
            xmarttransactionLegCurve
                    .setCurveOverrideApprovalComments(transactionLegCurve.getCurveOverrideApprovalComments());
            xmarttransactionLegCurve.setCurveName(transactionLegCurve.getCurveName());
            xmarttransactionLegCurve
                    .setCurveOverrideApprovalDate(transactionLegCurve.getCurveOverrideApprovalDateTime());

            addEntity(xmarttransactionLegCurve);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
