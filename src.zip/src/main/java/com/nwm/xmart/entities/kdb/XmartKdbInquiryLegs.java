package com.nwm.xmart.entities.kdb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Simple class that holds a list of KDB Inquiry Legs
 *
 * @author heskets
 */
public class XmartKdbInquiryLegs implements Serializable {

    private ArrayList<XmartKdbInquiryLeg> inquiryLegs = new ArrayList<>();

    public XmartKdbInquiryLegs() {
    }

    public void addInquiryLeg(XmartKdbInquiryLeg newInquiryLeg) {
        inquiryLegs.add(newInquiryLeg);
    }

    public Collection getInquiryLegs() {
        return inquiryLegs;
    }
}
