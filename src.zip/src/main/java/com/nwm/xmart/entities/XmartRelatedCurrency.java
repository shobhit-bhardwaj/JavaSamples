package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartRelatedCurrency extends XmartEntity {

    private static final long serialVersionUID = 1404217610964644510L;

    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private Boolean isNotDomesticCurrency;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String obligationScheme;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String relatedCurrenciesCurrencyCode;

    public XmartRelatedCurrency(long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public Boolean getNotDomesticCurrency() {
        return isNotDomesticCurrency;
    }

    public void setNotDomesticCurrency(Boolean notDomesticCurrency) {
        isNotDomesticCurrency = notDomesticCurrency;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getObligationScheme() {
        return obligationScheme;
    }

    public void setObligationScheme(String obligationScheme) {
        this.obligationScheme = obligationScheme;
    }

    public String getRelatedCurrenciesCurrencyCode() {
        return relatedCurrenciesCurrencyCode;
    }

    public void setRelatedCurrenciesCurrencyCode(String relatedCurrenciesCurrencyCode) {
        this.relatedCurrenciesCurrencyCode = relatedCurrenciesCurrencyCode;
    }
}
