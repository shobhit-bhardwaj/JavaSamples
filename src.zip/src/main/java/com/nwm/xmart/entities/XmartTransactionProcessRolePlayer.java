package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTransactionProcessRolePlayer extends XmartEntity {
    private static final long serialVersionUID = 191832058954768569L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String processDirectiveType;
    @XmartAttribute
    private String processRolePlayerType, status, additionalComments, employeeIdentifier, employeeSourceSystemId,
            personIdScheme;

    protected XmartTransactionProcessRolePlayer(long documentKey, String processDirectiveType) throws XmartException {
        super(documentKey);
        this.processDirectiveType = processDirectiveType;
    }

    public String getProcessDirectiveType() {
        return processDirectiveType;
    }

    public String getProcessRolePlayerType() {
        return processRolePlayerType;
    }

    public void setProcessRolePlayerType(String processRolePlayerType) {
        this.processRolePlayerType = processRolePlayerType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public String getEmployeeIdentifier() {
        return employeeIdentifier;
    }

    public void setEmployeeIdentifier(String employeeIdentifier) {
        this.employeeIdentifier = employeeIdentifier;
    }

    public String getEmployeeSourceSystemId() {
        return employeeSourceSystemId;
    }

    public void setEmployeeSourceSystemId(String employeeSourceSystemId) {
        this.employeeSourceSystemId = employeeSourceSystemId;
    }

    public String getPersonIdScheme() {
        return personIdScheme;
    }

    public void setPersonIdScheme(String personIdScheme) {
        this.personIdScheme = personIdScheme;
    }
}
