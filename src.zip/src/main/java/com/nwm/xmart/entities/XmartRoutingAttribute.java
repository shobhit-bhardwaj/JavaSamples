package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartRoutingAttribute extends XmartEntity {
    private static final long serialVersionUID = -6704225655595049349L;

    @XmartAttribute
    private String routingAttributesId;

    @XmartAttribute
    private String routingAttributesName;

    @XmartAttribute
    private String routingAttributesValue;

    public XmartRoutingAttribute(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getRoutingAttributesId() {
        return routingAttributesId;
    }

    public void setRoutingAttributesId(String routingAttributesId) {
        this.routingAttributesId = routingAttributesId;
    }

    public String getRoutingAttributesName() {
        return routingAttributesName;
    }

    public void setRoutingAttributesName(String routingAttributesName) {
        this.routingAttributesName = routingAttributesName;
    }

    public String getRoutingAttributesValue() {
        return routingAttributesValue;
    }

    public void setRoutingAttributesValue(String routingAttributesValue) {
        this.routingAttributesValue = routingAttributesValue;
    }
}
