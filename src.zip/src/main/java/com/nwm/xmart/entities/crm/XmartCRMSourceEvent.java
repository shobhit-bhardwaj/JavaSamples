package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.XmartOdcEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;

public class XmartCRMSourceEvent extends XmartOdcEntity {
    private static final long serialVersionUID = -3162394878181542618L;
    private CRMSourceEvent streamEvent;

    /**
     * Create object for {@link XmartCRMSourceEvent}
     *
     * @param streamEvent {@link CRMSourceEvent} containing the CRMSourceEvent we are interested in.
     * @param topicId     The Kafka topic of the CRM topic, used in the document key.
     *
     * @throws XmartException When things seem to go south.
     */
    public XmartCRMSourceEvent(CRMSourceEvent streamEvent, int topicId) throws XmartException {
        super(generateDocumentKey(streamEvent.getPartitionId(), topicId, streamEvent.getOffset(),
                streamEvent.getTimeStamp()));
        this.streamEvent = streamEvent;
    }

    /**
     * Get the {@link CRMSourceEvent} retrieved from the stream event.
     *
     * @return streamEvent
     */
    public CRMSourceEvent getStreamEvent() {
        return streamEvent;
    }
}
