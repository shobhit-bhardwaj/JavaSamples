package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartFuturesLeg extends XmartEntity {

    private static final long serialVersionUID = -2643623509554089380L;
    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute
    private String closingPriceAmountCurrencyCode;
    @XmartAttribute
    private BigDecimal closingPriceValue;
    @XmartAttribute
    private BigDecimal closingPricePercentage;
    @XmartAttribute
    private String type;
    @XmartAttribute
    private BigDecimal closingPricePrice;
    @XmartAttribute
    private String closingPriceCurrency;
    @XmartAttribute
    private BigDecimal quantityOfMeasure;
    @XmartAttribute
    private Boolean upFrontPaymentApplicable;

    public XmartFuturesLeg(Long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getClosingPriceAmountCurrencyCode() {
        return closingPriceAmountCurrencyCode;
    }

    public void setClosingPriceAmountCurrencyCode(String closingPriceAmountCurrencyCode) {
        this.closingPriceAmountCurrencyCode = closingPriceAmountCurrencyCode;
    }

    public BigDecimal getClosingPriceValue() {
        return closingPriceValue;
    }

    public void setClosingPriceValue(BigDecimal closingPriceValue) {
        this.closingPriceValue = closingPriceValue;
    }

    public BigDecimal getClosingPricePercentage() {
        return closingPricePercentage;
    }

    public void setClosingPricePercentage(BigDecimal closingPricePercentage) {
        this.closingPricePercentage = closingPricePercentage;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getClosingPricePrice() {
        return closingPricePrice;
    }

    public void setClosingPricePrice(BigDecimal closingPricePrice) {
        this.closingPricePrice = closingPricePrice;
    }

    public String getClosingPriceCurrency() {
        return closingPriceCurrency;
    }

    public void setClosingPriceCurrency(String closingPriceCurrency) {
        this.closingPriceCurrency = closingPriceCurrency;
    }

    public BigDecimal getQuantityOfMeasure() {
        return quantityOfMeasure;
    }

    public void setQuantityOfMeasure(BigDecimal quantityOfMeasure) {
        this.quantityOfMeasure = quantityOfMeasure;
    }

    public Boolean getUpFrontPaymentApplicable() {
        return upFrontPaymentApplicable;
    }

    public void setUpFrontPaymentApplicable(Boolean upFrontPaymentApplicable) {
        this.upFrontPaymentApplicable = upFrontPaymentApplicable;
    }
}
