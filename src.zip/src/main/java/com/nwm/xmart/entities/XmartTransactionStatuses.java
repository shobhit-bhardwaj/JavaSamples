package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;

/**
 * Created by aslammh on 16/11/17.
 */
public class XmartTransactionStatuses
        extends XmartOdcEntityCollection<Transaction, TransactionStatus, XmartTransactionStatus> {

    private static final long serialVersionUID = 5361107420089656709L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionStatuses.class);

    public XmartTransactionStatuses(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionStatus> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionStatus(), logger,
                "No TransactionStatus received for documentKey : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionStatus transactionStatus) throws XmartException {
        XmartTransactionStatus xmartTransactionStatus = new XmartTransactionStatus(getDocumentKey());
        xmartTransactionStatus.setTransactionState(getStr(transactionStatus.getTransactionState()));
        xmartTransactionStatus
                .setTransactionStateEffectiveDate(convertBusinessDate(transactionStatus.getEffectiveDate()));
        xmartTransactionStatus.setTransactionStateEffectiveDateTime(transactionStatus.getEffectiveDateTime());
        xmartTransactionStatus.setTransactionStateSystemId(getStr(transactionStatus.getTransactionStateSystemId()));
        xmartTransactionStatus.setTransactionStateScheme(getStr(transactionStatus.getTransactionStateScheme()));
        addEntity(xmartTransactionStatus);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}


