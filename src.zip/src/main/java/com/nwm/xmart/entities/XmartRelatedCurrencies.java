package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.CreditDerivativeLeg;
import com.rbs.odc.access.domain.RelatedCurrency;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartRelatedCurrencies
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartRelatedCurrency> {

    private static final Logger logger = LoggerFactory.getLogger(XmartRelatedCurrencies.class);
    private static final long serialVersionUID = -6987074549197008626L;

    public XmartRelatedCurrencies(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        CreditDerivativeLeg creditDerivativeLeg = transactionLeg.getCreditDerivativeLeg();
        if (nonNull(creditDerivativeLeg)) {
            for (RelatedCurrency relatedCurrency : nullCollToEmpty(creditDerivativeLeg.getRelatedCurrencies())) {

                if (isNull(relatedCurrency)) {
                    continue;
                }

                if (isNull(transactionLeg.getLegIdentifier())) {
                    logger.warn("Transaction leg identifier not received for document key " + getDocumentKey());
                }

                XmartRelatedCurrency xmartRelatedCurrency = new XmartRelatedCurrency(getDocumentKey(),
                        transactionLeg.getLegIdentifier());
                xmartRelatedCurrency.setNotDomesticCurrency(relatedCurrency.getNotDomesticCurrency());
                xmartRelatedCurrency.setObligationScheme(getStr(relatedCurrency.getObligationScheme()));
                xmartRelatedCurrency.setRelatedCurrenciesCurrencyCode(getCurrencyCode(relatedCurrency.getCurrencyId()));

                addEntity(xmartRelatedCurrency);
            }
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
