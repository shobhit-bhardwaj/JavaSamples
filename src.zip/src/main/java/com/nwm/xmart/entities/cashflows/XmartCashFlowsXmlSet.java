package com.nwm.xmart.entities.cashflows;

import com.nwm.xmart.core.XmartXmlSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;

import static com.nwm.xmart.util.XmlUtil.getXmlDocument;

public class XmartCashFlowsXmlSet extends XmartGenericXmlSet {

    private static final long serialVersionUID = -7929053845692252812L;

    private StringBuilder xmartCashFlowsXml = new StringBuilder();

    public XmartCashFlowsXmlSet(Boolean logXML) {
        super(logXML);
    }

    public String getXmartCashFlowsXml() {
        return getXmlDocument("XmartCashFlows", xmartCashFlowsXml.toString(), logXML);
    }

    public void add(XmartCashFlowsSet xmartSet) {
        xmartCashFlowsXml.append(xmartSet.getXmartCashFlows());
    }
}
