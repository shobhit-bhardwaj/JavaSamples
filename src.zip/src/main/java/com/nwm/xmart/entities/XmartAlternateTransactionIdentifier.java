package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

/**
 * Created by aslammh on 13/11/17.
 */
public class XmartAlternateTransactionIdentifier extends XmartEntity {

    private static final long serialVersionUID = -8596518543098260230L;

    @XmartAttribute
    private String alternateIdDescription, alternateIdSourceSystemId, alternateTransactionId;

    public XmartAlternateTransactionIdentifier(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getAlternateIdDescription() {
        return alternateIdDescription;
    }

    public void setAlternateIdDescription(String alternateIdDescription) {
        this.alternateIdDescription = alternateIdDescription;
    }

    public String getAlternateIdSourceSystemId() {
        return alternateIdSourceSystemId;
    }

    public void setAlternateIdSourceSystemId(String alternateIdSourceSystemId) {
        this.alternateIdSourceSystemId = alternateIdSourceSystemId;
    }

    public String getAlternateTransactionId() {
        return alternateTransactionId;
    }

    public void setAlternateTransactionId(String alternateTransactionId) {
        this.alternateTransactionId = alternateTransactionId;
    }
}
