package com.nwm.xmart.entities.rdx;

import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;

/**
 * Created by aslammh on 04/08/17.
 */
public class RdxInstrumentTestSource extends RichParallelSourceFunction<RDXSourceEvent> {

    private volatile boolean isRunning = true;

    //@Override
    public void run(SourceContext<RDXSourceEvent> sourceContext) throws Exception {
        // Create the listener to get the event.
        int recordCount = 3666983;

        RDXSourceEvent event;
        RdxEventBuilder rdxEventBuilder = new RdxEventBuilder();

        while (isRunning) {

            // keep processing until we get direction to stop. i.e until cancel is not called.
            //            Thread.sleep(100);

            event = rdxEventBuilder.getRdxInstrumentStreamEvent(recordCount);

            sourceContext.collect(event);

            recordCount++;
        }
    }

    //@Override
    public void cancel() {
        isRunning = false;
    }
}
