package com.nwm.xmart.entities.file;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.source.file.event.FileEvent;
import com.nwm.xmart.util.CollectionsUtil;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class XmartFileEventSet extends XmartGenericSet<FileEvent> {
    private static final long serialVersionUID = -2957788404037807712L;

    private XmartFileEvent xmartFileEvent;

    public XmartFileEventSet() {
        // Nothing in default constructor
    }

    @Override
    public void addStreamEvent(FileEvent streamEvent, int jobId, MappingNode mappingHierarchy) throws XmartException {
        this.xmartFileEvent = new XmartFileEvent(jobId, streamEvent);
        xmartMappedEntities
                .addAll(mappingHierarchy.mapSourceObject(streamEvent.getEventType().toString(), xmartFileEvent, null));
    }

    @Override
    public Long getWindowKey() {
        return xmartFileEvent.getDocumentKey();
    }

    public Long getDocumentKey() {
        return xmartFileEvent.getDocumentKey();
    }

    public List<XmartMappedEntity> getXmartMappedEntities() {
        return xmartMappedEntities;
    }

    public Collection<XmartMappedEntity> getRequiredEntities(String requiredEntityCollectionName) {
        return xmartMappedEntities.stream().filter(child -> child.isMatchingXmlEntity(requiredEntityCollectionName))
                                  .collect(Collectors.toList());
    }

    public String getXmlEntities(String requiredEntityCollectionName) {
        Collection<XmartMappedEntity> requiredEntities = getRequiredEntities(requiredEntityCollectionName);

        if (CollectionsUtil.isEmptyOrNull(requiredEntities)) {
            return null;
        }

        StringBuilder builder = new StringBuilder();

        for (XmartMappedEntity entity : requiredEntities) {
            builder.append(entity.toString());
        }
        return builder.toString();
    }
}
