package com.nwm.xmart.entities.common;

import com.nwm.xmart.core.BindObject;
import org.slf4j.Logger;

public interface IXmartEntityCollection extends BindObject {
    long getDocumentKey();

    /**
     * Gets the logger to write for the class. The returned logger will be used to log the XML when required to print the xml while logging,
     * iff it is to be printed here, else the calling method of the class will call the logging
     *
     * @return Logger from the implementing child class
     */
    Logger getLogger();
}
