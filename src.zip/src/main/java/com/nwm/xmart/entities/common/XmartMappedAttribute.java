package com.nwm.xmart.entities.common;

import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;

import static com.nwm.xmart.util.XmlUtil.getXmlAttribute;

/**
 * Created by aslammh on 01/12/17.
 */
public final class XmartMappedAttribute implements BindObject {

    private static final long serialVersionUID = 1487139785036974960L;

    private final String attributeName;
    private final Object attribute;
    private final Boolean mandatoryAttribute;
    private final Boolean triggerAttribute;
    private final Boolean keyAttribute;
    private final Boolean outputAttribute;

    private XmartMappedAttribute() {

        // no default constructure

        this.attributeName = null;
        this.attribute = null;
        this.mandatoryAttribute = false;
        this.triggerAttribute = false;
        this.keyAttribute = false;
        this.outputAttribute = false;
    }

    public XmartMappedAttribute(XmartMappedAttribute attribute) {

        this.attributeName = attribute.getAttributeName();
        this.attribute = attribute.getAttributeValue();
        this.mandatoryAttribute = attribute.isMandatory();
        this.triggerAttribute = attribute.isTrigger();
        this.keyAttribute = attribute.isUsedInKey();
        this.outputAttribute = attribute.isOutput();
    }

    public XmartMappedAttribute(String attributeName, Object attribute, Boolean mandatoryAttribute,
            Boolean triggerAttribute, Boolean outputAttribute, Boolean keyAttribute) throws XmartException {

        this.attributeName = attributeName;

        if (attribute == null) {
            throw new XmartException("Null attribute should not be added to list.");
        }

        this.attribute = attribute;
        this.mandatoryAttribute = mandatoryAttribute;
        this.triggerAttribute = triggerAttribute;
        this.keyAttribute = keyAttribute;
        this.outputAttribute = outputAttribute;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public Object getAttributeValue() {
        return attribute;
    }

    private Class getAttributeClass() {
        if (attribute != null) {
            return attribute.getClass();
        } else {
            return null;
        }
    }

    public Boolean isMandatory() {
        return mandatoryAttribute;
    }

    public Boolean isTrigger() {
        return triggerAttribute;
    }

    public Boolean isOutput() {
        return outputAttribute;
    }

    public Boolean isUsedInKey() {
        return keyAttribute;
    }

    public String toString() {
        return getXmlAttribute(attributeName, getAttributeClass(), attribute);
    }
}
