package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartBookCounterparty extends XmartEntity {

    private static final long serialVersionUID = -4930451328502386922L;

    @XmartAttribute
    private String transactionRoleScheme;
    @XmartAttribute
    private String sourceSystemBookId;
    @XmartAttribute
    private String bookSourceSystemId;

    public XmartBookCounterparty(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getTransactionRoleScheme() {
        return transactionRoleScheme;
    }

    public void setTransactionRoleScheme(String transactionRoleScheme) {
        this.transactionRoleScheme = transactionRoleScheme;
    }

    public String getSourceSystemBookId() {
        return sourceSystemBookId;
    }

    public void setSourceSystemBookId(String sourceSystemBookId) {
        this.sourceSystemBookId = sourceSystemBookId;
    }

    public String getBookSourceSystemId() {
        return bookSourceSystemId;
    }

    public void setBookSourceSystemId(String bookSourceSystemId) {
        this.bookSourceSystemId = bookSourceSystemId;
    }
}
