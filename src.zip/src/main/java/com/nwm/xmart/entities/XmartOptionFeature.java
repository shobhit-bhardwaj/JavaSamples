package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

public class XmartOptionFeature extends XmartEntity {

    private static final long serialVersionUID = -8716549554944971414L;
    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute
    private Boolean deltaExchangeApplicable;
    @XmartAttribute
    private Boolean optionStraddle;
    @XmartAttribute
    private Boolean fallbackExercise;
    @XmartAttribute
    private Boolean followUpConfirmation;
    @XmartAttribute
    private Date earliestExerciseTime;
    @XmartAttribute
    private Date expiryTime;
    @XmartAttribute
    private BigDecimal optionEntitlement;
    @XmartAttribute
    private BigDecimal premiumPercentage;
    @XmartAttribute
    private BigDecimal rebateAmountValue;
    @XmartAttribute
    private BigDecimal strikePercentage;
    @XmartAttribute
    private BigDecimal strikePrice;
    @XmartAttribute
    private BigDecimal strikeSpread;
    @XmartAttribute
    private Integer periodMultiplier;
    @XmartAttribute
    private String optionExerciseStyle;
    @XmartAttribute
    private String optionType;
    @XmartAttribute
    private String optionEarliestExerciseTimeCentre;
    @XmartAttribute
    private String latestExerciseTimeCentre;
    @XmartAttribute
    private String optionExpiryTimeCentre;
    @XmartAttribute
    private String periodScheme;
    @XmartAttribute
    private String americanTouchCondition;
    @XmartAttribute
    private String europeanTriggerCondition;
    @XmartAttribute
    private String deliveryStyle;
    @XmartAttribute
    private String premiumQuoteBasis;
    @XmartAttribute
    private String rebateAmountCurrencyCode;
    @XmartAttribute
    private String strikePriceCurrencyCode;
    @XmartAttribute
    private String strikeQuoteBasis;
    @XmartAttribute
    private String optionalEarlyTerminationCalculationAgent;
    //FROBI-7296, Flink can't handle LocalTime so using String
    @XmartAttribute
    private String optionEarliestExerciseTimeTime;
    //FROBI-7296, Flink can't handle LocalTime so using String
    @XmartAttribute
    private String latestExerciseTimeTime;
    //FROBI-7296, Flink can't handle LocalTime so using String
    @XmartAttribute
    private String optionExpiryTimeTime;
    @XmartAttribute
    private Date calledDate, firstCallableDate, finalMaturityDate;

    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private Date earliestExerciseDate;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private Date expiryDate;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String calculationAgent;

    public XmartOptionFeature(long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public Boolean getDeltaExchangeApplicable() {
        return deltaExchangeApplicable;
    }

    public void setDeltaExchangeApplicable(Boolean deltaExchangeApplicable) {
        this.deltaExchangeApplicable = deltaExchangeApplicable;
    }

    public Boolean getOptionStraddle() {
        return optionStraddle;
    }

    public void setOptionStraddle(Boolean optionStraddle) {
        this.optionStraddle = optionStraddle;
    }

    public Boolean getFallbackExercise() {
        return fallbackExercise;
    }

    public void setFallbackExercise(Boolean fallbackExercise) {
        this.fallbackExercise = fallbackExercise;
    }

    public Boolean getFollowUpConfirmation() {
        return followUpConfirmation;
    }

    public void setFollowUpConfirmation(Boolean followUpConfirmation) {
        this.followUpConfirmation = followUpConfirmation;
    }

    public Date getEarliestExerciseTime() {
        return earliestExerciseTime;
    }

    public void setEarliestExerciseTime(Date earliestExerciseTime) {
        this.earliestExerciseTime = earliestExerciseTime;
    }

    public Date getExpiryTime() {
        return expiryTime;
    }

    public void setExpiryTime(Date expiryTime) {
        this.expiryTime = expiryTime;
    }

    public BigDecimal getOptionEntitlement() {
        return optionEntitlement;
    }

    public void setOptionEntitlement(BigDecimal optionEntitlement) {
        this.optionEntitlement = optionEntitlement;
    }

    public BigDecimal getPremiumPercentage() {
        return premiumPercentage;
    }

    public void setPremiumPercentage(BigDecimal premiumPercentage) {
        this.premiumPercentage = premiumPercentage;
    }

    public BigDecimal getRebateAmountValue() {
        return rebateAmountValue;
    }

    public void setRebateAmountValue(BigDecimal rebateAmountValue) {
        this.rebateAmountValue = rebateAmountValue;
    }

    public BigDecimal getStrikePercentage() {
        return strikePercentage;
    }

    public void setStrikePercentage(BigDecimal strikePercentage) {
        this.strikePercentage = strikePercentage;
    }

    public BigDecimal getStrikePrice() {
        return strikePrice;
    }

    public void setStrikePrice(BigDecimal strikePrice) {
        this.strikePrice = strikePrice;
    }

    public BigDecimal getStrikeSpread() {
        return strikeSpread;
    }

    public void setStrikeSpread(BigDecimal strikeSpread) {
        this.strikeSpread = strikeSpread;
    }

    public Integer getPeriodMultiplier() {
        return periodMultiplier;
    }

    public void setPeriodMultiplier(Integer periodMultiplier) {
        this.periodMultiplier = periodMultiplier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getOptionExerciseStyle() {
        return optionExerciseStyle;
    }

    public void setOptionExerciseStyle(String optionExerciseStyle) {
        this.optionExerciseStyle = optionExerciseStyle;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public String getOptionEarliestExerciseTimeCentre() {
        return optionEarliestExerciseTimeCentre;
    }

    public void setOptionEarliestExerciseTimeCentre(String optionEarliestExerciseTimeCentre) {
        this.optionEarliestExerciseTimeCentre = optionEarliestExerciseTimeCentre;
    }

    public String getLatestExerciseTimeCentre() {
        return latestExerciseTimeCentre;
    }

    public void setLatestExerciseTimeCentre(String latestExerciseTimeCentre) {
        this.latestExerciseTimeCentre = latestExerciseTimeCentre;
    }

    public String getOptionExpiryTimeCentre() {
        return optionExpiryTimeCentre;
    }

    public void setOptionExpiryTimeCentre(String optionExpiryTimeCentre) {
        this.optionExpiryTimeCentre = optionExpiryTimeCentre;
    }

    public String getPeriodScheme() {
        return periodScheme;
    }

    public void setPeriodScheme(String periodScheme) {
        this.periodScheme = periodScheme;
    }

    public String getAmericanTouchCondition() {
        return americanTouchCondition;
    }

    public void setAmericanTouchCondition(String americanTouchCondition) {
        this.americanTouchCondition = americanTouchCondition;
    }

    public String getEuropeanTriggerCondition() {
        return europeanTriggerCondition;
    }

    public void setEuropeanTriggerCondition(String europeanTriggerCondition) {
        this.europeanTriggerCondition = europeanTriggerCondition;
    }

    public String getDeliveryStyle() {
        return deliveryStyle;
    }

    public void setDeliveryStyle(String deliveryStyle) {
        this.deliveryStyle = deliveryStyle;
    }

    public String getPremiumQuoteBasis() {
        return premiumQuoteBasis;
    }

    public void setPremiumQuoteBasis(String premiumQuoteBasis) {
        this.premiumQuoteBasis = premiumQuoteBasis;
    }

    public String getRebateAmountCurrencyCode() {
        return rebateAmountCurrencyCode;
    }

    public void setRebateAmountCurrencyCode(String rebateAmountCurrencyCode) {
        this.rebateAmountCurrencyCode = rebateAmountCurrencyCode;
    }

    public String getStrikePriceCurrencyCode() {
        return strikePriceCurrencyCode;
    }

    public void setStrikePriceCurrencyCode(String strikePriceCurrencyCode) {
        this.strikePriceCurrencyCode = strikePriceCurrencyCode;
    }

    public String getStrikeQuoteBasis() {
        return strikeQuoteBasis;
    }

    public void setStrikeQuoteBasis(String strikeQuoteBasis) {
        this.strikeQuoteBasis = strikeQuoteBasis;
    }

    public String getCalculationAgent() {
        return calculationAgent;
    }

    public void setCalculationAgent(String calculationAgent) {
        this.calculationAgent = calculationAgent;
    }

    public String getOptionEarliestExerciseTimeTime() {
        return optionEarliestExerciseTimeTime;
    }

    public void setOptionEarliestExerciseTimeTime(String optionEarliestExerciseTimeTime) {
        this.optionEarliestExerciseTimeTime = optionEarliestExerciseTimeTime;
    }

    public String getLatestExerciseTimeTime() {
        return latestExerciseTimeTime;
    }

    public void setLatestExerciseTimeTime(String latestExerciseTimeTime) {
        this.latestExerciseTimeTime = latestExerciseTimeTime;
    }

    public String getOptionExpiryTimeTime() {
        return optionExpiryTimeTime;
    }

    public void setOptionExpiryTimeTime(String optionExpiryTimeTime) {
        this.optionExpiryTimeTime = optionExpiryTimeTime;
    }

    public Date getEarliestExerciseDate() {
        return earliestExerciseDate;
    }

    public void setEarliestExerciseDate(Date earliestExerciseDate) {
        this.earliestExerciseDate = earliestExerciseDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getOptionalEarlyTerminationCalculationAgent() {
        return optionalEarlyTerminationCalculationAgent;
    }

    public void setOptionalEarlyTerminationCalculationAgent(String optionalEarlyTerminationCalculationAgent) {
        this.optionalEarlyTerminationCalculationAgent = optionalEarlyTerminationCalculationAgent;
    }

    public Date getCalledDate() {
        return calledDate;
    }

    public void setCalledDate(Date calledDate) {
        this.calledDate = calledDate;
    }

    public Date getFirstCallableDate() {
        return firstCallableDate;
    }

    public void setFirstCallableDate(Date firstCallableDate) {
        this.firstCallableDate = firstCallableDate;
    }

    public Date getFinalMaturityDate() {
        return finalMaturityDate;
    }

    public void setFinalMaturityDate(Date finalMaturityDate) {
        this.finalMaturityDate = finalMaturityDate;
    }
}
