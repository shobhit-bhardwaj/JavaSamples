package com.nwm.xmart.entities.kdb;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Simple class that holds a single KDB INquiry State
 *
 * @author heskets
 */
public class XmartKdbInquiryHeader implements Serializable {

    private final String micCode;
    private final String traderCode;
    private final String counterpartyId;
    private final String salesPersonCode;
    private final String rbsEntityCode;
    private final String quotePriceType;

    public XmartKdbInquiryHeader(String micCode, String traderCode, String salesPersonCode, String counterpartyId,
            String rbsEntityCode, String quotePriceType) {
        this.micCode = micCode;
        this.traderCode = traderCode;
        this.salesPersonCode = salesPersonCode;
        this.counterpartyId = counterpartyId;
        this.rbsEntityCode = rbsEntityCode;
        this.quotePriceType = quotePriceType;
    }

    public String getMicCode() {
        return micCode;
    }

    public String getTraderCode() {
        return traderCode;
    }

    public String getSalesPersonCode() {
        return salesPersonCode;
    }

    public String getCounterpartyId() {
        return counterpartyId;
    }

    public String getRbsEntityCode() {
        return rbsEntityCode;
    }

    public String getQuotePriceType() {
        return quotePriceType;
    }
}
