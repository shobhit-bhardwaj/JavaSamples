package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

public class XmartCreditDerivativeLegs
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartCreditDerivativeLeg> {
    private static final long serialVersionUID = 2309937500041537911L;
    private static final Logger logger = LoggerFactory.getLogger(XmartCreditDerivativeLegs.class);

    public XmartCreditDerivativeLegs(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return CollectionsUtil.nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        addCreditDerivativeLegs(transactionLeg.getLegIdentifier(), transactionLeg.getCreditDerivativeLeg());
    }

    private void addCreditDerivativeLegs(String legIdentifier, CreditDerivativeLeg creditDerivativeLeg)
            throws XmartException {
        if (isNull(creditDerivativeLeg)) {
            // This is possible when legType of this transactionLeg is not of type Credit_Derivative_leg
            return;
        }

        XmartCreditDerivativeLeg xmartCreditDerivativeLeg = new XmartCreditDerivativeLeg(getDocumentKey(),
                legIdentifier);
        xmartCreditDerivativeLeg.setAllGuarantees(creditDerivativeLeg.isAllGuarantees());
        xmartCreditDerivativeLeg.setBankruptcyApp(creditDerivativeLeg.isBankruptcyApplicable());
        xmartCreditDerivativeLeg.setFixedSettlement(creditDerivativeLeg.getFixedSettlement());
        xmartCreditDerivativeLeg.setFailureToPayApp(creditDerivativeLeg.isFailureToPayApplicable());
        xmartCreditDerivativeLeg.setFixedSettlement(creditDerivativeLeg.getFixedSettlement());
        xmartCreditDerivativeLeg.setGovernmentalInterventionApp(creditDerivativeLeg.isGovernmentalInterventionApp());
        xmartCreditDerivativeLeg.setGracePeriodDayType(getStr(creditDerivativeLeg.getGracePeriodDayType()));
        xmartCreditDerivativeLeg.setGracePeriodMultiplier(creditDerivativeLeg.getGracePeriodMultiplier());
        xmartCreditDerivativeLeg.setGracePeriodScheme(getStr(creditDerivativeLeg.getGracePeriodScheme()));
        //TODO FROBI-7260 Type in mapping sheet is Booleanbut String in CreditDerivativeLeg. assuming String
        xmartCreditDerivativeLeg.setInterestShortFallCapApp(creditDerivativeLeg.getInterestShortFallCapApp());
        xmartCreditDerivativeLeg.setInterestShortFallComp(creditDerivativeLeg.getInterestShortFallComp());
        xmartCreditDerivativeLeg.setMthToDefault(creditDerivativeLeg.getMthToDefault());
        xmartCreditDerivativeLeg.setObligationNotDomesticIssue(creditDerivativeLeg.getObligationNotDomesticIssue());
        xmartCreditDerivativeLeg.setNthToDefault(creditDerivativeLeg.getNthToDefault());
        xmartCreditDerivativeLeg.setObligationAccelerationApp(creditDerivativeLeg.isObligationAccelerationApplicable());
        xmartCreditDerivativeLeg.setObligationCharacteristic(creditDerivativeLeg.getObligationCharacteristic());
        xmartCreditDerivativeLeg.setObligationDefaultApp(creditDerivativeLeg.isObligationDefaultApplicable());
        xmartCreditDerivativeLeg.setDeliverableAssetCategory(getStr(creditDerivativeLeg.getDeliverableAssetCategory()));
        xmartCreditDerivativeLeg.setObligationExcluded(creditDerivativeLeg.getObligationExcluded());
        xmartCreditDerivativeLeg
                .setObligationLiabilityScheme(getStr(creditDerivativeLeg.getObligationLiabilityScheme()));
        xmartCreditDerivativeLeg.setObligationListed(creditDerivativeLeg.getObligationListed());
        xmartCreditDerivativeLeg.setObligationNotContingent(creditDerivativeLeg.getObligationNotContingent());
        xmartCreditDerivativeLeg.setObligationNotDomesticLaw(creditDerivativeLeg.getObligationNotDomesticLaw());
        xmartCreditDerivativeLeg.setObligationNotSovereigLend(creditDerivativeLeg.getObligationNotSovereignLend());
        xmartCreditDerivativeLeg.setObligationNotSubordinated(creditDerivativeLeg.getObligationNotSubordinated());
        xmartCreditDerivativeLeg.setObligationOtherCategory(creditDerivativeLeg.getObligationOtherCategory());
        xmartCreditDerivativeLeg.setOtherCreditEventApp(creditDerivativeLeg.isOtherCreditEventApplicable());
        xmartCreditDerivativeLeg.setPhysicalSettlementEscrow(creditDerivativeLeg.getPhysicalSettlementEscrow());
        xmartCreditDerivativeLeg.setPhysSettlementBusDays(creditDerivativeLeg.getPhysSettlementBusDays());
        xmartCreditDerivativeLeg.setPhysSettlementCalDays(creditDerivativeLeg.getPhysSettlementCalDays());
        xmartCreditDerivativeLeg.setPhysSettlementMaxBusDays(creditDerivativeLeg.getPhysSettlementMaxBusDays());
        xmartCreditDerivativeLeg.setProtectionTermsCategory(getStr(creditDerivativeLeg.getProtectionTermsCategory()));
        xmartCreditDerivativeLeg.setRecoveryRate(creditDerivativeLeg.getRecoveryRate());
        xmartCreditDerivativeLeg.setRepudiationMoratoriumApp(creditDerivativeLeg.isRepudiationMoratoriumApplicable());
        xmartCreditDerivativeLeg.setRestructuringApp(creditDerivativeLeg.isRestructuringApplicable());
        xmartCreditDerivativeLeg.setRestructuringMultipleHolder(creditDerivativeLeg.getRestructuringMultipleHolder());
        xmartCreditDerivativeLeg.setRestructuringType(getStr(creditDerivativeLeg.getRestructuringType()));
        xmartCreditDerivativeLeg.setSecuredListApp(creditDerivativeLeg.getSecuredListApp());
        xmartCreditDerivativeLeg.setSettlementCurrencyDesc(creditDerivativeLeg.getSettlementCurrencyDesc());
        xmartCreditDerivativeLeg.setStepUpProvisionsApp(creditDerivativeLeg.getStepUpProvisionsApp());
        xmartCreditDerivativeLeg.setWacCapInterestProvisionApp(creditDerivativeLeg.getWacCapInterestProvisionApp());

        CreditEventNotice creditEventNotice = creditDerivativeLeg.getCreditEventNotice();
        if (creditEventNotice != null) {
            xmartCreditDerivativeLeg.setOtherConditionToPayment(creditEventNotice.getOtherConditionToPayment());
            xmartCreditDerivativeLeg.setPhysicalSettlementNotice(creditEventNotice.getPhysicalSettlementNotice());
            xmartCreditDerivativeLeg.setPublicationSpecifiedNumber(creditEventNotice.getPublicationSpecifiedNumber());
            xmartCreditDerivativeLeg.setUseIsdaStdPublicSources(creditEventNotice.getUseIsdaStdPublicSources());
        }

        Amount defaultRequirement = creditDerivativeLeg.getDefaultRequirement();
        if (defaultRequirement != null) {
            xmartCreditDerivativeLeg.setDefaultRequirementValue(defaultRequirement.getValue());
            if (defaultRequirement.getCurrencyId() != null) {
                xmartCreditDerivativeLeg
                        .setDefaultRequirementCurrencyCode(defaultRequirement.getCurrencyId().getCurrencyCode());
            }
        }

        Amount failureToPay = creditDerivativeLeg.getFailureToPay();
        if (failureToPay != null) {
            xmartCreditDerivativeLeg.setFailureToPayValue(failureToPay.getValue());
            if (failureToPay.getCurrencyId() != null) {
                xmartCreditDerivativeLeg.setFailureToPayCurrencyCode(failureToPay.getCurrencyId().getCurrencyCode());
            }
        }

        Amount protectionAmount = creditDerivativeLeg.getProtectionAmount();
        if (protectionAmount != null) {
            xmartCreditDerivativeLeg.setProtectionAmountValue(protectionAmount.getValue());
            if (protectionAmount.getCurrencyId() != null) {
                xmartCreditDerivativeLeg
                        .setProtectionAmountCurrencyCode(protectionAmount.getCurrencyId().getCurrencyCode());
            }
        }

        /*TODO FROBI-7260 mapping sheet = referenceEntity; fields in referenceEntityId, assuming referenceEntityId*/
        PartyId referenceEntityId = creditDerivativeLeg.getReferenceEntityId();
        if (referenceEntityId != null) {
            xmartCreditDerivativeLeg.setReferenceEntityIdPartyIdClassification(getStr(referenceEntityId.getScheme()));
            xmartCreditDerivativeLeg.setReferenceEntityIdPartyId(referenceEntityId.getPartyId());
        }

        CurrencyId obligationCurrencyId = creditDerivativeLeg.getObligationCurrencyId();
        if (obligationCurrencyId != null) {
            xmartCreditDerivativeLeg.setObligationCurrencyIdCurrencyCode(obligationCurrencyId.getCurrencyCode());
        }

        addEntity(xmartCreditDerivativeLeg);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}






















