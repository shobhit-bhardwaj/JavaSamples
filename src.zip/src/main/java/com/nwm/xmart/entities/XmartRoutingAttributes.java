package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RoutingAttribute;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;

public class XmartRoutingAttributes
        extends XmartOdcEntityCollection<Transaction, RoutingAttribute, XmartRoutingAttribute> {
    private static final long serialVersionUID = -4202893022505953236L;
    private static final Logger logger = LoggerFactory.getLogger(XmartRoutingAttributes.class);

    public XmartRoutingAttributes(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RoutingAttribute> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRoutingAttributes());
    }

    @Override
    public void createAndAddEntity(RoutingAttribute routingAttribute) throws XmartException {
        XmartRoutingAttribute xmartRoutingAttribute = new XmartRoutingAttribute(getDocumentKey());
        xmartRoutingAttribute.setRoutingAttributesId(routingAttribute.getId());
        xmartRoutingAttribute.setRoutingAttributesName(routingAttribute.getName());
        xmartRoutingAttribute.setRoutingAttributesValue(routingAttribute.getValue());
        addEntity(xmartRoutingAttribute);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
