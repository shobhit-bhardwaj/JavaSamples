package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartReportableTransactionState extends XmartEntity {

    private static final long serialVersionUID = -7660067356273692648L;
    @XmartAttribute
    private String regimeImpactType;
    @XmartAttribute
    private String reportableTransactionReference;
    @XmartAttribute
    private String reportableTransactionState;

    protected XmartReportableTransactionState(long documentKey, String regimeImpactType,
            String reportableTransactionReference, String reportableTransactionState) throws XmartException {
        super(documentKey);
        this.regimeImpactType = regimeImpactType;
        this.reportableTransactionReference = reportableTransactionReference;
        this.reportableTransactionState = reportableTransactionState;
    }

    public String getRegimeImpactType() {
        return regimeImpactType;
    }

    public void setRegimeImpactType(String regimeImpactType) {
        this.regimeImpactType = regimeImpactType;
    }

    public String getReportableTransactionReference() {
        return reportableTransactionReference;
    }

    public void setReportableTransactionReference(String reportableTransactionReference) {
        this.reportableTransactionReference = reportableTransactionReference;
    }

    public String getReportableTransactionState() {
        return reportableTransactionState;
    }

    public void setReportableTransactionState(String reportableTransactionState) {
        this.reportableTransactionState = reportableTransactionState;
    }
}
