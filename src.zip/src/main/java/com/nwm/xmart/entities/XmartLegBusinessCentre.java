package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartLegBusinessCentre extends XmartEntity {
    private static final long serialVersionUID = -1344501059892757838L;

    @XmartAttribute(xmlTrigger = false, usedInJoin = true)
    private String legIdentifier;
    @XmartAttribute
    private String businessCentre;
    @XmartAttribute
    private String businessCentreRole;
    @XmartAttribute
    private String businessDayConvention;

    XmartLegBusinessCentre(Long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public void setLegIdentifier(String legIdentifier) {
        this.legIdentifier = legIdentifier;
    }

    public String getBusinessCentre() {
        return businessCentre;
    }

    public void setBusinessCentre(String businessCentre) {
        this.businessCentre = businessCentre;
    }

    public String getBusinessCentreRole() {
        return businessCentreRole;
    }

    public void setBusinessCentreRole(String businessCentreRole) {
        this.businessCentreRole = businessCentreRole;
    }

    public String getBusinessDayConvention() {
        return businessDayConvention;
    }

    public void setBusinessDayConvention(String businessDayConvention) {
        this.businessDayConvention = businessDayConvention;
    }
}
