package com.nwm.xmart.entities.sds;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent;
import com.nwm.xmart.streaming.source.json.JSONDocumentTraverser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoField;

import static java.util.Objects.isNull;


public class XmartSdsSourceEvent extends XmartEntity {

    private static final long serialVersionUID = 7845851523286650033L;

    private final int jobSourceId;
    private final String dfKey;
    private final long dfVersion;
    private final long offset;
    private final JSONDocumentTraverser jsonDocumentTraverser;

    XmartSdsSourceEvent(int jobSourceId, DataFabricWatchEvent watchEvent) throws XmartException {

        super();

        if (isNull(watchEvent)) {
            throw new XmartException("NULL source record provided to XmartSdsSourceEvent.");
        }

        this.jobSourceId = jobSourceId;
        this.dfKey = watchEvent.getDfKey();
        this.dfVersion = watchEvent.getDfVersion();
        this.offset = watchEvent.getOffset();
        this.jsonDocumentTraverser = watchEvent.getJsonPayload();

        setDocumentKey(generateDocumentKey(watchEvent.getTimestamp(), jobSourceId, watchEvent.getOffset()));

    }

    /**
     * Creates document key to be used in the different mapping
     *
     * @param sourceTopicId  Source topic id of kafka
     * @param sourcePosition Source position of this message
     *
     * @return document key
     * <p>
     * Document Key Format :
     * YY – 2 digits for Year
     * DOY - 3 digits for Day of the year
     * TTT – 3 digit for identifying the job (used as the last three digits of the JOB Name)
     * Offset - 11 digits from the offset ID
     */
    private static long generateDocumentKey(long timestamp, int sourceTopicId, long sourcePosition) {

        LocalDateTime consumeTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault());

        StringBuilder docKeyStr = new StringBuilder(19);
        String docKeyComp;

        docKeyStr.setLength(0);
        docKeyComp = String.format("%02d", consumeTime.get(ChronoField.YEAR));
        docKeyStr.insert(0, docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%03d", consumeTime.getDayOfYear());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));
        docKeyComp = String.format("%03d", sourceTopicId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));
        docKeyComp = String.format("%011d", sourcePosition);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 11));
        return Long.parseLong(docKeyStr.toString());
    }

    public int getJobSourceId() {
        return jobSourceId;
    }

    public String getDfKey() {
        return dfKey;
    }

    public long getDfVersion() {
        return dfVersion;
    }

    public long getOffset() {
        return offset;
    }

    public JSONDocumentTraverser getJsonDocumentTraverser() {
        return jsonDocumentTraverser;
    }

}
