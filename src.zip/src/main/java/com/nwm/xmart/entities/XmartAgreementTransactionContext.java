package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

/**
 * Created by aslammh on 13/11/17.
 */
public class XmartAgreementTransactionContext extends XmartEntity {

    private static final long serialVersionUID = 4969772288763514156L;
    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = true)
    private final Integer agreementTransactionContextId;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String legId;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String agreementId;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String transactionAgreementContext;

    public XmartAgreementTransactionContext(long documentKey, Integer agreementTransactionContextId)
            throws XmartException {
        super(documentKey);
        this.agreementTransactionContextId = agreementTransactionContextId;
    }

    public Integer getAgreementTransactionContextId() {
        return agreementTransactionContextId;
    }

    public String getLegId() {
        return legId;
    }

    public void setLegId(String legId) {
        this.legId = legId;
    }

    public String getAgreementId() {
        return agreementId;
    }

    public void setAgreementId(String agreementId) {
        this.agreementId = agreementId;
    }

    public String getTransactionAgreementContext() {
        return transactionAgreementContext;
    }

    public void setTransactionAgreementContext(String transactionAgreementContext) {
        this.transactionAgreementContext = transactionAgreementContext;
    }
}
