package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.LegInformationSource;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 13/11/17.
 */
public class XmartLegInformationSources
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartLegInformationSource> {

    private static final long serialVersionUID = 5008138739902203990L;
    private static final Logger logger = LoggerFactory.getLogger(XmartLegInformationSources.class);

    public XmartLegInformationSources(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        for (LegInformationSource legInformationSource : nullCollToEmpty(transactionLeg.getLegInformationSource())) {
            XmartLegInformationSource xmartLegInformationSource = new XmartLegInformationSource(
                    transactionLeg.getLegIdentifier(), getDocumentKey());
            if (nonNull(legInformationSource)) {
                xmartLegInformationSource.setInformationSource(legInformationSource.getInformationSource());
                xmartLegInformationSource.setInformationSourceId(legInformationSource.getInformationSourceId());
                xmartLegInformationSource.setInformationSourcePage(legInformationSource.getInformationSourcePage());
                xmartLegInformationSource
                        .setInformationSourceSystemId(getStr(legInformationSource.getInformationSourceSystemId()));
            }
            addEntity(xmartLegInformationSource);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
