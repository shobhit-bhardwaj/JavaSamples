package com.nwm.xmart.entities.tdx;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.nwm.xmart.streaming.source.tdx.event.TDXSourceEvent;
import com.nwm.xmart.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoField;

import static java.util.Objects.isNull;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartTdxSourceEvent extends XmartEntity {
    private static final Logger logger = LoggerFactory.getLogger(XmartTdxSourceEvent.class);

    private static final long serialVersionUID = 7845851523286650033L;
    private final Integer dfVersion;
    private final LocalDateTime dfFrom;
    private final LocalDateTime dfTo;

    long documentKey = 0;

    private TDXSourceEvent streamEvent;

    private int jobSourceId = 0;  // like topicId we need a UID for the collection
    private long eventSequenceID = 0;

    public XmartTdxSourceEvent(int jobSourceId, TDXSourceEvent streamEvent) throws XmartException {

        super();

        if (isNull(streamEvent)) {
            throw new XmartException("NULL source record provided to XmartTdxSourceEvent.");
        }

        this.streamEvent = streamEvent;

        this.dfVersion = streamEvent.getVersion();
        this.dfFrom = streamEvent.getFrom();
        this.dfTo = streamEvent.getTo();

        this.jobSourceId
                = jobSourceId; // needs to be something like topic ID which BDX set themselves just in ID for each each

        this.eventSequenceID = Math.abs(Long.valueOf(streamEvent.getEventSequenceId()));

        StringBuilder documentKeyString = new StringBuilder(19);
        String documentKeyComponent = null;

        LocalDateTime consumeTime = LocalDateTime.now();

        documentKeyString.setLength(0);

        documentKeyComponent = String.format("%02d", consumeTime.get(ChronoField.YEAR));
        documentKeyString.insert(0, documentKeyComponent.substring(documentKeyComponent.length() - 2));

        documentKeyComponent = String.format("%03d", consumeTime.getDayOfYear());
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 3));

        documentKeyComponent = String.format("%03d", jobSourceId);
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 3));

        documentKeyComponent = String.format("%011d", eventSequenceID);
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 11));

        documentKey = Long.parseLong(documentKeyString.toString());
    }

    public TDXSourceEvent getStreamEvent() {
        return streamEvent;
    }

    public int getTopicId() {
        return jobSourceId;
    }

    public long getEventSequenceID() {
        return eventSequenceID;
    }

    public long getDocumentKey() {
        return documentKey;
    }

    public Integer getDfVersion() {
        return dfVersion;
    }

    public String getDfFrom() {
        ZonedDateTime ldtZoned = dfFrom.atZone(ZoneId.systemDefault());
        ZonedDateTime utcZoned = ldtZoned.withZoneSameInstant(ZoneId.of("UTC"));
        return DateUtil.formatLocalDateTimeUTC(utcZoned.toLocalDateTime());
    }

    public String getDfTo() {
        ZonedDateTime ldtZoned = dfTo.atZone(ZoneId.systemDefault());
        ZonedDateTime utcZoned = ldtZoned.withZoneSameInstant(ZoneId.of("UTC"));
        return DateUtil.formatLocalDateTimeUTC(utcZoned.toLocalDateTime());
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("XmartTdxSourceEvent{");
        sb.append("documentKey=").append(documentKey);
        sb.append(", streamEvent=").append(streamEvent);
        sb.append(", topicId=").append(jobSourceId);
        sb.append(", eventSequenceID=").append(eventSequenceID);
        sb.append(", version=").append(dfVersion);
        sb.append(", from=").append(dfFrom);
        sb.append(", to=").append(dfTo);
        sb.append('}');
        return sb.toString();
    }
}
