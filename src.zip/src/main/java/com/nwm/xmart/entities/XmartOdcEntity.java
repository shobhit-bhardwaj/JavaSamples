package com.nwm.xmart.entities;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoField;

public class XmartOdcEntity extends XmartEntity {

    protected XmartOdcEntity(long documentKey) throws XmartException {
        super(documentKey);
    }

    /**
     * Creates document key to be used in the different mapping
     *
     * @param sourcePartition Source partition of kafka
     * @param sourceTopicId   Source topic id of kafka
     * @param sourcePosition  Source postition of this message kafka
     * @param sourceTimestamp timestamp of this message kafka
     *
     * @return documetn key
     *
     * <p>
     * Document Key Format :
     * YY – 2 digits for Year
     * DOY - 3 digits for Day of the year
     * TTT – 3 digit for identifying the job (used as the last three digits of the JOB Name)
     * PP – 2 digits from Kafka partition
     * Offset - 9 digits from the offset ID
     * </p>
     */
    protected static long generateDocumentKey(int sourcePartition, int sourceTopicId, long sourcePosition,
            long sourceTimestamp) {
        StringBuilder docKeyStr = new StringBuilder(19);
        String docKeyComp;
        LocalDateTime consumeTime = LocalDateTime
                .ofInstant(Instant.ofEpochMilli(sourceTimestamp), ZoneId.systemDefault());
        docKeyStr.setLength(0);
        docKeyComp = String.format("%02d", consumeTime.get(ChronoField.YEAR));
        docKeyStr.insert(0, docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%03d", consumeTime.getDayOfYear());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));
        docKeyComp = String.format("%03d", sourceTopicId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));
        docKeyComp = String.format("%02d", sourcePartition);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%09d", sourcePosition);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 9));
        return Long.parseLong(docKeyStr.toString());
    }
}
