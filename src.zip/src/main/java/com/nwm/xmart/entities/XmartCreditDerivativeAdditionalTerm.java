package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartCreditDerivativeAdditionalTerm extends XmartEntity {

    private static final long serialVersionUID = 7055019049083820893L;

    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String additionalTerm;

    public XmartCreditDerivativeAdditionalTerm(long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getAdditionalTerm() {
        return additionalTerm;
    }

    public void setAdditionalTerm(String additionalTerm) {
        this.additionalTerm = additionalTerm;
    }
}
