package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartCreditDerivativeLeg extends XmartEntity {
    private static final long serialVersionUID = 2803314822840896560L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String legIdentifier;

    @XmartAttribute
    private Boolean allGuarantees;

    @XmartAttribute
    private Boolean bankruptcyApp;

    @XmartAttribute
    private Boolean failureToPayApp;

    @XmartAttribute
    private Boolean obligationAccelerationApp;

    @XmartAttribute
    private Boolean obligationDefaultApp;

    @XmartAttribute
    private Boolean repudiationMoratoriumApp;

    @XmartAttribute
    private Boolean restructuringApp;

    @XmartAttribute
    private Boolean otherCreditEventApp;

    @XmartAttribute
    private Boolean restructuringMultipleHolder;

    @XmartAttribute
    private Boolean obligationNotSubordinated;

    @XmartAttribute
    private Boolean obligationNotSovereigLend;

    @XmartAttribute
    private Boolean obligationNotDomesticLaw;

    @XmartAttribute
    private Boolean obligationNotDomesticIssue;

    @XmartAttribute
    private Boolean obligationListed;

    @XmartAttribute
    private Boolean obligationNotContingent;

    @XmartAttribute
    private Boolean physicalSettlementEscrow;

    @XmartAttribute
    private Boolean useIsdaStdPublicSources;

    @XmartAttribute
    private Boolean physicalSettlementNotice;

    @XmartAttribute
    private Boolean governmentalInterventionApp;

    @XmartAttribute
    private String interestShortFallCapApp;

    @XmartAttribute
    private Boolean securedListApp;

    @XmartAttribute
    private Boolean fixedSettlement;

    @XmartAttribute
    private Boolean wacCapInterestProvisionApp;

    @XmartAttribute
    private Boolean stepUpProvisionsApp;

    @XmartAttribute
    private Boolean interestShortFallComp;

    @XmartAttribute
    private BigDecimal defaultRequirementValue;

    @XmartAttribute
    private BigDecimal failureToPayValue;

    @XmartAttribute
    private BigDecimal recoveryRate;

    @XmartAttribute
    private BigDecimal protectionAmountValue;

    @XmartAttribute
    private Integer physSettlementBusDays;

    @XmartAttribute
    private Integer physSettlementMaxBusDays;

    @XmartAttribute
    private Integer publicationSpecifiedNumber;

    @XmartAttribute
    private Integer physSettlementCalDays;

    @XmartAttribute
    private Integer nthToDefault;

    @XmartAttribute
    private Integer mthToDefault;

    @XmartAttribute
    private Integer gracePeriodMultiplier;

    @XmartAttribute
    private String restructuringType;

    @XmartAttribute
    private String settlementCurrencyDesc;

    @XmartAttribute
    private String deliverableAssetCategory;

    @XmartAttribute
    private String protectionTermsCategory;

    @XmartAttribute
    private String defaultRequirementCurrencyCode;

    @XmartAttribute
    private String obligationExcluded;

    @XmartAttribute
    private String obligationOtherCategory;

    @XmartAttribute
    private String obligationCharacteristic;

    @XmartAttribute
    private String obligationLiabilityScheme;

    @XmartAttribute
    private String failureToPayCurrencyCode;

    @XmartAttribute
    private String otherConditionToPayment;

    @XmartAttribute
    private String protectionAmountCurrencyCode;

    @XmartAttribute
    private String gracePeriodDayType;

    @XmartAttribute
    private String gracePeriodScheme;

    @XmartAttribute
    private String obligationCurrencyIdCurrencyCode;

    @XmartAttribute
    private String referenceEntityIdPartyIdClassification;

    @XmartAttribute
    private String referenceEntityIdPartyId;

    public XmartCreditDerivativeLeg(Long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public Boolean getAllGuarantees() {
        return allGuarantees;
    }

    public void setAllGuarantees(Boolean allGuarantees) {
        this.allGuarantees = allGuarantees;
    }

    public Boolean getBankruptcyApp() {
        return bankruptcyApp;
    }

    public void setBankruptcyApp(Boolean bankruptcyApp) {
        this.bankruptcyApp = bankruptcyApp;
    }

    public Boolean getFailureToPayApp() {
        return failureToPayApp;
    }

    public void setFailureToPayApp(Boolean failureToPayApp) {
        this.failureToPayApp = failureToPayApp;
    }

    public Boolean getObligationAccelerationApp() {
        return obligationAccelerationApp;
    }

    public void setObligationAccelerationApp(Boolean obligationAccelerationApp) {
        this.obligationAccelerationApp = obligationAccelerationApp;
    }

    public Boolean getObligationDefaultApp() {
        return obligationDefaultApp;
    }

    public void setObligationDefaultApp(Boolean obligationDefaultApp) {
        this.obligationDefaultApp = obligationDefaultApp;
    }

    public Boolean getRepudiationMoratoriumApp() {
        return repudiationMoratoriumApp;
    }

    public void setRepudiationMoratoriumApp(Boolean repudiationMoratoriumApp) {
        this.repudiationMoratoriumApp = repudiationMoratoriumApp;
    }

    public Boolean getRestructuringApp() {
        return restructuringApp;
    }

    public void setRestructuringApp(Boolean restructuringApp) {
        this.restructuringApp = restructuringApp;
    }

    public Boolean getOtherCreditEventApp() {
        return otherCreditEventApp;
    }

    public void setOtherCreditEventApp(Boolean otherCreditEventApp) {
        this.otherCreditEventApp = otherCreditEventApp;
    }

    public Boolean getRestructuringMultipleHolder() {
        return restructuringMultipleHolder;
    }

    public void setRestructuringMultipleHolder(Boolean restructuringMultipleHolder) {
        this.restructuringMultipleHolder = restructuringMultipleHolder;
    }

    public Boolean getObligationNotSubordinated() {
        return obligationNotSubordinated;
    }

    public void setObligationNotSubordinated(Boolean obligationNotSubordinated) {
        this.obligationNotSubordinated = obligationNotSubordinated;
    }

    public Boolean getObligationNotSovereigLend() {
        return obligationNotSovereigLend;
    }

    public void setObligationNotSovereigLend(Boolean obligationNotSovereigLend) {
        this.obligationNotSovereigLend = obligationNotSovereigLend;
    }

    public Boolean getObligationNotDomesticLaw() {
        return obligationNotDomesticLaw;
    }

    public void setObligationNotDomesticLaw(Boolean obligationNotDomesticLaw) {
        this.obligationNotDomesticLaw = obligationNotDomesticLaw;
    }

    public Boolean getObligationNotDomesticIssue() {
        return obligationNotDomesticIssue;
    }

    public void setObligationNotDomesticIssue(Boolean obligationNotDomesticIssue) {
        this.obligationNotDomesticIssue = obligationNotDomesticIssue;
    }

    public Boolean getObligationListed() {
        return obligationListed;
    }

    public void setObligationListed(Boolean obligationListed) {
        this.obligationListed = obligationListed;
    }

    public Boolean getObligationNotContingent() {
        return obligationNotContingent;
    }

    public void setObligationNotContingent(Boolean obligationNotContingent) {
        this.obligationNotContingent = obligationNotContingent;
    }

    public Boolean getPhysicalSettlementEscrow() {
        return physicalSettlementEscrow;
    }

    public void setPhysicalSettlementEscrow(Boolean physicalSettlementEscrow) {
        this.physicalSettlementEscrow = physicalSettlementEscrow;
    }

    public Boolean getUseIsdaStdPublicSources() {
        return useIsdaStdPublicSources;
    }

    public void setUseIsdaStdPublicSources(Boolean useIsdaStdPublicSources) {
        this.useIsdaStdPublicSources = useIsdaStdPublicSources;
    }

    public Boolean getPhysicalSettlementNotice() {
        return physicalSettlementNotice;
    }

    public void setPhysicalSettlementNotice(Boolean physicalSettlementNotice) {
        this.physicalSettlementNotice = physicalSettlementNotice;
    }

    public Boolean getGovernmentalInterventionApp() {
        return governmentalInterventionApp;
    }

    public void setGovernmentalInterventionApp(Boolean governmentalInterventionApp) {
        this.governmentalInterventionApp = governmentalInterventionApp;
    }

    public String getInterestShortFallCapApp() {
        return interestShortFallCapApp;
    }

    public void setInterestShortFallCapApp(String interestShortFallCapApp) {
        this.interestShortFallCapApp = interestShortFallCapApp;
    }

    public Boolean getSecuredListApp() {
        return securedListApp;
    }

    public void setSecuredListApp(Boolean securedListApp) {
        this.securedListApp = securedListApp;
    }

    public Boolean getFixedSettlement() {
        return fixedSettlement;
    }

    public void setFixedSettlement(Boolean fixedSettlement) {
        this.fixedSettlement = fixedSettlement;
    }

    public Boolean getWacCapInterestProvisionApp() {
        return wacCapInterestProvisionApp;
    }

    public void setWacCapInterestProvisionApp(Boolean wacCapInterestProvisionApp) {
        this.wacCapInterestProvisionApp = wacCapInterestProvisionApp;
    }

    public Boolean getStepUpProvisionsApp() {
        return stepUpProvisionsApp;
    }

    public void setStepUpProvisionsApp(Boolean stepUpProvisionsApp) {
        this.stepUpProvisionsApp = stepUpProvisionsApp;
    }

    public Boolean getInterestShortFallComp() {
        return interestShortFallComp;
    }

    public void setInterestShortFallComp(Boolean interestShortFallComp) {
        this.interestShortFallComp = interestShortFallComp;
    }

    public BigDecimal getDefaultRequirementValue() {
        return defaultRequirementValue;
    }

    public void setDefaultRequirementValue(BigDecimal defaultRequirementValue) {
        this.defaultRequirementValue = defaultRequirementValue;
    }

    public BigDecimal getFailureToPayValue() {
        return failureToPayValue;
    }

    public void setFailureToPayValue(BigDecimal failureToPayValue) {
        this.failureToPayValue = failureToPayValue;
    }

    public BigDecimal getRecoveryRate() {
        return recoveryRate;
    }

    public void setRecoveryRate(BigDecimal recoveryRate) {
        this.recoveryRate = recoveryRate;
    }

    public BigDecimal getProtectionAmountValue() {
        return protectionAmountValue;
    }

    public void setProtectionAmountValue(BigDecimal protectionAmountValue) {
        this.protectionAmountValue = protectionAmountValue;
    }

    public Integer getPhysSettlementBusDays() {
        return physSettlementBusDays;
    }

    public void setPhysSettlementBusDays(Integer physSettlementBusDays) {
        this.physSettlementBusDays = physSettlementBusDays;
    }

    public Integer getPhysSettlementMaxBusDays() {
        return physSettlementMaxBusDays;
    }

    public void setPhysSettlementMaxBusDays(Integer physSettlementMaxBusDays) {
        this.physSettlementMaxBusDays = physSettlementMaxBusDays;
    }

    public Integer getPublicationSpecifiedNumber() {
        return publicationSpecifiedNumber;
    }

    public void setPublicationSpecifiedNumber(Integer publicationSpecifiedNumber) {
        this.publicationSpecifiedNumber = publicationSpecifiedNumber;
    }

    public Integer getPhysSettlementCalDays() {
        return physSettlementCalDays;
    }

    public void setPhysSettlementCalDays(Integer physSettlementCalDays) {
        this.physSettlementCalDays = physSettlementCalDays;
    }

    public Integer getNthToDefault() {
        return nthToDefault;
    }

    public void setNthToDefault(Integer nthToDefault) {
        this.nthToDefault = nthToDefault;
    }

    public Integer getMthToDefault() {
        return mthToDefault;
    }

    public void setMthToDefault(Integer mthToDefault) {
        this.mthToDefault = mthToDefault;
    }

    public Integer getGracePeriodMultiplier() {
        return gracePeriodMultiplier;
    }

    public void setGracePeriodMultiplier(Integer gracePeriodMultiplier) {
        this.gracePeriodMultiplier = gracePeriodMultiplier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getRestructuringType() {
        return restructuringType;
    }

    public void setRestructuringType(String restructuringType) {
        this.restructuringType = restructuringType;
    }

    public String getSettlementCurrencyDesc() {
        return settlementCurrencyDesc;
    }

    public void setSettlementCurrencyDesc(String settlementCurrencyDesc) {
        this.settlementCurrencyDesc = settlementCurrencyDesc;
    }

    public String getDeliverableAssetCategory() {
        return deliverableAssetCategory;
    }

    public void setDeliverableAssetCategory(String deliverableAssetCategory) {
        this.deliverableAssetCategory = deliverableAssetCategory;
    }

    public String getProtectionTermsCategory() {
        return protectionTermsCategory;
    }

    public void setProtectionTermsCategory(String protectionTermsCategory) {
        this.protectionTermsCategory = protectionTermsCategory;
    }

    public String getDefaultRequirementCurrencyCode() {
        return defaultRequirementCurrencyCode;
    }

    public void setDefaultRequirementCurrencyCode(String defaultRequirementCurrencyCode) {
        this.defaultRequirementCurrencyCode = defaultRequirementCurrencyCode;
    }

    public String getObligationExcluded() {
        return obligationExcluded;
    }

    public void setObligationExcluded(String obligationExcluded) {
        this.obligationExcluded = obligationExcluded;
    }

    public String getObligationOtherCategory() {
        return obligationOtherCategory;
    }

    public void setObligationOtherCategory(String obligationOtherCategory) {
        this.obligationOtherCategory = obligationOtherCategory;
    }

    public String getObligationCharacteristic() {
        return obligationCharacteristic;
    }

    public void setObligationCharacteristic(String obligationCharacteristic) {
        this.obligationCharacteristic = obligationCharacteristic;
    }

    public String getObligationLiabilityScheme() {
        return obligationLiabilityScheme;
    }

    public void setObligationLiabilityScheme(String obligationLiabilityScheme) {
        this.obligationLiabilityScheme = obligationLiabilityScheme;
    }

    public String getFailureToPayCurrencyCode() {
        return failureToPayCurrencyCode;
    }

    public void setFailureToPayCurrencyCode(String failureToPayCurrencyCode) {
        this.failureToPayCurrencyCode = failureToPayCurrencyCode;
    }

    public String getOtherConditionToPayment() {
        return otherConditionToPayment;
    }

    public void setOtherConditionToPayment(String otherConditionToPayment) {
        this.otherConditionToPayment = otherConditionToPayment;
    }

    public String getProtectionAmountCurrencyCode() {
        return protectionAmountCurrencyCode;
    }

    public void setProtectionAmountCurrencyCode(String protectionAmountCurrencyCode) {
        this.protectionAmountCurrencyCode = protectionAmountCurrencyCode;
    }

    public String getGracePeriodDayType() {
        return gracePeriodDayType;
    }

    public void setGracePeriodDayType(String gracePeriodDayType) {
        this.gracePeriodDayType = gracePeriodDayType;
    }

    public String getGracePeriodScheme() {
        return gracePeriodScheme;
    }

    public void setGracePeriodScheme(String gracePeriodScheme) {
        this.gracePeriodScheme = gracePeriodScheme;
    }

    public String getObligationCurrencyIdCurrencyCode() {
        return obligationCurrencyIdCurrencyCode;
    }

    public void setObligationCurrencyIdCurrencyCode(String obligationCurrencyIdCurrencyCode) {
        this.obligationCurrencyIdCurrencyCode = obligationCurrencyIdCurrencyCode;
    }

    public String getReferenceEntityIdPartyIdClassification() {
        return referenceEntityIdPartyIdClassification;
    }

    public void setReferenceEntityIdPartyIdClassification(String referenceEntityIdPartyIdClassification) {
        this.referenceEntityIdPartyIdClassification = referenceEntityIdPartyIdClassification;
    }

    public String getReferenceEntityIdPartyId() {
        return referenceEntityIdPartyId;
    }

    public void setReferenceEntityIdPartyId(String referenceEntityIdPartyId) {
        this.referenceEntityIdPartyId = referenceEntityIdPartyId;
    }
}
