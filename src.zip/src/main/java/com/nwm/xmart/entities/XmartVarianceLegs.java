package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

public class XmartVarianceLegs extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartVarianceLeg> {
    private static final long serialVersionUID = 6521628050694214185L;
    private static final Logger logger = LoggerFactory.getLogger(XmartVarianceLegs.class);

    public XmartVarianceLegs(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        if (isNull(transactionLeg.getVarianceLeg())) {
            // This is possible when LegType of this transactionLeg is not of type Fx_Leg
            return;
        }

        XmartVarianceLeg xmartVarianceLeg = new XmartVarianceLeg(getDocumentKey(), transactionLeg.getLegIdentifier());
        VarianceLeg varianceLeg = transactionLeg.getVarianceLeg();

        xmartVarianceLeg.setStrikeLevel(varianceLeg.getStrikeLevel());
        xmartVarianceLeg.setStrikeOffMethod(getStr(varianceLeg.getStrikeOffMethod()));

        Amount varianceAmount = varianceLeg.getVarianceAmount();
        if (varianceAmount != null) {
            CurrencyId currencyId = varianceAmount.getCurrencyId();
            if (currencyId != null) {
                xmartVarianceLeg.setVarianceAmountCurrencyCode(currencyId.getCurrencyCode());
            }
            xmartVarianceLeg.setVarianceAmountValue(varianceAmount.getValue());
        }
        addEntity(xmartVarianceLeg);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
