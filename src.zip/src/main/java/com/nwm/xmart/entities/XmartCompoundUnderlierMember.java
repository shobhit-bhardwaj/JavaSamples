package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartCompoundUnderlierMember extends XmartEntity {

    private static final long serialVersionUID = 5782243562477114575L;

    @XmartAttribute(xmlTrigger = false, usedInJoin = true)
    private String legIdentifier, underlierId;
    @XmartAttribute
    private BigDecimal basketWeightPercentage;
    @XmartAttribute
    private String basketWeightCurrencyCode;
    @XmartAttribute
    private BigDecimal basketWeightValue;
    @XmartAttribute
    private BigDecimal basketWeightOpenUnits;
    @XmartAttribute
    private String instrumentScheme;
    @XmartAttribute
    private String instrumentId;
    @XmartAttribute
    private BigDecimal attachmentPoint;
    @XmartAttribute
    private BigDecimal exhaustionPoint;

    public XmartCompoundUnderlierMember(Long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public void setLegIdentifier(String legIdentifier) {
        this.legIdentifier = legIdentifier;
    }

    public String getUnderlierId() {
        return underlierId;
    }

    public void setUnderlierId(String underlierId) {
        this.underlierId = underlierId;
    }

    public BigDecimal getBasketWeightPercentage() {
        return basketWeightPercentage;
    }

    public void setBasketWeightPercentage(BigDecimal basketWeightPercentage) {
        this.basketWeightPercentage = basketWeightPercentage;
    }

    public String getBasketWeightCurrencyCode() {
        return basketWeightCurrencyCode;
    }

    public void setBasketWeightCurrencyCode(String basketWeightCurrencyCode) {
        this.basketWeightCurrencyCode = basketWeightCurrencyCode;
    }

    public BigDecimal getBasketWeightValue() {
        return basketWeightValue;
    }

    public void setBasketWeightValue(BigDecimal basketWeightValue) {
        this.basketWeightValue = basketWeightValue;
    }

    public BigDecimal getBasketWeightOpenUnits() {
        return basketWeightOpenUnits;
    }

    public void setBasketWeightOpenUnits(BigDecimal basketWeightOpenUnits) {
        this.basketWeightOpenUnits = basketWeightOpenUnits;
    }

    public String getInstrumentScheme() {
        return instrumentScheme;
    }

    public void setInstrumentScheme(String instrumentScheme) {
        this.instrumentScheme = instrumentScheme;
    }

    public String getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(String instrumentId) {
        this.instrumentId = instrumentId;
    }

    public BigDecimal getAttachmentPoint() {
        return attachmentPoint;
    }

    public void setAttachmentPoint(BigDecimal attachmentPoint) {
        this.attachmentPoint = attachmentPoint;
    }

    public BigDecimal getExhaustionPoint() {
        return exhaustionPoint;
    }

    public void setExhaustionPoint(BigDecimal exhaustionPoint) {
        this.exhaustionPoint = exhaustionPoint;
    }
}
