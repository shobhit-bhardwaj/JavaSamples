package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartLinkedTransactions
        extends XmartOdcEntityCollection<Transaction, TransactionLink, XmartLinkedTransaction> {

    private static final Logger logger = LoggerFactory.getLogger(XmartLinkedTransactions.class);
    private static final long serialVersionUID = -7407396551435797658L;

    public XmartLinkedTransactions(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLink> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getLinkedTransactions(), logger,
                "Linked Transactions not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLink transactionLink) throws XmartException {

        XmartLinkedTransaction xmartLinkedTransaction = new XmartLinkedTransaction(getDocumentKey());
        xmartLinkedTransaction.setLinkageReasonScheme(getStr(transactionLink.getLinkageReasonScheme()));
        xmartLinkedTransaction.setLinkSourceSystemId(getStr(transactionLink.getLinkSourceSystemId()));
        xmartLinkedTransaction.setLinkTransactionId(transactionLink.getLinkTransactionId());
        xmartLinkedTransaction.setLinkTransactionLegId(transactionLink.getLinkTransactionLegId());
        xmartLinkedTransaction.setLinkTransactionVersion(transactionLink.getLinkTransactionVersion());
        xmartLinkedTransaction.setTradeIdClassification(getStr(transactionLink.getTradeIdClassification()));

        addEntity(xmartLinkedTransaction);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
