package com.nwm.xmart.entities.mdx;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.Date;

import static java.util.Objects.isNull;

public class XmartMdxDocumentEvent extends XmartEntity {
    private static final Logger logger = LoggerFactory.getLogger(XmartMdxDocumentEvent.class);

    private static final long serialVersionUID = 7845851523286650033L;
    private MdxDocumentEvent streamEvent;

    public XmartMdxDocumentEvent(int jobId, MdxDocumentEvent streamEvent) throws XmartException {
        super();

        if (isNull(streamEvent)) {
            throw new XmartException("NULL source record provided to XmartMdxDocumentEvent.");
        }

        this.streamEvent = streamEvent;
        setDocumentKey(generateDoucumentKey(streamEvent, jobId));
    }

    /*
    YY – Year in 2 digit
    DDD - Day of the year
    TTT – 3 digit Flink Job Id identifying the job and data flow (for instance for an MDX flow with 4 sources, we would see JOB IDs of 401, 402, 403 and 404)
    SID - 1 digit for source Type
    HHMISS – the time the record was processed by the Flink source function
    NNNN - 4 digits numeric identifier of an individual record - taken the last five digits of a sequential counter
    generated and incremented in the MDX source and restarted at 0 with each rerun of the job
    */
    private long generateDoucumentKey(MdxDocumentEvent mdxEvent, int jobId) {
        StringBuilder docKeyStr = new StringBuilder(19);
        String docKeyComp;
        LocalDateTime localDateTime = LocalDateTime.now();
        docKeyStr.setLength(0);

        //YY
        docKeyStr.insert(0, String.format("%02d", localDateTime.getYear() % 100));

        //DDD
        docKeyComp = String.format("%03d", localDateTime.getDayOfYear());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));

        //TTT
        docKeyComp = String.format("%02d", jobId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 2));

        //SID
        docKeyComp = String.format("%01d", Integer.valueOf(mdxEvent.getSourceID()));
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 1));

        //HHMISS
        Date date = new Date(mdxEvent.getDocumentReceivedTimestamp());
        docKeyComp = String.format("%02d", date.getHours()) + String.format("%02d", date.getMinutes()) + String
                .format("%02d", date.getSeconds());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 6));

        //NNNN
        docKeyComp = String.format("%05d", mdxEvent.getCurrentJobEventID() % 100000);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 5));

        return Long.parseLong(docKeyStr.toString());
    }

    public MdxDocumentEvent getStreamEvent() {
        return streamEvent;
    }
}
