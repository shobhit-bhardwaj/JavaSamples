package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.PostTradeClassification;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartPostTradeClassifications
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartPostTradeClassification> {

    private static final long serialVersionUID = 4700985675269993583L;
    private static final Logger logger = LoggerFactory.getLogger(XmartPostTradeClassifications.class);

    public XmartPostTradeClassifications(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpacts not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {

        for (PostTradeClassification postTradeClassification : regulatoryRegimeImpact.getPostTradeClassification()) {

            XmartPostTradeClassification xmartPostTradeClassification = new XmartPostTradeClassification(
                    getDocumentKey());
            xmartPostTradeClassification.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartPostTradeClassification.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartPostTradeClassification.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());

            if (nonNull(postTradeClassification)) {
                xmartPostTradeClassification
                        .setPostTradeClassification(getStr(postTradeClassification.getPostTradeClassification()));
            }
            addEntity(xmartPostTradeClassification);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
