package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.util.Date;

public class XmartTransactionLegCurve extends XmartEntity {
    private static final long serialVersionUID = 7614539699816663536L;

    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveId;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveSystemId;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveCurrencyIdCurrencyCode;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveRole;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveCcyIdCurrencyCode;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String currencyCode;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String projectionType;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveOverrideReason;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveOverrideApprover;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private Date curveOverrideApprovalDateTime;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveOverrideApprovalComments;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String curveName;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private Date curveOverrideApprovalDate;

    protected XmartTransactionLegCurve(long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getCurveId() {
        return curveId;
    }

    public void setCurveId(String curveId) {
        this.curveId = curveId;
    }

    public String getCurveSystemId() {
        return curveSystemId;
    }

    public void setCurveSystemId(String curveSystemId) {
        this.curveSystemId = curveSystemId;
    }

    public String getCurveCurrencyIdCurrencyCode() {
        return curveCurrencyIdCurrencyCode;
    }

    public void setCurveCurrencyIdCurrencyCode(String curveCurrencyIdCurrencyCode) {
        this.curveCurrencyIdCurrencyCode = curveCurrencyIdCurrencyCode;
    }

    public String getCurveCcyIdCurrencyCode() {
        return curveCcyIdCurrencyCode;
    }

    public void setCurveCcyIdCurrencyCode(String curveCcyIdCurrencyCode) {
        this.curveCcyIdCurrencyCode = curveCcyIdCurrencyCode;
    }

    public String getCurveRole() {
        return curveRole;
    }

    public void setCurveRole(String curveRole) {
        this.curveRole = curveRole;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getProjectionType() {
        return projectionType;
    }

    public void setProjectionType(String projectionType) {
        this.projectionType = projectionType;
    }

    public String getCurveOverrideReason() {
        return curveOverrideReason;
    }

    public void setCurveOverrideReason(String curveOverrideReason) {
        this.curveOverrideReason = curveOverrideReason;
    }

    public String getCurveOverrideApprover() {
        return curveOverrideApprover;
    }

    public void setCurveOverrideApprover(String curveOverrideApprover) {
        this.curveOverrideApprover = curveOverrideApprover;
    }

    public Date getCurveOverrideApprovalDateTime() {
        return curveOverrideApprovalDateTime;
    }

    public void setCurveOverrideApprovalDateTime(Date curveOverrideApprovalDateTime) {
        this.curveOverrideApprovalDateTime = curveOverrideApprovalDateTime;
    }

    public String getCurveOverrideApprovalComments() {
        return curveOverrideApprovalComments;
    }

    public void setCurveOverrideApprovalComments(String curveOverrideApprovalComments) {
        this.curveOverrideApprovalComments = curveOverrideApprovalComments;
    }

    public String getCurveName() {
        return curveName;
    }

    public void setCurveName(String curveName) {
        this.curveName = curveName;
    }

    public Date getCurveOverrideApprovalDate() {
        return curveOverrideApprovalDate;
    }

    public void setCurveOverrideApprovalDate(Date curveOverrideApprovalDate) {
        this.curveOverrideApprovalDate = curveOverrideApprovalDate;
    }
}
