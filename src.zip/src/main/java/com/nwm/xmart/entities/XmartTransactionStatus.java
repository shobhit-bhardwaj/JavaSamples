package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.util.Date;

/**
 * Created by aslammh on 16/11/17.
 */
public class XmartTransactionStatus extends XmartEntity {

    private static final long serialVersionUID = -2057218577419078713L;
    @XmartAttribute
    private String transactionState;

    @XmartAttribute
    private Date transactionStateEffectiveDate;

    @XmartAttribute
    private Date transactionStateEffectiveDateTime;

    @XmartAttribute
    private String transactionStateSystemId;

    @XmartAttribute
    private String transactionStateScheme;

    public XmartTransactionStatus(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getTransactionState() {
        return transactionState;
    }

    public void setTransactionState(String transactionState) {
        this.transactionState = transactionState;
    }

    public Date getTransactionStateEffectiveDate() {
        return transactionStateEffectiveDate;
    }

    public void setTransactionStateEffectiveDate(Date transactionStateEffectiveDate) {
        this.transactionStateEffectiveDate = transactionStateEffectiveDate;
    }

    public Date getTransactionStateEffectiveDateTime() {
        return transactionStateEffectiveDateTime;
    }

    public void setTransactionStateEffectiveDateTime(Date transactionStateEffectiveDateTime) {
        this.transactionStateEffectiveDateTime = transactionStateEffectiveDateTime;
    }

    public String getTransactionStateSystemId() {
        return transactionStateSystemId;
    }

    public void setTransactionStateSystemId(String transactionStateSystemId) {
        this.transactionStateSystemId = transactionStateSystemId;
    }

    public String getTransactionStateScheme() {
        return transactionStateScheme;
    }

    public void setTransactionStateScheme(String transactionStateScheme) {
        this.transactionStateScheme = transactionStateScheme;
    }
}
