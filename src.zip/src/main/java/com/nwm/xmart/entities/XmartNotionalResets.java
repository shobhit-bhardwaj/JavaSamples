package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.NotionalReset;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLifecycleEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartNotionalResets
        extends XmartOdcEntityCollection<Transaction, TransactionLifecycleEvent, XmartNotionalReset> {

    private static final long serialVersionUID = 7463582654040274880L;
    private static final Logger logger = LoggerFactory.getLogger(XmartNotionalResets.class);

    public XmartNotionalResets(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLifecycleEvent> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLifecycleEvents(), logger,
                "Lifecycle Events not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLifecycleEvent transactionLifecycleEvent) throws XmartException {

        for (NotionalReset notionalReset : nullCollToEmpty(transactionLifecycleEvent.getNotionalResets())) {
            XmartNotionalReset xmartNotionalReset = new XmartNotionalReset(getDocumentKey());
            xmartNotionalReset.setSourceSystemEventId(transactionLifecycleEvent.getSourceSystemEventId());
            xmartNotionalReset.setEventType(getStr(transactionLifecycleEvent.getEventType()));

            //TODO confirm alternate for the deprecated method notionalReset.getLegIdentifier()
            if (nonNull(notionalReset)) {
                xmartNotionalReset.setLegIdentifier(notionalReset.getLegIdentifier());
                if (nonNull(notionalReset.getResetAmount())) {
                    xmartNotionalReset.setResetAmountValue(notionalReset.getResetAmount().getValue());
                    if (nonNull(notionalReset.getResetAmount().getCurrencyId())) {
                        xmartNotionalReset.setResetAmountCurrencyCode(
                                notionalReset.getResetAmount().getCurrencyId().getCurrencyCode());
                    }
                }
            }
            addEntity(xmartNotionalReset);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
