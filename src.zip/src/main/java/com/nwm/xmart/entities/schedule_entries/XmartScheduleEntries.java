package com.nwm.xmart.entities.schedule_entries;

import com.nwm.xmart.bean.schedule_entries.domain.XmartODCId;
import com.nwm.xmart.bean.schedule_entries.domain.XmartODCScheduleEntries;
import com.nwm.xmart.bean.schedule_entries.domain.XmartODCScheduleEntryKey;
import com.nwm.xmart.bean.schedule_entries.domain.XmartODCTransactionId;
import com.nwm.xmart.entities.XmartOdcEntityCollection;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Collections;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.DateUtil.convertLocalTime;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartScheduleEntries extends
                                  XmartOdcEntityCollection<DataFabricStreamEvent<XmartODCScheduleEntries>, XmartODCScheduleEntries, XmartScheduleEntry> {
    private static final long serialVersionUID = -6253763208344812024L;
    private static final Logger logger = LoggerFactory.getLogger(XmartScheduleEntries.class);

    public XmartScheduleEntries(long documentKey,
            DataFabricStreamEvent<XmartODCScheduleEntries> xmartODCScheduleEntriesDataFabricStreamEvent)
            throws XmartException {
        super(documentKey, xmartODCScheduleEntriesDataFabricStreamEvent);
    }

    @Override
    public Collection<XmartODCScheduleEntries> getFromEntities(
            DataFabricStreamEvent<XmartODCScheduleEntries> xmartODCScheduleEntriesDataFabricStreamEvent) {
        return Collections.singletonList(xmartODCScheduleEntriesDataFabricStreamEvent.getEventPayload());
    }

    @Override
    public void createAndAddEntity(XmartODCScheduleEntries xmartODCScheduleEntries) throws XmartException {
        XmartODCScheduleEntryKey parentKey = xmartODCScheduleEntries.getParentKey();
        if (isNull(parentKey) || isNull(parentKey.getTransactionId())) {
            return;
        }
        XmartODCId odcId = parentKey.getTransactionId();
        XmartODCTransactionId transactionId = odcId.getId();

        Long odcVersion = odcId.getOdcVersion();

        for (ScheduleEntry scheduleEntry : nullCollToEmpty(xmartODCScheduleEntries.getChildData())) {
            XmartScheduleEntry xmartScheduleEntry = new XmartScheduleEntry(getDocumentKey(),
                    parentKey.getLegIdentifier(), getStr(scheduleEntry.getScheduleEntryType()),
                    getStr(transactionId.getSourceSystemId()), transactionId.getSourceSystemTransactionId(),
                    odcVersion);

            xmartScheduleEntry.setStartDate(convertBusinessDate(scheduleEntry.getStartDate()));
            xmartScheduleEntry.setUnadjustedStartDate(convertBusinessDate(scheduleEntry.getUnadjustedStartDate()));
            xmartScheduleEntry.setEndDate(convertBusinessDate(scheduleEntry.getEndDate()));
            xmartScheduleEntry.setUnadjustedEndDate(convertBusinessDate(scheduleEntry.getUnadjustedEndDate()));
            xmartScheduleEntry.setTriggerRate(scheduleEntry.getTriggerRate());

            Amount triggerPayoutAmount = scheduleEntry.getTriggerPayout();
            if (nonNull(triggerPayoutAmount)) {
                xmartScheduleEntry.setTriggerPayoutCurrencyCode(
                        getCurrencyCode(scheduleEntry.getTriggerPayout().getCurrencyId()));
                xmartScheduleEntry.setTriggerPayoutValue(scheduleEntry.getTriggerPayout().getValue());
            }

            xmartScheduleEntry.setPayoutStyle(getStr(scheduleEntry.getPayoutStyle()));
            xmartScheduleEntry.setPaymentDate(convertBusinessDate(scheduleEntry.getPaymentDate()));

            BarrierScheduleEntry barrierScheduleEntry = scheduleEntry.getBarrierScheduleEntry();
            if (nonNull(barrierScheduleEntry)) {
                xmartScheduleEntry.setBarrierScheduleEntryBarrierType(getStr(barrierScheduleEntry.getBarrierType()));

                BarrierLevel entryLower = barrierScheduleEntry.getLower();
                if (nonNull(entryLower)) {
                    xmartScheduleEntry.setBarrierScheduleEntryLowerBarrierDirectionType(
                            getStr(entryLower.getBarrierDirectionType()));
                    xmartScheduleEntry
                            .setBarrierScheduleEntryLowerAdjustedTriggerLevel(entryLower.getAdjustedTriggerLevel());
                    xmartScheduleEntry
                            .setBarrierScheduleEntryLowerBarrierTriggerLevel(entryLower.getBarrierTriggerLevel());
                    xmartScheduleEntry
                            .setBarrierScheduleEntryLowerKnockConditionType(getStr(entryLower.getKnockConditionType()));
                }

                BarrierLevel upper = barrierScheduleEntry.getUpper();
                if (nonNull(upper)) {
                    xmartScheduleEntry
                            .setBarrierScheduleEntryUpperBarrierDirectionType(getStr(upper.getBarrierDirectionType()));
                    xmartScheduleEntry
                            .setBarrierScheduleEntryUpperAdjustedTriggerLevel(upper.getAdjustedTriggerLevel());
                    xmartScheduleEntry.setBarrierScheduleEntryUpperBarrierTriggerLevel(upper.getBarrierTriggerLevel());
                    xmartScheduleEntry
                            .setBarrierScheduleEntryUpperKnockConditionType(getStr(upper.getKnockConditionType()));
                }
            }

            AsianAveragingScheduleEntry asianAveragingScheduleEntry = scheduleEntry.getAsianAveragingScheduleEntry();
            if (nonNull(asianAveragingScheduleEntry)) {
                xmartScheduleEntry.setAsianAveragingScheduleEntryAveragingInOut(
                        getStr(asianAveragingScheduleEntry.getAveragingInOut()));
                xmartScheduleEntry.setAsianAveragingScheduleEntryAverageRateWeighting(
                        asianAveragingScheduleEntry.getAverageRateWeighting());
            }
            CalculationPeriodScheduleEntry calPeriodScheduleEntry = scheduleEntry.getCalculationPeriodScheduleEntry();
            if (nonNull(calPeriodScheduleEntry)) {
                xmartScheduleEntry
                        .setCalculationPeriodScheduleDigitalPayoutRate(calPeriodScheduleEntry.getDigitalPayoutRate());
                xmartScheduleEntry.setCalculationPeriodScheduleFixingDate(
                        convertBusinessDate(calPeriodScheduleEntry.getFixingDate()));
                xmartScheduleEntry
                        .setCalculationPeriodScheduleFixingDateTime(calPeriodScheduleEntry.getFixingDateTime());
                xmartScheduleEntry
                        .setCalculationPeriodScheduleNonStandardPeriod(calPeriodScheduleEntry.getNonStandardPeriod());
                xmartScheduleEntry.setCalculationPeriodScheduleNonStandardPeriodComment(
                        calPeriodScheduleEntry.getNonStandardPeriodComment());
                xmartScheduleEntry.setCalculationPeriodScheduleEntryRate(calPeriodScheduleEntry.getRate());
                xmartScheduleEntry.setCalculationPeriodScheduleEntrySpread(calPeriodScheduleEntry.getSpread());
            }

            NotionalScheduleEntry notionalScheduleEntry = scheduleEntry.getNotionalScheduleEntry();
            if (nonNull(notionalScheduleEntry)) {
                Amount stepAmount = notionalScheduleEntry.getStepAmount();
                if (nonNull(stepAmount)) {
                    xmartScheduleEntry.setNotionalScheduleEntryStepAmountCurrencyCode(
                            getCurrencyCode(stepAmount.getCurrencyId()));
                    xmartScheduleEntry.setNotionalScheduleEntryStepAmountValue(stepAmount.getValue());
                }
                xmartScheduleEntry
                        .setNotionalScheduleEntrystepDirection(getStr(notionalScheduleEntry.getStepDirection()));
            }

            if (nonNull(scheduleEntry.getCapRateScheduleEntry())) {
                xmartScheduleEntry.setCapRateScheduleEntryRate(scheduleEntry.getCapRateScheduleEntry().getRate());
            }

            xmartScheduleEntry.setPayoutStyle(getStr(scheduleEntry.getPayoutStyle()));

            if (nonNull(scheduleEntry.getFloorRateScheduleEntry())) {
                xmartScheduleEntry.setFloorRateScheduleEntryRate(scheduleEntry.getFloorRateScheduleEntry().getRate());
            }

            QuantityScheduleEntry quantityScheduleEntry = scheduleEntry.getQuantityScheduleEntry();
            if (nonNull(quantityScheduleEntry)) {
                xmartScheduleEntry.setQuantityScheduleEntryStepQuantity(quantityScheduleEntry.getStepQuantity());
                xmartScheduleEntry.setQuantityUnitOfMeasure(getStr(quantityScheduleEntry.getQuantityUnitOfMeasure()));
                xmartScheduleEntry
                        .setQuantityScheduleEntryStepDirection(getStr(quantityScheduleEntry.getStepDirection()));

                if (nonNull(quantityScheduleEntry.getUnitPrice())) {
                    if (nonNull(quantityScheduleEntry.getUnitPrice().getAmount())) {
                        xmartScheduleEntry.setQuantityScheduleEntryCurrencyCode(
                                getCurrencyCode(quantityScheduleEntry.getUnitPrice().getAmount().getCurrencyId()));
                        xmartScheduleEntry.setQuantityScheduleEntryValue(
                                quantityScheduleEntry.getUnitPrice().getAmount().getValue());
                    }

                    xmartScheduleEntry
                            .setQuantityScheduleEntryPercentage(quantityScheduleEntry.getUnitPrice().getPercentage());
                    xmartScheduleEntry
                            .setQuantityScheduleEntryType(getStr(quantityScheduleEntry.getUnitPrice().getType()));
                    xmartScheduleEntry.setQuantityScheduleEntryPrice(quantityScheduleEntry.getUnitPrice().getPrice());
                    xmartScheduleEntry
                            .setQuantityScheduleEntryCurrency(quantityScheduleEntry.getUnitPrice().getCurrency());
                }
            }

            if (nonNull(scheduleEntry.getInterestRateScheduleEntry())) {
                xmartScheduleEntry
                        .setInterestRateScheduleEntryRate(scheduleEntry.getInterestRateScheduleEntry().getRate());
            }

            xmartScheduleEntry.setSourceSystemEventId(scheduleEntry.getSourceSystemEventId());
            xmartScheduleEntry.setFixingDate(convertBusinessDate(scheduleEntry.getFixingDate()));
            if (nonNull(scheduleEntry.getFixingTime())) {
                xmartScheduleEntry.setFixingTimeCentre(scheduleEntry.getFixingTime().getCentre());

                BusinessTime _businessTime = nonNull(scheduleEntry.getFixingTime().getTime()) ?
                                             scheduleEntry.getFixingTime().getTime() : null;
                if (nonNull(_businessTime)) {
                    xmartScheduleEntry.setFixingTimeTime(convertLocalTime(_businessTime.getLocalTime()));
                }
            }

            xmartScheduleEntry.setScheduleEntriesRate(scheduleEntry.getRate());
            xmartScheduleEntry.setScheduleEntriesSpread(scheduleEntry.getSpread());
            xmartScheduleEntry.setRateMultiplier(scheduleEntry.getRateMultiplier());

            addEntity(xmartScheduleEntry);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}