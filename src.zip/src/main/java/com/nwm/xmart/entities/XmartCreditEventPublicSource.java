package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartCreditEventPublicSource extends XmartEntity {

    private static final long serialVersionUID = -6604514222165135327L;

    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String publicSourceName;

    public XmartCreditEventPublicSource(long documentKey, String transactionLegIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = transactionLegIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getPublicSourceName() {
        return publicSourceName;
    }

    public void setPublicSourceName(String publicSourceName) {
        this.publicSourceName = publicSourceName;
    }
}
