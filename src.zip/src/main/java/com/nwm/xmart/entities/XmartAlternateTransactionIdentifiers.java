package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.rbs.odc.access.domain.AlternateTransactionId;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.XmartUtil.getStr;

/**
 * Created by aslammh on 13/11/17.
 */
public class XmartAlternateTransactionIdentifiers
        extends XmartOdcEntityCollection<Transaction, AlternateTransactionId, XmartAlternateTransactionIdentifier> {
    private static final long serialVersionUID = -3611606458176239995L;
    private static final Logger logger = LoggerFactory.getLogger(XmartAlternateTransactionIdentifiers.class);

    public XmartAlternateTransactionIdentifiers(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<AlternateTransactionId> getFromEntities(Transaction transaction) {
        return CollectionsUtil.nullCollToEmpty(transaction.getAlternateTransactionIdentifiers());
    }

    @Override
    public void createAndAddEntity(AlternateTransactionId alternateTransactionId) throws XmartException {
        XmartAlternateTransactionIdentifier xmartAlternateTransactionIdentifier
                = new XmartAlternateTransactionIdentifier(getDocumentKey());

        xmartAlternateTransactionIdentifier
                .setAlternateTransactionId(alternateTransactionId.getAlternateTransactionId());
        xmartAlternateTransactionIdentifier
                .setAlternateIdDescription(getStr(alternateTransactionId.getAlternateIdDescription()));
        xmartAlternateTransactionIdentifier
                .setAlternateIdSourceSystemId(getStr(alternateTransactionId.getAlternateIdSourceSystemId()));

        addEntity(xmartAlternateTransactionIdentifier);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
