package com.nwm.xmart.entities.cashflows;

import com.nwm.xmart.entities.XmartOdcEntityCollection;
import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Collections;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

/**
 * @deprecated Cashflows are loaded with configurable mappings
 */
@Deprecated
public class XmartCashFlows extends XmartOdcEntityCollection<Cashflows, Cashflows, XmartCashFlow> {
    private static final long serialVersionUID = -4886737990838415915L;
    private static final Logger logger = LoggerFactory.getLogger(XmartCashFlows.class);

    Long odcVersion;

    public XmartCashFlows(long documentKey, Cashflows cashflows, Long odcVersion) throws XmartException {
        super(documentKey, cashflows);
        this.odcVersion = odcVersion;
    }

    @Override
    public Collection<Cashflows> getFromEntities(Cashflows cashflows) {
        return Collections.singletonList(cashflows);
    }

    @Override
    public void createAndAddEntity(Cashflows cashflows) throws XmartException {
        String sourceSystemTransactionId = null;
        String sourceSystemId = null;
        if (nonNull(cashflows.getTransactionId())) {
            sourceSystemTransactionId = cashflows.getTransactionId().getSourceSystemTransactionId();
            sourceSystemId = getStr(cashflows.getTransactionId().getSourceSystemId());
        }

        for (Cashflow cashflow : nullCollToEmpty(cashflows.getCashflows())) {
            //TODO document Key needs to be ignored.
            XmartCashFlow xmartCashFlow = new XmartCashFlow(getDocumentKey());

            xmartCashFlow.setOdcVersion(odcVersion);
            xmartCashFlow.setSourceSystemTransactionId(sourceSystemTransactionId);
            xmartCashFlow.setSourceSystemId(sourceSystemId);

            Amount amount = cashflow.getAmount();
            if (nonNull(amount)) {
                xmartCashFlow.setCashflowAmountCurrencyCode(getCurrencyCode(amount.getCurrencyId()));
                xmartCashFlow.setCashflowAmountValue(amount.getValue());
            }

            xmartCashFlow.setEffectiveDate(convertBusinessDate(cashflow.getEffectiveDate()));

            AdjustableDate effectiveDt = cashflow.getEffectiveDt();
            if (nonNull(effectiveDt)) {
                xmartCashFlow.setEffectiveDtAdjustedDate(convertBusinessDate(effectiveDt.getAdjustedDate()));
                xmartCashFlow.setEffectiveDtUnadjustedDate(convertBusinessDate(effectiveDt.getUnadjustedDate()));
            }

            xmartCashFlow.setEventDateTime(cashflow.getEventDateTime());
            xmartCashFlow.setEstimated(cashflow.getIsEstimated());
            xmartCashFlow.setLegIdentifier(cashflow.getLegIdentifier());

            TradingParty payer = cashflow.getPayer();
            if (nonNull(payer)) {
                if (nonNull(payer.getSourceBookId())) {
                    xmartCashFlow.setPayerSourceSystemBookId(payer.getSourceBookId().getSourceSystemBookId());
                    xmartCashFlow.setPayerBookSourceSystemId(getStr(payer.getSourceBookId().getBookSourceSystemId()));
                }
                if (nonNull(payer.getTradingCounterpartyId())) {
                    xmartCashFlow.setPayerPartyClassification(
                            getStr(payer.getTradingCounterpartyId().getPartyClassification()));
                    xmartCashFlow.setPayerPartyReference(payer.getTradingCounterpartyId().getPartyReference());
                }
            }

            xmartCashFlow.setPaymentType(getStr(cashflow.getPaymentType()));

            TradingParty receiver = cashflow.getReceiver();
            if (nonNull(receiver)) {
                if (nonNull(receiver.getSourceBookId())) {
                    xmartCashFlow.setReceiverSourceSystemBookId(receiver.getSourceBookId().getSourceSystemBookId());
                    xmartCashFlow
                            .setReceiverBookSourceSystemId(getStr(receiver.getSourceBookId().getBookSourceSystemId()));
                }

                if (nonNull(receiver.getTradingCounterpartyId())) {
                    xmartCashFlow.setReceiverPartyClassification(
                            getStr(receiver.getTradingCounterpartyId().getPartyClassification()));
                    xmartCashFlow.setReceiverPartyReference(receiver.getTradingCounterpartyId().getPartyReference());
                }
            }

            xmartCashFlow.setSourceSystemEventId(cashflow.getSourceSystemEventId());
            xmartCashFlow.setSettlementMessageRequired(cashflow.getSettlementMessageRequired());

            if (nonNull(cashflow.getBrokerage()) && nonNull(cashflow.getBrokerage().getRcAmount())) {
                xmartCashFlow.setRcAmountValue(cashflow.getBrokerage().getRcAmount().getValue());
                xmartCashFlow.setRcAmountCurrencyCode(
                        getCurrencyCode(cashflow.getBrokerage().getRcAmount().getCurrencyId()));
            }

            addEntity(xmartCashFlow);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
