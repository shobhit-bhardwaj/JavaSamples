package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.DateUtil.convertLocalTime;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartOptionFeatures extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartOptionFeature> {

    private static final long serialVersionUID = 3495922000442016212L;
    private static final Logger logger = LoggerFactory.getLogger(XmartOptionFeatures.class);

    public XmartOptionFeatures(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        XmartOptionFeature xmartOptionFeature = new XmartOptionFeature(getDocumentKey(),
                transactionLeg.getLegIdentifier());

        if (nonNull(transactionLeg.getOptionFeature())) {
            OptionFeature optionFeature = transactionLeg.getOptionFeature();
            xmartOptionFeature.setOptionExerciseStyle(getStr(optionFeature.getOptionExerciseStyle()));
            xmartOptionFeature.setOptionType(getStr(optionFeature.getOptionType()));
            //TODO find alternate of deprecated method
            xmartOptionFeature.setEarliestExerciseTime(optionFeature.getEarliestExerciseTime());
            xmartOptionFeature.setExpiryTime(optionFeature.getExpiryTime());
            xmartOptionFeature.setAmericanTouchCondition(getStr(optionFeature.getAmericanTouchCondition()));
            xmartOptionFeature.setEuropeanTriggerCondition(getStr(optionFeature.getEuropeanTriggerCondition()));
            xmartOptionFeature.setDeliveryStyle(getStr(optionFeature.getDeliveryStyle()));
            xmartOptionFeature.setOptionEntitlement(optionFeature.getOptionEntitlement());
            xmartOptionFeature.setPremiumQuoteBasis(getStr(optionFeature.getPremiumQuoteBasis()));
            xmartOptionFeature.setPremiumPercentage(optionFeature.getPremiumPercentage());
            xmartOptionFeature.setStrikePercentage(optionFeature.getStrikePercentage());
            xmartOptionFeature.setStrikePrice(optionFeature.getStrikePrice());
            xmartOptionFeature.setStrikeQuoteBasis(getStr(optionFeature.getStrikeQuoteBasis()));
            xmartOptionFeature.setStrikeSpread(optionFeature.getStrikeSpread());
            xmartOptionFeature.setDeltaExchangeApplicable(optionFeature.getDeltaExchangeApplicable());
            xmartOptionFeature.setOptionStraddle(optionFeature.getOptionStraddle());
            xmartOptionFeature.setFallbackExercise(optionFeature.getFallbackExercise());
            xmartOptionFeature.setFollowUpConfirmation(optionFeature.getFollowUpConfirmation());

            if (nonNull(optionFeature.getOptionEarliestExerciseTime())) {
                BusinessCentreTime optionEarliestExerciseTime = optionFeature.getOptionEarliestExerciseTime();
                xmartOptionFeature.setOptionEarliestExerciseTimeCentre(optionEarliestExerciseTime.getCentre());

                if (nonNull(optionEarliestExerciseTime.getTime())) {
                    xmartOptionFeature.setOptionEarliestExerciseTimeTime(
                            convertLocalTime(optionEarliestExerciseTime.getTime().getLocalTime()));
                }
            }

            if (nonNull(optionFeature.getLatestExerciseTime())) {
                BusinessCentreTime latestExerciseTime = optionFeature.getLatestExerciseTime();
                xmartOptionFeature.setLatestExerciseTimeCentre(latestExerciseTime.getCentre());

                if (nonNull(latestExerciseTime.getTime())) {
                    xmartOptionFeature
                            .setLatestExerciseTimeTime(convertLocalTime(latestExerciseTime.getTime().getLocalTime()));
                }
            }

            if (nonNull(optionFeature.getOptionExpiryTime())) {
                BusinessCentreTime optionExpiryTime = optionFeature.getOptionExpiryTime();
                xmartOptionFeature.setOptionExpiryTimeCentre(optionExpiryTime.getCentre());

                if (nonNull(optionExpiryTime.getTime())) {
                    xmartOptionFeature
                            .setOptionExpiryTimeTime(convertLocalTime(optionExpiryTime.getTime().getLocalTime()));
                }
            }

            if (nonNull(optionFeature.getExerciseFrequency())) {
                Interval exerciseFrequency = optionFeature.getExerciseFrequency();
                xmartOptionFeature.setPeriodMultiplier(exerciseFrequency.getPeriodMultiplier());
                xmartOptionFeature.setPeriodScheme(getStr(exerciseFrequency.getPeriodScheme()));
            }

            if (nonNull(optionFeature.getRebateAmount())) {
                Amount rebateAmount = optionFeature.getRebateAmount();
                xmartOptionFeature.setRebateAmountValue(rebateAmount.getValue());
                if (nonNull(rebateAmount.getCurrencyId())) {
                    xmartOptionFeature.setRebateAmountCurrencyCode(rebateAmount.getCurrencyId().getCurrencyCode());
                }
            }

            if (nonNull(optionFeature.getStrikePriceCurrencyId())) {
                CurrencyId strikePriceCurrencyId = optionFeature.getStrikePriceCurrencyId();
                xmartOptionFeature.setStrikePriceCurrencyCode(strikePriceCurrencyId.getCurrencyCode());
            }

            if (nonNull(optionFeature.getOptionEarlyTermination())) {
                OptionalEarlyTermination optionEarlyTermination = optionFeature.getOptionEarlyTermination();
                xmartOptionFeature
                        .setOptionalEarlyTerminationCalculationAgent(optionEarlyTermination.getCalculationAgent());
            }
            xmartOptionFeature.setEarliestExerciseDate(optionFeature.getEarliestExerciseTime());
            xmartOptionFeature.setExpiryDate(optionFeature.getExpiryTime());
            xmartOptionFeature.setCalculationAgent(getStr(optionFeature.getCalculationAgent()));

            xmartOptionFeature.setCalledDate(convertBusinessDate(optionFeature.getCalledDate()));
            xmartOptionFeature.setFirstCallableDate(convertBusinessDate(optionFeature.getFirstCallableDate()));
            xmartOptionFeature.setFinalMaturityDate(convertBusinessDate(optionFeature.getFinalMaturityDate()));

            addEntity(xmartOptionFeature);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}















