package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartExternalTransactionIdentifier extends XmartEntity {

    private static final long serialVersionUID = 8415794333615529344L;
    @XmartAttribute
    private String alternateIdDescription;

    @XmartAttribute
    private String alternateTransactionId;

    @XmartAttribute
    private String partyClassification;

    @XmartAttribute
    private String partyReference;

    public XmartExternalTransactionIdentifier(Long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getAlternateIdDescription() {
        return alternateIdDescription;
    }

    public void setAlternateIdDescription(String alternateIdDescription) {
        this.alternateIdDescription = alternateIdDescription;
    }

    public String getAlternateTransactionId() {
        return alternateTransactionId;
    }

    public void setAlternateTransactionId(String alternateTransactionId) {
        this.alternateTransactionId = alternateTransactionId;
    }

    public String getPartyClassification() {
        return partyClassification;
    }

    public void setPartyClassification(String partyClassification) {
        this.partyClassification = partyClassification;
    }

    public String getPartyReference() {
        return partyReference;
    }

    public void setPartyReference(String partyReference) {
        this.partyReference = partyReference;
    }
}
