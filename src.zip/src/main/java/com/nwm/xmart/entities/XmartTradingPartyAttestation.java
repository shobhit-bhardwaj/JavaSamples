package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTradingPartyAttestation extends XmartEntity {
    private static final long serialVersionUID = -6692937829749094896L;

    @XmartAttribute
    private String tradingPartyAttestationValue;

    @XmartAttribute
    private String tradingPartyId;

    @XmartAttribute
    private String tradingPartyIdPath;

    public XmartTradingPartyAttestation(long docKey) throws XmartException {
        super(docKey);
    }

    public String getTradingPartyAttestationValue() {
        return tradingPartyAttestationValue;
    }

    public void setTradingPartyAttestationValue(String tradingPartyAttestationValue) {
        this.tradingPartyAttestationValue = tradingPartyAttestationValue;
    }

    public String getTradingPartyId() {
        return tradingPartyId;
    }

    public void setTradingPartyId(String tradingPartyId) {
        this.tradingPartyId = tradingPartyId;
    }

    public String getTradingPartyIdPath() {
        return tradingPartyIdPath;
    }

    public void setTradingPartyIdPath(String tradingPartyIdPath) {
        this.tradingPartyIdPath = tradingPartyIdPath;
    }
}
