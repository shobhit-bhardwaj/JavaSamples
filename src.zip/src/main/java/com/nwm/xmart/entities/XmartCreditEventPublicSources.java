package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.CreditDerivativeLeg;
import com.rbs.odc.access.domain.CreditEventPublicSource;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static java.util.Objects.isNull;

public class XmartCreditEventPublicSources
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartCreditEventPublicSource> {
    private static final Logger logger = LoggerFactory.getLogger(XmartCreditEventPublicSource.class);
    private static final long serialVersionUID = -7123116901901618010L;

    public XmartCreditEventPublicSources(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        addXmartCreditEventPublicSources(getDocumentKey(), transactionLeg);
    }

    private void addXmartCreditEventPublicSources(long documentKey, TransactionLeg transactionLeg)
            throws XmartException {
        if (isNull(transactionLeg)) {
            return;
        }

        CreditDerivativeLeg creditDerivativeLeg = transactionLeg.getCreditDerivativeLeg();
        if (isNull(creditDerivativeLeg)) {
            return;
        }

        for (CreditEventPublicSource creditEventPublicSource : nullCollToEmpty(
                creditDerivativeLeg.getCreditEventPublicSources())) {
            if (isNull(creditEventPublicSource)) {
                continue;
            }

            String publicSourceName = creditEventPublicSource.getPublicSourceName();

            XmartCreditEventPublicSource xmartCreditEventPublicSource = new XmartCreditEventPublicSource(documentKey,
                    transactionLeg.getLegIdentifier());
            xmartCreditEventPublicSource.setPublicSourceName(publicSourceName);
            addEntity(xmartCreditEventPublicSource);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
