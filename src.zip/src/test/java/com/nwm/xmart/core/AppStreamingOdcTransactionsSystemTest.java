package com.nwm.xmart.core;

import com.nwm.xmart.bean.BeanProvider;
import com.nwm.xmart.bean.SystemTestBeanProvider;
import com.nwm.xmart.processor.OdcTransactionIntegrationTestProcessor;
import com.nwm.xmart.streaming.common.job.StreamJob;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppStreamingOdcTransactionsSystemTest {

    private static final Logger logger = LoggerFactory.getLogger(AppStreamingOdcTransactionsSystemTest.class);
    String args[] = { "src\\test\\resources\\TestOdcTransactionFlinkJob.properties" };

    @Test
    public void odcTransactionIntegrationTest() throws Exception {

        BeanProvider beanProvider = new SystemTestBeanProvider();
        // StreamJob implementation can override any abstract method as long as it calls super() first
        StreamJob streamJob = new XmartStreamingJob(beanProvider, OdcTransactionIntegrationTestProcessor.class);
        try {
//            streamJob.run(args);
        } catch (Exception e) {
            Assertions.fail("System Test Failed" + e.getMessage());
            e.printStackTrace();
        }
    }
}
