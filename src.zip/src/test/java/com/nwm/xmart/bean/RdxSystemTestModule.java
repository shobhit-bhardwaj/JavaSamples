package com.nwm.xmart.bean;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;
import com.nwm.xmart.database.dao.LoggerDao;
import com.nwm.xmart.database.dao.SqlServerDao;
import com.nwm.xmart.database.dao.XmartDao;
import com.nwm.xmart.source.rdx.RdxIntegrationTestSource;
import com.nwm.xmart.sink.LoggerSink;
import com.nwm.xmart.sink.XmartSink;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;

/**
 * Created by aslammh on 22/09/17.
 */
public class RdxSystemTestModule extends AbstractModule {

    @Override
    protected void configure() {

        bind(XmartDao.class).annotatedWith(Names.named("LoggerDao")).to(LoggerDao.class);

        bind(XmartDao.class).annotatedWith(Names.named("SqlServerDao")).to(SqlServerDao.class);

        bind(XmartSink.class).annotatedWith(Names.named("LoggerSink")).to(LoggerSink.class);

        bind(XmartSink.class).annotatedWith(Names.named("BdxSink")).to(LoggerSink.class);

        bind(RichParallelSourceFunction.class).annotatedWith(Names.named("TestSource")).to(RdxIntegrationTestSource.class);
    }

}
