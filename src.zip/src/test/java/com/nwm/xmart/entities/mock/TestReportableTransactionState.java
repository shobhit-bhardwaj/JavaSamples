package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.RegimeImpactType;
import com.rbs.odc.access.domain.ReportableTransactionState;
import com.rbs.odc.access.domain.TransactionState;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestReportableTransactionState implements ReportableTransactionState {
    private RegimeImpactType regimeImpactType;
    private TransactionState reportableTransactionState;
    private String reportableTransactionReference;

    public TestReportableTransactionState() {
        try {
            regimeImpactType = RegimeImpactType.valueOf(getRndInt() % RegimeImpactType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("RegimeImpactType creation failed Using default value" + e.getMessage());
            regimeImpactType = RegimeImpactType.NULL;
        }

        try {
            reportableTransactionState = TransactionState.valueOf(getRndInt() % TransactionState.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("TransactionState creation failed Using default value" + e.getMessage());
            reportableTransactionState = TransactionState.NULL;
        }

        this.reportableTransactionReference = getRandomString();
    }

    @Override
    public TransactionState getReportableTransactionState() {
        return reportableTransactionState;
    }

    @Override
    public String getReportableTransactionReference() {
        return reportableTransactionReference;
    }

    @Override
    public RegimeImpactType getRegimeImpactType() {
        return regimeImpactType;
    }

    @Override
    public String toString() {
        return "TestReportableTransactionState{" + "regimeImpactType=" + regimeImpactType
                + ", reportableTransactionState=" + reportableTransactionState + ", reportableTransactionReference='"
                + reportableTransactionReference + '\'' + '}';
    }
}
