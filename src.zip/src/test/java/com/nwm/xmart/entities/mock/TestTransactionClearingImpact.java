package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.FrontLoadingCategory;
import com.rbs.odc.access.domain.TransactionClearingImpact;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionClearingImpact implements TransactionClearingImpact {
    private String mandatoryClearingException;
    private FrontLoadingCategory frontLoadingCategory;
    private String clearingExemptionOverrideReason;

    public TestTransactionClearingImpact() {
        mandatoryClearingException = getRandomString();

        try {
            frontLoadingCategory = FrontLoadingCategory.valueOf(getRndInt() % FrontLoadingCategory.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("TestTransactionClearingImpact creation failed Using default value" + e.getMessage());
            frontLoadingCategory = FrontLoadingCategory.NULL;
        }

        clearingExemptionOverrideReason = getRandomString();
    }

    @Override
    public String getMandatoryClearingException() {
        return mandatoryClearingException;
    }

    @Override
    public FrontLoadingCategory getFrontLoadingCategory() {
        return frontLoadingCategory;
    }

    @Override
    public String getClearingExemptionOverrideReason() {
        return clearingExemptionOverrideReason;
    }
}
