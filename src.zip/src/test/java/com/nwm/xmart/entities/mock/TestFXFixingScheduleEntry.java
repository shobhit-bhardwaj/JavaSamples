package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.ForeignKey;

import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

class TestFXFixingScheduleEntry implements FXFixingScheduleEntry {

    private Currency Currency1 = new TestCurrency();
    private CurrencyId Currency1Id = new TestCurrencyId();
    private Currency Currency2 = new TestCurrency();
    private CurrencyId Currency2Id = new TestCurrencyId();
    private QuoteBasis quoteBasis;
    private BusinessDate FixingDate = new TestBusinessDate();
    private BusinessCentreTime FixingTime = new TestBusinessCentreTime();
    private String InformationSource = getRandomString();
    private String InformationSourcePage = getRandomString();
    private Collection<ForeignKey> ForeignKeys;

    TestFXFixingScheduleEntry() {

        try {
            quoteBasis = QuoteBasis.valueOf(getRndInt() % QuoteBasis.values().size());
        } catch (UnknownEnumerationValueException e) {
            quoteBasis = QuoteBasis.NULL;
        }
    }

    @Override
    public String toString() {
        return "TestFXFixingScheduleEntry{Currency1Id=" + Currency1Id + ", Currency2Id=" + Currency2Id + ", quoteBasis="
                + quoteBasis + ", FixingDate=" + FixingDate + ", FixingTime=" + FixingTime + ", InformationSource='"
                + InformationSource + ", InformationSourcePage='" + InformationSourcePage;
    }

    @Override
    public Currency getCurrency1() {
        return Currency1;
    }

    public CurrencyId getCurrency1Id() {
        return Currency1Id;
    }

    @Override
    public Currency getCurrency2() {
        return Currency2;
    }

    @Override
    public CurrencyId getCurrency2Id() {
        return Currency2Id;
    }

    @Override
    public QuoteBasis getQuoteBasis() {
        return quoteBasis;
    }

    @Override
    public BusinessDate getFixingDate() {
        return FixingDate;
    }

    @Override
    public BusinessCentreTime getFixingTime() {
        return FixingTime;
    }

    @Override
    public String getInformationSource() {
        return InformationSource;
    }

    @Override
    public String getInformationSourcePage() {
        return InformationSourcePage;
    }

    @Override
    public Collection<ForeignKey> getForeignKeys() {
        return ForeignKeys;
    }

    @Override
    public int compareTo(FXFixingScheduleEntry o) {
        throw new RuntimeException();
    }
}
