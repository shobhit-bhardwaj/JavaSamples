package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestIncomeStreamLeg implements IncomeStreamLeg {

    private String initialPriceMethod = getRandomString();
    private UnitPrice initialPrice = new TestUnitPrice();
    private UnitPrice finalPrice = new TestUnitPrice();
    private String finalPriceMethod = getRandomString();
    private PartyId referenceEntityId = new TestPartyId();
    private Party referenceEntity;
    private Amount notionalAmount = new TestAmount();
    private RateType fixedOrFloatingRateType;

    TestIncomeStreamLeg() {
        try {
            fixedOrFloatingRateType = RateType.valueOf(getRndInt() % RateType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            fixedOrFloatingRateType = RateType.NULL;
        }
    }

    @Override
    public String getInitialPriceMethod() {
        return initialPriceMethod;
    }

    @Override
    public UnitPrice getInitialPrice() {
        return initialPrice;
    }

    @Override
    public String getFinalPriceMethod() {
        return finalPriceMethod;
    }

    @Override
    public UnitPrice getFinalPrice() {
        return finalPrice;
    }

    @Override
    public PartyId getReferenceEntityId() {
        return referenceEntityId;
    }

    @Override
    public Party getReferenceEntity() {
        return referenceEntity;
    }

    @Override
    public Amount getNotionalAmount() {
        return notionalAmount;
    }

    @Override
    public RateType getFixedOrFloatingRateType() {
        return fixedOrFloatingRateType;
    }
}
