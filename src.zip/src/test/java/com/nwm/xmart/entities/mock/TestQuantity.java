package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Quantity;
import com.rbs.odc.access.domain.QuantityTypeScheme;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestQuantity implements Quantity {
    private QuantityTypeScheme type;
    private BigDecimal value;

    public TestQuantity() {
        try {
            type = QuantityTypeScheme.valueOf(getRndInt() % QuantityTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("QuantityTypeScheme creation failed Using default value" + e.getMessage());
            type = QuantityTypeScheme.NULL;
        }
        value = new BigDecimal(getRndInt());
    }

    @Override
    public QuantityTypeScheme getType() {
        return type;
    }

    @Override
    public BigDecimal getValue() {
        return value;
    }
}
