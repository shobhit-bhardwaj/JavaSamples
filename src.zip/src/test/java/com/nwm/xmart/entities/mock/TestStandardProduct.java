package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BookReportObligation;
import com.rbs.odc.access.domain.StandardProduct;
import com.rbs.odc.access.domain.SystemId;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestStandardProduct implements StandardProduct {

    String standardProductDescription = getRandomString();
    String standardProductId = getRandomString();
    SystemId standardProductSourceSystemId = SystemId.PabFX;

    @Override
    public String getDescription() {
        return standardProductDescription;
    }

    @Override
    public String getProductId() {
        return standardProductId;
    }

    @Override
    public SystemId getProductSourceSystemId() {
        return standardProductSourceSystemId;
    }

}
