package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Interval;
import com.rbs.odc.access.domain.Period;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestInterval implements Interval {
    Integer periodMultiplier;
    Period periodScheme;

    public TestInterval() {
        periodMultiplier = getRndInt();
        try {
            periodScheme = Period.valueOf(getRndInt() % Period.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Period creation failed Using default value" + e.getMessage());
            periodScheme = Period.NULL;
        }
    }

    @Override
    public Integer getPeriodMultiplier() {
        return periodMultiplier;
    }

    @Override
    public Period getPeriodScheme() {
        return periodScheme;
    }
}
