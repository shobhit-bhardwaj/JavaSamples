//package com.nwm.xmart.entities.mdx;
//
//import com.nwm.xmart.entities.XmartEntitiesBaseTest;
//import com.nwm.xmart.exception.XmartException;
//import com.nwm.xmart.exception.XmartMandatoryAttributeMissingException;
//import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Tag;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import rbs.gbm.mdx.webService.impl.MdxDateTime;
//import rbs.gbm.mdx.webService.impl.MdxTimePointContent;
//
//import java.math.BigDecimal;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.powermock.api.mockito.PowerMockito.when;
//
//class XmartMdxTimeSeriesEsmasTest extends XmartEntitiesBaseTest {
//    @Mock
//    MdxDocumentEvent mdxDocumentEvent;
//    @Mock
//    MdxTimePointContent mdxTimePointContent;
//
//    private double value;
//    private MdxDateTime logicalTime;
//    private Date writeTime;
//    private Integer version;
//    private String status;
//    private Map<String, String> metadata;
//    private String instrumentName;
//
//    private XmartMdxTimeSeriesEsmas xmartMdxTimeSeriesEsmas;
//
//    private static void xmlCheck(XmartMdxTimeSeriesEsmas xmartMdxTimeSeriesEsmas) {
//        String xml = validateXML(xmartMdxTimeSeriesEsmas, XMLEntityType.XmartMdxTimeSeriesEsmas);
//        xmartMdxTimeSeriesEsmas.getEntity()
//                               .forEach(xmartMdxTimeSeriesEsma -> validateXmlValues(xmartMdxTimeSeriesEsma, xml));
//    }
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.initMocks(this);
//        this.version = getRndInt();
//        this.status = getRandomString();
//        this.writeTime = getRandomDate();
//        this.value = getRndDouble();
//        this.instrumentName = getRandomString();
//
//        metadata = new HashMap<>();
//        metadata.put("TradingVenues", getRandomString());
//        metadata.put("FirstTradeDate", getRandomString());
//        metadata.put("Issuer", getRandomString());
//    }
//
//    private void mock() {
//        when(mdxDocumentEvent.getMdxTimePointContent()).thenReturn(mdxTimePointContent);
//        when(mdxDocumentEvent.getIdentifier()).thenReturn("timeseries/esma/shared/mdx/" + instrumentName + "/xxxx");
//        when(mdxTimePointContent.getVersion()).thenReturn(version);
//        when(mdxTimePointContent.getStatus()).thenReturn(status);
//        when(mdxTimePointContent.getWriteTime()).thenReturn(writeTime);
//        when(mdxTimePointContent.getValue()).thenReturn(value);
//        when(mdxTimePointContent.getMetadata()).thenReturn(metadata);
//    }
//
//    private void create() throws XmartException {
//        xmartMdxTimeSeriesEsmas = new XmartMdxTimeSeriesEsmas(documentKey, mdxDocumentEvent);
//    }
//
//    private void verifyMappigValues(List<XmartMdxTimeSeriesEsma> xmartMdxTimeSeriesEsmas,
//            MdxTimePointContent mdxTimePointContent) {
//        XmartMdxTimeSeriesEsma xmartMdxTimeSeriesEsma = xmartMdxTimeSeriesEsmas.get(0);
//
//        String split[] = mdxDocumentEvent.getIdentifier().split("/");
//        assertEquals(split[4], instrumentName);
//        assertEquals(mdxTimePointContent.getVersion(), xmartMdxTimeSeriesEsma.getMdxDocumentVersion());
//        assertEquals(mdxTimePointContent.getWriteTime(), xmartMdxTimeSeriesEsma.getMdxWrittenOnUTC());
//        assertEquals(new BigDecimal(mdxTimePointContent.getValue()), xmartMdxTimeSeriesEsma.getValue());
//        assertEquals(mdxTimePointContent.getMetadata().get("TradingVenues"), xmartMdxTimeSeriesEsma.getTradingVenues());
//        assertEquals(mdxTimePointContent.getMetadata().get("FirstTradeDate"),
//                xmartMdxTimeSeriesEsma.getFirstTradeDate());
//        assertEquals(mdxTimePointContent.getMetadata().get("Issuer"), xmartMdxTimeSeriesEsma.getIssuer());
//    }
//
//    @Tag("UnitTest")
//    @Test
//    public void testAddMdxTsEsmas() {
//        mock();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add MdxTsEsmas failed ", e);
//        }
//        verifyMappigValues(xmartMdxTimeSeriesEsmas.getEntity(), mdxTimePointContent);
//        xmlCheck(xmartMdxTimeSeriesEsmas);
//    }
//
//    @Tag("UnitTest")
//    @Test
//    public void testMandatoryFields() {
//        mock();
//        when(mdxTimePointContent.getWriteTime()).thenReturn(null);
//        assertThrows(XmartMandatoryAttributeMissingException.class, () -> this.create());
//    }
//}
