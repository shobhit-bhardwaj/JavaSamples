package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CurrencyId;
import com.rbs.odc.access.domain.ReferenceObligation;
import com.rbs.odc.access.domain.SecurityInstrument;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestReferenceObligation implements ReferenceObligation {
    private SecurityInstrument security;
    private BigDecimal referencePricePercentage;
    private CurrencyId originalFaceAmountCurrency;
    private Boolean standardReferenceObligation;

    public TestReferenceObligation() {
        this.security = new TestSecurityInstrument();
        this.referencePricePercentage = new BigDecimal(getRndInt());
        this.originalFaceAmountCurrency = new TestCurrencyId();

        this.standardReferenceObligation = getRndInt() % 2 == 0;
    }

    @Override
    public SecurityInstrument getSecurity() {
        return security;
    }

    @Override
    public BigDecimal getReferencePricePercentage() {
        return referencePricePercentage;
    }

    @Override
    public CurrencyId getOriginalFaceAmountCurrency() {
        return originalFaceAmountCurrency;
    }

    @Override
    public Boolean getStandardReferenceObligation() {
        return standardReferenceObligation;
    }
}
