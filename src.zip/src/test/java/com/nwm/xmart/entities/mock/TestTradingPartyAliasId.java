package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.TradingPartyAliasId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTradingPartyAliasId implements TradingPartyAliasId {

    private String nucleusId = getRandomString();
    private SystemInstanceId systemInstanceId;
    private String tradingPartyId = getRandomString();
    private boolean nucleusIdBool = getRndInt() % 2 == 1;

    public TestTradingPartyAliasId() {
        try {
            systemInstanceId = SystemInstanceId.valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            systemInstanceId = SystemInstanceId.NULL;
        }
    }

    @Override

    public SystemInstanceId getTradingPartySystemId() {
        return systemInstanceId;
    }

    @Override
    public String getTradingPartyId() {
        return tradingPartyId;
    }

    @Override
    public boolean isNucleusId() {
        return nucleusIdBool;
    }

    @Override
    public String getNucleusId() {
        return nucleusId;
    }
}
