package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.AttestationValue;
import com.rbs.odc.access.domain.TradingPartyAttestation;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestTradingPartyAttestation  implements TradingPartyAttestation {

    private int _index;
    public TestTradingPartyAttestation(int index){
        _index = index;
    }

    @Override
    public AttestationValue getAttestationValue() {
        return null;
    }
    @Override
    public String getIdPath() {
        return "idPath-"+ _index;
    }

    @Override
    public String getId() {
        return "id-" + _index;
    }
}
