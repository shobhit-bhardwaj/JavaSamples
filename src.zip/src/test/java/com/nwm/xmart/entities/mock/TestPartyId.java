package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.PartyClassification;
import com.rbs.odc.access.domain.PartyId;
import com.rbs.odc.access.domain.PartyIdClassification;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestPartyId implements PartyId {

    String partyId;
    PartyIdClassification scheme;

    public TestPartyId() {
        this.partyId = getRandomString();
        try {
            scheme = PartyIdClassification.valueOf(getRndInt() % PartyClassification.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Cannot create obkject using default value", e);
            scheme = PartyIdClassification.NULL;
        }
    }

    @Override
    public String getPartyId() {
        return partyId;
    }

    @Override
    public PartyIdClassification getScheme() {
        return scheme;
    }

    @Override
    public int compareTo(PartyId o) {
        throw new UnsupportedOperationException();
    }
}
