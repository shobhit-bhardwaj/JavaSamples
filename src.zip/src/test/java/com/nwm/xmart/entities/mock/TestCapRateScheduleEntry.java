package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CapRateScheduleEntry;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestCapRateScheduleEntry implements CapRateScheduleEntry {
    private BigDecimal rate = new BigDecimal(getRndInt());

    @Override
    public BigDecimal getRate() {
        return rate;
    }
}
