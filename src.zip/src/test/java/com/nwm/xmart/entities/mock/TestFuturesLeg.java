package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.ClosingPrice;
import com.rbs.odc.access.domain.FuturesLeg;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestFuturesLeg implements FuturesLeg {

    private BigDecimal quantityOfMeasure;
    private Boolean upFrontPaymentApplicable;
    private ClosingPrice closingPrice;

    public TestFuturesLeg() {
        quantityOfMeasure = new BigDecimal(getRndDouble());
        upFrontPaymentApplicable = getRndInt() % 2 == 1;
        closingPrice = new TestClosingPrice();
    }

    @Override
    public BigDecimal getQuantityOfMeasure() {
        return quantityOfMeasure;
    }

    @Override
    public Boolean isUpFrontPaymentApplicable() {
        return upFrontPaymentApplicable;
    }

    @Override
    public ClosingPrice getClosingPrice() {
        return closingPrice;
    }
}
