package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestRegimeBookRole implements RegimeBookRole {
    SourceBookId sourceBookId;
    TransactionRoleScheme reportingRoleScheme;
    Collection<BookReportObligation> bookReportObligations = new ArrayList<>();
    TradingCapacityScheme tradingCapacity;
    TransactionRoleScheme reportableTradingRole;

    public TestRegimeBookRole() {
        this.sourceBookId = new TestSourceBookId();
        try {
            reportingRoleScheme = TransactionRoleScheme
                    .valueOf(getRndInt() % TransactionRoleScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            reportingRoleScheme = TransactionRoleScheme.NULL;
        }

        try {
            tradingCapacity = TradingCapacityScheme.valueOf(getRndInt() % TradingCapacityScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            tradingCapacity = TradingCapacityScheme.NULL;
        }

        try {
            reportableTradingRole = TransactionRoleScheme
                    .valueOf(getRndInt() % TransactionRoleScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            reportableTradingRole = TransactionRoleScheme.NULL;
        }

        bookReportObligations.add(new TestBookReportObligation());
        bookReportObligations.add(new TestBookReportObligation());
    }

    @Override
    public SourceBookId getSourceBookId() {
        return sourceBookId;
    }

    @Override
    public TransactionRoleScheme getReportingRoleScheme() {
        return reportingRoleScheme;
    }

    @Override
    public Collection<BookReportObligation> getBookReportObligations() {
        return bookReportObligations; //Not relevant for this test
    }

    @Override
    public TradingCapacityScheme getTradingCapacity() {
        return tradingCapacity;
    }

    @Override
    public TransactionRoleScheme getReportableTradingRole() {
        return reportableTradingRole;
    }
}
