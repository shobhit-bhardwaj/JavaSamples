package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestAgreementTransactionContext implements AgreementTransactionContext {
    private String transactionAgreementContext;
    private LegalAgreementId legalAgreementId;
    private String legId;
    private int id;
    private Collection<ExceptionalTermsDetail> exceptionalTermsDetail = new ArrayList<>();
    private Collection<TransactionMarginElection> transactionMarginElection = new ArrayList<>();

    public TestAgreementTransactionContext() {
        transactionAgreementContext = getRandomString();
        this.id = getRndInt();
        this.legId = getRandomString();
        this.legalAgreementId = new TestLegalAgreementId();
        exceptionalTermsDetail.add(new TestExceptionalTermsDetail());
        exceptionalTermsDetail.add(new TestExceptionalTermsDetail());
        transactionMarginElection.add(new TestTransactionMarginElection());
        transactionMarginElection.add(new TestTransactionMarginElection());
    }

    @Override
    public LegalAgreementId getLegalAgreementId() {
        return legalAgreementId;
    }

    @Override
    public LegalAgreement getLegalAgreement() {
        return null;
    }

    @Override
    public Collection<TransactionMarginElection> getTransactionMarginElection() {
        return transactionMarginElection;
    }

    @Override
    public Collection<ExceptionalTermsDetail> getExceptionalTermsDetail() {
        return exceptionalTermsDetail;
    }

    @Override
    public String getLegId() {
        return legId;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getTransactionAgreementContext() {
        return transactionAgreementContext;
    }
}
