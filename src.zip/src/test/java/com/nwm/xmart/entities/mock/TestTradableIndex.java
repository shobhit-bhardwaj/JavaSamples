package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTradableIndex implements TradableIndex {
    private String alternateIdentifier;
    private String name;
    private Long indexSeries;
    private Long indexVersion;
    private BigDecimal attachmentPoint;
    private BigDecimal exhaustionPoint;
    private InstrumentId instrumentId;
    private Instrument instrument;
    private BusinessDate indexAnnexDate;
    private BusinessDate indexEffectiveDate;
    private Interval tenor;
    private Interval initialLag;
    private Interval finalLag;
    private String paymentPeriodScheme;
    private Integer paymentPeriodMultiplier;
    private DayCountFraction indexDayCountConvention;
    private BigDecimal currentTrancheStart;
    private BigDecimal currentTrancheEnd;
    private BigDecimal origPoolAmount;
    private BigDecimal currentPoolAmount;
    private BigDecimal basketConstituentCount;
    private BigDecimal indexFactor;

    public TestTradableIndex() {

        this.alternateIdentifier = getRandomString();
        this.name = getRandomString();
        this.indexVersion = new Long(getRndInt());
        this.attachmentPoint = new BigDecimal(getRndDouble());
        this.exhaustionPoint = new BigDecimal(getRndDouble());
        this.indexAnnexDate = new TestBusinessDate();
        this.indexEffectiveDate = new TestBusinessDate();
        try {
            this.indexDayCountConvention = DayCountFraction.valueOf(getRndInt() % DayCountFraction.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("DayCountFraction creation failed Using default value" + e.getMessage());
            this.indexDayCountConvention = DayCountFraction.NULL;
        }

        this.tenor = new TestInterval();

        this.initialLag = new TestInterval();
        this.finalLag = new TestInterval();
        this.paymentPeriodScheme = getRandomString();
        this.paymentPeriodMultiplier = getRndInt();
        this.instrumentId = new TestInstrumentId();
        this.indexSeries = new Long(getRndInt());
        this.currentTrancheStart = new BigDecimal(getRndDouble());
        this.currentTrancheEnd = new BigDecimal(getRndDouble());
        this.origPoolAmount = new BigDecimal(getRndDouble());
        this.currentPoolAmount = new BigDecimal(getRndDouble());
        this.basketConstituentCount = new BigDecimal(getRndDouble());
        this.indexFactor = new BigDecimal(getRndDouble());
    }

    @Override
    public String getAlternateIdentifier() {
        return alternateIdentifier;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Long getIndexSeries() {
        return indexSeries;
    }

    @Override
    public Long getIndexVersion() {
        return indexVersion;
    }

    @Override
    public BigDecimal getAttachmentPoint() {
        return attachmentPoint;
    }

    @Override
    public BigDecimal getExhaustionPoint() {
        return exhaustionPoint;
    }

    @Override
    public InstrumentId getInstrumentId() {
        return instrumentId;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public BusinessDate getIndexAnnexDate() {
        return indexAnnexDate;
    }

    @Override
    public BusinessDate getIndexEffectiveDate() {
        return indexEffectiveDate;
    }

    @Override
    public Interval getTenor() {
        return tenor;
    }

    @Override
    public Interval getInitialLag() {
        return initialLag;
    }

    @Override
    public Interval getFinalLag() {
        return finalLag;
    }

    @Override
    public String getPaymentPeriodScheme() {
        return paymentPeriodScheme;
    }

    @Override
    public Integer getPaymentPeriodMultiplier() {
        return paymentPeriodMultiplier;
    }

    @Override
    public DayCountFraction getIndexDayCountConvention() {
        return indexDayCountConvention;
    }

    @Override
    public BigDecimal getCurrentTrancheStart() {
        return currentTrancheStart;
    }

    @Override
    public BigDecimal getCurrentTrancheEnd() {
        return currentTrancheEnd;
    }

    @Override
    public BigDecimal getOrigPoolAmount() {
        return origPoolAmount;
    }

    @Override
    public BigDecimal getCurrentPoolAmount() {
        return currentPoolAmount;
    }

    @Override
    public BigDecimal getBasketConstituentCount() {
        return basketConstituentCount;
    }

    @Override
    public BigDecimal getIndexFactor() {
        return indexFactor;
    }
}
