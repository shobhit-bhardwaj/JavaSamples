package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BreakDateCalculationMethod;
import com.rbs.odc.access.domain.BusinessDate;
import com.rbs.odc.access.domain.EarlyTermination;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestEarlyTermination implements EarlyTermination {
    private BusinessDate unadjstDate = new TestBusinessDate();
    private BusinessDate adjustdDate = new TestBusinessDate();
    private BreakDateCalculationMethod breakDateCalculationMethod;

    TestEarlyTermination() {
        try {
            breakDateCalculationMethod = BreakDateCalculationMethod
                    .valueOf(getRndInt() % BreakDateCalculationMethod.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            breakDateCalculationMethod = BreakDateCalculationMethod.NULL;
        }
    }

    @Override
    public BusinessDate getUnadjstDate() {
        return unadjstDate;
    }

    @Override
    public BusinessDate getAdjustdDate() {
        return adjustdDate;
    }

    @Override
    public BreakDateCalculationMethod getBreakDateCalculationMethod() {
        return breakDateCalculationMethod;
    }
}
