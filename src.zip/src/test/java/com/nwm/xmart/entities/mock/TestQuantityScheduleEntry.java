package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestQuantityScheduleEntry implements QuantityScheduleEntry {
    private BigDecimal stepQuantity;
    private QuantityUnitOfMeasure quantityUnitOfMeasure;
    private IncreaseDecreaseScheme stepDirection;
    private UnitPrice unitPrice;

    public TestQuantityScheduleEntry() {
        stepQuantity = BigDecimal.valueOf(getRndInt());

        try {
            quantityUnitOfMeasure = QuantityUnitOfMeasure
                    .valueOf(getRndInt() % QuantityUnitOfMeasure.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            quantityUnitOfMeasure = QuantityUnitOfMeasure.NULL;
        }
        try {
            stepDirection = IncreaseDecreaseScheme.valueOf(getRndInt() % IncreaseDecreaseScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("IncreaseDecreaseScheme creation failed Using default value" + e.getMessage());
            stepDirection = IncreaseDecreaseScheme.NULL;
        }

        this.unitPrice = new TestUnitPrice();
    }

    @Override
    public BigDecimal getStepQuantity() {
        return stepQuantity;
    }

    @Override
    public QuantityUnitOfMeasure getQuantityUnitOfMeasure() {
        return quantityUnitOfMeasure;
    }

    @Override
    public IncreaseDecreaseScheme getStepDirection() {
        return stepDirection;
    }

    @Override
    public UnitPrice getUnitPrice() {
        return unitPrice;
    }
}
