package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;
import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestOptionFeature implements OptionFeature {
    private final BigDecimal strikePrice;
    private final BigDecimal premiumPercentage;
    private final Date expiryTime;
    private final CurrencyId strikePriceCurrencyId;
    private final Currency strikePriceCurrency;
    private final BigDecimal strikePercentage;
    private final BigDecimal optionEntitlement;
    private final Date earliestExerciseTime;
    private final Boolean optionStraddle;
    private final BigDecimal strikeSpread;
    private final Amount rebateAmount;
    private final Interval exerciseFrequency;
    private final Boolean deltaExchangeApplicable;
    private final BusinessCentreTime optionExpiryTime;
    private final BusinessCentreTime optionEarliestExerciseTime;
    private final BusinessCentreTime latestExerciseTime;
    private final OptionalEarlyTermination optionEarlyTermination;
    private final Boolean fallbackExercise;
    private final Boolean followUpConfirmation;
    private OptionExerciseStyle optionExerciseStyle;
    private OptionType optionType;
    private StrikeQuoteBasis strikeQuoteBasis;
    private PremiumQuoteBasis premiumQuoteBasis;
    private TriggerCondition europeanTriggerCondition;
    private TouchCondition americanTouchCondition;
    private DeliveryStyleScheme deliveryStyle;
    private CalculationAgent calculationAgent;
    private BusinessDate calledDate = new TestBusinessDate();
    private BusinessDate firstCallableDate = new TestBusinessDate();
    private BusinessDate finalMaturityDate = new TestBusinessDate();


    public TestOptionFeature() {

        optionEarlyTermination = new TestOptionalEarlyTermination();

        try {
            optionExerciseStyle = OptionExerciseStyle.valueOf(getRndInt() % OptionExerciseStyle.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            optionExerciseStyle = OptionExerciseStyle.NULL;
        }

        try {
            optionType = OptionType.valueOf(getRndInt() % OptionType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            optionType = OptionType.NULL;
        }

        try {
            strikeQuoteBasis = StrikeQuoteBasis.valueOf(getRndInt() % StrikeQuoteBasis.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            strikeQuoteBasis = StrikeQuoteBasis.NULL;
        }

        try {
            deliveryStyle = DeliveryStyleScheme.valueOf(getRndInt() % DeliveryStyleScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            deliveryStyle = DeliveryStyleScheme.NULL;
        }

        try {
            americanTouchCondition = TouchCondition.valueOf(getRndInt() % TouchCondition.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            americanTouchCondition = TouchCondition.NULL;
        }

        try {
            europeanTriggerCondition = TriggerCondition.valueOf(getRndInt() % TriggerCondition.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            europeanTriggerCondition = TriggerCondition.NULL;
        }

        try {
            premiumQuoteBasis = PremiumQuoteBasis.valueOf(getRndInt() % PremiumQuoteBasis.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            premiumQuoteBasis = PremiumQuoteBasis.NULL;
        }

        try {
            calculationAgent = CalculationAgent.valueOf(getRndInt() % CalculationAgent.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            calculationAgent = CalculationAgent.NULL;
        }

        premiumPercentage = new BigDecimal(getRndInt());
        expiryTime = getRandomDate();
        strikePriceCurrencyId = new TestCurrencyId();
        strikePriceCurrency = new TestCurrency();
        strikePercentage = new BigDecimal(getRndInt());
        optionEntitlement = new BigDecimal(getRndInt());
        earliestExerciseTime = getRandomDate();
        optionStraddle = getRndInt() % 2 == 1;
        strikeSpread = new BigDecimal(getRndInt());
        rebateAmount = new TestAmount();
        exerciseFrequency = new TestInterval();
        deltaExchangeApplicable = getRndInt() % 2 == 1;
        optionExpiryTime = new TestBusinessCentreTime();
        optionEarliestExerciseTime = new TestBusinessCentreTime();
        latestExerciseTime = new TestBusinessCentreTime();
        fallbackExercise = getRndInt() % 2 == 1;
        followUpConfirmation = getRndInt() % 2 == 1;
        strikePrice = new BigDecimal(getRndInt());
    }

    @Override
    public OptionExerciseStyle getOptionExerciseStyle() {
        return optionExerciseStyle;
    }

    @Override
    public OptionType getOptionType() {
        return optionType;
    }

    @Override
    public BigDecimal getStrikePrice() {
        return strikePrice;
    }

    @Override
    public StrikeQuoteBasis getStrikeQuoteBasis() {
        return strikeQuoteBasis;
    }

    @Override
    public BigDecimal getPremiumPercentage() {
        return premiumPercentage;
    }

    @Override
    public PremiumQuoteBasis getPremiumQuoteBasis() {
        return premiumQuoteBasis;
    }

    @Override
    public Date getExpiryTime() {
        return expiryTime;
    }

    @Override
    public TriggerCondition getEuropeanTriggerCondition() {
        return europeanTriggerCondition;
    }

    @Override
    public TouchCondition getAmericanTouchCondition() {
        return americanTouchCondition;
    }

    @Override
    public DeliveryStyleScheme getDeliveryStyle() {
        return deliveryStyle;
    }

    @Override
    public CurrencyId getStrikePriceCurrencyId() {
        return strikePriceCurrencyId;
    }

    @Override
    public Currency getStrikePriceCurrency() {
        return strikePriceCurrency;
    }

    @Override
    public BigDecimal getStrikePercentage() {
        return strikePercentage;
    }

    @Override
    public BigDecimal getOptionEntitlement() {
        return optionEntitlement;
    }

    @Override
    public Date getEarliestExerciseTime() {
        return earliestExerciseTime;
    }

    @Override
    public Boolean getOptionStraddle() {
        return optionStraddle;
    }

    @Override
    public BigDecimal getStrikeSpread() {
        return strikeSpread;
    }

    @Override
    public Amount getRebateAmount() {
        return rebateAmount;
    }

    @Override
    public Interval getExerciseFrequency() {
        return exerciseFrequency;
    }

    @Override
    public Boolean getDeltaExchangeApplicable() {
        return deltaExchangeApplicable;
    }

    @Override
    public BusinessCentreTime getOptionExpiryTime() {
        return optionExpiryTime;
    }

    @Override
    public BusinessCentreTime getOptionEarliestExerciseTime() {
        return optionEarliestExerciseTime;
    }

    @Override
    public BusinessCentreTime getLatestExerciseTime() {
        return latestExerciseTime;
    }

    @Override
    public OptionalEarlyTermination getOptionEarlyTermination() {
        return optionEarlyTermination;
    }

    @Override
    public Boolean getFallbackExercise() {
        return fallbackExercise;
    }

    @Override
    public Boolean getFollowUpConfirmation() {
        return followUpConfirmation;
    }

    @Override
    public CalculationAgent getCalculationAgent() {
        return calculationAgent;
    }

    @Override
    public BusinessDate getCalledDate() {
        return null;
    }

    @Override
    public BusinessDate getFirstCallableDate() {
        return null;
    }

    @Override
    public BusinessDate getFinalMaturityDate() {
        return null;
    }
}
