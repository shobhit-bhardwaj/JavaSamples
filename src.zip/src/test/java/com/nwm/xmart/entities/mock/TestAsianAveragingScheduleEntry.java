package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.AsianAveragingScheduleEntry;
import com.rbs.odc.access.domain.AveragingInOut;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestAsianAveragingScheduleEntry implements AsianAveragingScheduleEntry {
    private BigDecimal averageRateWeighting;
    private AveragingInOut averagingInOut;

    public TestAsianAveragingScheduleEntry() {
        this.averageRateWeighting = new BigDecimal(getRndInt());
        ;
        try {
            averagingInOut = AveragingInOut.valueOf(getRndInt() % AveragingInOut.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            averagingInOut = AveragingInOut.NULL;
        }
    }

    @Override
    public AveragingInOut getAveragingInOut() {
        return averagingInOut;
    }

    @Override
    public BigDecimal getAverageRateWeighting() {
        return averageRateWeighting;
    }
}
