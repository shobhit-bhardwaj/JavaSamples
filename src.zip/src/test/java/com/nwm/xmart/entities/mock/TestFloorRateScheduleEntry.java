package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.FloorRateScheduleEntry;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestFloorRateScheduleEntry implements FloorRateScheduleEntry {

    private BigDecimal rate = new BigDecimal(getRndInt());

    @Override
    public BigDecimal getRate() {
        return rate;
    }
}
