//package com.nwm.xmart.entities.mdx.mock;
//
//import rbs.gbm.mdx.webService.impl.MdxValuationDate;
//import rbs.gbm.mdx.webService.interfaces.IMdxDocumentStatus;
//import rbs.gbm.mdx.webService.interfaces.IMdxHeader;
//import rbs.gbm.mdx.webService.interfaces.IMdxIdentifier;
//
//import java.util.Date;
//
//import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;
//import static com.nwm.xmart.util.DateUtil.formatDateWithOutTime;
//
//public class TestMdxHeader implements IMdxHeader {
//    private String transport;
//    private String typeName;
//    private String path;
//    private MdxValuationDate valuationDate;
//    private boolean hasValuationDate;
//    private String toxml;
//    private IMdxIdentifier getIdentifier;
//    private int version;
//    private Date writeTime;
//    private String writeUser;
//    private String writeSite;
//    private String owningSite;
//    private long sequenceNumber;
//    private String writeApplicationName;
//    private String writeMachineName;
//    private IMdxDocumentStatus status;
//    private String xmlWriteTime;
//
//    public TestMdxHeader() {
//        this.transport = getRandomString();
//        this.typeName = getRandomString();
//        this.version = getRndInt();
//        this.xmlWriteTime = getRandomDate().toString();
//        this.path = getRandomString();
//        this.writeTime = getRandomDate();
//        this.valuationDate = new MdxValuationDate(formatDateWithOutTime(getRandomDate()));
//    }
//
//    @Override
//    public String getTransport() {
//        return transport;
//    }
//
//    @Override
//    public String getTypeName() {
//        return typeName;
//    }
//
//    @Override
//    public String getPath() {
//        return path;
//    }
//
//    @Override
//    public MdxValuationDate getValuationDate() {
//        return valuationDate;
//    }
//
//    @Override
//    public boolean hasValuationDate() {
//        return false;
//    }
//
//    @Override
//    public String toXml() throws Exception {
//        return null;
//    }
//
//    @Override
//    public IMdxIdentifier getIdentifier() {
//        return null;
//    }
//
//    @Override
//    public int getVersion() {
//        return version;
//    }
//
//    @Override
//    public Date getWriteTime() {
//        return writeTime;
//    }
//
//    @Override
//    public String getWriteUser() {
//        return null;
//    }
//
//    @Override
//    public String getWriteSite() {
//        return null;
//    }
//
//    @Override
//    public String getOwningSite() {
//        return null;
//    }
//
//    @Override
//    public long getSequenceNumber() {
//        return 0;
//    }
//
//    @Override
//    public String getWriteApplicationName() {
//        return null;
//    }
//
//    @Override
//    public String getWriteMachineName() {
//        return null;
//    }
//
//    @Override
//    public IMdxDocumentStatus getStatus() {
//        return null;
//    }
//
//    @Override
//    public String getXmlWriteTime() {
//        return xmlWriteTime;
//    }
//
//    @Override
//    public void setXmlWriteTime(String s) {
//
//    }
//}
