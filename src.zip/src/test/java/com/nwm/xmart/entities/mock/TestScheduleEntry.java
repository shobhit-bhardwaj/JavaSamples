package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestScheduleEntry implements ScheduleEntry {
    private BusinessDate startDate;
    private BusinessDate endDate;
    private BigDecimal triggerRate;
    private Amount triggerPayout;
    private TriggerPayoutStyleScheme payoutStyle;
    private BusinessDate paymentDate;
    private ScheduleEntryType scheduleEntryType;
    private BarrierScheduleEntry barrierScheduleEntry;
    private AsianAveragingScheduleEntry asianAveragingScheduleEntry;
    private CalculationPeriodScheduleEntry calculationPeriodScheduleEntry;
    private NotionalScheduleEntry notionalScheduleEntry;
    private CapRateScheduleEntry capRateScheduleEntry;
    private FloorRateScheduleEntry floorRateScheduleEntry;
    private QuantityScheduleEntry quantityScheduleEntry;
    private InterestRateScheduleEntry interestRateScheduleEntry;
    private String sourceSystemEventId;
    private BusinessDate unadjustedStartDate;
    private BusinessDate unadjustedEndDate;
    private Collection<FXFixingScheduleEntry> fxFixingScheduleEntries;
    private BusinessDate fixingDate;
    private BusinessCentreTime fixingTime;
    private BigDecimal rate;
    private BigDecimal spread;
    private BigDecimal rateMultiplier;

    public TestScheduleEntry() {
        try {
            scheduleEntryType = ScheduleEntryType.valueOf(getRndInt() % ScheduleEntryType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            scheduleEntryType = ScheduleEntryType.NULL;
        }

        fxFixingScheduleEntries = new ArrayList<>(2);
        fxFixingScheduleEntries.add(new TestFXFixingScheduleEntry());
        fxFixingScheduleEntries.add(new TestFXFixingScheduleEntry());
        startDate = new TestBusinessDate();
        endDate = new TestBusinessDate();
        triggerRate = new BigDecimal(getRndInt());
        sourceSystemEventId = getRandomString();
        unadjustedStartDate = new TestBusinessDate();
        unadjustedEndDate = new TestBusinessDate();
        barrierScheduleEntry = new TestBarrierScheduleEntry();
        asianAveragingScheduleEntry = new TestAsianAveragingScheduleEntry();
        calculationPeriodScheduleEntry = new TestCalculationPeriodScheduleEntry();
        notionalScheduleEntry = new TestNotionalScheduleEntry();
        floorRateScheduleEntry = new TestFloorRateScheduleEntry();
        quantityScheduleEntry = new TestQuantityScheduleEntry();
        interestRateScheduleEntry = new TestInterestRateScheduleEntry();
        capRateScheduleEntry = new TestCapRateScheduleEntry();

        try {
            payoutStyle = TriggerPayoutStyleScheme.valueOf(getRndInt() % TriggerPayoutStyleScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            payoutStyle = TriggerPayoutStyleScheme.NULL;
        }

        fixingDate = new TestBusinessDate();
        fixingTime = new TestBusinessCentreTime();
        rate = new BigDecimal(getRndInt());
        spread = new BigDecimal(getRndInt());
        rateMultiplier = new BigDecimal(getRndInt());
        triggerPayout = new TestAmount();
        paymentDate = new TestBusinessDate();
    }

    @Override
    public BusinessDate getStartDate() {
        return startDate;
    }

    @Override
    public BusinessDate getEndDate() {
        return endDate;
    }

    @Override
    public BigDecimal getTriggerRate() {
        return triggerRate;
    }

    @Override
    public Amount getTriggerPayout() {
        return triggerPayout;
    }

    @Override
    public TriggerPayoutStyleScheme getPayoutStyle() {
        return payoutStyle;
    }

    @Override
    public BusinessDate getPaymentDate() {
        return paymentDate;
    }

    @Override
    public ScheduleEntryType getScheduleEntryType() {
        return scheduleEntryType;
    }

    @Override
    public BarrierScheduleEntry getBarrierScheduleEntry() {
        return barrierScheduleEntry;
    }

    @Override
    public AsianAveragingScheduleEntry getAsianAveragingScheduleEntry() {
        return asianAveragingScheduleEntry;
    }

    @Override
    public CalculationPeriodScheduleEntry getCalculationPeriodScheduleEntry() {
        return calculationPeriodScheduleEntry;
    }

    @Override
    public NotionalScheduleEntry getNotionalScheduleEntry() {
        return notionalScheduleEntry;
    }

    @Override
    public CapRateScheduleEntry getCapRateScheduleEntry() {
        return capRateScheduleEntry;
    }

    @Override
    public FloorRateScheduleEntry getFloorRateScheduleEntry() {
        return floorRateScheduleEntry;
    }

    @Override
    public QuantityScheduleEntry getQuantityScheduleEntry() {
        return quantityScheduleEntry;
    }

    @Override
    public InterestRateScheduleEntry getInterestRateScheduleEntry() {
        return interestRateScheduleEntry;
    }

    @Override
    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    @Override
    public BusinessDate getUnadjustedStartDate() {
        return unadjustedStartDate;
    }

    @Override
    public BusinessDate getUnadjustedEndDate() {
        return unadjustedEndDate;
    }

    @Override
    public Collection<FXFixingScheduleEntry> getFxFixingScheduleEntries() {
        return fxFixingScheduleEntries;
    }

    @Override
    public BusinessDate getFixingDate() {
        return fixingDate;
    }

    @Override
    public BusinessCentreTime getFixingTime() {
        return fixingTime;
    }

    @Override
    public BigDecimal getRate() {
        return rate;
    }

    @Override
    public BigDecimal getSpread() {
        return spread;
    }

    @Override
    public BigDecimal getRateMultiplier() {
        return rateMultiplier;
    }

    @Override
    public int compareTo(ScheduleEntry o) {
        return 0;
    }
}
