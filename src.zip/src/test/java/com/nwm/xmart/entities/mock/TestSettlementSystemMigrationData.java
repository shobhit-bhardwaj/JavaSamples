package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.MigrationType;
import com.rbs.odc.access.domain.SettlementSystemMigrationData;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestSettlementSystemMigrationData implements SettlementSystemMigrationData {
    private MigrationType migrationType;
    private Date effectiveDate;

    public TestSettlementSystemMigrationData() {
        try {
            migrationType = MigrationType.valueOf(getRndInt() % MigrationType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("MigrationType creation failed Using default value" + e.getMessage());
            migrationType = MigrationType.NULL;
        }
        this.effectiveDate = getRandomDate();
    }

    @Override
    public MigrationType getMigrationType() {
        return migrationType;
    }

    @Override
    public Date getEffectiveDate() {
        return effectiveDate;
    }
}
