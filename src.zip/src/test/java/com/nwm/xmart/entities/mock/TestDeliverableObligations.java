package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.DeliverableObligations;
import com.rbs.odc.access.domain.ObligationLiabilityScheme;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestDeliverableObligations implements DeliverableObligations {

    private String category;
    private Boolean accruedInterest;
    private ObligationLiabilityScheme obligationLiabilityScheme;
    private Boolean notSubordinated;
    private Boolean notSovereignLender;
    private Boolean notDomesticCurrency;
    private Boolean notDomesticLaw;
    private Boolean notDomesticIssue;
    private Boolean listed;
    private Boolean notContingent;
    private Boolean transferable;
    private Boolean acceleratedOrMatured;
    private Boolean notBearer;
    private Boolean indirectLoanParticipation;
    private String qualifyingParticipnSeller;
    private Boolean partCashAssignableLoans;
    private Boolean partCashConsentRequired;
    private Boolean partCashLoanParticipations;
    private String excluded;
    private String otherCategory;
    private String otherCharacteristic;

    public TestDeliverableObligations() {
        accruedInterest = getRndInt() % 2 == 1;
        notSubordinated = getRndInt() % 2 == 1;
        notSovereignLender = getRndInt() % 2 == 1;
        notDomesticCurrency = getRndInt() % 2 == 1;
        notDomesticLaw = getRndInt() % 2 == 1;
        notDomesticIssue = getRndInt() % 2 == 1;
        listed = getRndInt() % 2 == 1;
        notContingent = getRndInt() % 2 == 1;
        transferable = getRndInt() % 2 == 1;
        acceleratedOrMatured = getRndInt() % 2 == 1;
        notBearer = getRndInt() % 2 == 1;
        indirectLoanParticipation = getRndInt() % 2 == 1;
        partCashAssignableLoans = getRndInt() % 2 == 1;
        partCashConsentRequired = getRndInt() % 2 == 1;
        partCashLoanParticipations = getRndInt() % 2 == 1;
        excluded = getRandomString();
        otherCategory = getRandomString();
        otherCharacteristic = getRandomString();
        category = getRandomString();
        qualifyingParticipnSeller = getRandomString();

        try {
            obligationLiabilityScheme = ObligationLiabilityScheme
                    .valueOf(getRndInt() % ObligationLiabilityScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            obligationLiabilityScheme = ObligationLiabilityScheme.NULL;
        }
    }

    @Override
    public String getCategory() {
        return category;
    }

    @Override
    public Boolean getAccruedInterest() {
        return accruedInterest;
    }

    @Override
    public ObligationLiabilityScheme getObligationLiabilityScheme() {
        return obligationLiabilityScheme;
    }

    @Override
    public Boolean getNotSubordinated() {
        return notSubordinated;
    }

    @Override
    public Boolean getNotSovereignLender() {
        return notSovereignLender;
    }

    @Override
    public Boolean getNotDomesticCurrency() {
        return notDomesticCurrency;
    }

    @Override
    public Boolean getNotDomesticLaw() {
        return notDomesticLaw;
    }

    @Override
    public Boolean getNotDomesticIssue() {
        return notDomesticIssue;
    }

    @Override
    public Boolean getListed() {
        return listed;
    }

    @Override
    public Boolean getNotContingent() {
        return notContingent;
    }

    @Override
    public Boolean getTransferable() {
        return transferable;
    }

    @Override
    public Boolean getAcceleratedOrMatured() {
        return acceleratedOrMatured;
    }

    @Override
    public Boolean getNotBearer() {
        return notBearer;
    }

    @Override
    public Boolean getIndirectLoanParticipation() {
        return indirectLoanParticipation;
    }

    @Override
    public String getQualifyingParticipnSeller() {
        return qualifyingParticipnSeller;
    }

    @Override
    public Boolean getPartCashAssignableLoans() {
        return partCashAssignableLoans;
    }

    @Override
    public Boolean getPartCashConsentRequired() {
        return partCashConsentRequired;
    }

    @Override
    public Boolean getPartCashLoanParticipations() {
        return partCashLoanParticipations;
    }

    @Override
    public String getExcluded() {
        return excluded;
    }

    @Override
    public String getOtherCategory() {
        return otherCategory;
    }

    @Override
    public String getOtherCharacteristic() {
        return otherCharacteristic;
    }
}
