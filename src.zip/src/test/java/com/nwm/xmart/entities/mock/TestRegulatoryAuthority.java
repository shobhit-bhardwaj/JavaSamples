package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.RegulatoryAuthority;
import com.rbs.odc.access.domain.RegulatoryAuthorityId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestRegulatoryAuthority implements RegulatoryAuthority {
    private RegulatoryAuthorityId regulatoryAuthority;

    public TestRegulatoryAuthority() {
        try {
            regulatoryAuthority = RegulatoryAuthorityId
                    .valueOf(getRndInt() % RegulatoryAuthorityId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed using default value" + e.getMessage());
            regulatoryAuthority = RegulatoryAuthorityId.NULL;
        }
    }

    @Override
    public RegulatoryAuthorityId getRegulatoryAuthority() {
        return regulatoryAuthority;
    }
}
