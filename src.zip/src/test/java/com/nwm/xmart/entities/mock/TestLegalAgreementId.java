package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.LegalAgreementId;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestLegalAgreementId implements LegalAgreementId {

    private final String agreementId;

    public TestLegalAgreementId() {
        this.agreementId = getRandomString();
    }

    @Override
    public String getAgreementId() {
        return agreementId;
    }

    @Override
    public int compareTo(LegalAgreementId o) {
        return 0;
    }
}
