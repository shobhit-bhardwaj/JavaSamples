package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Employee;
import com.rbs.odc.access.domain.EmployeeId;
import com.rbs.odc.access.domain.EmployeeIdEntry;

import java.util.ArrayList;
import java.util.Collection;

public class TestEmployee implements Employee {

    private EmployeeId employeeId;
    private Collection<EmployeeIdEntry> employeeIdEntry = new ArrayList<>();

    public TestEmployee() {
        employeeId = new TestEmployeeId();
        
        employeeIdEntry.add(new TestEmployeeIdEntry());
        employeeIdEntry.add(new TestEmployeeIdEntry());
    }

    @Override
    public EmployeeId getId() {
        return employeeId;
    }

    @Override
    public Collection<EmployeeIdEntry> getIdEntry() {
        return employeeIdEntry;
    }
}
