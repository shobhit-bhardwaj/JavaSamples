package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Party;
import com.rbs.odc.access.domain.PartyId;
import com.rbs.odc.access.domain.TransactionLegalEntity;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestTransactionLegalEntity implements TransactionLegalEntity {
    private String transactionRoleScheme;
    private PartyId partyEntityId;
    private Party party;

    public TestTransactionLegalEntity(PartyId partyId) {
        transactionRoleScheme = getRandomString();
        this.partyEntityId = partyId;
    }

    public String getTransactionRoleScheme() {
        return transactionRoleScheme;
    }

    public PartyId getPartyEntityId() {
        return partyEntityId;
    }

    public Party getParty() {//NOT relevant for thsi test
        return party;
    }
}
