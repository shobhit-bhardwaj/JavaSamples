package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionLeg implements TransactionLeg {

    private final TestForwardFeature forwardFeature;
    private AdjustableDate terminationDt;
    private Amount initialPrincipal, payAmount, receiveAmount;
    private AveragingMethod averagingMethod;
    private BigDecimal accruedInterestPercentage, basketDivisor, capInterestRate, digitalPayoutRate, floorInterestRate,
            forwardExchangeRate, forwardPoints, gentanBondRate, hairCut, maxCapInterestRate, minFloorInterestRate,
            openUnitsQuantity, payCurrencySideRate, quantity, receiveCurrencySideRate, spotExchangeRate, spread;
    private boolean cashflowMatchParameter, finalExchange, intermediateExchange, nonDeliverable, rehypothecable,
            segregated;
    private BreakClauseType breakClauseType;
    private BusinessDate deliveryDate, effectiveDate, firstCalculationPeriodStartDate, firstCompPeriodEndDate,
            firstPaymentDate, firstRegPeriodStartDate, lastPaymentDate, lastRegularPaymentDate,
            lastRegularPeriodEndDate, terminationDate, unadjustedEffectiveDate, valueDate;
    private CashSettlementTerms cashSettlementTerms;
    private CollateralLeg collateralLeg;
    private CrossCurrencyType crossCurrencyType;
    private CurrencyId basketCurrencyId, settlementCurrencyId, sideRateBaseCurrencyId;
    private DayCountConvention businessDayConvention;
    private DayCountFraction dayCountConvention;
    private Discounting discounting;
    private Dividend dividend;
    private EarlyTermination earlyTermination;
    private FXLinkedNotional fxLinkedNotional;
    private IncomeStreamLeg incomeStreamLeg;
    private InstrumentId instrumentId;
    private InstrumentLeg instrumentLeg;
    private InstrumentLoanLeg instrumentLoanLeg;
    private Integer contractMultiplier, daysInYear, referenceRateTenor;
    private LegType legType;
    private NotionalSource notionalSource;
    private PrincipalType initialPrincipalType;
    private QuantityUnitOfMeasure quantityUnitOfMeasure;
    private QuoteBasis currencyQuoteBasis;
    private QuoteBasis receiveSideRateQuoteBasis;
    private QuoteBasis paySideRateQuoteBasis;
    private RateTreatment rateTreatment;
    private ReturnType returnType;
    private RollConventionScheme rollConventionScheme;
    private SettlementType settlementType;
    private SpreadScheduleTypeScheme spreadType;
    private String basketName, cashSettlementMethod, legAtomicProduct, legIdentifier, principalAmortizationStyle,
            rateSource, referenceRate, settlementInstructionType;
    private Stub finalStub, initialStub;
    private TradingParty payer, receiver;
    private UnitPrice unitPrice;
    private WeeklyRollConvention weeklyRollConvention;
    private BigDecimal legForwardPoints;
    private StandardProduct standardProduct;

    public TestTransactionLeg() {
        accruedInterestPercentage = new BigDecimal(getRndDouble());
        basketDivisor = new BigDecimal(getRndDouble());
        capInterestRate = new BigDecimal(getRndDouble());
        digitalPayoutRate = new BigDecimal(getRndDouble());
        floorInterestRate = new BigDecimal(getRndDouble());
        forwardExchangeRate = new BigDecimal(getRndDouble());
        forwardPoints = new BigDecimal(getRndDouble());
        gentanBondRate = new BigDecimal(getRndDouble());
        hairCut = new BigDecimal(getRndDouble());
        maxCapInterestRate = new BigDecimal(getRndDouble());
        minFloorInterestRate = new BigDecimal(getRndDouble());
        openUnitsQuantity = new BigDecimal(getRndDouble());
        payCurrencySideRate = new BigDecimal(getRndDouble());
        quantity = new BigDecimal(getRndDouble());
        receiveCurrencySideRate = new BigDecimal(getRndDouble());
        spotExchangeRate = new BigDecimal(getRndDouble());
        spread = new BigDecimal(getRndDouble());
        cashflowMatchParameter = getRndInt() % 2 == 1;
        finalExchange = getRndInt() % 2 == 1;
        intermediateExchange = getRndInt() % 2 == 1;
        nonDeliverable = getRndInt() % 2 == 1;
        rehypothecable = getRndInt() % 2 == 1;
        segregated = getRndInt() % 2 == 1;
        deliveryDate = new TestBusinessDate();
        effectiveDate = new TestBusinessDate();
        firstCalculationPeriodStartDate = new TestBusinessDate();
        firstCompPeriodEndDate = new TestBusinessDate();
        firstPaymentDate = new TestBusinessDate();
        firstRegPeriodStartDate = new TestBusinessDate();
        lastPaymentDate = new TestBusinessDate();
        lastRegularPaymentDate = new TestBusinessDate();
        lastRegularPeriodEndDate = new TestBusinessDate();
        terminationDate = new TestBusinessDate();
        unadjustedEffectiveDate = new TestBusinessDate();
        valueDate = new TestBusinessDate();
        basketName = getRandomString();
        cashSettlementMethod = getRandomString();
        legAtomicProduct = getRandomString();
        legIdentifier = getRandomString();
        principalAmortizationStyle = getRandomString();
        rateSource = getRandomString();
        referenceRate = getRandomString();
        settlementInstructionType = getRandomString();
        terminationDt = new TestAdjustableDate();

        try {
            averagingMethod = AveragingMethod.valueOf(getRndInt() % AveragingMethod.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            averagingMethod = AveragingMethod.NULL;
        }
        try {
            dayCountConvention = DayCountFraction.valueOf(getRndInt() % DayCountFraction.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            dayCountConvention = DayCountFraction.NULL;
        }
        try {
            legType = LegType.valueOf(getRndInt() % LegType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            legType = LegType.NULL;
        }
        try {
            notionalSource = NotionalSource.valueOf(getRndInt() % NotionalSource.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            notionalSource = NotionalSource.NULL;
        }
        try {
            initialPrincipalType = PrincipalType.valueOf(getRndInt() % PrincipalType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            initialPrincipalType = PrincipalType.NULL;
        }
        try {
            quantityUnitOfMeasure = QuantityUnitOfMeasure
                    .valueOf(getRndInt() % QuantityUnitOfMeasure.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            quantityUnitOfMeasure = QuantityUnitOfMeasure.NULL;
        }
        try {
            currencyQuoteBasis = QuoteBasis.valueOf(getRndInt() % QuoteBasis.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            currencyQuoteBasis = QuoteBasis.NULL;
        }

        try {
            paySideRateQuoteBasis = QuoteBasis.valueOf(getRndInt() % QuoteBasis.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            paySideRateQuoteBasis = QuoteBasis.NULL;
        }
        try {
            receiveSideRateQuoteBasis = QuoteBasis.valueOf(getRndInt() % QuoteBasis.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            receiveSideRateQuoteBasis = QuoteBasis.NULL;
        }
        try {
            rateTreatment = RateTreatment.valueOf(getRndInt() % RateTreatment.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            rateTreatment = RateTreatment.NULL;
        }
        try {
            returnType = ReturnType.valueOf(getRndInt() % ReturnType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            returnType = ReturnType.NULL;
        }
        try {
            rollConventionScheme = RollConventionScheme.valueOf(getRndInt() % RollConventionScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            rollConventionScheme = RollConventionScheme.NULL;
        }
        try {
            settlementType = SettlementType.valueOf(getRndInt() % SettlementType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            settlementType = SettlementType.NULL;
        }
        try {
            spreadType = SpreadScheduleTypeScheme.valueOf(getRndInt() % SpreadScheduleTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            spreadType = SpreadScheduleTypeScheme.NULL;
        }

        try {
            crossCurrencyType = CrossCurrencyType.valueOf(getRndInt() % CrossCurrencyType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            crossCurrencyType = CrossCurrencyType.NULL;
        }

        try {
            businessDayConvention = DayCountConvention.valueOf(getRndInt() % DayCountConvention.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            businessDayConvention = DayCountConvention.NULL;
        }

        try {
            weeklyRollConvention = WeeklyRollConvention.valueOf(getRndInt() % WeeklyRollConvention.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            weeklyRollConvention = WeeklyRollConvention.NULL;
        }

        try {
            breakClauseType = BreakClauseType.valueOf(getRndInt() % BreakClauseType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            breakClauseType = BreakClauseType.NULL;
        }

        initialPrincipal = new TestAmount();
        payAmount = new TestAmount();
        receiveAmount = new TestAmount();
        contractMultiplier = getRndInt();
        daysInYear = getRndInt();
        referenceRateTenor = getRndInt();
        basketCurrencyId = new TestCurrencyId();
        settlementCurrencyId = new TestCurrencyId();
        sideRateBaseCurrencyId = new TestCurrencyId();
        cashSettlementTerms = new TestCashSettlementTerms();
        fxLinkedNotional = new TestFXLinkedNotional();
        collateralLeg = new TestCollateralLeg();
        discounting = new TestDiscounting();
        dividend = new TestDividend();
        earlyTermination = new TestEarlyTermination();
        incomeStreamLeg = new TestIncomeStreamLeg();
        unitPrice = new TestUnitPrice();
        instrumentId = new TestInstrumentId();
        instrumentLeg = new TestInstrumentLeg();
        instrumentLoanLeg = new TestInstrumentLoanLeg();

        finalStub = new TestStub();
        initialStub = new TestStub();
        payer = new TestTradingParty();
        receiver = new TestTradingParty();
        forwardFeature = new TestForwardFeature();

        legForwardPoints = new BigDecimal(getRndDouble());
        standardProduct = new TestStandardProduct();

    }

    @Override
    public CashSettlementTerms getCashSettlementTerms() {
        return cashSettlementTerms;
    }

    @Override
    public BusinessDate getTerminationDate() {
        return terminationDate;
    }

    @Override
    public Discounting getDiscounting() {
        return discounting;
    }

    @Override
    public EarlyTermination getEarlyTermination() {
        return earlyTermination;
    }

    @Override
    public WeeklyRollConvention getWeeklyRollConvention() {
        return weeklyRollConvention;
    }

    @Override
    public Stub getInitialStub() {
        return initialStub;
    }

    @Override
    public Stub getFinalStub() {
        return finalStub;
    }

    @Override
    public AdjustableDate getTerminationDt() {
        return terminationDt;
    }

    @Override
    public BreakClauseType getBreakClauseType() {
        return breakClauseType;
    }

    @Override
    public BusinessDate getFirstCompPeriodEndDate() {
        return firstCompPeriodEndDate;
    }

    @Override
    public NotionalSource getNotionalSource() {
        return notionalSource;
    }

    @Override
    public RateTreatment getRateTreatment() {
        return rateTreatment;
    }

    @Override
    public Boolean isFinalExchange() {
        return finalExchange;
    }

    @Override
    public SpreadScheduleTypeScheme getSpreadType() {
        return spreadType;
    }

    @Override
    public ReferenceObligation getReferenceObligation() {
        return null;
    }

    @Override
    public InstrumentUnderlier getInstrumentUnderlier() {
        return null;
    }

    @Override
    public Set<LegBusinessCentre> getLegBusinessCentres() {
        return null;
    }

    @Override
    public Set<LegBusinessCentre> getLegBusinessCentres(BusinessCentreRole businessCentreRole) {
        return null;
    }

    @Override
    public TradingParty getTradingCounterParty(TradingPartyId tradingPartyId) {
        return null;
    }

    @Override
    public BusinessDate getLastPaymentDate() {
        return lastPaymentDate;
    }

    @Override
    public BusinessDate getFirstRegPeriodStartDate() {
        return firstRegPeriodStartDate;
    }

    @Override
    public BusinessDate getLastRegularPeriodEndDate() {
        return lastRegularPeriodEndDate;
    }

    @Override
    public BigDecimal getCapInterestRate() {
        return capInterestRate;
    }

    @Override
    public BigDecimal getMaxCapInterestRate() {
        return maxCapInterestRate;
    }

    @Override
    public BigDecimal getFloorInterestRate() {
        return floorInterestRate;
    }

    @Override
    public BigDecimal getMinFloorInterestRate() {
        return minFloorInterestRate;
    }

    @Override
    public boolean isCashflowMatchParameter() {
        return cashflowMatchParameter;
    }

    @Override
    public Collection<TransactionLegCurve> getTransactionLegCurves() {
        return null;
    }

    @Override
    public Map<LegPeriodType, TransactionLegParameter> getLegParameters() {
        return null;
    }

    @Override
    public TransactionLegParameter getLegParameter(LegPeriodType legPeriodType) {
        return null;
    }

    @Override
    public BigDecimal getOpenUnitsQuantity() {
        return openUnitsQuantity;
    }

    @Override
    public Dividend getDividend() {
        return dividend;
    }

    @Override
    public VarianceLeg getVarianceLeg() {
        return null;
    }

    @Override
    public Amount getCurrentNotionalFromNotionalSchedule(BusinessDate businessDate) {
        return null;
    }

    @Override
    public Set<ScheduleEntry> getScheduleEntries(ScheduleEntryType scheduleEntryType) {
        return null;
    }

    @Override
    public BusinessDate getTerminationDateConsideringInstrumentEndDate() {
        return null;
    }

    @Override
    public Boolean isNonDeliverable() {
        return nonDeliverable;
    }

    @Override
    public BigDecimal getGentanBondRate() {
        return gentanBondRate;
    }

    @Override
    public Integer getContractMultiplier() {
        return contractMultiplier;
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public BusinessDate getEffectiveDate() {
        return effectiveDate;
    }

    @Override
    public BusinessDate getValueDate() {
        return valueDate;
    }

    @Override
    public Amount getPayAmount() {
        return payAmount;
    }

    @Override
    public Amount getReceiveAmount() {
        return receiveAmount;
    }

    @Override
    public BigDecimal getForwardPoints() {
        return forwardPoints;
    }

    @Override
    public BigDecimal getSpotExchangeRate() {
        return spotExchangeRate;
    }

    @Override
    public BigDecimal getForwardExchangeRate() {
        return forwardExchangeRate;
    }

    @Override
    public BigDecimal getHairCut() {
        return hairCut;
    }

    @Override
    public BigDecimal getQuantity() {
        return quantity;
    }

    @Override
    public BigDecimal getSpread() {
        return spread;
    }

    @Override
    public FXLeg getFxLeg() {
        return null;
    }

    @Override
    public CreditDerivativeLeg getCreditDerivativeLeg() {
        return null;
    }

    @Override
    public DayCountFraction getDayCountConvention() {
        return dayCountConvention;
    }

    @Override
    public InterestRateLeg getInterestRateLeg() {
        return null;
    }

    @Override
    public FuturesLeg getFuturesLeg() {
        return null;
    }

    @Override
    public String getReferenceRate() {
        return referenceRate;
    }

    @Override
    public Period getResetPeriodScheme() {
        return null;
    }

    @Override
    public Collection<Underlier> getUnderliers() {
        return null;
    }

    @Override
    public Integer getResetPeriodMultiplier() {
        return null;
    }

    @Override
    public Period getPaymentPeriodScheme() {
        return null;
    }

    @Override
    public Integer getPaymentPeriodMultiplier() {
        return null;
    }

    @Override
    public String getPrincipalAmortizationStyle() {
        return principalAmortizationStyle;
    }

    @Override
    public AveragingMethod getAveragingMethod() {
        return averagingMethod;
    }

    @Override
    public DayCountConvention getBusinessDayConvention() {
        return businessDayConvention;
    }

    @Override
    public CollateralLeg getCollateralLeg() {
        return collateralLeg;
    }

    @Override
    public BusinessDate getDeliveryDate() {
        return deliveryDate;
    }

    @Override
    public QuoteBasis getCurrencyQuoteBasis() {
        return currencyQuoteBasis;
    }

    @Override
    public PrincipalType getInitialPrincipalType() {
        return initialPrincipalType;
    }

    @Override
    public String getRateSource() {
        return rateSource;
    }

    @Override
    public OptionFeature getOptionFeature() {
        return null;
    }

    @Override
    public ForwardFeature getForwardFeature() {
        return null;
    }

    @Override
    public Set<ScheduleEntry> getScheduleEntries() {
        return null;
    }

    @Override
    public LegType getLegType() {
        return legType;
    }

    @Override
    public InstrumentLoanLeg getInstrumentLoanLeg() {
        return instrumentLoanLeg;
    }

    @Override
    public String getBasketName() {
        return basketName;
    }

    @Override
    public TradingParty getPayer() {
        return payer;
    }

    @Override
    public TradingParty getReceiver() {
        return receiver;
    }

    @Override
    public RollConventionScheme getRollConventionScheme() {
        return rollConventionScheme;
    }

    @Override
    public CurrencyId getSettlementCurrencyId() {
        return settlementCurrencyId;
    }

    @Override
    public CurrencyId getBasketCurrencyId() {
        return basketCurrencyId;
    }

    @Override
    public SettlementType getSettlementType() {
        return settlementType;
    }

    @Override
    public UnitPrice getUnitPrice() {
        return unitPrice;
    }

    @Override
    public BigDecimal getBasketDivisor() {
        return basketDivisor;
    }

    @Override
    public QuantityUnitOfMeasure getQuantityUnitOfMeasure() {
        return quantityUnitOfMeasure;
    }

    @Override
    public CrossCurrencyType getCrossCurrencyType() {
        return crossCurrencyType;
    }

    @Override
    public ReturnType getReturnType() {
        return returnType;
    }

    @Override
    public Integer getReferenceRateTenor() {
        return referenceRateTenor;
    }

    @Override
    public Period getCalculationPeriodScheme() {
        return null;
    }

    @Override
    public Integer getCalculationPeriodMultiplier() {
        return null;
    }

    @Override
    public IncomeStreamLeg getIncomeStreamLeg() {
        return incomeStreamLeg;
    }

    @Override
    public BusinessDate getFirstPaymentDate() {
        return firstPaymentDate;
    }

    @Override
    public Currency getBasketCurrency() {
        return null;
    }

    @Override
    public Currency getSettlementCurrency() {
        return null;
    }

    @Override
    public InstrumentId getInstrumentId() {
        return instrumentId;
    }

    @Override
    public Boolean isIntermediateExchange() {
        return intermediateExchange;
    }

    @Override
    public BusinessDate getUnadjustedEffectiveDate() {
        return unadjustedEffectiveDate;
    }

    @Override
    public Instrument getInstrument() {
        return null;
    }

    @Override
    public InflationRateLeg getInflationRateLeg() {
        return null;
    }

    @Override
    public Amount getInitialPrincipalConsideringInstrument() {
        return null;
    }

    @Override
    public InstrumentLeg getInstrumentLeg() {
        return instrumentLeg;
    }

    @Override
    public String getLegAtomicProduct() {
        return legAtomicProduct;
    }

    @Override
    public BigDecimal getDigitalPayoutRate() {
        return digitalPayoutRate;
    }

    @Override
    public String getCashSettlementMethod() {
        return cashSettlementMethod;
    }

    @Override
    public String getPaymentIndicator() {
        return null;
    }

    @Override
    public BigDecimal getAccruedInterestPercentage() {
        return accruedInterestPercentage;
    }

    @Override
    public CurrencyId getSideRateBaseCurrencyId() {
        return sideRateBaseCurrencyId;
    }

    @Override
    public Currency getSideRateBaseCurrency() {
        return null;
    }

    @Override
    public BigDecimal getPayCurrencySideRate() {
        return payCurrencySideRate;
    }

    @Override
    public QuoteBasis getPaySideRateQuoteBasis() {
        return paySideRateQuoteBasis;
    }

    @Override
    public BigDecimal getReceiveCurrencySideRate() {
        return receiveCurrencySideRate;
    }

    @Override
    public QuoteBasis getReceiveSideRateQuoteBasis() {
        return receiveSideRateQuoteBasis;
    }

    @Override
    public Amount getInitialPrincipal() {
        return initialPrincipal;
    }

    @Override
    public Integer getDaysInYear() {
        return daysInYear;
    }

    @Override
    public FXLinkedNotional getFxLinkNot() {
        return null;
    }

    @Override
    public FXLinkedNotional getFxLinkedNotional() {
        return fxLinkedNotional;
    }

    @Override
    public BusinessDate getLastRegularPaymentDate() {
        return lastRegularPaymentDate;
    }

    @Override
    public BusinessDate getFirstCalculationPeriodStartDate() {
        return firstCalculationPeriodStartDate;
    }

    @Override
    public Boolean isRehypothecable() {
        return rehypothecable;
    }

    @Override
    public Boolean isSegregated() {
        return segregated;
    }

    @Override
    public String getSettlementInstructionType() {
        return settlementInstructionType;
    }

    @Override
    public void resetData() {
    }

    @Override
    public Collection<LegInformationSource> getLegInformationSource() {
        return null;
    }

    @Override
    public String getNettingGroupId() {
        return null;
    }

    @Override
    public CouponTransferType getCouponTransferType() {
        return null;
    }

    @Override
    public BigDecimal getLegForwardPoints() {
        return legForwardPoints;
    }

    @Override
    public StandardProduct getStandardProduct() {
        return standardProduct;
    }

    @Override
    public Boolean isCloseoutNettingEnforceable() {
        return null;
    }

    @Override
    public Boolean isCloseoutNettingProductCovered() {
        return null;
    }

    @Override
    public String getInstrumentClass1() {
        return null;
    }

    @Override
    public String getInstrumentClass2() {
        return null;
    }

    @Override
    public int compareTo(TransactionLeg o) {
        return 0;
    }
}
