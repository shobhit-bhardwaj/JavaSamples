//package com.nwm.xmart.entities.mdx;
//
//import com.nwm.xmart.entities.XmartEntitiesBaseTest;
//import com.nwm.xmart.entities.mdx.mock.TestMdxHeader;
//import com.nwm.xmart.exception.XmartException;
//import com.nwm.xmart.exception.XmartMandatoryAttributeMissingException;
//import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Tag;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.mockito.Spy;
//import rbs.gbm.mdx.webService.interfaces.IMdxContent;
//import rbs.gbm.mdx.webService.interfaces.IMdxDocument;
//import rbs.gbm.mdx.webService.interfaces.IMdxHeader;
//
//import java.math.BigDecimal;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.atomic.AtomicInteger;
//
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.junit.jupiter.api.Assertions.fail;
//import static org.powermock.api.mockito.PowerMockito.when;
//
//class XmartMdxInstrumentsTest extends XmartEntitiesBaseTest {
//    @Mock
//    private MdxDocumentEvent mdxDocumentEvent;
//
//    @Mock
//    private IMdxDocument iMdxDocument;
//
//    @Mock
//    private IMdxContent iMdxContent;
//
//    @Spy
//    private IMdxHeader mdxHeader = new TestMdxHeader();
//
//    private Map<String, Object> headerMap = new HashMap<>();
//    private Map<String, Object> isinMap = new HashMap<>();
//    private Map<String, Object> derivedMap = new HashMap<>();
//    private Map<String, Object> attributeMap = new HashMap<>();
//    private Integer templateVersion;
//
//    private XmartMdxInstruments xmartMdxInstruments;
//
//    private static void xmlCheck(XmartMdxInstruments xmartMdxInstruments) {
//        String xml = validateXML(xmartMdxInstruments,
//                XmartEntitiesBaseTest.XMLEntityType.XmartMdxInstruments);
//        xmartMdxInstruments.getEntity().forEach(
//                xmartMdxInstrument -> validateXmlValues(xmartMdxInstrument, xml));
//    }
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.initMocks(this);
//        headerMap.put("AssetClass", getRandomString());
//        headerMap.put("InstrumentType", getRandomString());
//        headerMap.put("UseCase", getRandomString());
//        headerMap.put("Level", getRandomString());
//
//        isinMap.put("ISIN", getRandomString());
//        isinMap.put("Status", getRandomString());
//        isinMap.put("StatusReason", getRandomString());
//        isinMap.put("LastUpdateDateTime", getRandomString());
//
//        derivedMap.put("ClassificationType", getRandomString());
//        derivedMap.put("CommodityDerivativeIndicator", getRandomString());
//        derivedMap.put("FullName", getRandomString());
//        derivedMap.put("FXType", getRandomString());
//        derivedMap.put("ISOReferenceRate", getRandomString());
//        derivedMap.put("IssuerorOperatoroftheTradingVenueIdentifier", getRandomString());
//        derivedMap.put("ReturnorPayoutTrigger", getRandomString());
//        derivedMap.put("ShortName", getRandomString());
//        derivedMap.put("SingleorMultiCurrency", getRandomString());
//
//        attributeMap.put("AdditionalSubProduct", getRandomString());
//        attributeMap.put("BaseProduct", getRandomString());
//        attributeMap.put("DebtSeniority", getRandomString());
//        attributeMap.put("DeliveryType", getRandomString());
//        attributeMap.put("ExpiryDate", getRandomString());
//        attributeMap.put("FinalPriceType", getRandomString());
//        attributeMap.put("InstrumentISINFarLeg", getRandomString());
//        attributeMap.put("InstrumentISINNearLeg", getRandomString());
//        attributeMap.put("NotionalCurrency", getRandomString());
//        attributeMap.put("NotionalSchedule", getRandomString());
//        attributeMap.put("OptionExerciseStyle", getRandomString());
//        attributeMap.put("OptionType", getRandomString());
//        attributeMap.put("OtherAdditionalSubProduct", getRandomString());
//        attributeMap.put("OtherBaseProduct", getRandomString());
//        /*attributeMap.put("OtherLegReferenceRate", getRandomString());
//        attributeMap.put("OtherLegReferenceRateTermUnit", getRandomString());
//        attributeMap.put("OtherLegReferenceRateTermValue", new BigDecimal(getRndInt()));*/
//
//        attributeMap.put("OtherNotionalCurrency", getRandomString());
//        attributeMap.put("OtherReferenceRate", getRandomString());
//        attributeMap.put("OtherSubProduct", getRandomString());
//        attributeMap.put("PlaceofSettlement", getRandomString());
//
//        attributeMap.put("PriceMultiplier", new BigDecimal(getRndInt()));
//
//        attributeMap.put("ReferenceRate", getRandomString());
//        attributeMap.put("ReferenceRateTermUnit", getRandomString());
//        attributeMap.put("ReferenceRateTermValue", new BigDecimal(getRndInt()));
//
//        attributeMap.put("SettlementCurrency", getRandomString());
//        attributeMap.put("StrikePrice", getRandomString());
//        attributeMap.put("SubProduct", getRandomString());
//        attributeMap.put("TransactionType", getRandomString());
//        attributeMap.put("ValuationMethodorTrigger", getRandomString());
//    }
//
//    private void mock() {
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Header>");
//        headerMap.forEach((k, v) -> xml.append("<").append(k).append(">").append(v).append("</").append(k).append(">"));
//        xml.append("</Header>");
//
//        xml.append("<ISIN>");
//        isinMap.forEach((k, v) -> xml.append("<").append(k).append(">").append(v).append("</").append(k).append(">"));
//        xml.append("</ISIN>");
//
//        xml.append("<Derived>");
//        derivedMap
//                .forEach((k, v) -> xml.append("<").append(k).append(">").append(v).append("</").append(k).append(">"));
//        xml.append("</Derived>");
//
//        xml.append("<Attributes>");
//        attributeMap
//                .forEach((k, v) -> xml.append("<").append(k).append(">").append(v).append("</").append(k).append(">"));
//        xml.append("</Attributes>");
//
//        templateVersion = getRndInt();
//        xml.append("<TemplateVersion>").append(templateVersion).append("</TemplateVersion>");
//
//        xml.append("</Instrument>");
//
//        when(mdxDocumentEvent.getiMdxDocument()).thenReturn(iMdxDocument);
//        when(iMdxDocument.getContent()).thenReturn(iMdxContent);
//
//        when(iMdxContent.asString()).thenReturn(xml.toString());
//        when(iMdxDocument.getHeader()).thenReturn(mdxHeader);
//    }
//
//    private void verifyMappigValues(List<XmartMdxInstrument> xmartMdxInstruments) {
//        AtomicInteger match = new AtomicInteger();
//        xmartMdxInstruments.forEach(xmartMdxInstrument -> {
//            attributeMap.forEach((k, v) -> {
//                if (k.equals("OtherLegReferenceRateTermValue")) {
//                    if (areEqual((BigDecimal) v,
//                            xmartMdxInstrument.getOtherLegReferenceRateTermValue())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                }
//                if (k.equals("PriceMultiplier")) {
//                    if (areEqual((BigDecimal) v, xmartMdxInstrument.getPriceMultiplier())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                }
//
//                if (k.equals("ReferenceRateTermValue")) {
//                    if (areEqual((BigDecimal) v, xmartMdxInstrument.getReferenceRateTermValue())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                }
//
//                if (areEqual((String) v, xmartMdxInstrument.getAdditionalSubProduct())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getBaseProduct())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getDebtSeniority())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getDeliveryType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getExpiryDate())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getFinalPriceType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getInstrumentISINFarLeg())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getInstrumentISINNearLeg())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getNotionalCurrency())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getNotionalSchedule())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getOptionExerciseStyle())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getOptionType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getOtherAdditionalSubProduct())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getOtherBaseProduct())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                /*if (areEqual((String) v, xmartMdxInstrument.getOtherLegReferenceRate())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getOtherLegReferenceRateTermUnit())) {
//                    match.getAndIncrement();
//                    return;
//                }*/
//
//                if (areEqual((String) v, xmartMdxInstrument.getOtherNotionalCurrency())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getOtherReferenceRate())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getOtherSubProduct())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getPlaceofSettlement())) {
//                    match.getAndIncrement();
//                    return;
//                }
//
//                if (areEqual((String) v, xmartMdxInstrument.getReferenceRate())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getReferenceRateTermUnit())) {
//                    match.getAndIncrement();
//                    return;
//                }
//
//                if (areEqual((String) v, xmartMdxInstrument.getSettlementCurrency())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getStrikePrice())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getSubProduct())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getTransactionType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getValuationMethodorTrigger())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() != attributeMap.size()) {
//            fail("xmartMdxSvRefRegulatoryInstrument and Attribute Map did not match " + match.get() + " - - - "
//                    + attributeMap.size());
//        }
//
//        match.set(0);
//        xmartMdxInstruments.forEach(xmartMdxInstrument -> {
//            derivedMap.forEach((k, v) -> {
//                if (areEqual((String) v, xmartMdxInstrument.getClassificationType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getCommodityDerivativeIndicator())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getFullName())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getfXType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getiSOReferenceRate())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v,
//                        xmartMdxInstrument.getIssuerorOperatoroftheTradingVenueIdentifier())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getReturnorPayoutTrigger())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getDerivedShortName())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getSingleorMultiCurrency())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                /*if (areEqual((String) v, xmartMdxInstrument.getUnderlyingIssuerType())) {
//                    match.getAndIncrement();
//                    return;
//                }*/
//            });
//        });
//        if (match.get() != derivedMap.size()) {
//            fail("xmartMdxSvRefRegulatoryInstrument and Derived Map did not match");
//        }
//
//        match.set(0);
//        xmartMdxInstruments.forEach(xmartMdxInstrument -> {
//            headerMap.forEach((k, v) -> {
//                if (areEqual((String) v, xmartMdxInstrument.getAssetClass())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getInstrumentType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getLevel())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getUseCase())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() != headerMap.size()) {
//            fail("xmartMdxSvRefRegulatoryInstrument and Header Map did not match");
//        }
//
//        match.set(0);
//        xmartMdxInstruments.forEach(xmartMdxInstrument -> {
//            isinMap.forEach((k, v) -> {
//                if (areEqual((String) v, xmartMdxInstrument.getiSIN())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getLastUpdateDateTime())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getStatus())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrument.getStatusReason())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() != headerMap.size()) {
//            fail("xmartMdxSvRefRegulatoryInstrument and isin Map did not match");
//        }
//    }
//
//    private void create() throws XmartException {
//        xmartMdxInstruments = new XmartMdxInstruments(documentKey, mdxDocumentEvent);
//    }
//
//    @Tag("UnitTest")
//    @Test
//    public void testAddRefRegulatoryInstrument() {
//        mock();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add MdxSvRefRegulatoryInstruments failed ", e);
//        }
//        verifyMappigValues(xmartMdxInstruments.getEntity());
//        xmlCheck(xmartMdxInstruments);
//    }
//
//    @Tag("UnitTest")
//    @Test
//    public void testMandatoryFields() {
//        headerMap.remove("AssetClass");
//        isinMap.remove("ISIN");
//        mock();
//        when(mdxHeader.getTransport()).thenReturn(null);
//        when(mdxHeader.getTypeName()).thenReturn(null);
//        when(mdxHeader.getPath()).thenReturn(null);
//        assertThrows(XmartMandatoryAttributeMissingException.class, () -> this.create());
//    }
//}
