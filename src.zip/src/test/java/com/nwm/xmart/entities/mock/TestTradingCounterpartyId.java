package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.PartyClassification;
import com.rbs.odc.access.domain.TradingCounterpartyId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTradingCounterpartyId implements TradingCounterpartyId {
    String partyReference;
    PartyClassification partyClassification;

    public TestTradingCounterpartyId() {
        partyReference = getRandomString();
        try {
            partyClassification = PartyClassification.valueOf((getRndInt() % (PartyClassification.values().size()-1))+1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            partyClassification = PartyClassification.NULL;
        }
    }

    @Override
    public String getPartyReference() {
        return partyReference;
    }

    @Override
    public PartyClassification getPartyClassification() {
        return partyClassification;
    }

    @Override
    public String getNucleusId() {
        return null;// Not relevant for this test
    }

    @Override
    public int compareTo(TradingCounterpartyId o) {
        return 0;// Not relevant for this test
    }
}
