package com.nwm.xmart.entities.mock;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestInterestRateScheduleEntry implements com.rbs.odc.access.domain.InterestRateScheduleEntry {
    private BigDecimal rate = new BigDecimal(getRndInt());

    @Override
    public BigDecimal getRate() {
        return rate;
    }
}
