package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.SecurityInstrument;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestSecurityInstrument implements SecurityInstrument {
    private String securityName;
    private String seniority;

    public TestSecurityInstrument() {
        securityName = getRandomString();
        seniority = getRandomString();
    }

    @Override
    public String getSecurityName() {
        return securityName;
    }

    @Override
    public String getSeniority() {
        return seniority;
    }
}
