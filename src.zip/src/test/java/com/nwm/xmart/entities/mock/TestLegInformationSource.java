package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.LegInformationSource;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestLegInformationSource implements LegInformationSource {
    private String legIdentifier;
    private String informationSourceId;
    private SystemInstanceId informationSourceSystemId;
    private String informationSource;
    private String informationSourcePage;

    public TestLegInformationSource() {
        this.informationSourceId = getRandomString();
        try {
            this.informationSourceSystemId = SystemInstanceId
                    .valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            this.informationSourceSystemId = SystemInstanceId.NULL;
        }
        this.informationSource = getRandomString();
        this.informationSourcePage = getRandomString();
    }

    public TestLegInformationSource(String legIdentifier) {
        this();
        this.legIdentifier = legIdentifier;
    }

    @Override
    public SystemInstanceId getInformationSourceSystemId() {
        return informationSourceSystemId;
    }

    @Override
    public String getInformationSourceId() {
        return informationSourceId;
    }

    @Override
    public String getInformationSource() {
        return informationSource;
    }

    @Override
    public String getInformationSourcePage() {
        return informationSourcePage;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }
}
