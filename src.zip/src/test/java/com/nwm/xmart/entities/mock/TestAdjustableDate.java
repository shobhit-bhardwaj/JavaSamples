package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.AdjustableDate;
import com.rbs.odc.access.domain.BusinessDate;

public class TestAdjustableDate implements AdjustableDate {

    private BusinessDate date;

    TestAdjustableDate() {
        date = new TestBusinessDate();
    }

    @Override
    public BusinessDate getUnadjustedDate() {
        return date;
    }

    @Override
    public BusinessDate getAdjustedDate() {
        return date;
    }
}
