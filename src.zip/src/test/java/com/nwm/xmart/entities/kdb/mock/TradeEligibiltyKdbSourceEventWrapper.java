package com.nwm.xmart.entities.kdb.mock;

import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.sorting.DateTimeSortKey;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.kdb.sorting.SortKeyI;

import java.sql.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TradeEligibiltyKdbSourceEventWrapper {

    private static final SortKeyI sortKey = new DateTimeSortKey(new int[] { 0, 5 });
    private static String[] columnNames = { "date", "sym", "id_val", "leg_val", "table", "time", "isin",
                                            "instrument_name", "execution_eligibility", "out_of_scope", "mifid_fx_type",
                                            "id_key", "leg_key", "isin_tracking_id", "isin_error", "isin_db_recv_ts",
                                            "mifid_tracking_id", "mifid_error", "mifid_party_id", "mifid_inst_req",
                                            "mifid_db_recv_ts" };

    private static String[] columnTypes = { "Date", "String", "String", "String", "String", "Time", "String", "String",
                                            "String", "String", "String", "String", "String", "String", "String",
                                            "Timestamp", "String", "String", "String", "String", "Timestamp" };
    private KDBSourceEvent kdbSourceEvent;

    public TradeEligibiltyKdbSourceEventWrapper() {
        KDBFunctionType kdbFunctionType = KDBFunctionType.values()[getRndInt() % KDBFunctionType.values().length];
        boolean success = true;
        Object[] recordData = generateTradeEligibiltyData();
        long recordIndex = getRndInt();
        long documentReceivedTimestamp = getRndInt();
        String dateTime = getRandomString();
        String tag = getRandomString();
        String message = getRandomString();
        String functionName = "FXmifidTradeEligibility";
        String sourceID = getRndInt() + "";
        String tablename = "";
        kdbSourceEvent = new KDBSourceEvent(sourceID, functionName, tablename, success, message, tag, columnNames, recordData,
                recordIndex, sortKey, kdbFunctionType, dateTime);
    }

    private static Object[] generateTradeEligibiltyData() {
        Object[] data = new Object[columnNames.length];
        for (int i = 0; i < columnNames.length; i++) {
            switch (columnTypes[i]) {
            case "Date":
                data[i] = new Date(getRandomDate().getTime());
                break;
            case "String":
                data[i] = getRandomString();
                break;
            case "Time":
                data[i] = getRandomTime();
                break;
            case "Timestamp":
                data[i] = getRandomTimestamp();
                break;
            case "Integer":
                data[i] = getRndInt();
                break;
            default:
            }
        }
        return data;
    }

    public KDBSourceEvent getKdbSourceEvent() {
        return kdbSourceEvent;
    }
}
