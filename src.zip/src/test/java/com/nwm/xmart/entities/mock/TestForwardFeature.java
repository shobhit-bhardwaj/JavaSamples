package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.ForwardFeature;
import com.rbs.odc.access.domain.OptionType;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestForwardFeature implements ForwardFeature {

    private OptionType optionType;
    private Amount strikePrice;
    private String accumulatorType;
    private BigDecimal gearingFactor;
    private BigDecimal knockOutTriggerLevel;
    private Integer maximumNumberOfTradingDays;
    private Integer numberOfDailyShares;

    public TestForwardFeature() {
        try {
            optionType = OptionType.valueOf(getRndInt() % OptionType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            optionType = OptionType.NULL;
        }

        strikePrice = new TestAmount();
        accumulatorType = getRandomString();
        gearingFactor = new BigDecimal(getRndInt());
        knockOutTriggerLevel = new BigDecimal(getRndInt());
        maximumNumberOfTradingDays = Integer.valueOf(getRndInt());
        numberOfDailyShares = Integer.valueOf(getRndInt());
    }

    @Override
    public OptionType getOptionType() {
        return optionType;
    }

    @Override
    public Amount getStrikePrice() {
        return strikePrice;
    }

    @Override
    public String getAccumulatorType() {
        return accumulatorType;
    }

    @Override
    public BigDecimal getGearingFactor() {
        return gearingFactor;
    }

    @Override
    public BigDecimal getKnockOutTriggerLevel() {
        return knockOutTriggerLevel;
    }

    @Override
    public Integer getMaximumNumberOfTradingDays() {
        return maximumNumberOfTradingDays;
    }

    @Override
    public Integer getNumberOfDailyShares() {
        return numberOfDailyShares;
    }
}
