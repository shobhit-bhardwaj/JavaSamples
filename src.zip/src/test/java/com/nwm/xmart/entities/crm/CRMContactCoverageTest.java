package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.nwm.xmart.streaming.source.crm.entity.contactCoverage.ContactCoverage;
import com.nwm.xmart.streaming.source.crm.entity.contactCoverage.Product;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMContactCoverageTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private ContactCoverage contactCoverage;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmContactCoverage() {
        contactCoverage = new ContactCoverage();

        contactCoverage.setId(getRandomString());
        contactCoverage.setIsDeleted(getRndInt() % 2 == 0);
        contactCoverage.setSystemModstamp(getRandomString());
        contactCoverage.setName(getRandomString());
        contactCoverage.setCreatedById(getRandomString());
        contactCoverage.setCreatedDate(getRandomString());
        contactCoverage.setLastModifiedById(getRandomString());
        contactCoverage.setLastModifiedDate(getRandomString());
        contactCoverage.setCallOrderNumber(getRndInt());
        contactCoverage.setContact(getRandomString());
        contactCoverage.setDesk(getRandomString());

        Employee employee = new Employee();
        employee.setUser(getRandomString());
        employee.setECDId(getRandomString());
        contactCoverage.setEmployee(employee);

        contactCoverage.setEndDate(getRandomString());
        contactCoverage.setInactive(getRndInt() % 2 == 0);
        contactCoverage.setInactiveMisMatch(getRndInt() % 2 == 0);
        contactCoverage.setIsBackup(getRndInt() % 2 == 0);
        contactCoverage.setIsMyCoverage(getRndInt() % 2 == 0);
        contactCoverage.setIsPriority(getRndInt() % 2 == 0);
        contactCoverage.setIsTemporary(getRndInt() % 2 == 0);
        contactCoverage.setOriginalParentContactCoverage(getRandomString());
        contactCoverage.setParentContactCoverage(getRandomString());
        contactCoverage.setPriorityStatus(getRandomString());

        Product product = new Product();
        product.setName(getRandomString());
        product.setCategory(getRandomString());
        product.setDescription(getRandomString());
        product.setExpiryDate(getRandomString());
        product.setInactive(getRndInt() % 2 == 1);
        product.setSubCategory(getRandomString());
        contactCoverage.setProduct(product);

        contactCoverage.setRank(getRandomString());
        contactCoverage.setRole(getRandomString());
        contactCoverage.setStartDate(getRandomString());
        contactCoverage.setStatus(getRandomString());
        contactCoverage.setToBeProcessed(getRndInt() % 2 == 0);
        contactCoverage.setUniqueId(getRandomString());
    }

     /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmContactCoverageMapping(List<XmartMappedEntity> xmartCrmUserRoleEntities) {
        XmartMappedEntity xmartMappedEntity = xmartCrmUserRoleEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 29;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("contactCoverageId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getCreatedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getCreatedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("contactId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getContact(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("desk".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getDesk(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("ecdId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getEmployee().getECDId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("userId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getEmployee().getUser(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/

            if ("endDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getEndDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("inactive".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getInactive(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isBackup".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getIsBackup(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isMyCoverage".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getIsMyCoverage(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isPriority".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getIsPriority(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isTemporary".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getIsTemporary(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("originalParentContactCoverage".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getOriginalParentContactCoverage(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("parentContactCoverage".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getParentContactCoverage(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("priorityStatus".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getPriorityStatus(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("productName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getProduct().getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("productCategory".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getProduct().getCategory(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("productDescription".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getProduct().getDescription(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("productExpiryDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getProduct().getExpiryDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("productInactive".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getProduct().getInactive(),
                        (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("productSubCategory".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getProduct().getSubCategory(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("rank".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getRank(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("role".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getRole(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("startDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getStartDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("status".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contactCoverage.getStatus(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmContactCoverage();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.ContactCoverage);
        when(crmSourceEvent.getContactCoverage()).thenReturn(contactCoverage);
    }

    @Test
    void testCRMContactCoverage() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartMappedEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmContactCoverages");
        verifyCrmContactCoverageMapping(xmartMappedEntities);
    }
}
