package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BusinessCentreTime;
import com.rbs.odc.access.domain.FXLinkedNotional;
import com.rbs.odc.core.domain.BusinessCentreTimeImpl;

public class TestFXLinkedNotional implements FXLinkedNotional {

    private BusinessCentreTime businessCentreTime = new TestBusinessCentreTime();

    @Override
    public BusinessCentreTimeImpl getFixingTime() {
        return new BusinessCentreTimeImpl(businessCentreTime);
    }
}
