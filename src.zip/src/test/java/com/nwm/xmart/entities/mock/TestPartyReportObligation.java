package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.PartyReportObligation;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestPartyReportObligation implements PartyReportObligation {

    String regulatoryReportName = getRandomString();

    @Override
    public String getRegulatoryReportName() {
        return regulatoryReportName;
    }
}
