package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.MiFIDIIPostTradeClassificationScheme;
import com.rbs.odc.access.domain.PostTradeClassification;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestPostTradeClassification implements PostTradeClassification {
    private MiFIDIIPostTradeClassificationScheme postTradeClassification;

    public TestPostTradeClassification() {
        try {
            postTradeClassification = MiFIDIIPostTradeClassificationScheme
                    .valueOf(getRndInt() % MiFIDIIPostTradeClassificationScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("LinkageReasonScheme creation failed Using default value" + e.getMessage());
            postTradeClassification = MiFIDIIPostTradeClassificationScheme.NULL;
        }
    }

    @Override
    public MiFIDIIPostTradeClassificationScheme getPostTradeClassification() {
        return postTradeClassification;
    }
}