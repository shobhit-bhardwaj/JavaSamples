package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.TransactionMarginJurisdiction;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestTransactionMarginJurisdiction implements TransactionMarginJurisdiction {
    private String jurisdictionPartyApplicabilityScope;
    private String regulatoryAuthority;

    public TestTransactionMarginJurisdiction() {
        jurisdictionPartyApplicabilityScope = getRandomString();
        regulatoryAuthority = getRandomString();
    }

    @Override
    public String getJurisdictionPartyApplicabilityScope() {
        return jurisdictionPartyApplicabilityScope;
    }

    @Override
    public String getRegulatoryAuthority() {
        return regulatoryAuthority;
    }
}
