package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.DeliverOrPayIndicator;
import com.rbs.odc.access.domain.InstrumentLoanLeg;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestInstrumentLoanLeg implements InstrumentLoanLeg {
    DeliverOrPayIndicator deliverOrPayIndicator;

    public TestInstrumentLoanLeg() {
        try {
            deliverOrPayIndicator = DeliverOrPayIndicator
                    .valueOf(getRndInt() % DeliverOrPayIndicator.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            deliverOrPayIndicator = DeliverOrPayIndicator.NULL;
        }
    }

    @Override
    public DeliverOrPayIndicator getDeliverOrPayIndicator() {
        return deliverOrPayIndicator;
    }
}
