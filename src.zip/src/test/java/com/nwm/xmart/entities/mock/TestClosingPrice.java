package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.ClosingPrice;
import com.rbs.odc.access.domain.UnitPriceType;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestClosingPrice implements ClosingPrice {
    Amount amount;
    private BigDecimal percentage;
    private boolean b_amount;
    private boolean b_percentage;
    private UnitPriceType type;
    String currency;
    private BigDecimal price;

    TestClosingPrice() {
        this.amount = new TestAmount();
        this.percentage = new BigDecimal(getRndDouble());
        this.b_amount = getRndInt() % 2 == 1;
        this.b_percentage = getRndInt() % 2 == 1;
        this.currency = getRandomString();
        this.price = new BigDecimal(getRndDouble());

        try {
            type = UnitPriceType.valueOf(getRndInt() % UnitPriceType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            type = UnitPriceType.NULL;
        }
    }

    @Override
    public Amount getAmount() {
        return amount;
    }

    @Override
    public BigDecimal getPercentage() {
        return percentage;
    }

    @Override
    public boolean isAmount() {
        return b_amount;
    }

    @Override
    public boolean isPercentage() {
        return b_percentage;
    }

    @Override
    public UnitPriceType getType() {
        return type;
    }

    @Override
    public String getCurrency() {
        return currency;
    }

    @Override
    public BigDecimal getPrice() {
        return price;
    }
}
