package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.ReportingWaiver;
import com.rbs.odc.access.domain.ReportingWaiverTypeScheme;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestReportingWaiver implements ReportingWaiver {
    private ReportingWaiverTypeScheme reportingWaiverType;

    public TestReportingWaiver() {
        try {
            reportingWaiverType = ReportingWaiverTypeScheme
                    .valueOf(getRndInt() % ReportingWaiverTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("ReportingWaiverTypeScheme creation failed Using default value" + e.getMessage());
            reportingWaiverType = ReportingWaiverTypeScheme.NULL;
        }
    }

    @Override
    public ReportingWaiverTypeScheme getReportingWaiverType() {
        return reportingWaiverType;
    }
}
