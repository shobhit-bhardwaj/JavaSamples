package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.callReport.*;
import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMCallReportTest {
    @Mock
    CRMSourceEvent crmSourceEvent;
    List<ExternalAttendee> externalAttendees;
    List<CallReportAccount> callReportAccounts;
    private MappingNode mappingHierarchy;
    private CallReport callReport;
    private XmartGenericSet xmartSet;
    private int topicId = getRndInt();
    private List<InternalAttendee> internalAttendees;

    private List<InternalAttendee> setUpInternalAttendee() {
        internalAttendees = new ArrayList<>();
        InternalAttendee internalAttendee = null;

        internalAttendee = new InternalAttendee();
        internalAttendee.setCreatedById(getRandomString());
        internalAttendee.setCreatedDate(getRandomString());
        internalAttendee.setId(getRandomString());
        internalAttendee.setIsDeleted(getRndInt() % 2 == 0);
        internalAttendee.setLastModifiedById(getRandomString());
        internalAttendee.setLastModifiedDate(getRandomString());
        internalAttendee.setName(getRandomString());
        internalAttendee.setSharingReasons(getRandomString());
        internalAttendee.setSystemModstamp(getRandomString());
        internalAttendee.setStatus(getRandomString());
        internalAttendee.setAttendanceReason(getRandomString());
        internalAttendee.setCallReport(getRandomString());
        internalAttendee.setEmail(getRandomString());

        Employee employee = new Employee();
        employee.setECDId(getRandomString());
        employee.setUser(getRandomString());
        internalAttendee.setEmployee(employee);

        internalAttendee.setIsAttending(getRndInt() % 2 == 0);
        internalAttendee.setIsAutoNotified(getRndInt() % 2 == 0);
        internalAttendee.setIsNotify(getRndInt() % 2 == 0);
        internalAttendee.setIsShare(getRndInt() % 2 == 0);
        internalAttendee.setNotifyByEmail(getRndInt() % 2 == 0);
        internalAttendee.setRole(getRandomString());

        internalAttendees.add(internalAttendee);
        return internalAttendees;
    }

    private List<ExternalAttendee> setUpExternalAttendee() {
        externalAttendees = new ArrayList<>();
        ExternalAttendee externalAttendee = null;

        externalAttendee = new ExternalAttendee();
        externalAttendee.setCreatedById(getRandomString());
        externalAttendee.setCreatedDate(getRandomString());
        externalAttendee.setId(getRandomString());
        externalAttendee.setInteractionType(getRandomString());
        externalAttendee.setIsDeleted(getRndInt() % 2 == 0);
        externalAttendee.setLastModifiedById(getRandomString());
        externalAttendee.setLastModifiedDate(getRandomString());
        externalAttendee.setMeetingDate(getRandomString());
        externalAttendee.setMeetingType(getRandomString());
        externalAttendee.setName(getRandomString());
        externalAttendee.setPriority(getRandomString());
        externalAttendee.setSharingReasons(getRandomString());
        externalAttendee.setSubjectObjectives(getRandomString());
        externalAttendee.setSystemModstamp(getRandomString());
        externalAttendee.setStatus(getRandomString());
        externalAttendee.setCallReport(getRandomString());
        externalAttendee.setContact(getRandomString());
        externalAttendee.setEmail(getRandomString());
        externalAttendee.setPhone(getRandomString());
        externalAttendee.setTitle(getRandomString());

        externalAttendees.add(externalAttendee);
        return externalAttendees;
    }

    private List<CallReportAccount> setUpCallReportAccount() {
        callReportAccounts = new ArrayList<>();
        CallReportAccount callReportAccount = null;

        callReportAccount = new CallReportAccount();
        callReportAccount.setId(getRandomString());
        callReportAccount.setCreatedById(getRandomString());
        callReportAccount.setCreatedDate(getRandomString());
        callReportAccount.setIsDeleted(getRndInt() % 2 == 0);
        callReportAccount.setLastModifiedById(getRandomString());
        callReportAccount.setLastModifiedDate(getRandomString());
        callReportAccount.setName(getRandomString());
        callReportAccount.setSystemModstamp(getRandomString());

        Account account = new Account();
        account.setExternalAccountNumber(getRandomString());
        callReportAccount.setAccount(account);

        callReportAccount.setCallReport(getRandomString());
        callReportAccount.setIsPrimary(getRndInt() % 2 == 0);

        callReportAccounts.add(callReportAccount);
        return callReportAccounts;
    }

    private void setUpCrmCallReport() {
        callReport = new CallReport();

        callReport.setBookmark(getRndInt() % 2 == 0);
        callReport.setCallOutcome(getRandomString());
        callReport.setCallReportLOBTxT(getRandomString());
        callReport.setCallReportRoleTxT(getRandomString());
        callReport.setCreatedById(getRandomString());
        callReport.setCreatedDate(getRandomString());
        callReport.setId(getRandomString());
        callReport.setIsDeleted(getRndInt() % 2 == 0);
        callReport.setLastActivityDate(getRandomString());
        callReport.setLastModifiedById(getRandomString());
        callReport.setLastModifiedDate(getRandomString());
        callReport.setLocalEndTime(getRandomString());
        callReport.setLocalStartTime(getRandomString());
        callReport.setName(getRandomString());
        callReport.setOwnerId(getRandomString());
        callReport.setPostalCode(getRandomString());
        callReport.setSecurityLevel(getRandomString());
        callReport.setSharingReasons(getRandomString());
        callReport.setSystemModstamp(getRandomString());
        callReport.setCalledContactNumber(getRandomString());
        callReport.setCallDisposition(getRandomString());
        callReport.setCallRating(getRandomString());
        callReport.setCallReportID(getRandomString());
        callReport.setCity(getRandomString());
        callReport.setClientInitiated(getRndInt() % 2 == 0);

        Client client = new Client();
        client.setExternalAccountNumber(getRandomString());
        callReport.setClient(client);

        callReport.setCountry(getRandomString());
        callReport.setCreatedByEmployee(getRandomString());
        callReport.setDoNotForward(getRndInt() % 2 == 0);
        callReport.setEndTime(getRandomString());
        callReport.setInteractionType(getRandomString());
        callReport.setLocation(getRandomString());
        callReport.setLock(getRandomString());

        LoggedBy loggedBy = new LoggedBy();
        loggedBy.setECDId(getRandomString());
        loggedBy.setUser(getRandomString());
        callReport.setLoggedBy(loggedBy);

        callReport.setLoggedFrom(getRandomString());
        callReport.setMeetingDate(getRandomString());
        callReport.setMeetingType(getRandomString());
        callReport.setNotes(getRandomString());
        callReport.setNotifyAttendees(getRndInt() % 2 == 0);
        callReport.setNotifyByEmail(getRndInt() % 2 == 0);
        callReport.setNotifyOthers(getRndInt() % 2 == 0);
        callReport.setNumberOfRelationships(getRndInt());
        callReport.setPriority(getRandomString());
        callReport.setPrivate(getRndInt() % 2 == 0);
        callReport.setRecordType(getRandomString());
        callReport.setRelatedEvent(getRandomString());
        callReport.setRelatedToId(getRandomString());
        callReport.setRelatedToType(getRandomString());
        callReport.setSelectedContact(getRandomString());
        callReport.setStartTime(getRandomString());
        callReport.setState(getRandomString());
        callReport.setStatus(getRandomString());
        callReport.setSubjectMeetingObjectives(getRandomString());
        callReport.setSubType(getRandomString());
        callReport.setTimeSpentHrs(getRandomString());
        callReport.setTimeSpentMin(getRndInt());
        callReport.setTransactionId(getRandomString());
        callReport.setVisibilityLevel(getRandomString());
        callReport.setUserProfile(getRandomString());

        callReport.setInternalAttendees(setUpInternalAttendee());
        callReport.setExternalAttendees(setUpExternalAttendee());
        callReport.setCallReportAccount(setUpCallReportAccount());
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmCallReportMapping(List<XmartMappedEntity> xmartMappedEntities) {
        XmartMappedEntity xmartMappedEntity = xmartMappedEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 42;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("callOutcome".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCallOutcome(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("callReportLOBTxT".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCallReportLOBTxT(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("callReportRoleTxT".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCallReportRoleTxT(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCreatedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCreatedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("callReportId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("localEndTime".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getLocalEndTime(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("localStartTime".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getLocalStartTime(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ownerId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getOwnerId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("postalCode".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getPostalCode(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("securityLevel".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getSecurityLevel(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("calledContactNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCalledContactNumber(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            /*if ("callDisposition".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCallDisposition(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            /*if ("callRating".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCallRating(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("callReportExternalId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCallReportID(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("city".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCity(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("clientInitiated".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getClientInitiated(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("externalAccountNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getClient().getExternalAccountNumber(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("country".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCountry(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("createdByEmployee".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getCreatedByEmployee(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("doNotForward".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getDoNotForward(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("endTime".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getEndTime(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("interactionType".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getInteractionType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("location".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getLocation(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("loggedByECDId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getLoggedBy().getECDId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("loggedFrom".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getLoggedFrom(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("meetingDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getMeetingDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("meetingType".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getMeetingType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("priority".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getPriority(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("private".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getPrivate(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("recordType".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getRecordType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("relatedEvent".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getRelatedEvent(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("relatedToId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getRelatedToId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("relatedToType".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getRelatedToType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("selectedContactId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getSelectedContact(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/

            if ("startTime".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getStartTime(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("state".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getState(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("status".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getStatus(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("subjectMeetingObjectives".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getSubjectMeetingObjectives(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("subType".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getSubType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("timeSpentHrs".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getTimeSpentHrs(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("timeSpentMin".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getTimeSpentMin(), (Integer) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("transactionId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getTransactionId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("visibilityLevel".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getVisibilityLevel(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("userProfile".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReport.getUserProfile(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Call Report Count Count doesn't match the Expected Count");
        }
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyExternalAttendeesMapping(List<XmartMappedEntity> xmartMappedEntities) {
        XmartMappedEntity xmartMappedEntity = xmartMappedEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 13;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getCreatedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getCreatedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("externalAttendeeId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getLastModifiedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getLastModifiedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getSystemModstamp(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("status".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getStatus(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("callReportId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getCallReport(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("contactId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getContact(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("email".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getEmail(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("phone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getPhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("title".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(externalAttendees.get(0).getTitle(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Call Report External Attendees Count Count doesn't match the Expected Count");
        }
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyInternalAttendeesMapping(List<XmartMappedEntity> xmartMappedEntities) {
        XmartMappedEntity xmartMappedEntity = xmartMappedEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 15;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getCreatedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getCreatedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("internalAttendeeId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getLastModifiedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getLastModifiedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getSystemModstamp(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("status".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getStatus(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("attendanceReason".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getAttendanceReason(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("callReportId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getCallReport(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("email".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getEmail(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("ecdId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getEmployee().getECDId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("isAttending".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getIsAttending(),
                        (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isNotify".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getIsNotify(),
                        (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isShare".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getIsShare(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("role".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(internalAttendees.get(0).getRole(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Call Report Internal Attendees Count Count doesn't match the Expected Count");
        }
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmCallReportAccountsMapping(List<XmartMappedEntity> xmartMappedEntities) {
        XmartMappedEntity xmartMappedEntity = xmartMappedEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 10;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("callReportAccountId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getCreatedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getCreatedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getLastModifiedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getLastModifiedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getSystemModstamp(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("externalAccountNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getAccount().getExternalAccountNumber(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("callReportId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getCallReport(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isPrimary".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callReportAccounts.get(0).getIsPrimary(),
                        (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Call Report Account Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmCallReport();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.CallReport);
        when(crmSourceEvent.getCallReport()).thenReturn(callReport);
    }

    @Test
    void testCRMCallReport() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartCrmCallReportEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmCallReports");
        verifyCrmCallReportMapping(xmartCrmCallReportEntities);

        List<XmartMappedEntity> xmartExternalAttendees = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmCallReportExternalAttendees");
        verifyExternalAttendeesMapping(xmartExternalAttendees);

        List<XmartMappedEntity> xmartInternalAttendees = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmCallReportInternalAttendees");
        verifyInternalAttendeesMapping(xmartInternalAttendees);

        List<XmartMappedEntity> xmartCallReportAccounts = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmCallReportAccounts");
        verifyCrmCallReportAccountsMapping(xmartCallReportAccounts);
    }
}
























