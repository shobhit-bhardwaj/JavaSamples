package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.EmployeeId;
import com.rbs.odc.access.domain.TransactionProcessRolePlayer;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestTransactionProcessRolePlayer implements TransactionProcessRolePlayer {
    private String processRolePlayerType;
    private String status;
    private String additionalComments;
    private EmployeeId employeeId;

    public TestTransactionProcessRolePlayer() {
        this.processRolePlayerType = getRandomString();
        this.status = getRandomString();
        this.additionalComments = getRandomString();
        employeeId = new TestEmployeeId();
    }

    @Override
    public String getProcessRolePlayerType() {
        return processRolePlayerType;
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public String getAdditionalComments() {
        return additionalComments;
    }

    @Override
    public EmployeeId getEmployeeId() {
        return employeeId;
    }
}
