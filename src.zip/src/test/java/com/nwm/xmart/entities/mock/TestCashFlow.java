package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestCashFlow implements Cashflow {
    private String sourceSystemEventId = getRandomString();
    private String legIdentifier = getRandomString();
    private PaymentType paymentType;
    private Amount amount = new TestAmount();
    private BusinessDate effectiveDate = new TestBusinessDate();
    private Date eventDateTime = getRandomDate();
    private TradingParty payer = new TestTradingParty();
    private TradingParty receiver = new TestTradingParty();
    private Boolean isEstimated = getRndInt() % 2 == 0;
    private Brokerage brokerage = new TestBrokerage();
    private AdjustableDate effectiveDt = new TestAdjustableDate();
    private Boolean settlementMessageRequired = getRndInt() % 2 == 0;

    public TestCashFlow() {
        try {
            paymentType = PaymentType.valueOf(getRndInt() % PaymentType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            paymentType = PaymentType.NULL;
        }
    }

    @Override
    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public PaymentType getPaymentType() {
        return paymentType;
    }

    @Override
    public Amount getAmount() {
        return amount;
    }

    @Override
    public BusinessDate getEffectiveDate() {
        return effectiveDate;
    }

    @Override
    public Date getEventDateTime() {
        return eventDateTime;
    }

    @Override
    public TradingParty getPayer() {
        return payer;
    }

    @Override
    public TradingParty getReceiver() {
        return receiver;
    }

    @Override
    public TradingParty getTradingCounterParty(TradingParty tradingParty) {
        return null;
    }

    @Override
    public Boolean getIsEstimated() {
        return isEstimated;
    }

    @Override
    public Brokerage getBrokerage() {
        return brokerage;
    }

    @Override
    public AdjustableDate getEffectiveDt() {
        return effectiveDt;
    }

    @Override
    public Boolean getSettlementMessageRequired() {
        return settlementMessageRequired;
    }
}
