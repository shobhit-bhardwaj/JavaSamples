package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.nwm.xmart.streaming.source.crm.entity.organization.Member;
import com.nwm.xmart.streaming.source.crm.entity.organization.Organization;
import com.nwm.xmart.streaming.source.crm.entity.organization.RecordType;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMOrganizationTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private Organization organization;

    private XmartGenericSet xmartSet;

    private List<Member> members;

    private int topicId = getRndInt();

    private void setUpCrmOrganization() {
        organization = new Organization();

        organization.setCreatedById(getRandomString());
        organization.setCreatedDate(getRandomString());
        organization.setExternalID(getRandomString());
        organization.setId(getRandomString());
        organization.setLastModifiedById(getRandomString());
        organization.setLastModifiedDate(getRandomString());
        organization.setName(getRandomString());
        organization.setOwnerId(getRandomString());
        organization.setPrivateSide(getRndInt() % 2 == 1);

        RecordType recordType = new RecordType();
        recordType.setRecordTypeName(getRandomString());
        organization.setRecordType(recordType);

        organization.setRoleId(getRandomString());
        organization.setSharingTeamGroup(getRandomString());
        organization.setShortName(getRandomString());
        organization.setSystemModstamp(getRandomString());
        organization.setDescription(getRandomString());
        organization.setIsTop(getRndInt() % 2 == 1);
        organization.setParent(getRandomString());
        organization.setType(getRandomString());

        members = new ArrayList<>();
        Member member = new Member();

        member.setCreatedById(getRandomString());
        member.setCreatedDate(getRandomString());
        member.setId(getRandomString());
        member.setLastModifiedById(getRandomString());
        member.setLastModifiedDate(getRandomString());
        member.setName(getRandomString());
        member.setOwnerId(getRandomString());
        member.setSystemModstamp(getRandomString());

        Employee employee = new Employee();
        employee.setECDId(getRandomString());
        employee.setUser(getRandomString());
        member.setEmployee(employee);

        member.setOrganizationStructure(getRandomString());
        member.setRole(getRandomString());
        member.setUserId(getRandomString());

        members.add(member);

        organization.setMembers(members);
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmOrganizationMapping(List<XmartMappedEntity> xmartMappedEntities) {
        XmartMappedEntity xmartMappedEntity = xmartMappedEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 18;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getCreatedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getCreatedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("externalID".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getExternalID(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("organizationStructureId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ownerId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getOwnerId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("privateSide".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getPrivateSide(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("recordTypeName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getRecordType().getRecordTypeName(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("roleId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getRoleId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("sharingTeamGroup".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getSharingTeamGroup(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("shortName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getShortName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("description".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getDescription(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isTop".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getIsTop(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("parent".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getParent(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("type".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Organization Attribute Count doesn't match the Expected Count");
        }
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmOrganizationMembersMapping(List<XmartMappedEntity> xmartMappedEntities) {
        XmartMappedEntity xmartMappedEntity = xmartMappedEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 12;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getCreatedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getCreatedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("organizationMemberId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getLastModifiedById(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getLastModifiedDate(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getName(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ownerId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getOwnerId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getSystemModstamp(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("ecdId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getEmployee().getECDId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("organizationStructureId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getOrganizationStructure(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("role".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(organization.getMembers().get(0).getRole(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("userId".equals(xmartMappedAttribute.getAttributeName())) {
                assertTrue(organization.getMembers().get(0).getUserId()
                                       .equals((String) organization.getMembers().get(0).getEmployee().getUser())
                        || organization.getMembers().get(0).getUserId()
                                       .equals((String) organization.getMembers().get(0).getUserId()));
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Organization Members doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmOrganization();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.Organization);
        when(crmSourceEvent.getOrganization()).thenReturn(organization);
    }

    @Test
    void testCRMOrganization() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartMappedEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmOrganizations");
        verifyCrmOrganizationMapping(xmartMappedEntities);

        List<XmartMappedEntity> members = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmOrganizationMembers");
        verifyCrmOrganizationMembersMapping(members);
    }
}
