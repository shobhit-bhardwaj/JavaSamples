package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.InitialPrice;
import com.rbs.odc.access.domain.UnitPriceType;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestInitialPrice implements InitialPrice {

    private Amount amount = new TestAmount();
    private BigDecimal percentage = new BigDecimal(getRndDouble());
    private UnitPriceType type;

    public TestInitialPrice() {
        try {
            type = UnitPriceType.valueOf(getRndInt() % UnitPriceType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            type = UnitPriceType.NULL;
        }
    }

    @Override
    public Amount getAmount() {
        return amount;
    }

    @Override
    public BigDecimal getPercentage() {
        return percentage;
    }

    @Override
    public UnitPriceType getType() {
        return type;
    }
}
