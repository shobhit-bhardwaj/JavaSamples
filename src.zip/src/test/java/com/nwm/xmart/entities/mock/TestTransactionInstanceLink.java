package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionInstanceLink implements TransactionInstanceLink {
    private LinkageReasonScheme linkageReasonScheme;
    private SystemInstanceId linkSourceSystemId;
    private String linkTransactionId;
    private String linkTransactionLegId;
    private String linkTransactionVersion;
    private String linkTransactionInstance;
    private TradeIdClassificationScheme tradeIdClassification;

    public TestTransactionInstanceLink() {
        try {
            linkageReasonScheme = LinkageReasonScheme.valueOf(getRndInt() % LinkageReasonScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("LinkageReasonScheme creation failed Using default value" + e.getMessage());
            linkageReasonScheme = LinkageReasonScheme.NULL;
        }

        try {
            linkSourceSystemId = SystemInstanceId.valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("SystemInstanceId creation failed Using default value" + e.getMessage());
            linkSourceSystemId = SystemInstanceId.NULL;
        }

        linkTransactionId = getRandomString();
        linkTransactionLegId = getRandomString();
        linkTransactionVersion = getRandomString();
        linkTransactionInstance = getRandomString();

        try {
            tradeIdClassification = TradeIdClassificationScheme
                    .valueOf(getRndInt() % TradeIdClassificationScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("TradeIdClassificationScheme creation failed Using default value" + e.getMessage());
            tradeIdClassification = TradeIdClassificationScheme.NULL;
        }
    }

    @Override
    public LinkageReasonScheme getLinkageReasonScheme() {
        return linkageReasonScheme;
    }

    @Override
    public SystemInstanceId getLinkSourceSystemId() {
        return linkSourceSystemId;
    }

    @Override
    public String getLinkTransactionId() {
        return linkTransactionId;
    }

    @Override
    public String getLinkTransactionLegId() {
        return linkTransactionLegId;
    }

    @Override
    public String getLinkTransactionVersion() {
        return linkTransactionVersion;
    }

    @Override
    public String getLinkTransactionInstance() {
        return linkTransactionInstance;
    }

    @Override
    public TradeIdClassificationScheme getTradeIdClassification() {
        return tradeIdClassification;
    }
}
