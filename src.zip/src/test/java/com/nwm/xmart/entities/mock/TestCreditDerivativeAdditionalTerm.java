package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CreditDerivativeAdditionalTerm;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestCreditDerivativeAdditionalTerm implements CreditDerivativeAdditionalTerm {
    private static final long serialVersionUID = -3964799939830373858L;
    String additionalTerm = getRandomString();

    @Override
    public String getAdditionalTerm() {
        return additionalTerm;
    }
}
