package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.RateReset;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestRateReset implements RateReset {
    private String legIdentifier;
    private BigDecimal resetRate;

    public TestRateReset() {
        legIdentifier = getRandomString();
        resetRate = new BigDecimal(getRndInt());
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public BigDecimal getResetRate() {
        return resetRate;
    }
}
