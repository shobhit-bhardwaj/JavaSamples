//package com.nwm.xmart.entities.mdx;
//
//import com.nwm.xmart.entities.XmartEntitiesBaseTest;
//import com.nwm.xmart.entities.mdx.mock.TestMdxHeader;
//import com.nwm.xmart.exception.XmartException;
//import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Tag;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.mockito.Spy;
//import rbs.gbm.mdx.webService.interfaces.IMdxContent;
//import rbs.gbm.mdx.webService.interfaces.IMdxDocument;
//import rbs.gbm.mdx.webService.interfaces.IMdxHeader;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.atomic.AtomicInteger;
//
//import static org.junit.jupiter.api.Assertions.fail;
//import static org.powermock.api.mockito.PowerMockito.when;
//
//class XmartMdxInstrumentUnderlyingsTest extends XmartEntitiesBaseTest {
//    @Mock
//    private MdxDocumentEvent mdxDocumentEvent;
//
//    @Mock
//    private IMdxDocument iMdxDocument;
//
//    @Mock
//    private IMdxContent iMdxContent;
//
//    @Spy
//    private IMdxHeader mdxHeader = new TestMdxHeader();
//
//    private Map<String, Object> derivedMap = new HashMap<>();
//    private Map<String, Object> attributeMap = new HashMap<>();
//    private Map<String, Object> underlyingMap = new HashMap<>();
//    private Map<String, Object> underlyingIndexMap = new HashMap<>();
//    private Map<String, Object> underlyingPropMap = new HashMap<>();
//    private Map<String, Object> underlyingISINMap = new HashMap<>();
//
//    private List<String> iSOUnderlyingInstrumentIndex = new ArrayList<>();
//    private List<String> underlyingInstrumentIsin = new ArrayList<>();
//    private List<String> instrumentIsin = new ArrayList<>();
//
//    private List<Map<String, Object>> underlyingIndexMaps = new ArrayList<>();
//    private List<Map<String, Object>> underlyingPropMaps = new ArrayList<>();
//
//    private XmartMdxInstrumentUnderlyings xmartMdxInstrumentUnderlyings;
//
//    private static void xmlCheck(XmartMdxInstrumentUnderlyings xmartMdxInstrumentUnderlyings) {
//        String xml = validateXML(xmartMdxInstrumentUnderlyings, XMLEntityType.XmartMdxInstrumentUnderlyings);
//        xmartMdxInstrumentUnderlyings.getEntity().forEach(
//                xmartMdxInstrumentUnderlying -> validateXmlValues(xmartMdxInstrumentUnderlying, xml));
//    }
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    private void mock(String xml) {
//        when(mdxDocumentEvent.getiMdxDocument()).thenReturn(iMdxDocument);
//        when(iMdxDocument.getContent()).thenReturn(iMdxContent);
//
//        when(iMdxContent.asString()).thenReturn(xml);
//        when(iMdxDocument.getHeader()).thenReturn(mdxHeader);
//    }
//
//    /*Case 1
//    <Attributes>
//	    <UnderlyingInstrumentISIN>XS1374865555</UnderlyingInstrumentISIN>
//    </Attributes>*/
//    private void mockAttributesUnderlyingInstrumentISINRoot() {
//        attributeMap.put("type", "root");
//        attributeMap.put("UnderlyingInstrumentISIN", getRandomString());
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//        attributeMap
//                .forEach((k, v) -> xml.append("<").append(k).append(">").append(v).append("</").append(k).append(">"));
//        xml.append("</Attributes>");
//
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*Case 1
//    <Attributes>
//	    <UnderlyingInstrumentISIN>XS1374865555</UnderlyingInstrumentISIN>
//    </Attributes>*/
//    private void verifyAttributesUnderlyingInstrumentISINRoot(
//            List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        AtomicInteger match = new AtomicInteger();
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            attributeMap.forEach((k, v) -> {
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentISIN())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() != attributeMap.size()) {
//            fail("verifyAttributesUnderlyingInstrumentISIN and mocked Map did not match " + match.get() + " - - - "
//                    + attributeMap.size());
//        }
//    }
//
//    /*Case 1
//    <Attributes>
//	    <UnderlyingInstrumentISIN>XS1374865555</UnderlyingInstrumentISIN>
//    </Attributes>*/
//    @Tag("UnitTest")
//    @Test
//    public void testAddAttributesUnderlyingInstrumentISINRoot() {
//        mockAttributesUnderlyingInstrumentISINRoot();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add RefRegulatoryInstrumentAttributeRoot failed ", e);
//        }
//        verifyAttributesUnderlyingInstrumentISINRoot(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    /*Case 2
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentISIN>INE713G08012</UnderlyingInstrumentISIN>
//		    <UnderlyingInstrumentISIN>XS0161774665</UnderlyingInstrumentISIN>
//        </Underlying>
//    </Attributes>*/
//    private void mockAttributesUnderlyingUnderlyingInstrumentISIN() {
//        attributeMap.put("type", "Underlying");
//        underlyingInstrumentIsin.add(getRandomString());
//        underlyingInstrumentIsin.add(getRandomString());
//        underlyingInstrumentIsin.add(getRandomString());
//        underlyingInstrumentIsin.add(getRandomString());
//        attributeMap.put("Underlying", underlyingInstrumentIsin);
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//
//        attributeMap.forEach((k, v) -> {
//            if ("Underlying".equals(k)) {
//                xml.append("<").append(k).append(">");
//
//                List<String> underlyingInstrumentIsin = (List) v;
//                underlyingInstrumentIsin.forEach(value -> {
//                    xml.append("<").append("UnderlyingInstrumentISIN").append(">").append(value).append("</")
//                       .append("UnderlyingInstrumentISIN").append(">");
//                });
//
//                xml.append("</").append(k).append(">");
//            }
//        });
//        xml.append("</Attributes>");
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*Case 2
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentISIN>INE713G08012</UnderlyingInstrumentISIN>
//		    <UnderlyingInstrumentISIN>XS0161774665</UnderlyingInstrumentISIN>
//        </Underlying>
//    </Attributes>*/
//    private void verifyAttributesUnderlyingUnderlyingInstrumentISIN(
//            List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        AtomicInteger match = new AtomicInteger();
//        List<String> underlyingInstrumentIsin = (List) attributeMap.get("Underlying");
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            underlyingInstrumentIsin.forEach(v -> {
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentISIN())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) attributeMap.get("type"), xmartMdxInstrumentUnderlying.getType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() / underlyingInstrumentIsin.size() != underlyingInstrumentIsin.size()) {
//            fail("verifyAttributesUnderlyingUnderlyingInstrumentISIN and mocked Map did not match "
//                    + match.get() / underlyingInstrumentIsin.size() + " - - - " + underlyingInstrumentIsin.size());
//        }
//    }
//
//    /*Case 2
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentISIN>INE713G08012</UnderlyingInstrumentISIN>
//		    <UnderlyingInstrumentISIN>XS0161774665</UnderlyingInstrumentISIN>
//        </Underlying>
//    </Attributes>*/
//    @Tag("UnitTest")
//    @Test
//    public void testAddAttributesUnderlyingUnderlyingInstrumentISIN() {
//        mockAttributesUnderlyingUnderlyingInstrumentISIN();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add AttributesUnderlyingUnderlyingInstrumentISIN failed ", e);
//        }
//        verifyAttributesUnderlyingUnderlyingInstrumentISIN(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    /*Case 3
//    <Attributes>
//	    <Underlying>
//		    <InstrumentISIN>JP343610ADB8</InstrumentISIN>
//        </Underlying>
//    </Attributes>*/
//    private void mockAttributesUnderlyingInstrumentISIN() {
//        attributeMap.put("type", "Underlying");
//        instrumentIsin.add(getRandomString());
//        instrumentIsin.add(getRandomString());
//        instrumentIsin.add(getRandomString());
//        instrumentIsin.add(getRandomString());
//        attributeMap.put("Underlying", instrumentIsin);
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//
//        attributeMap.forEach((k, v) -> {
//            if ("Underlying".equals(k)) {
//                xml.append("<").append(k).append(">");
//
//                List<String> instrumentIsin = (List) v;
//                instrumentIsin.forEach(value -> {
//                    xml.append("<").append("InstrumentISIN").append(">").append(value).append("</")
//                       .append("InstrumentISIN").append(">");
//                });
//
//                xml.append("</").append(k).append(">");
//            }
//        });
//        xml.append("</Attributes>");
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*Case 3
//    <Attributes>
//	    <Underlying>
//		    <InstrumentISIN>JP343610ADB8</InstrumentISIN>
//        </Underlying>
//    </Attributes>*/
//    private void verifyAttributesUnderlyingInstrumentISIN(
//            List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        AtomicInteger match = new AtomicInteger();
//        List<String> instrumentIsin = (List) attributeMap.get("Underlying");
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            instrumentIsin.forEach(v -> {
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentISIN())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) attributeMap.get("type"), xmartMdxInstrumentUnderlying.getType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() / instrumentIsin.size() != instrumentIsin.size()) {
//            fail("verifyAttributesUnderlyingUnderlyingInstrumentISIN and mocked Map did not match "
//                    + match.get() / instrumentIsin.size() + " - - - " + instrumentIsin.size());
//        }
//    }
//
//    /*Case 3
//    <Attributes>
//	    <Underlying>
//		    <InstrumentISIN>JP343610ADB8</InstrumentISIN>
//        </Underlying>
//    </Attributes>*/
//    @Tag("UnitTest")
//    @Test
//    public void testAddAttributesUnderlyingInstrumentISIN() {
//        mockAttributesUnderlyingInstrumentISIN();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add testAddAttributesUnderlyingInstrumentISIN failed ", e);
//        }
//        verifyAttributesUnderlyingInstrumentISIN(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    /*Case 4
//    <Attributes>
//	    <UnderlyingInstrumentIndexTermValue>1</UnderlyingInstrumentIndexTermValue>
//	    <UnderlyingInstrumentIndexTermUnit>MNTH</UnderlyingInstrumentIndexTermUnit>
//	    <UnderlyingInstrumentIndex>GBP-LIBOR-BBA</UnderlyingInstrumentIndex>
//    </Attributes>*/
//    private void mockAttributesAll() {
//        attributeMap.put("type", "root");
//        attributeMap.put("UnderlyingInstrumentIndex", getRandomString());
//        attributeMap.put("UnderlyingInstrumentIndexTermValue", new BigDecimal(getRndInt()));
//        attributeMap.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//        attributeMap
//                .forEach((k, v) -> xml.append("<").append(k).append(">").append(v).append("</").append(k).append(">"));
//        xml.append("</Attributes>");
//
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*Case 4
//    <Attributes>
//	    <UnderlyingInstrumentIndexTermValue>1</UnderlyingInstrumentIndexTermValue>
//	    <UnderlyingInstrumentIndexTermUnit>MNTH</UnderlyingInstrumentIndexTermUnit>
//	    <UnderlyingInstrumentIndex>GBP-LIBOR-BBA</UnderlyingInstrumentIndex>
//    </Attributes>*/
//    private void verifyAttributesAll(List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        AtomicInteger match = new AtomicInteger();
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            attributeMap.forEach((k, v) -> {
//                if (k.equals("UnderlyingInstrumentIndexTermValue")) {
//                    if (areEqual((BigDecimal) v,
//                            xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndexTermValue())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndex())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndexTermUnit())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() != attributeMap.size()) {
//            fail("verifyAttributesAll and mocked Map did not match " + match.get() + " - - - " + attributeMap.size());
//        }
//    }
//
//    /*Case 4
//    <Attributes>
//	    <UnderlyingInstrumentIndexTermValue>1</UnderlyingInstrumentIndexTermValue>
//	    <UnderlyingInstrumentIndexTermUnit>MNTH</UnderlyingInstrumentIndexTermUnit>
//	    <UnderlyingInstrumentIndex>GBP-LIBOR-BBA</UnderlyingInstrumentIndex>
//    </Attributes>*/
//    @Tag("UnitTest")
//    @Test
//    public void testAddAttributesAll() {
//        mockAttributesAll();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add testAddAttributesAll failed ", e);
//        }
//        verifyAttributesAll(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    /*Case 5
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//		    <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//		    <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//	    </Underlying>
//    </Attributes>*/
//    private void mockAttributesUnderlyingAll() {
//        underlyingMap.put("type", "Underlying");
//        underlyingMap.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingMap.put("UnderlyingInstrumentIndexTermValue", new BigDecimal(getRndInt()));
//        underlyingMap.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        attributeMap.put("Underlying", underlyingMap);
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//
//        attributeMap.forEach((k, v) -> {
//            xml.append("<").append(k).append(">");
//
//            HashMap<String, Object> underlyingMap = (HashMap) v;
//            underlyingMap.forEach((key, value) -> {
//                xml.append("<").append(key).append(">").append(value).append("</").append(key).append(">");
//            });
//
//            xml.append("</").append(k).append(">");
//        });
//        xml.append("</Attributes>");
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*Case 5
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//		    <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//		    <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//	    </Underlying>
//    </Attributes>*/
//    private void verfiyAttributesUnderlyingAll(List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        /*underlyingMap.put("type", "Underlying");
//        underlyingMap.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingMap.put("UnderlyingInstrumentIndexTermValue", new BigDecimal(getRndInt()));
//        underlyingMap.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        attributeMap.put("Underlying", underlyingMap);*/
//
//        AtomicInteger match = new AtomicInteger();
//        HashMap<String, Object> underlyingMap = (HashMap<String, Object>) attributeMap.get("Underlying");
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            underlyingMap.forEach((k, v) -> {
//                if (k.equals("UnderlyingInstrumentIndexTermValue")) {
//                    if (areEqual((BigDecimal) v,
//                            xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndexTermValue())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndex())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndexTermUnit())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() != underlyingMap.size()) {
//            fail("verfiyAttributesUnderlyingAll and mocked Map did not match " + match.get() + " - - - " + underlyingMap
//                    .size());
//        }
//    }
//
//    /*Case 5
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//		    <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//		    <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//	    </Underlying>
//    </Attributes>*/
//    @Tag("UnitTest")
//    @Test
//    public void testAddAttributesUnderlyingAll() {
//        mockAttributesUnderlyingAll();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add testAddAttributesAll failed ", e);
//        }
//        verfiyAttributesUnderlyingAll(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    /*Case 6.1
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentIndex>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndex>
//		    <UnderlyingInstrumentIndexProp>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndexProp>
//	    <Underlying/>
//    </Attributes>*/
//    private void mockAttributesUnderlyingUnderlyingInstrumentIndex() {
//        Map<String, Object> underlyingInstrumentIndex = new HashMap<>();
//        underlyingInstrumentIndex.put("type", "UnderlyingInstrumentIndex");
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermValue", new BigDecimal(getRndInt()));
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingIndexMaps.add(underlyingInstrumentIndex);
//        underlyingInstrumentIndex = new HashMap<>();
//        underlyingInstrumentIndex.put("type", "UnderlyingInstrumentIndex");
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermValue", new BigDecimal(getRndInt()));
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingIndexMaps.add(underlyingInstrumentIndex);
//        attributeMap.put("UnderlyingInstrumentIndex", underlyingIndexMaps);
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//        xml.append("<Underlying>");
//        attributeMap.forEach((k, v) -> {
//            ((List<Map<String, Object>>) v).forEach(value -> {
//                xml.append("<").append(k).append(">");
//                value.forEach((key, keyV) -> {
//                    xml.append("<").append(key).append(">").append(keyV).append("</").append(key).append(">");
//                });
//                xml.append("</").append(k).append(">");
//            });
//        });
//        xml.append("</Underlying>");
//        xml.append("</Attributes>");
//
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*Case 6.1
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentIndex>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndex>
//		    <UnderlyingInstrumentIndexProp>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndexProp>
//	    <Underlying/>
//    </Attributes>*/
//    private void verifyAttributesUnderlyingUnderlyingInstrumentIndex(
//            List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        /*Map<String, Object> underlyingInstrumentIndex = new HashMap<>();
//        underlyingInstrumentIndex.put("type", "UnderlyingInstrumentIndex");
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermValue", getRndDouble());
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingIndexMaps.add(underlyingInstrumentIndex);
//        underlyingInstrumentIndex = new HashMap<>();
//        underlyingInstrumentIndex.put("type", "UnderlyingInstrumentIndex");
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermValue", getRndDouble());
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        underlyingInstrumentIndex.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingIndexMaps.add(underlyingInstrumentIndex);
//        attributeMap.put("UnderlyingInstrumentIndex", underlyingIndexMaps);*/
//
//        List<Map<String, Object>> underlyingIndexMaps = (List<Map<String, Object>>) attributeMap
//                .get("UnderlyingInstrumentIndex");
//        AtomicInteger match = new AtomicInteger();
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            underlyingIndexMaps.forEach((value) -> {
//                value.forEach((k, v) -> {
//                    if (k.equals("UnderlyingInstrumentIndexTermValue")) {
//                        if (areEqual((BigDecimal) v,
//                                xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndexTermValue())) {
//                            match.getAndIncrement();
//                            return;
//                        }
//                    }
//                    if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndex())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                    if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentIndexTermUnit())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                    if (areEqual((String) v, xmartMdxInstrumentUnderlying.getType())) {
//                        match.getAndIncrement();
//                        return;
//                    }
//                });
//            });
//        });
//    }
//
//    /*Case 6.1
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentIndex>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndex>
//		    <UnderlyingInstrumentIndexProp>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndexProp>
//	    <Underlying/>
//    </Attributes>*/
//    /*@Tag("UnitTest")
//    @Test*/
//    public void testAndAttributesUnderlyingUnderlyingInstrumentIndex() {
//        mockAttributesUnderlyingUnderlyingInstrumentIndex();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add AttributesUnderlyingUnderlyingInstrumentIndex failed ", e);
//        }
//        verifyAttributesUnderlyingUnderlyingInstrumentIndex(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    /*Case 6.2
//    <Attributes>
//	    <Underlying>
//		    <UnderlyingInstrumentIndex>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndex>
//		    <UnderlyingInstrumentIndexProp>
//                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
//                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
//                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
//		    </UnderlyingInstrumentIndexProp>
//	    <Underlying/>
//    </Attributes>*/
//    private void mockAttributesUnderlyingUnderlyingInstrumentIndexProp() {
//        attributeMap.put("type", "UnderlyingInstrumentIndexProp");
//        Map<String, Object> underlyingInstrumentIndexProp = new HashMap<>();
//        underlyingInstrumentIndexProp.put("UnderlyingInstrumentIndexTermValue", new BigDecimal(getRndInt()));
//        underlyingInstrumentIndexProp.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        underlyingInstrumentIndexProp.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingPropMaps.add(underlyingInstrumentIndexProp);
//        underlyingInstrumentIndexProp = new HashMap<>();
//        underlyingInstrumentIndexProp.put("UnderlyingInstrumentIndexTermValue", new BigDecimal(getRndInt()));
//        underlyingInstrumentIndexProp.put("UnderlyingInstrumentIndexTermUnit", getRandomString());
//        underlyingInstrumentIndexProp.put("UnderlyingInstrumentIndex", getRandomString());
//        underlyingPropMaps.add(underlyingInstrumentIndexProp);
//        attributeMap.put("UnderlyingInstrumentIndexProp", underlyingPropMaps);
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//        xml.append("<Underlying>");
//        attributeMap.forEach((k, v) -> {
//            if ("UnderlyingInstrumentIndexProp".equals(k)) {
//                xml.append("<").append(k).append(">");
//                ((List<Map<String, Object>>) v).forEach(value -> {
//                    value.forEach((key, keyV) -> {
//                        xml.append("<").append(key).append(">").append(keyV).append("</").append(key).append(">");
//                    });
//                });
//                xml.append("</").append(k).append(">");
//            }
//        });
//        xml.append("</Underlying>");
//        xml.append("</Attributes>");
//
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*case 7
//    <Derived>
//	    <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
//    </Derived>*/
//    private void mockDerivedISOUnderlyingInstrumentIndex() {
//        derivedMap.put("type", "Derived");
//        derivedMap.put("ISOUnderlyingInstrumentIndex", getRandomString());
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Derived>");
//        derivedMap
//                .forEach((k, v) -> xml.append("<").append(k).append(">").append(v).append("</").append(k).append(">"));
//        xml.append("</Derived>");
//
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*case 7
//    <Derived>
//	    <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
//    </Derived>*/
//    private void verifyDerivedISOUnderlyingInstrumentIndex(
//            List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        AtomicInteger match = new AtomicInteger();
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            derivedMap.forEach((k, v) -> {
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getiSOUnderlyingInstrumentIndex())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() != derivedMap.size()) {
//            fail("verifyDerivedISOUnderlyingInstrumentIndex and mocked Map did not match " + match.get() + " - - - "
//                    + derivedMap.size());
//        }
//    }
//
//    /*case 7
//    <Derived>
//	    <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
//    </Derived>*/
//    @Tag("UnitTest")
//    @Test
//    public void testAddDerivedISOUnderlyingInstrumentIndex() {
//        mockDerivedISOUnderlyingInstrumentIndex();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add DerivedISOUnderlyingInstrumentIndex failed ", e);
//        }
//        verifyDerivedISOUnderlyingInstrumentIndex(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    /*Case 8
//    <Attributes>
//	    <Underlying>
//		    <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
//		    <ISOUnderlyingInstrumentIndex>CDZ.NA.HK</ISOUnderlyingInstrumentIndex>
//	    </Underlying>
//    </Attributes>*/
//    private void mockAttributesUnderlyingISOUnderlyingInstrumentIndex() {
//        attributeMap.put("type", "Underlying");
//        iSOUnderlyingInstrumentIndex.add(getRandomString());
//        iSOUnderlyingInstrumentIndex.add(getRandomString());
//        iSOUnderlyingInstrumentIndex.add(getRandomString());
//        iSOUnderlyingInstrumentIndex.add(getRandomString());
//        iSOUnderlyingInstrumentIndex.add(getRandomString());
//        iSOUnderlyingInstrumentIndex.add(getRandomString());
//        attributeMap.put("Underlying", iSOUnderlyingInstrumentIndex);
//
//        StringBuilder xml = new StringBuilder();
//        xml.append("<Instrument>");
//
//        xml.append("<Attributes>");
//
//        attributeMap.forEach((k, v) -> {
//            if ("Underlying".equals(k)) {
//                xml.append("<").append(k).append(">");
//
//                List<String> iSOUnderlyingInstrumentIndex = (List) v;
//
//                iSOUnderlyingInstrumentIndex.forEach(value -> {
//                    xml.append("<").append("ISOUnderlyingInstrumentIndex").append(">").append(value).append("</")
//                       .append("ISOUnderlyingInstrumentIndex").append(">");
//                });
//
//                xml.append("</").append(k).append(">");
//            }
//        });
//        xml.append("</Attributes>");
//        xml.append("</Instrument>");
//
//        mock(xml.toString());
//    }
//
//    /*Case 8
//    <Attributes>
//	    <Underlying>
//		    <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
//		    <ISOUnderlyingInstrumentIndex>CDZ.NA.HK</ISOUnderlyingInstrumentIndex>
//	    </Underlying>
//    </Attributes>*/
//    private void verifyAttributesUnderlyingISOUnderlyingInstrumentIndex(
//            List<XmartMdxInstrumentUnderlying> xmartMdxInstrumentUnderlyings) {
//        AtomicInteger match = new AtomicInteger();
//        List<String> iSOUnderlyingInstrumentIndex = (List) attributeMap.get("Underlying");
//        xmartMdxInstrumentUnderlyings.forEach(xmartMdxInstrumentUnderlying -> {
//            iSOUnderlyingInstrumentIndex.forEach(v -> {
//                if (areEqual((String) v, xmartMdxInstrumentUnderlying.getUnderlyingInstrumentISIN())) {
//                    match.getAndIncrement();
//                    return;
//                }
//                if (areEqual((String) attributeMap.get("type"), xmartMdxInstrumentUnderlying.getType())) {
//                    match.getAndIncrement();
//                    return;
//                }
//            });
//        });
//        if (match.get() / iSOUnderlyingInstrumentIndex.size() != iSOUnderlyingInstrumentIndex.size()) {
//            fail("verifyAttributesUnderlyingISOUnderlyingInstrumentIndex and mocked Map did not match "
//                    + match.get() / iSOUnderlyingInstrumentIndex.size() + " - - - " + iSOUnderlyingInstrumentIndex
//                    .size());
//        }
//    }
//
//    /*Case 8
//    <Attributes>
//	    <Underlying>
//		    <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
//		    <ISOUnderlyingInstrumentIndex>CDZ.NA.HK</ISOUnderlyingInstrumentIndex>
//	    </Underlying>
//    </Attributes>*/
//    @Tag("UnitTest")
//    @Test
//    public void testAddAttributesUnderlyingISOUnderlyingInstrumentIndex() {
//        mockAttributesUnderlyingISOUnderlyingInstrumentIndex();
//        try {
//            create();
//        } catch (XmartException e) {
//            e.printStackTrace();
//            fail("Add AttributesUnderlyingISOUnderlyingInstrumentIndex failed ", e);
//        }
//        verifyAttributesUnderlyingISOUnderlyingInstrumentIndex(xmartMdxInstrumentUnderlyings.getEntity());
//        //        xmlCheck(xmartMdxInstrumentUnderlyings);
//    }
//
//    private void create() throws XmartException {
//        xmartMdxInstrumentUnderlyings = new XmartMdxInstrumentUnderlyings(documentKey, mdxDocumentEvent);
//    }
//}
