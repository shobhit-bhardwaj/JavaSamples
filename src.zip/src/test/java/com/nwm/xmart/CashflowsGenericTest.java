package com.nwm.xmart;

import com.nwm.xmart.entities.XmartEntitiesBaseTest;
import com.nwm.xmart.entities.cashflows.XmartCashflowSet;
import com.nwm.xmart.entities.cashflows.XmartCashflowsEvent;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.entities.common.XmartMappedAttribute;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.entities.mock.TestCashFlow;
import com.nwm.xmart.entities.mock.TestTransactionId;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.rbs.odc.access.domain.Cashflow;
import com.rbs.odc.access.domain.Cashflows;
import com.rbs.odc.access.domain.TransactionId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import static com.nwm.xmart.util.AttributeMappingRulesUtil.mapBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.powermock.api.mockito.PowerMockito.when;

public class CashflowsGenericTest extends XmartEntitiesBaseTest {

    private static Long odcVersion = Long.valueOf(getRndInt());
    @Spy
    private static TransactionId transactionId = new TestTransactionId();
    @Mock
    private XmartCashflowsEvent xmartCashflowsEvent;
    @Mock
    private Cashflows cashflows;
    @Mock
    private Collection<Cashflow> cashflowCollection;
    @Mock
    private Iterator<Cashflow> cashflowIterator;
    @Spy
    private Cashflow cashflow1 = new TestCashFlow(), cashflow2 = new TestCashFlow();
    @Mock
    private MappingNode mappingHierarchy;

    private static void verifyMappings(Cashflow cashflow, XmartMappedEntity xmartMappedEntity) throws XmartException {
        assertEquals("XmartCashFlows", xmartMappedEntity.getEntityCollectionName());
        assertEquals("XmartCashFlow", xmartMappedEntity.getEntityName());
        assertEquals(odcVersion, xmartMappedEntity.getAttribute("odcVersion").getAttributeValue());
        assertEquals(transactionId.getSourceSystemTransactionId(),
                xmartMappedEntity.getAttribute("sourceSystemTransactionId").getAttributeValue());
        assertEquals(getStr(transactionId.getSourceSystemId()),
                xmartMappedEntity.getAttribute("sourceSystemId").getAttributeValue());

        assertEquals(cashflow.getAmount().getValue(),
                xmartMappedEntity.getAttribute("cashflowAmountValue").getAttributeValue());
        assertEquals(cashflow.getAmount().getCurrencyId().getCurrencyCode(),
                xmartMappedEntity.getAttribute("cashflowAmountCurrencyCode").getAttributeValue());
        //        assertEquals(mapBusinessDate(cashflow.getEffectiveDate()),mapBusinessDate(xmartMappedEntity.getAttribute("effectiveDate").getAttributeValue()));
        assertEquals(mapBusinessDate(cashflow.getEffectiveDt().getAdjustedDate()),
                xmartMappedEntity.getAttribute("effectiveDtAdjustedDate").getAttributeValue());

        assertEquals(mapBusinessDate(cashflow.getEffectiveDt().getUnadjustedDate()),
                xmartMappedEntity.getAttribute("effectiveDtUnadjustedDate").getAttributeValue());
        assertEquals(cashflow.getEventDateTime(), xmartMappedEntity.getAttribute("eventDateTime").getAttributeValue());
        assertEquals(cashflow.getIsEstimated(), xmartMappedEntity.getAttribute("isEstimated").getAttributeValue());
        assertEquals(cashflow.getLegIdentifier(), xmartMappedEntity.getAttribute("legIdentifier").getAttributeValue());
        assertEquals(cashflow.getPayer().getSourceBookId().getSourceSystemBookId(),
                xmartMappedEntity.getAttribute("payerSourceSystemBookId").getAttributeValue());

        assertEquals(getStr(cashflow.getPayer().getSourceBookId().getBookSourceSystemId()),
                xmartMappedEntity.getAttribute("payerBookSourceSystemId").getAttributeValue());

        assertEquals(getStr(cashflow.getPayer().getTradingCounterpartyId().getPartyClassification()),
                xmartMappedEntity.getAttribute("payerPartyClassification").getAttributeValue());

        assertEquals(cashflow.getPayer().getTradingCounterpartyId().getPartyReference(),
                xmartMappedEntity.getAttribute("payerPartyReference").getAttributeValue());

        assertEquals(getStr(cashflow.getPaymentType()),
                xmartMappedEntity.getAttribute("paymentType").getAttributeValue());

        assertEquals(cashflow.getReceiver().getSourceBookId().getSourceSystemBookId(),
                xmartMappedEntity.getAttribute("receiverSourceSystemBookId").getAttributeValue());

        assertEquals(getStr(cashflow.getReceiver().getSourceBookId().getBookSourceSystemId()),
                xmartMappedEntity.getAttribute("receiverBookSourceSystemId").getAttributeValue());

        assertEquals(getStr(cashflow.getReceiver().getTradingCounterpartyId().getPartyClassification()),
                xmartMappedEntity.getAttribute("receiverPartyClassification").getAttributeValue());

        assertEquals(cashflow.getReceiver().getTradingCounterpartyId().getPartyReference(),
                xmartMappedEntity.getAttribute("receiverPartyReference").getAttributeValue());

        assertEquals(cashflow.getSourceSystemEventId(),
                xmartMappedEntity.getAttribute("sourceSystemEventId").getAttributeValue());

        assertEquals(cashflow.getSettlementMessageRequired(),
                xmartMappedEntity.getAttribute("settlementMessageRequired").getAttributeValue());

        assertEquals(cashflow.getBrokerage().getRcAmount().getValue(),
                xmartMappedEntity.getAttribute("rcAmountValue").getAttributeValue());

        assertEquals(cashflow.getBrokerage().getRcAmount().getCurrencyId().getCurrencyCode(),
                xmartMappedEntity.getAttribute("rcAmountCurrencyCode").getAttributeValue());
    }

    /**
     * Compares the attributes to occur in the supplied xml, <h3>DOES NOT fail the test, just prints error logs</h3>
     *
     * @param xml
     * @param xmartMappedEntities
     */
    private static void validateXmlLax(String xml, Collection<XmartMappedEntity> xmartMappedEntities) {
        logger.error("Workig for XML [" + xml + "]");
        for (XmartMappedEntity xmartMappedEntity : xmartMappedEntities) {
            for (XmartMappedAttribute xmartMappedAttribute : xmartMappedEntity.getAttributes()) {
                if (xmartMappedAttribute.isOutput()) {
                    String expectedTag = xmartMappedAttribute.getAttributeName() + "=\"" + xmartMappedAttribute
                            .getAttributeValue() + "\"";
                    if (!xml.contains(expectedTag)) {
                        logger.error("Could not find in the XML printed above " + expectedTag);
                    }
                }
            }
        }
    }

    void mock() {
        when(xmartCashflowsEvent.getCashflows()).thenReturn(cashflows);
        when(xmartCashflowsEvent.getOdcVersion()).thenReturn(odcVersion);
        when(cashflows.getTransactionId()).thenReturn(transactionId);
        when(cashflows.getCashflows()).thenReturn(cashflowCollection);
        when(cashflowCollection.iterator()).thenReturn(cashflowIterator);
        when(cashflowIterator.hasNext()).thenReturn(true).thenReturn(false);
        when(cashflowIterator.next()).thenReturn(cashflow1);
    }

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        //prepare the mapping hierachrt
        try {
            mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/cashflows.csv");
        } catch (XmartException e) {
            fail("Failed to read mapping config ", e);
        }
    }

    @Tag("UnitTest")
    @Test
    void all() throws XmartException {
        mock();
        XmartGenericSet<XmartCashflowsEvent> xmartSet = new XmartCashflowSet();
        xmartSet.addStreamEvent(xmartCashflowsEvent, 123, mappingHierarchy);
        List<XmartMappedEntity> xmartMappedEntities = xmartSet.getXmartMappedEntities();
        //we supplied one cashflow so should have one entiry here
        assertEquals(1, xmartMappedEntities.size(), "Mapped entities size did not match");
        //Lets check the variables for the entity now
        verifyMappings(cashflow1, xmartMappedEntities.get(0));
        //Get the xml set from the mapper and verify the xml ??

        XmartGenericXmlSet xmartGenericXmlSet = new XmartGenericXmlSet(true);
        xmartGenericXmlSet.add(xmartSet);
        validateXmlLax(xmartGenericXmlSet.getEntityXml("XmartCashFlows"),
                xmartSet.getRequiredEntities("XmartCashFlows"));
    }
}
